#!/bin/bash
set -e

if [ -z "$JWT_SECRET" ] && [ -z "$CSRF_SECRET" ]; then
    echo "═══════════════════════════════════════════════════════════"
    echo "  ℹ️  Security secrets not provided via environment"
    echo "      SecretService will auto-generate and persist them on first start."
    echo "      To customize, create a .env file in the deploy directory."
    echo "      Template: deploy/.env.example"
    echo "═══════════════════════════════════════════════════════════"
fi

if [ -n "$INITIAL_ADMIN_PASSWORD" ] && [ "$INITIAL_ADMIN_PASSWORD" = "admin123" ]; then
    echo "  ⚠️  Using default admin password 'admin123' — change it immediately after first login."
fi

if [ "$(id -u)" = "0" ]; then
    chown -R appuser:appuser /app/runtime /app/config 2>/dev/null || true

    exec runuser -u appuser -- "$@"
fi

exec "$@"
