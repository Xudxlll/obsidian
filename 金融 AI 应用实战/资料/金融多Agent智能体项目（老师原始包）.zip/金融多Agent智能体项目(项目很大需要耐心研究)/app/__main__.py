import uvicorn
import sys
import os
from pathlib import Path

if sys.platform == 'win32':
    try:
        os.environ['PYTHONIOENCODING'] = 'utf-8'
        os.environ['PYTHONUTF8'] = '1'

        import io
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

        try:
            import ctypes
            ctypes.windll.kernel32.SetConsoleCP(65001)
            ctypes.windll.kernel32.SetConsoleOutputCP(65001)
        except Exception:
            pass

    except Exception as e:
        print(f"Warning: Failed to set UTF-8 encoding: {e}", file=sys.stderr)

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

def check_env_file():
    import logging
    logger = logging.getLogger("app.startup")
    
    logger.info("🔍 检查环境配置文件...")

    current_dir = Path.cwd()
    logger.info(f"📂 当前工作目录: {current_dir}")

    logger.info(f"📂 项目根目录: {project_root}")
    
    env_locations = [
        project_root / ".env",
        current_dir / ".env",
        Path(__file__).parent / ".env"
    ]

    env_found = False

    for env_path in env_locations:
        if env_path.exists():
            if not env_found:
                logger.info(f"✅ 找到.env文件: {env_path}")
                logger.info(f"📏 文件大小: {env_path.stat().st_size} bytes")
                env_found = True

                try:
                    from app.core.config import redact_env_line
                    with open(env_path, 'r', encoding='utf-8') as f:
                        lines = f.readlines()
                    logger.info(f"📄 .env文件内容预览 (共{len(lines)}行):")

                    for i, line in enumerate(lines[:10]):
                        line_stripped = line.strip()
                        if line_stripped and not line_stripped.startswith('#'):
                            logger.debug(f"  {redact_env_line(line_stripped)}")
                    if len(lines) > 10:
                        logger.debug(f"  ... (还有{len(lines) - 10}行)")
                except Exception as e:
                    logger.warning(f"⚠️ 读取.env文件时出错: {e}")
            else:
                logger.debug(f"ℹ️  其他位置也有.env文件: {env_path}")

    if not env_found:
        logger.warning("⚠️ 未找到.env文件，将使用默认配置")
        logger.info(f"💡 提示: 请在项目根目录 ({project_root}) 创建 .env 文件")
    
    logger.info("-" * 50)

try:
    from app.core.config import settings
    from app.core.dev_config import DEV_CONFIG
except Exception as e:
    import logging as _logging
    _logger = _logging.getLogger("app.startup")
    _logger.error("导入配置模块失败: %s", e, exc_info=True)
    sys.exit(1)

def main():
    import logging
    logger = logging.getLogger("app.startup")
    
    logger.info("🚀 Starting Zhenshabi Backend...")
    logger.info(f"📍 Host: {settings.HOST}")
    logger.info(f"🔌 Port: {settings.PORT}")
    logger.info(f"🐛 Debug Mode: {settings.DEBUG}")
    logger.info(f"📚 API Docs: http://{settings.HOST}:{settings.PORT}/docs" if settings.DEBUG else "📚 API Docs: Disabled in production")
    
    from app.core.config import is_using_default_secret
    jwt_using_default = is_using_default_secret("JWT_SECRET")

    logger.info("🔧 关键配置信息:")
    logger.info(f"  📊 MongoDB: {settings.MONGODB_HOST}:{settings.MONGODB_PORT}/{settings.MONGODB_DATABASE}")
    logger.info(f"  🔴 Redis: {settings.REDIS_HOST}:{settings.REDIS_PORT}/{settings.REDIS_DB}")
    logger.info(f"  🔐 JWT Secret: {'⚠️ 使用默认值' if jwt_using_default else '已配置'}")
    logger.info(f"  📝 日志级别: {settings.LOG_LEVEL}")

    logger.info("🌍 环境变量加载状态:")
    env_vars_to_check = [
        ('MONGODB_HOST', settings.MONGODB_HOST, 'localhost'),
        ('MONGODB_PORT', str(settings.MONGODB_PORT), '27017'),
        ('MONGODB_DATABASE', settings.MONGODB_DATABASE, 'zhenshabi'),
        ('REDIS_HOST', settings.REDIS_HOST, 'localhost'),
        ('REDIS_PORT', str(settings.REDIS_PORT), '6379'),
        ('JWT_SECRET', '⚠️ 默认值' if jwt_using_default else '***', 'change-me-in-production')
    ]
    
    for env_name, current_value, default_value in env_vars_to_check:
        status = "✅ 已设置" if current_value != default_value else "⚠️ 默认值"
        logger.info(f"  {env_name}: {current_value} ({status})")
    
    logger.info("-" * 50)

    uvicorn_config = DEV_CONFIG.get_uvicorn_config(settings.DEBUG)

    logger.info("🔧 正在设置日志配置...")
    try:
        from app.core.logging_config import setup_logging as app_setup_logging
        app_setup_logging(settings.LOG_LEVEL)
    except Exception as e:
        logger.debug(f"应用日志配置失败，回退到默认配置: {e}")
        DEV_CONFIG.setup_logging(settings.DEBUG)
    logger.info("✅ 日志配置设置完成")

    logger.info("📋 Configuration Loading Phase:")
    check_env_file()

    try:
        uvicorn.run(
            "app.main:app",
            host=settings.HOST,
            port=settings.PORT,
            **uvicorn_config
        )
    except KeyboardInterrupt:
        logger.info("🛑 Server stopped by user")
    except Exception as e:
        logger.error("服务启动失败: %s", e, exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main()
