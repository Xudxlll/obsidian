from datetime import datetime
from typing import Optional, Dict, Any, List, Literal
from pydantic import BaseModel, Field, ConfigDict
from bson import ObjectId

def to_str_id(v: Any) -> str:
    try:
        if isinstance(v, ObjectId):
            return str(v)
        return str(v)
    except Exception:
        return ""

MarketType = Literal["CN", "HK", "US"]
ExchangeType = Literal["SZSE", "SSE", "SEHK", "NYSE", "NASDAQ"]
StockStatus = Literal["L", "D", "P"]
CurrencyType = Literal["CNY", "HKD", "USD"]

class MarketInfo(BaseModel):
    market: MarketType = Field(..., description="市场标识")
    exchange: ExchangeType = Field(..., description="交易所代码")
    exchange_name: str = Field(..., description="交易所名称")
    currency: CurrencyType = Field(..., description="交易货币")
    timezone: str = Field(..., description="时区")
    trading_hours: Optional[Dict[str, Any]] = Field(None, description="交易时间")

class TechnicalIndicators(BaseModel):
    trend: Optional[Dict[str, float]] = Field(None, description="趋势指标")
    oscillator: Optional[Dict[str, float]] = Field(None, description="震荡指标")
    channel: Optional[Dict[str, float]] = Field(None, description="通道指标")
    volume: Optional[Dict[str, float]] = Field(None, description="成交量指标")
    volatility: Optional[Dict[str, float]] = Field(None, description="波动率指标")
    custom: Optional[Dict[str, Any]] = Field(None, description="自定义指标")

class StockBasicInfoExtended(BaseModel):
    symbol: str = Field(..., description="股票代码（A股6位数字/港股5位数字/美股字母）", pattern=r"^[A-Z0-9\.]+$")
    full_symbol: str = Field(..., description="完整标准化代码(如 000001.SZ)")
    name: str = Field(..., description="股票名称")

    code: Optional[str] = Field(None, description="股票代码(已废弃,使用symbol)")

    area: Optional[str] = Field(None, description="所在地区")
    industry: Optional[str] = Field(None, description="行业")
    market: Optional[str] = Field(None, description="交易所名称")
    list_date: Optional[str] = Field(None, description="上市日期")
    sse: Optional[str] = Field(None, description="板块")
    sec: Optional[str] = Field(None, description="所属板块")
    source: Optional[str] = Field(None, description="数据来源")
    updated_at: Optional[datetime] = Field(None, description="更新时间")

    total_mv: Optional[float] = Field(None, description="总市值(亿元)")
    circ_mv: Optional[float] = Field(None, description="流通市值(亿元)")

    pe: Optional[float] = Field(None, description="市盈率")
    pb: Optional[float] = Field(None, description="市净率")
    pe_ttm: Optional[float] = Field(None, description="滚动市盈率")
    pb_mrq: Optional[float] = Field(None, description="最新市净率")
    roe: Optional[float] = Field(None, description="净资产收益率")

    turnover_rate: Optional[float] = Field(None, description="换手率%")
    volume_ratio: Optional[float] = Field(None, description="量比")

    name_en: Optional[str] = Field(None, description="英文名称")
    
    market_info: Optional[MarketInfo] = Field(None, description="市场信息")
    
    board: Optional[str] = Field(None, description="板块标准化")
    industry_code: Optional[str] = Field(None, description="行业代码")
    sector: Optional[str] = Field(None, description="所属板块标准化（GICS行业）")
    delist_date: Optional[str] = Field(None, description="退市日期")
    status: Optional[StockStatus] = Field(None, description="上市状态")
    is_hs: Optional[bool] = Field(None, description="是否沪深港通标的")

    total_shares: Optional[float] = Field(None, description="总股本")
    float_shares: Optional[float] = Field(None, description="流通股本")

    lot_size: Optional[int] = Field(None, description="每手股数（港股特有）")

    currency: Optional[CurrencyType] = Field(None, description="交易货币")
    
    data_version: Optional[int] = Field(None, description="数据版本")
    
    model_config = ConfigDict(
        extra="allow",
        json_schema_extra={
            "example": {
                "symbol": "000001",
                "full_symbol": "000001.SZ",
                "name": "平安银行",

                "area": "深圳",
                "industry": "银行",
                "market": "深圳证券交易所",
                "sse": "主板",
                "total_mv": 2500.0,
                "pe": 5.2,
                "pb": 0.8,

                "market_info": {
                    "market": "CN",
                    "exchange": "SZSE",
                    "exchange_name": "深圳证券交易所",
                    "currency": "CNY",
                    "timezone": "Asia/Shanghai"
                },
                "status": "L",
                "data_version": 1
            }
        }
    )

class MarketQuotesExtended(BaseModel):
    symbol: str = Field(..., description="股票代码（A股6位数字/港股5位数字/美股字母）", pattern=r"^[A-Z0-9\.]+$")
    full_symbol: Optional[str] = Field(None, description="完整标准化代码")
    market: Optional[MarketType] = Field(None, description="市场标识")

    code: Optional[str] = Field(None, description="股票代码(已废弃,使用symbol)")

    close: Optional[float] = Field(None, description="收盘价")
    pct_chg: Optional[float] = Field(None, description="涨跌幅%")
    amount: Optional[float] = Field(None, description="成交额")
    open: Optional[float] = Field(None, description="开盘价")
    high: Optional[float] = Field(None, description="最高价")
    low: Optional[float] = Field(None, description="最低价")
    pre_close: Optional[float] = Field(None, description="前收盘价")
    trade_date: Optional[str] = Field(None, description="交易日期")
    updated_at: Optional[datetime] = Field(None, description="更新时间")
    
    current_price: Optional[float] = Field(None, description="当前价格(与close相同)")
    change: Optional[float] = Field(None, description="涨跌额")
    volume: Optional[float] = Field(None, description="成交量")
    turnover_rate: Optional[float] = Field(None, description="换手率")
    volume_ratio: Optional[float] = Field(None, description="量比")
    
    bid_prices: Optional[List[float]] = Field(None, description="买1-5价")
    bid_volumes: Optional[List[float]] = Field(None, description="买1-5量")
    ask_prices: Optional[List[float]] = Field(None, description="卖1-5价")
    ask_volumes: Optional[List[float]] = Field(None, description="卖1-5量")
    
    timestamp: Optional[datetime] = Field(None, description="行情时间戳")
    
    data_source: Optional[str] = Field(None, description="数据来源")
    data_version: Optional[int] = Field(None, description="数据版本")
    
    model_config = ConfigDict(
        extra="allow",
        json_schema_extra={
            "example": {
                "symbol": "000001",
                "full_symbol": "000001.SZ",
                "market": "CN",

                "close": 12.65,
                "pct_chg": 1.61,
                "amount": 1580000000,
                "open": 12.50,
                "high": 12.80,
                "low": 12.30,
                "trade_date": "2024-01-15",

                "current_price": 12.65,
                "change": 0.20,
                "volume": 125000000
            }
        }
    )

class StockBasicInfoResponse(BaseModel):
    success: bool = True
    data: Optional[StockBasicInfoExtended] = None
    message: str = ""

class MarketQuotesResponse(BaseModel):
    success: bool = True
    data: Optional[MarketQuotesExtended] = None
    message: str = ""

class StockListResponse(BaseModel):
    success: bool = True
    data: Optional[List[StockBasicInfoExtended]] = None
    total: int = 0
    page: int = 1
    page_size: int = 20
    message: str = ""
