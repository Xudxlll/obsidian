from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, ConfigDict, field_serializer, model_validator
from enum import Enum
from bson import ObjectId
from .user import PyObjectId
from app.utils.timezone import now_tz

class AnalysisStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class BatchStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    PARTIAL_SUCCESS = "partial_success"
    FAILED = "failed"
    CANCELLED = "cancelled"

class AnalysisParameters(BaseModel):
    market_type: str = "A股"
    analysis_date: Optional[datetime] = None
    selected_analysts: List[str] = Field(default_factory=list)
    custom_prompt: Optional[str] = None
    include_sentiment: bool = True
    include_risk: bool = True
    language: str = "zh-CN"
    analyst_model: Optional[str] = "qwen-turbo"
    debate_model: Optional[str] = "qwen-max"

    phase2_enabled: bool = False
    phase2_debate_rounds: int = 2
    phase3_enabled: bool = False
    phase3_debate_rounds: int = 2
    phase4_enabled: bool = True
    phase4_debate_rounds: int = 1

    mcp_enabled: bool = Field(default=False, description="是否启用 MCP 工具")
    mcp_tools: List[str] = Field(default_factory=list, description="兼容旧字段：MCP 工具ID列表")
    mcp_tool_ids: List[str] = Field(default_factory=list, description="MCP 工具ID列表（推荐字段）")

    prefetch_data: bool = Field(
        default=True, description="分析前是否先从数据源拉取最新数据到标准库（关闭则直接使用库内已有数据）"
    )

class AnalysisResult(BaseModel):
    analysis_id: Optional[str] = None
    summary: Optional[str] = None
    recommendation: Optional[str] = None
    confidence_score: Optional[float] = None
    risk_level: Optional[str] = None
    key_points: List[str] = Field(default_factory=list)
    detailed_analysis: Optional[Dict[str, Any]] = None
    charts: List[str] = Field(default_factory=list)
    tokens_used: int = 0
    execution_time: float = 0.0
    error_message: Optional[str] = None
    model_info: Optional[str] = None

class AnalysisTask(BaseModel):
    id: Optional[PyObjectId] = Field(default_factory=ObjectId, alias="_id")
    task_id: str = Field(..., description="任务唯一标识")
    batch_id: Optional[str] = None
    user_id: PyObjectId
    symbol: str = Field(..., description="6位股票代码")
    stock_code: Optional[str] = Field(None, description="股票代码(已废弃,使用symbol)")
    stock_name: Optional[str] = None
    status: AnalysisStatus = AnalysisStatus.PENDING

    progress: int = Field(default=0, ge=0, le=100, description="任务进度 0-100")

    created_at: datetime = Field(default_factory=now_tz)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    
    worker_id: Optional[str] = None
    parameters: AnalysisParameters = Field(default_factory=AnalysisParameters)
    result: Optional[AnalysisResult] = None
    
    retry_count: int = 0
    max_retries: int = 3
    last_error: Optional[str] = None
    
    model_config = ConfigDict(
        populate_by_name=True,
        arbitrary_types_allowed=True
    )

class AnalysisBatch(BaseModel):
    id: Optional[PyObjectId] = Field(default_factory=ObjectId, alias="_id")
    batch_id: str = Field(..., description="批次唯一标识")
    user_id: PyObjectId
    title: str = Field(..., description="批次标题")
    description: Optional[str] = None
    status: BatchStatus = BatchStatus.PENDING
    
    total_tasks: int = 0
    completed_tasks: int = 0
    failed_tasks: int = 0
    cancelled_tasks: int = 0
    progress: int = Field(default=0, ge=0, le=100, description="整体进度 0-100")
    
    created_at: datetime = Field(default_factory=now_tz)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    
    parameters: AnalysisParameters = Field(default_factory=AnalysisParameters)
    
    results_summary: Optional[Dict[str, Any]] = None
    
    model_config = ConfigDict(
        populate_by_name=True,
        arbitrary_types_allowed=True
    )

class StockInfo(BaseModel):
    symbol: str = Field(..., description="6位股票代码")
    code: Optional[str] = Field(None, description="股票代码(已废弃,使用symbol)")
    name: str = Field(..., description="股票名称")
    market: str = Field(..., description="市场类型")
    industry: Optional[str] = None
    sector: Optional[str] = None
    market_cap: Optional[float] = None
    price: Optional[float] = None
    change_percent: Optional[float] = None

class SingleAnalysisRequest(BaseModel):
    symbol: Optional[str] = Field(None, description="6位股票代码")
    stock_code: Optional[str] = Field(None, description="股票代码(已废弃,使用symbol)")
    parameters: Optional[AnalysisParameters] = None

    @model_validator(mode="after")
    def _validate_symbol_present(self) -> "SingleAnalysisRequest":

        if not (self.symbol and self.symbol.strip()) and not (
            self.stock_code and self.stock_code.strip()
        ):
            raise ValueError("symbol 和 stock_code 不能同时为空，至少提供一个")
        return self

    def get_symbol(self) -> str:
        return self.symbol or self.stock_code or ""

class BatchAnalysisRequest(BaseModel):
    title: str = Field(..., description="批次标题")
    description: Optional[str] = None
    symbols: Optional[List[str]] = Field(None, min_length=1, max_length=10, description="股票代码列表（最多10个）")
    stock_codes: Optional[List[str]] = Field(None, min_length=1, max_length=10, description="股票代码列表(已废弃,使用symbols，最多10个)")
    parameters: Optional[AnalysisParameters] = None

    def get_symbols(self) -> List[str]:
        return self.symbols or self.stock_codes or []

class AnalysisTaskResponse(BaseModel):
    task_id: str
    batch_id: Optional[str]
    symbol: str
    stock_code: Optional[str] = None
    stock_name: Optional[str]
    status: AnalysisStatus
    progress: int
    created_at: datetime
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    result: Optional[AnalysisResult]

    @field_serializer('created_at', 'started_at', 'completed_at')
    def serialize_datetime(self, dt: Optional[datetime], _info) -> Optional[str]:
        if dt:
            return dt.isoformat()
        return None

class AnalysisBatchResponse(BaseModel):
    batch_id: str
    title: str
    description: Optional[str]
    status: BatchStatus
    total_tasks: int
    completed_tasks: int
    failed_tasks: int
    progress: int
    created_at: datetime
    completed_at: Optional[datetime]
    
    @field_serializer('created_at', 'completed_at')
    def serialize_datetime(self, dt: Optional[datetime], _info) -> Optional[str]:
        if dt:
            return dt.isoformat()
        return None

class AnalysisHistoryQuery(BaseModel):
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=10, ge=1, le=100)
    symbol: Optional[str] = None
    status: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
