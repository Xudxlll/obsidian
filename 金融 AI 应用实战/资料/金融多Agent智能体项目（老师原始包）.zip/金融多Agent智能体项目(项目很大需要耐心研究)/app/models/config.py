from datetime import datetime
from app.utils.timezone import now_tz
from typing import Optional, Dict, Any, List
from pydantic import BaseModel, Field, ConfigDict, field_serializer, field_validator
from enum import Enum
from bson import ObjectId
from app.constants.llm_defaults import (
    DEFAULT_MAX_TOKENS,
    DEFAULT_TEMPERATURE,
    DEFAULT_TIMEOUT,
    DEFAULT_RETRY_TIMES,
    THINKING_EFFORT_LEVELS,
)
from .user import PyObjectId

def validate_thinking_effort(v: Optional[str]) -> Optional[str]:
    if v is None or v == "":
        return None
    if v not in THINKING_EFFORT_LEVELS:
        raise ValueError(f"thinking_effort 必须是 {list(THINKING_EFFORT_LEVELS)} 之一或留空")
    return v

class ModelProvider(str, Enum):
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    ZHIPU = "zhipu"
    QWEN = "qwen"
    BAIDU = "baidu"
    TENCENT = "tencent"
    GEMINI = "gemini"
    GLM = "glm"
    CLAUDE = "claude"
    DEEPSEEK = "deepseek"
    DASHSCOPE = "dashscope"
    GOOGLE = "google"
    SILICONFLOW = "siliconflow"
    OPENROUTER = "openrouter"
    CUSTOM_OPENAI = "custom_openai"
    QIANFAN = "qianfan"
    LOCAL = "local"

    AI302 = "302ai"
    ONEAPI = "oneapi"
    NEWAPI = "newapi"
    FASTGPT = "fastgpt"
    CUSTOM_AGGREGATOR = "custom_aggregator"

class LLMProvider(BaseModel):
    id: Optional[PyObjectId] = Field(default_factory=ObjectId, alias="_id")
    name: str = Field(..., description="厂家唯一标识")
    display_name: str = Field(..., description="显示名称")
    description: Optional[str] = Field(None, description="厂家描述")
    website: Optional[str] = Field(None, description="官网地址")
    api_doc_url: Optional[str] = Field(None, description="API文档地址")
    logo_url: Optional[str] = Field(None, description="Logo地址")
    is_active: bool = Field(True, description="是否启用")
    supported_features: List[str] = Field(default_factory=list, description="支持的功能")
    default_base_url: Optional[str] = Field(None, description="默认API地址")
    api_key: Optional[str] = Field(None, description="API密钥")
    api_secret: Optional[str] = Field(None, description="API密钥（某些厂家需要）")
    extra_config: Dict[str, Any] = Field(default_factory=dict, description="额外配置参数")
    protocol: Optional[str] = Field(None, description="请求协议(anthropic/openai)，缺省按厂家名推断")

    is_aggregator: bool = Field(default=False, description="是否为聚合渠道（如302.AI、OpenRouter）")
    aggregator_type: Optional[str] = Field(None, description="聚合渠道类型（openai_compatible/custom）")
    model_name_format: Optional[str] = Field(None, description="模型名称格式（如：{provider}/{model}）")

    created_at: Optional[datetime] = Field(default_factory=now_tz)
    updated_at: Optional[datetime] = Field(default_factory=now_tz)

    model_config = ConfigDict(populate_by_name=True, arbitrary_types_allowed=True)

class ModelInfo(BaseModel):
    name: str = Field(..., description="模型标识名称")
    display_name: str = Field(..., description="模型显示名称")
    description: Optional[str] = Field(None, description="模型描述")
    context_length: Optional[int] = Field(None, description="上下文长度")
    max_tokens: Optional[int] = Field(None, description="最大输出token数")
    input_price_per_1k: Optional[float] = Field(None, description="输入价格(每1K tokens)")
    output_price_per_1k: Optional[float] = Field(None, description="输出价格(每1K tokens)")
    currency: str = Field(default="CNY", description="货币单位")
    is_deprecated: bool = Field(default=False, description="是否已废弃")
    release_date: Optional[str] = Field(None, description="发布日期")
    capabilities: List[str] = Field(default_factory=list, description="能力标签(如: vision, function_calling)")

    original_provider: Optional[str] = Field(None, description="原厂商标识（用于聚合渠道）")
    original_model: Optional[str] = Field(None, description="原厂商模型名（用于能力映射）")

class ModelCatalog(BaseModel):
    id: Optional[PyObjectId] = Field(default_factory=ObjectId, alias="_id")
    provider: str = Field(..., description="厂家标识")
    provider_name: str = Field(..., description="厂家显示名称")
    models: List[ModelInfo] = Field(default_factory=list, description="模型列表")
    created_at: Optional[datetime] = Field(default_factory=now_tz)
    updated_at: Optional[datetime] = Field(default_factory=now_tz)

    model_config = ConfigDict(populate_by_name=True, arbitrary_types_allowed=True)

class LLMProviderRequest(BaseModel):
    name: str = Field(..., description="厂家唯一标识")
    display_name: str = Field(..., description="显示名称")
    description: Optional[str] = Field(None, description="厂家描述")
    website: Optional[str] = Field(None, description="官网地址")
    api_doc_url: Optional[str] = Field(None, description="API文档地址")
    logo_url: Optional[str] = Field(None, description="Logo地址")
    is_active: bool = Field(True, description="是否启用")
    supported_features: List[str] = Field(default_factory=list, description="支持的功能")
    default_base_url: Optional[str] = Field(None, description="默认API地址")
    api_key: Optional[str] = Field(None, description="API密钥")
    api_secret: Optional[str] = Field(None, description="API密钥（某些厂家需要）")
    extra_config: Dict[str, Any] = Field(default_factory=dict, description="额外配置参数")
    protocol: Optional[str] = Field(None, description="请求协议(anthropic/openai)")

    is_aggregator: bool = Field(default=False, description="是否为聚合渠道")
    aggregator_type: Optional[str] = Field(None, description="聚合渠道类型")
    model_name_format: Optional[str] = Field(None, description="模型名称格式")

class LLMProviderResponse(BaseModel):
    id: str
    name: str
    display_name: str
    description: Optional[str] = None
    website: Optional[str] = None
    api_doc_url: Optional[str] = None
    logo_url: Optional[str] = None
    is_active: bool
    supported_features: List[str]
    default_base_url: Optional[str] = None
    api_key: Optional[str] = None
    api_secret: Optional[str] = None
    extra_config: Dict[str, Any] = Field(default_factory=dict)
    protocol: Optional[str] = None

    is_aggregator: bool = False
    aggregator_type: Optional[str] = None
    model_name_format: Optional[str] = None

    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    @field_serializer("api_key", "api_secret")
    @classmethod
    def _sanitize_secret(cls, v: Optional[str]) -> Optional[str]:
        if not v:
            return None
        if len(v) <= 10:
            return "****"
        return f"{v[:6]}****{v[-4:]}"

class DataSourceType(str, Enum):

    MONGODB = "mongodb"

    TUSHARE = "tushare"
    AKSHARE = "akshare"
    BAOSTOCK = "baostock"

    FINNHUB = "finnhub"
    YAHOO_FINANCE = "yahoo_finance"
    ALPHA_VANTAGE = "alpha_vantage"
    IEX_CLOUD = "iex_cloud"

    WIND = "wind"
    CHOICE = "choice"

    QUANDL = "quandl"
    LOCAL_FILE = "local_file"
    CUSTOM = "custom"

class DatabaseType(str, Enum):
    MONGODB = "mongodb"
    MYSQL = "mysql"
    POSTGRESQL = "postgresql"
    REDIS = "redis"
    SQLITE = "sqlite"

class LLMConfig(BaseModel):
    provider: str = Field(default="openai", description="供应商标识（支持动态添加）")
    model_name: str = Field(..., description="模型名称/代码")
    model_display_name: Optional[str] = Field(None, description="模型显示名称")
    api_key: Optional[str] = Field(None, description="API密钥(可选，优先从厂家配置获取)")
    api_base: Optional[str] = Field(None, description="API基础URL")
    max_tokens: int = Field(
        default=DEFAULT_MAX_TOKENS,
        ge=1,
        le=128000,
        description="单次请求最大输出token数（与上下文窗口是两个概念）"
    )
    context_window: Optional[int] = Field(
        default=None,
        ge=1,
        le=10_000_000,
        description="模型上下文窗口（输入能力，token 数；留空自动取模型目录 context_length）"
    )
    temperature: float = Field(default=DEFAULT_TEMPERATURE, ge=0.0, le=2.0, description="温度参数")
    thinking_budget: Optional[int] = Field(
        default=None,
        ge=1024,
        le=128000,
        description="推理思考预算 token 数（仅 Anthropic 协议生效且优先于档位换算；OpenAI 兼容协议的数值由档位换算，不消费此参数）"
    )
    thinking_effort: Optional[str] = Field(
        default=None,
        description="思考强度档位：None=不干预(不注入思考参数)；off=显式关闭；"
                    "minimal/low/medium/high=max=开启并设定强度。协议层按厂家方言映射，"
                    "见 app/llm/protocols/thinking.py"
    )
    timeout: int = Field(default=DEFAULT_TIMEOUT, description="请求超时时间(秒)")
    retry_times: int = Field(default=DEFAULT_RETRY_TIMES, description="重试次数")
    max_concurrency: int = Field(default=5, ge=1, le=50, description="模型并发上限(同时在途请求数)")
    enabled: bool = Field(default=True, description="是否启用")
    description: Optional[str] = Field(None, description="配置描述")

    model_category: Optional[str] = Field(None, description="模型类别(用于OpenRouter等)")
    custom_endpoint: Optional[str] = Field(None, description="自定义端点URL")
    enable_memory: bool = Field(default=False, description="启用记忆功能")
    enable_debug: bool = Field(default=False, description="启用调试模式")
    priority: int = Field(default=0, description="优先级")

    input_price_per_1k: Optional[float] = Field(None, description="输入token价格(每1000个token)")
    output_price_per_1k: Optional[float] = Field(None, description="输出token价格(每1000个token)")
    currency: str = Field(default="CNY", description="货币单位(CNY/USD/EUR)")

    suitable_roles: List[str] = Field(
        default_factory=lambda: ["both"],
        description="适用角色: analyst(一阶段分析师), debate(辩论推理), both(两者都适合)"
    )

    _validate_effort = field_validator("thinking_effort")(validate_thinking_effort)

class DataSourceConfig(BaseModel):
    name: str = Field(..., description="数据源名称")
    type: DataSourceType = Field(..., description="数据源类型")
    api_key: Optional[str] = Field(None, description="API密钥")
    api_secret: Optional[str] = Field(None, description="API密钥")
    endpoint: Optional[str] = Field(None, description="API端点")
    timeout: int = Field(default=30, description="请求超时时间(秒)")
    rate_limit: int = Field(default=100, description="每分钟请求限制")
    enabled: bool = Field(default=True, description="是否启用")
    priority: int = Field(default=0, description="优先级，数字越大优先级越高")
    config_params: Dict[str, Any] = Field(default_factory=dict, description="额外配置参数")
    description: Optional[str] = Field(None, description="配置描述")
    market_categories: Optional[List[str]] = Field(default_factory=list, description="所属市场分类列表")
    display_name: Optional[str] = Field(None, description="显示名称")
    provider: Optional[str] = Field(None, description="数据提供商")
    created_at: Optional[datetime] = Field(default_factory=now_tz, description="创建时间")
    updated_at: Optional[datetime] = Field(default_factory=now_tz, description="更新时间")

class DatabaseConfig(BaseModel):
    name: str = Field(..., description="数据库名称")
    type: DatabaseType = Field(..., description="数据库类型")
    host: str = Field(..., description="主机地址")
    port: int = Field(..., description="端口号")
    username: Optional[str] = Field(None, description="用户名")
    password: Optional[str] = Field(None, description="密码")
    database: Optional[str] = Field(None, description="数据库名")
    connection_params: Dict[str, Any] = Field(default_factory=dict, description="连接参数")
    pool_size: int = Field(default=10, description="连接池大小")
    max_overflow: int = Field(default=20, description="最大溢出连接数")
    enabled: bool = Field(default=True, description="是否启用")
    description: Optional[str] = Field(None, description="配置描述")

class MarketCategory(BaseModel):
    id: str = Field(..., description="分类ID")
    name: str = Field(..., description="分类名称")
    display_name: str = Field(..., description="显示名称")
    description: Optional[str] = Field(None, description="分类描述")
    enabled: bool = Field(default=True, description="是否启用")
    sort_order: int = Field(default=1, description="排序顺序")
    created_at: Optional[datetime] = Field(default_factory=now_tz, description="创建时间")
    updated_at: Optional[datetime] = Field(default_factory=now_tz, description="更新时间")

class DataSourceGrouping(BaseModel):
    data_source_name: str = Field(..., description="数据源名称")
    market_category_id: str = Field(..., description="市场分类ID")
    priority: int = Field(default=0, description="在该分类中的优先级")
    enabled: bool = Field(default=True, description="是否启用")
    created_at: Optional[datetime] = Field(default_factory=now_tz, description="创建时间")
    updated_at: Optional[datetime] = Field(default_factory=now_tz, description="更新时间")

class UsageRecord(BaseModel):
    id: Optional[str] = Field(None, description="记录ID")
    timestamp: str = Field(..., description="时间戳")
    provider: str = Field(..., description="供应商")
    model_name: str = Field(..., description="模型名称")
    input_tokens: int = Field(..., description="输入token数")
    output_tokens: int = Field(..., description="输出token数")
    cost: float = Field(..., description="成本")
    currency: str = Field(default="CNY", description="货币单位")
    session_id: str = Field(default="", description="会话ID（语义升级为 task_id，保留字段兼容）")
    analysis_type: str = Field(default="stock_analysis", description="分析类型")
    stock_code: Optional[str] = Field(None, description="股票代码")
    task_id: str = Field(default="", description="分析任务ID")
    user_id: str = Field(default="", description="任务发起者用户ID")
    agent_key: str = Field(default="", description="智能体标识（英文 key，显示名由前端配置解析）")
    phase: str = Field(default="", description="阶段（analysts/research/trader/risk/summary 等）")
    cache_creation_input_tokens: int = Field(default=0, description="缓存写入token（Anthropic prompt caching）")
    cache_read_input_tokens: int = Field(default=0, description="缓存命中token（Anthropic cache_read / OpenAI cached_tokens）")

class UsageStatistics(BaseModel):
    total_requests: int = Field(default=0, description="总请求数")
    total_input_tokens: int = Field(default=0, description="总输入token数")
    total_output_tokens: int = Field(default=0, description="总输出token数")
    total_cache_read_tokens: int = Field(default=0, description="缓存命中token总数")
    total_cache_creation_tokens: int = Field(default=0, description="缓存写入token总数")
    total_cost: float = Field(default=0.0, description="总成本（已废弃，使用 cost_by_currency）")
    cost_by_currency: Dict[str, float] = Field(default_factory=dict, description="按货币统计的成本")
    by_provider: Dict[str, Any] = Field(default_factory=dict, description="按供应商统计")
    by_model: Dict[str, Any] = Field(default_factory=dict, description="按模型统计")
    by_date: Dict[str, Any] = Field(default_factory=dict, description="按日期统计")
    by_task: Dict[str, Any] = Field(default_factory=dict, description="按任务统计")
    by_agent: Dict[str, Any] = Field(default_factory=dict, description="按智能体统计")

class SystemConfig(BaseModel):
    id: Optional[PyObjectId] = Field(default_factory=ObjectId, alias="_id")
    config_name: str = Field(..., description="配置名称")
    config_type: str = Field(..., description="配置类型")
    
    llm_configs: List[LLMConfig] = Field(default_factory=list, description="大模型配置列表")
    default_llm: Optional[str] = Field(None, description="默认大模型")
    
    data_source_configs: List[DataSourceConfig] = Field(default_factory=list, description="数据源配置列表")
    default_data_source: Optional[str] = Field(None, description="默认数据源")
    
    database_configs: List[DatabaseConfig] = Field(default_factory=list, description="数据库配置列表")
    
    system_settings: Dict[str, Any] = Field(default_factory=dict, description="系统设置")
    
    created_at: datetime = Field(default_factory=now_tz)
    updated_at: datetime = Field(default_factory=now_tz)
    created_by: Optional[PyObjectId] = Field(None, description="创建者")
    updated_by: Optional[PyObjectId] = Field(None, description="更新者")
    version: int = Field(default=1, description="配置版本")
    is_active: bool = Field(default=True, description="是否激活")
    
    model_config = ConfigDict(populate_by_name=True, arbitrary_types_allowed=True)

class LLMConfigRequest(BaseModel):
    provider: str = Field(..., description="供应商标识（支持动态添加）")
    model_name: str
    model_display_name: Optional[str] = None
    api_key: Optional[str] = None
    api_base: Optional[str] = None
    max_tokens: int = Field(default=DEFAULT_MAX_TOKENS, ge=1, le=128000)
    context_window: Optional[int] = Field(default=None, ge=1, le=10_000_000)
    thinking_budget: Optional[int] = Field(default=None, ge=1024, le=128000)
    thinking_effort: Optional[str] = None
    temperature: float = DEFAULT_TEMPERATURE
    timeout: int = DEFAULT_TIMEOUT
    retry_times: int = DEFAULT_RETRY_TIMES
    max_concurrency: int = Field(default=5, ge=1, le=50, description="模型并发上限(同时在途请求数)")
    enabled: bool = True
    description: Optional[str] = None

    enable_memory: bool = False
    enable_debug: bool = False
    priority: int = 0
    model_category: Optional[str] = None

    input_price_per_1k: Optional[float] = None
    output_price_per_1k: Optional[float] = None
    currency: str = "CNY"

    suitable_roles: List[str] = Field(default_factory=lambda: ["both"])

    _validate_effort = field_validator("thinking_effort")(validate_thinking_effort)

    @field_validator("thinking_budget", mode="before")
    @classmethod
    def _budget_empty_to_none(cls, v):
        return None if v == "" else v

class DataSourceConfigRequest(BaseModel):
    name: str
    type: DataSourceType
    api_key: Optional[str] = None
    api_secret: Optional[str] = None
    endpoint: Optional[str] = None
    timeout: int = 30
    rate_limit: int = 100
    enabled: bool = True
    priority: int = 0
    config_params: Dict[str, Any] = Field(default_factory=dict)
    description: Optional[str] = None
    market_categories: Optional[List[str]] = Field(default_factory=list)
    display_name: Optional[str] = None
    provider: Optional[str] = None

class MarketCategoryRequest(BaseModel):
    id: str
    name: str
    display_name: str
    description: Optional[str] = None
    enabled: bool = True
    sort_order: int = 1

class DataSourceGroupingRequest(BaseModel):
    data_source_name: str
    market_category_id: str
    priority: int = 0
    enabled: bool = True

class DataSourceOrderRequest(BaseModel):
    data_sources: List[Dict[str, Any]] = Field(..., description="排序后的数据源列表")

class DatabaseConfigRequest(BaseModel):
    name: str
    type: DatabaseType
    host: str
    port: int
    username: Optional[str] = None
    password: Optional[str] = None
    database: Optional[str] = None
    connection_params: Dict[str, Any] = Field(default_factory=dict)
    pool_size: int = 10
    max_overflow: int = 20
    enabled: bool = True
    description: Optional[str] = None

class SystemConfigResponse(BaseModel):
    config_name: str
    config_type: str
    llm_configs: List[LLMConfig]
    default_llm: Optional[str]
    data_source_configs: List[DataSourceConfig]
    default_data_source: Optional[str]
    database_configs: List[DatabaseConfig]
    system_settings: Dict[str, Any]
    created_at: datetime
    updated_at: datetime
    version: int
    is_active: bool

    @field_serializer('created_at', 'updated_at')
    def serialize_datetime(self, dt: Optional[datetime], _info) -> Optional[str]:
        if dt:
            return dt.isoformat()
        return None

class ConfigTestRequest(BaseModel):
    config_type: str = Field(..., description="配置类型: llm/datasource/database")
    config_data: Dict[str, Any] = Field(..., description="配置数据")

class ConfigTestResponse(BaseModel):
    success: bool
    message: str
    details: Optional[Dict[str, Any]] = None
    response_time: Optional[float] = None
