from __future__ import annotations

import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from threading import Lock
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

DEFAULT_USER_MAX_FAILURES = 5
DEFAULT_USER_WINDOW_SECONDS = 300
DEFAULT_USER_LOCK_SECONDS = 900

DEFAULT_IP_MAX_FAILURES = 20
DEFAULT_IP_WINDOW_SECONDS = 300
DEFAULT_IP_LOCK_SECONDS = 1800

_REDIS_KEY_PREFIX = "auth:rl"

@dataclass
class _Bucket:

    failures: List[float] = field(default_factory=list)
    locked_until: float = 0.0

class _InMemoryStore:

    def __init__(self) -> None:
        self._buckets: Dict[str, _Bucket] = defaultdict(_Bucket)
        self._lock = Lock()

    def _purge(self, bucket: _Bucket, now: float, window: int) -> None:
        cutoff = now - window
        bucket.failures = [ts for ts in bucket.failures if ts > cutoff]

    def _is_bucket_empty(self, bucket: _Bucket, now: float) -> bool:
        return not bucket.failures and bucket.locked_until <= now

    def count_failure(self, key: str, window: int) -> int:
        now = time.time()
        with self._lock:
            bucket = self._buckets[key]
            self._purge(bucket, now, window)
            bucket.failures.append(now)
            return len(bucket.failures)

    def set_lock(self, key: str, lock_seconds: int) -> None:
        with self._lock:
            bucket = self._buckets[key]
            bucket.locked_until = time.time() + lock_seconds

    def is_locked(self, key: str) -> bool:
        with self._lock:
            bucket = self._buckets.get(key)
            if bucket is None:
                return False
            now = time.time()
            if bucket.locked_until > now:
                return True
            bucket.locked_until = 0.0
            if not bucket.failures:
                self._buckets.pop(key, None)
            return False

    def check_locked_with_remaining(self, key: str) -> Tuple[bool, int]:

        with self._lock:
            bucket = self._buckets.get(key)
            if bucket is None:
                return False, 0
            now = time.time()
            if bucket.locked_until > now:
                return True, int(bucket.locked_until - now)
            bucket.locked_until = 0.0
            if not bucket.failures:
                self._buckets.pop(key, None)
            return False, 0

    def get_remaining_lock(self, key: str) -> int:
        with self._lock:
            bucket = self._buckets.get(key)
            if bucket is None:
                return 0
            now = time.time()
            if bucket.locked_until > now:
                return int(bucket.locked_until - now)
            return 0

    def reset(self, key: str) -> None:
        with self._lock:
            self._buckets.pop(key, None)

class AuthRateLimiter:

    def __init__(
        self,
        user_max_failures: int = DEFAULT_USER_MAX_FAILURES,
        user_window_seconds: int = DEFAULT_USER_WINDOW_SECONDS,
        user_lock_seconds: int = DEFAULT_USER_LOCK_SECONDS,
        ip_max_failures: int = DEFAULT_IP_MAX_FAILURES,
        ip_window_seconds: int = DEFAULT_IP_WINDOW_SECONDS,
        ip_lock_seconds: int = DEFAULT_IP_LOCK_SECONDS,
    ) -> None:
        self.user_max_failures = user_max_failures
        self.user_window_seconds = user_window_seconds
        self.user_lock_seconds = user_lock_seconds
        self.ip_max_failures = ip_max_failures
        self.ip_window_seconds = ip_window_seconds
        self.ip_lock_seconds = ip_lock_seconds
        self._fallback = _InMemoryStore()

    def _redis(self):
        try:
            from app.core.database import get_redis_client

            client = get_redis_client()
            return client if client is not None else None
        except Exception as e:
            logger.debug(f"Redis 不可用，登录限流降级到进程内存储: {e}")
            return None

    @staticmethod
    def _user_key(ip: str, username: str) -> str:
        return f"{_REDIS_KEY_PREFIX}:u:{ip}:{(username or '').lower()}"

    @staticmethod
    def _ip_key(ip: str) -> str:
        return f"{_REDIS_KEY_PREFIX}:ip:{ip}"

    @staticmethod
    def _lock_key(base_key: str) -> str:
        return f"{base_key}:lock"

    async def check(self, ip: str, username: str) -> Tuple[bool, str, int]:
        redis = self._redis()
        user_key = self._user_key(ip, username)
        ip_key = self._ip_key(ip)

        if redis is not None:
            try:
                pipe = redis.pipeline()
                pipe.ttl(self._lock_key(user_key))
                pipe.ttl(self._lock_key(ip_key))
                user_ttl, ip_ttl = await pipe.execute()
                if user_ttl is not None and user_ttl > 0:
                    return True, "用户名已被临时锁定", int(user_ttl)
                if user_ttl == -1:
                    return True, "用户名已被临时锁定", self.user_lock_seconds
                if ip_ttl is not None and ip_ttl > 0:
                    return True, "IP 已被临时锁定", int(ip_ttl)
                if ip_ttl == -1:
                    return True, "IP 已被临时锁定", self.ip_lock_seconds
                return False, "", 0
            except Exception as e:
                logger.warning(f"Redis 检查锁定状态失败，降级内存: {e}")

        locked, remaining = self._fallback.check_locked_with_remaining(self._lock_key(user_key))
        if locked:
            return True, "用户名已被临时锁定", remaining
        locked, remaining = self._fallback.check_locked_with_remaining(self._lock_key(ip_key))
        if locked:
            return True, "IP 已被临时锁定", remaining
        return False, "", 0

    async def record_failure(self, ip: str, username: str) -> Tuple[bool, str, int]:
        redis = self._redis()
        user_key = self._user_key(ip, username)
        ip_key = self._ip_key(ip)

        if redis is not None:
            try:
                pipe = redis.pipeline()
                pipe.incr(user_key)
                pipe.expire(user_key, self.user_window_seconds)
                pipe.incr(ip_key)
                pipe.expire(ip_key, self.ip_window_seconds)
                user_count, _, ip_count, _ = await pipe.execute()

                if user_count and int(user_count) >= self.user_max_failures:
                    await redis.set(
                        self._lock_key(user_key), "1", ex=self.user_lock_seconds
                    )
                    logger.warning(
                        f"🚨 登录限流：锁定 用户/IP ({username}/{ip}) "
                        f"{self.user_lock_seconds}s（失败 {user_count}/{self.user_max_failures}）"
                    )
                    return (
                        True,
                        "用户名或密码错误次数过多，已临时锁定",
                        self.user_lock_seconds,
                    )

                if ip_count and int(ip_count) >= self.ip_max_failures:
                    await redis.set(
                        self._lock_key(ip_key), "1", ex=self.ip_lock_seconds
                    )
                    logger.warning(
                        f"🚨 登录限流：锁定 IP {ip} "
                        f"{self.ip_lock_seconds}s（失败 {ip_count}/{self.ip_max_failures}）"
                    )
                    return (
                        True,
                        "该 IP 登录失败次数过多，已临时锁定",
                        self.ip_lock_seconds,
                    )

                return False, "", 0
            except Exception as e:
                logger.warning(f"Redis 记录失败计数异常: {e}")
                return False, "", 0

        user_count = self._fallback.count_failure(user_key, self.user_window_seconds)
        ip_count = self._fallback.count_failure(ip_key, self.ip_window_seconds)

        if user_count >= self.user_max_failures:
            self._fallback.set_lock(self._lock_key(user_key), self.user_lock_seconds)
            return True, "用户名或密码错误次数过多，已临时锁定", self.user_lock_seconds
        if ip_count >= self.ip_max_failures:
            self._fallback.set_lock(self._lock_key(ip_key), self.ip_lock_seconds)
            return True, "该 IP 登录失败次数过多，已临时锁定", self.ip_lock_seconds
        return False, "", 0

    async def reset(self, ip: str, username: str) -> None:

        redis = self._redis()
        user_key = self._user_key(ip, username)
        if redis is not None:
            try:
                pipe = redis.pipeline()
                pipe.delete(user_key)
                pipe.delete(self._lock_key(user_key))
                await pipe.execute()
                return
            except Exception as e:
                logger.debug(f"Redis 重置失败计数异常，降级内存: {e}")

        self._fallback.reset(user_key)
        self._fallback.reset(self._lock_key(user_key))

_limiter: Optional[AuthRateLimiter] = None
_limiter_lock = Lock()

def get_auth_rate_limiter() -> AuthRateLimiter:
    global _limiter
    if _limiter is None:
        with _limiter_lock:
            if _limiter is None:
                _limiter = AuthRateLimiter()
    return _limiter

def reset_auth_rate_limiter_for_tests() -> None:
    global _limiter
    with _limiter_lock:
        _limiter = None
