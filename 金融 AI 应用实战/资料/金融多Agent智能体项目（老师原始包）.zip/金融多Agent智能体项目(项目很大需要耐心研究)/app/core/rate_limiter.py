import asyncio
import threading
import time
import logging
from collections import deque
from typing import Optional

logger = logging.getLogger(__name__)

class RateLimiter:

    def __init__(self, max_calls: int, time_window: float, name: str = "RateLimiter"):

        self.max_calls = max_calls
        self.time_window = time_window
        self.name = name
        self.calls = deque()
        self._lock: Optional[asyncio.Lock] = None
        
        self.total_calls = 0
        self.total_waits = 0
        self.total_wait_time = 0.0
        
        logger.info(f"🔧 {self.name} 初始化: {max_calls}次/{time_window}秒")
    
    async def acquire(self):

        if self._lock is None:
            self._lock = asyncio.Lock()
        while True:
            wait_time = 0.0
            async with self._lock:
                now = time.time()

                while self.calls and self.calls[0] <= now - self.time_window:
                    self.calls.popleft()

                if len(self.calls) < self.max_calls:
                    self.calls.append(now)
                    self.total_calls += 1
                    return

                oldest_call = self.calls[0]
                wait_time = oldest_call + self.time_window - now + 0.01

                if wait_time > 0:
                    self.total_waits += 1
                    self.total_wait_time += wait_time

            if wait_time > 0:
                logger.debug(f"⏳ {self.name} 达到速率限制，等待 {wait_time:.2f}秒")
                await asyncio.sleep(wait_time)
    
    def get_stats(self) -> dict:
        return {
            "name": self.name,
            "max_calls": self.max_calls,
            "time_window": self.time_window,
            "current_calls": len(self.calls),
            "total_calls": self.total_calls,
            "total_waits": self.total_waits,
            "total_wait_time": self.total_wait_time,
            "avg_wait_time": self.total_wait_time / self.total_waits if self.total_waits > 0 else 0
        }
    
    def reset_stats(self):
        self.total_calls = 0
        self.total_waits = 0
        self.total_wait_time = 0.0
        logger.info(f"🔄 {self.name} 统计信息已重置")

class TushareRateLimiter(RateLimiter):

    TIER_LIMITS = {
        "free": {"max_calls": 100, "time_window": 60},
        "basic": {"max_calls": 200, "time_window": 60},
        "standard": {"max_calls": 400, "time_window": 60},
        "premium": {"max_calls": 600, "time_window": 60},
        "vip": {"max_calls": 800, "time_window": 60},
    }
    
    def __init__(self, tier: str = "standard", safety_margin: float = 0.8):

        if tier not in self.TIER_LIMITS:
            logger.warning(f"⚠️ 未知的Tushare积分等级: {tier}，使用默认值 'standard'")
            tier = "standard"
        
        limits = self.TIER_LIMITS[tier]
        
        max_calls = int(limits["max_calls"] * safety_margin)
        time_window = limits["time_window"]
        
        super().__init__(
            max_calls=max_calls,
            time_window=time_window,
            name=f"TushareRateLimiter({tier})"
        )
        
        self.tier = tier
        self.safety_margin = safety_margin
        
        logger.info(f"✅ Tushare速率限制器已配置: {tier}等级, "
                   f"{max_calls}次/{time_window}秒 (安全边际: {safety_margin*100:.0f}%)")

class AKShareRateLimiter(RateLimiter):

    def __init__(self, max_calls: int = 60, time_window: float = 60):

        super().__init__(
            max_calls=max_calls,
            time_window=time_window,
            name="AKShareRateLimiter"
        )

class BaoStockRateLimiter(RateLimiter):

    def __init__(self, max_calls: int = 100, time_window: float = 60):

        super().__init__(
            max_calls=max_calls,
            time_window=time_window,
            name="BaoStockRateLimiter"
        )

_tushare_limiter: Optional[TushareRateLimiter] = None
_akshare_limiter: Optional[AKShareRateLimiter] = None
_baostock_limiter: Optional[BaoStockRateLimiter] = None
_rate_limiter_lock = threading.Lock()

def get_tushare_rate_limiter(tier: str = "standard", safety_margin: float = 0.8) -> TushareRateLimiter:

    global _tushare_limiter
    if _tushare_limiter is None:
        with _rate_limiter_lock:
            if _tushare_limiter is None:
                _tushare_limiter = TushareRateLimiter(tier=tier, safety_margin=safety_margin)
    elif _tushare_limiter.tier != tier or _tushare_limiter.safety_margin != safety_margin:
        logger.warning(
            f"get_tushare_rate_limiter 参数与首次创建不一致"
            f"(existing tier={_tushare_limiter.tier}, requested tier={tier}), "
            f"返回已有实例。如需不同 tier 请使用独立变量管理。"
        )
    return _tushare_limiter

def get_akshare_rate_limiter() -> AKShareRateLimiter:
    global _akshare_limiter
    if _akshare_limiter is None:
        with _rate_limiter_lock:
            if _akshare_limiter is None:
                _akshare_limiter = AKShareRateLimiter()
    return _akshare_limiter

def get_baostock_rate_limiter() -> BaoStockRateLimiter:
    global _baostock_limiter
    if _baostock_limiter is None:
        with _rate_limiter_lock:
            if _baostock_limiter is None:
                _baostock_limiter = BaoStockRateLimiter()
    return _baostock_limiter

def reset_all_limiters():
    global _tushare_limiter, _akshare_limiter, _baostock_limiter
    with _rate_limiter_lock:
        _tushare_limiter = None
        _akshare_limiter = None
        _baostock_limiter = None
    logger.info("🔄 所有速率限制器已重置")
