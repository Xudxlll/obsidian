from __future__ import annotations

import asyncio
import logging
import threading
from typing import Awaitable, Dict, Set

logger = logging.getLogger(__name__)

class TaskRegistry:

    def __init__(self) -> None:
        self._tasks: Set[asyncio.Task] = set()
        self._critical: Set[asyncio.Task] = set()
        self._lock = threading.Lock()
        self._names: Dict[int, str] = {}
        self._stats_created = 0
        self._stats_completed = 0
        self._stats_failed = 0

    def register(
        self,
        coro: Awaitable,
        *,
        name: str = "",
        critical: bool = False,
    ) -> asyncio.Task:

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError as exc:
            raise RuntimeError(
                "TaskRegistry.register 必须在事件循环中调用；"
                "worker thread 请通过 run_async / run_coroutine_threadsafe 桥接。"
            ) from exc

        task = loop.create_task(coro, name=name or None)
        task_id = id(task)
        with self._lock:
            self._tasks.add(task)
            self._names[task_id] = name or task.get_name()
            if critical:
                self._critical.add(task)
            self._stats_created += 1
            pending_count = len(self._tasks)

        def _discard(t: asyncio.Task) -> None:
            display: str
            with self._lock:
                self._tasks.discard(t)
                self._critical.discard(t)
                display = self._names.pop(id(t), t.get_name())
                self._stats_completed += 1
            if t.cancelled():
                logger.debug("TaskRegistry: 任务已取消 name=%s", display)
                return
            exc = t.exception()
            if exc is not None:
                with self._lock:
                    self._stats_failed += 1
                logger.warning(
                    "TaskRegistry: 任务异常 name=%s exc=%r", display, exc
                )

        task.add_done_callback(_discard)
        logger.debug(
            "TaskRegistry: 注册任务 name=%s critical=%s pending=%d",
            name or task.get_name(),
            critical,
            pending_count,
        )
        return task

    async def shutdown(self, timeout: float = 10.0) -> None:

        with self._lock:
            pending = [t for t in self._tasks if not t.done()]
            if not pending:
                logger.info("TaskRegistry.shutdown: 无待处理任务")
                return

            non_critical = [t for t in pending if t not in self._critical]
            critical = [t for t in pending if t in self._critical]
            names_snapshot: Dict[int, str] = dict(self._names)

        for t in non_critical:
            t.cancel()
        if non_critical:
            logger.info(
                "TaskRegistry.shutdown: 已取消 %d 个非 critical 任务",
                len(non_critical),
            )
            await asyncio.gather(*non_critical, return_exceptions=True)

        if critical:
            logger.info(
                "TaskRegistry.shutdown: 等待 %d 个 critical 任务完成（timeout=%.1fs）",
                len(critical),
                timeout,
            )
            done, still_pending = await asyncio.wait(
                critical, timeout=timeout
            )
            if still_pending:
                names = [
                    names_snapshot.get(id(t), t.get_name()) for t in still_pending
                ]
                logger.warning(
                    "TaskRegistry.shutdown: %d 个 critical 任务超时被强制取消: %s",
                    len(still_pending),
                    names,
                )
                for t in still_pending:
                    t.cancel()
                await asyncio.gather(*still_pending, return_exceptions=True)

        logger.info("TaskRegistry.shutdown: 完成")

    def pending_count(self) -> int:
        with self._lock:
            return sum(1 for t in self._tasks if not t.done())

    def get_stats(self) -> Dict[str, int]:
        with self._lock:
            return {
                "pending": sum(1 for t in self._tasks if not t.done()),
                "critical_pending": sum(1 for t in self._critical if not t.done()),
                "total_created": self._stats_created,
                "total_completed": self._stats_completed,
                "total_failed": self._stats_failed,
            }

task_registry = TaskRegistry()
