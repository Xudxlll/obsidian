from __future__ import annotations

import logging
import threading
import time
from collections import OrderedDict
from typing import Any, Callable, Dict, Hashable, Optional

logger = logging.getLogger(__name__)

class BoundedLRUCache:

    def __init__(
        self,
        maxsize: int = 512,
        ttl: Optional[float] = None,
        *,
        name: str = "",
        on_evict: Optional[Callable[[Any, Any], None]] = None,
    ) -> None:
        if maxsize < 1:
            raise ValueError(f"maxsize 必须 >= 1, got {maxsize}")
        if ttl is not None and ttl <= 0:
            raise ValueError(f"ttl 必须 > 0 或 None, got {ttl}")
        self._maxsize = maxsize
        self._ttl = ttl
        self._name = name or self.__class__.__name__
        self._data: "OrderedDict[Hashable, tuple[Any, float]]" = OrderedDict()
        self._lock = threading.Lock()
        self._hits = 0
        self._misses = 0
        self._evictions = 0
        self._expired = 0
        self._on_evict = on_evict

    def get(self, key: Hashable) -> Optional[Any]:

        with self._lock:
            entry = self._data.get(key)
            if entry is None:
                self._misses += 1
                return None
            value, expires_at = entry
            if expires_at is not None and time.monotonic() > expires_at:
                self._data.pop(key, None)
                self._expired += 1
                self._misses += 1
                self._fire_evict_callback(key, value)
                return None
            self._data.move_to_end(key)
            self._hits += 1
            return value

    def set(self, key: Hashable, value: Any, ttl: Optional[float] = None) -> None:

        if ttl is not None and ttl <= 0:
            raise ValueError(f"ttl 必须 > 0 或 None, got {ttl}")
        effective_ttl = ttl if ttl is not None else self._ttl
        expires_at = (
            time.monotonic() + effective_ttl if effective_ttl else None
        )
        with self._lock:
            if key in self._data:
                self._data[key] = (value, expires_at)
                self._data.move_to_end(key)
                return
            self._data[key] = (value, expires_at)
            while len(self._data) > self._maxsize:
                evicted_key, (evicted_value, _) = self._data.popitem(last=False)
                self._evictions += 1
                self._fire_evict_callback(evicted_key, evicted_value)

    def invalidate(self, key: Hashable) -> bool:
        with self._lock:
            entry = self._data.pop(key, None)
            if entry is None:
                return False
            value, _ = entry
            self._fire_evict_callback(key, value)
            return True

    def clear(self) -> int:
        with self._lock:
            items = list(self._data.items())
            count = len(items)
            self._data.clear()
        for k, (v, _) in items:
            self._fire_evict_callback(k, v)
        return count

    def _fire_evict_callback(self, key: Any, value: Any) -> None:
        if self._on_evict is None:
            return
        try:
            self._on_evict(key, value)
        except Exception as e:
            logger.warning(
                "BoundedLRUCache[%s] on_evict 回调失败 key=%r: %s",
                self._name,
                key,
                e,
            )

    def __len__(self) -> int:
        with self._lock:
            return len(self._data)

    def __contains__(self, key: object) -> bool:

        with self._lock:
            entry = self._data.get(key)
            if entry is None:
                return False
            _, expires_at = entry
            if expires_at is not None and time.monotonic() > expires_at:
                return False
            return True

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            total = self._hits + self._misses
            hit_rate = (self._hits / total) if total else 0
            return {
                "name": self._name,
                "size": len(self._data),
                "maxsize": self._maxsize,
                "ttl": self._ttl,
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": round(hit_rate, 4),
                "evictions": self._evictions,
                "expired": self._expired,
            }

    def items(self):
        with self._lock:
            now = time.monotonic()
            result = []
            for k, (v, expires_at) in self._data.items():
                if expires_at is not None and now > expires_at:
                    continue
                result.append((k, v))
            return result

    def values(self):
        return [v for _, v in self.items()]

    def keys(self):
        return [k for k, _ in self.items()]
