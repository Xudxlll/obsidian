import logging
from typing import List

class DevConfig:
    
    RELOAD_DIRS: List[str] = ["app"]
    
    RELOAD_EXCLUDES: List[str] = [
        "__pycache__",
        "*.pyc",
        "*.pyo", 
        "*.pyd",
        
        ".git",
        ".gitignore",
        
        ".pytest_cache",
        ".coverage",
        "htmlcov",
        
        "*.log",
        "logs",
        
        "*.tmp",
        "*.temp",
        "*.swp",
        "*.swo",
        
        ".DS_Store",
        "Thumbs.db",
        "desktop.ini",
        
        ".vscode",
        ".idea",
        "*.sublime-*",
        
        "*.db",
        "*.sqlite",
        "*.sqlite3",
        
        ".env",
        ".env.local",
        ".env.production",
        
        "*.md",
        "*.txt",
        "*.json",
        "*.yaml",
        "*.yml",
        "*.toml",
        
        "node_modules",
        "dist",
        "build",
        "*.js",
        "*.css",
        "*.html",
        
        "requirements*.txt",
        "Dockerfile*",
        "docker-compose*"
    ]
    
    RELOAD_INCLUDES: List[str] = [
        "*.py"
    ]
    
    RELOAD_DELAY: float = 0.5
    
    LOG_LEVEL: str = "info"
    
    ACCESS_LOG: bool = True
    
    @classmethod
    def get_uvicorn_config(cls, debug: bool = True) -> dict:
        return {
            "reload": False,
            "log_level": cls.LOG_LEVEL,
            "access_log": cls.ACCESS_LOG,
            "log_config": None
        }
    
    @classmethod
    def setup_logging(cls, debug: bool = True):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S',
            force=True
        )

        if debug:
            logging.getLogger("watchfiles").setLevel(logging.ERROR)
            logging.getLogger("watchfiles.main").setLevel(logging.ERROR)
            logging.getLogger("watchfiles.watcher").setLevel(logging.ERROR)

            logging.getLogger("webapi").setLevel(logging.INFO)
            logging.getLogger("app.core.database").setLevel(logging.INFO)
            logging.getLogger("uvicorn.error").setLevel(logging.INFO)

            webapi_logger = logging.getLogger("webapi")
            webapi_logger.info("🔧 DEV_CONFIG: webapi logger 测试消息")
        else:
            logging.getLogger("watchfiles").setLevel(logging.ERROR)
            logging.getLogger("uvicorn").setLevel(logging.WARNING)

DEV_CONFIG = DevConfig()
