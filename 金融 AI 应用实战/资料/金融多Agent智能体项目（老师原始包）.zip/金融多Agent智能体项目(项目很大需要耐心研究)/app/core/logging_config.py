import logging
import logging.config
import sys
from importlib.util import find_spec
from pathlib import Path
import platform

from app.core.config import settings
from app.core.env import get_env
from app.utils.runtime_paths import get_logs_dir, resolve_path

_IS_WINDOWS = platform.system() == "Windows"
_USE_CONCURRENT_HANDLER = _IS_WINDOWS and find_spec("concurrent_log_handler") is not None
if _IS_WINDOWS and not _USE_CONCURRENT_HANDLER:
    logging.warning("concurrent-log-handler 未安装，在 Windows 上可能遇到日志轮转问题")

try:
    import tomllib as toml_loader
except Exception:
    try:
        import tomli as toml_loader
    except Exception:
        toml_loader = None

def resolve_logging_cfg_path() -> Path:
    profile = str(get_env("LOGGING_PROFILE", "")).lower()
    is_docker_env = str(get_env("DOCKER", "")).lower() in {"1", "true", "yes"} or Path("/.dockerenv").exists()
    cfg_candidate = "config/logging_docker.toml" if profile == "docker" or is_docker_env else "config/logging.toml"
    return Path(cfg_candidate)

class SimpleJsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        import json
        obj = {
            "time": self.formatTime(record, "%Y-%m-%d %H:%M:%S"),
            "name": record.name,
            "level": record.levelname,
            "trace_id": getattr(record, "trace_id", "-"),
            "message": record.getMessage(),
        }
        return json.dumps(obj, ensure_ascii=False)

def _parse_size(size_str: str) -> int:
    if isinstance(size_str, int):
        return size_str
    if isinstance(size_str, str):
        size_str = size_str.strip().upper()
        multipliers = {"KB": 1024, "MB": 1024 ** 2, "GB": 1024 ** 3}
        for suffix, multiplier in multipliers.items():
            if size_str.endswith(suffix):
                try:
                    return int(float(size_str[: -len(suffix)]) * multiplier)
                except Exception:
                    return 10 * 1024 * 1024
    return 10 * 1024 * 1024

def _resolve_logs_dir(dir_value: str | Path) -> Path:
    dir_path = Path(dir_value)
    if dir_path.is_absolute():
        dir_path.mkdir(parents=True, exist_ok=True)
        return dir_path
    resolved = resolve_path(dir_value, settings.RUNTIME_BASE_DIR)
    resolved.mkdir(parents=True, exist_ok=True)
    return resolved

def _resolve_log_file(file_value: str | Path, default_dir: Path) -> str:
    file_path = Path(file_value)
    if not file_path.is_absolute():
        file_path = default_dir / file_path
    file_path.parent.mkdir(parents=True, exist_ok=True)
    return str(file_path)

def setup_logging(log_level: str = "INFO"):
    try:
        cfg_path = resolve_logging_cfg_path()

        if cfg_path.exists() and toml_loader is not None:
            with cfg_path.open("rb") as f:
                toml_data = toml_loader.load(f)

            logging_root = toml_data.get("logging", {})
            level = logging_root.get("level", log_level)
            fmt_cfg = logging_root.get("format", {})
            fmt_console = fmt_cfg.get(
                "console", "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
            )
            fmt_file = fmt_cfg.get(
                "file", "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
            )
            if "%(trace_id)" not in str(fmt_console):
                fmt_console = str(fmt_console) + " trace=%(trace_id)s"
            if "%(trace_id)" not in str(fmt_file):
                fmt_file = str(fmt_file) + " trace=%(trace_id)s"

            handlers_cfg = logging_root.get("handlers", {})
            file_handler_cfg = handlers_cfg.get("file", {})
            file_dir_cfg = file_handler_cfg.get("directory", "logs")

            file_dir = _resolve_logs_dir(file_dir_cfg)

            main_handler_cfg = handlers_cfg.get("main", {})
            webapi_handler_cfg = handlers_cfg.get("webapi", {})
            worker_handler_cfg = handlers_cfg.get("worker", {})

            main_log = _resolve_log_file(
                main_handler_cfg.get("filename", Path(file_dir) / "zhenshabi.log"),
                file_dir,
            )
            main_enabled = main_handler_cfg.get("enabled", True)
            main_level = main_handler_cfg.get("level", "INFO")
            main_max_bytes = _parse_size(main_handler_cfg.get("max_size", "100MB"))
            main_backup_count = int(main_handler_cfg.get("backup_count", 5))

            webapi_log = _resolve_log_file(
                webapi_handler_cfg.get("filename", Path(file_dir) / "webapi.log"),
                file_dir,
            )
            webapi_enabled = webapi_handler_cfg.get("enabled", True)
            webapi_level = webapi_handler_cfg.get("level", "DEBUG")
            webapi_max_bytes = _parse_size(webapi_handler_cfg.get("max_size", "100MB"))
            webapi_backup_count = int(webapi_handler_cfg.get("backup_count", 5))

            worker_log = _resolve_log_file(
                worker_handler_cfg.get("filename", Path(file_dir) / "worker.log"),
                file_dir,
            )
            worker_enabled = worker_handler_cfg.get("enabled", True)
            worker_level = worker_handler_cfg.get("level", "DEBUG")
            worker_max_bytes = _parse_size(worker_handler_cfg.get("max_size", "100MB"))
            worker_backup_count = int(worker_handler_cfg.get("backup_count", 5))

            error_handler_cfg = handlers_cfg.get("error", {})
            error_log = _resolve_log_file(
                error_handler_cfg.get("filename", Path(file_dir) / "error.log"),
                file_dir,
            )
            error_enabled = error_handler_cfg.get("enabled", True)
            error_level = error_handler_cfg.get("level", "ERROR")
            error_max_bytes = _parse_size(error_handler_cfg.get("max_size", "100MB"))
            error_backup_count = int(error_handler_cfg.get("backup_count", 5))

            use_json_console = bool(fmt_cfg.get("json", False)) or str(fmt_cfg.get("mode", "")).lower() == "json"
            use_json_file = (
                bool(fmt_cfg.get("file_json", False))
                or bool(fmt_cfg.get("json_file", False))
                or str(fmt_cfg.get("file_mode", "")).lower() == "json"
            )

            handlers_config = {
                "console": {
                    "class": "logging.StreamHandler",
                    "formatter": "json_console_fmt" if use_json_console else "console_fmt",
                    "level": level,
                    "filters": ["request_context"],
                    "stream": sys.stdout,
                },
            }

            handler_class = "concurrent_log_handler.ConcurrentRotatingFileHandler" if _USE_CONCURRENT_HANDLER else "logging.handlers.RotatingFileHandler"

            if main_enabled:
                handlers_config["main_file"] = {
                    "class": handler_class,
                    "formatter": "json_file_fmt" if use_json_file else "file_fmt",
                    "level": main_level,
                    "filename": main_log,
                    "maxBytes": main_max_bytes,
                    "backupCount": main_backup_count,
                    "encoding": "utf-8",
                    "filters": ["request_context"],
                }

            if webapi_enabled:
                handlers_config["file"] = {
                    "class": handler_class,
                    "formatter": "json_file_fmt" if use_json_file else "file_fmt",
                    "level": webapi_level,
                    "filename": webapi_log,
                    "maxBytes": webapi_max_bytes,
                    "backupCount": webapi_backup_count,
                    "encoding": "utf-8",
                    "filters": ["request_context"],
                }

            if worker_enabled:
                handlers_config["worker_file"] = {
                    "class": handler_class,
                    "formatter": "json_file_fmt" if use_json_file else "file_fmt",
                    "level": worker_level,
                    "filename": worker_log,
                    "maxBytes": worker_max_bytes,
                    "backupCount": worker_backup_count,
                    "encoding": "utf-8",
                    "filters": ["request_context"],
                }

            if error_enabled:
                handlers_config["error_file"] = {
                    "class": handler_class,
                    "formatter": "json_file_fmt" if use_json_file else "file_fmt",
                    "level": error_level,
                    "filename": error_log,
                    "maxBytes": error_max_bytes,
                    "backupCount": error_backup_count,
                    "encoding": "utf-8",
                    "filters": ["request_context"],
                }

            main_handlers = ["console"]
            if main_enabled:
                main_handlers.append("main_file")
            if error_enabled:
                main_handlers.append("error_file")

            webapi_handlers = ["console"]
            if webapi_enabled:
                webapi_handlers.append("file")
            if main_enabled:
                webapi_handlers.append("main_file")
            if error_enabled:
                webapi_handlers.append("error_file")

            worker_handlers = ["console"]
            if worker_enabled:
                worker_handlers.append("worker_file")
            if main_enabled:
                worker_handlers.append("main_file")
            if error_enabled:
                worker_handlers.append("error_file")

            logging_config = {
                "version": 1,
                "disable_existing_loggers": False,
                "filters": {
                    "request_context": {"()": "app.core.logging_context.LoggingContextFilter"}
                },
                "formatters": {
                    "console_fmt": {
                        "format": fmt_console,
                        "datefmt": "%Y-%m-%d %H:%M:%S",
                    },
                    "file_fmt": {
                        "format": fmt_file,
                        "datefmt": "%Y-%m-%d %H:%M:%S",
                    },
                    "json_console_fmt": {
                        "()": "app.core.logging_config.SimpleJsonFormatter"
                    },
                    "json_file_fmt": {
                        "()": "app.core.logging_config.SimpleJsonFormatter"
                    },
                },
                "handlers": handlers_config,
                "loggers": {
                    "zhenshabi": {
                        "level": "INFO",
                        "handlers": main_handlers,
                        "propagate": False
                    },
                    "webapi": {
                        "level": "INFO",
                        "handlers": webapi_handlers,
                        "propagate": False
                    },
                    "worker": {
                        "level": "DEBUG",
                        "handlers": worker_handlers,
                        "propagate": False
                    },
                    "uvicorn": {
                        "level": "INFO",
                        "handlers": webapi_handlers,
                        "propagate": False
                    },
                    "fastapi": {
                        "level": "INFO",
                        "handlers": webapi_handlers,
                        "propagate": False
                    },
                    "app": {
                        "level": "INFO",
                        "handlers": main_handlers,
                        "propagate": False
                    },
                    "app.routers": {
                        "level": "INFO",
                        "handlers": webapi_handlers,
                        "propagate": False
                    },
                    "app.middleware": {
                        "level": "INFO",
                        "handlers": webapi_handlers,
                        "propagate": False
                    },
                },
                "root": {"level": level, "handlers": main_handlers},
            }

            toml_loggers = logging_root.get("loggers", {})
            for lg_name, lg_cfg in toml_loggers.items():
                lg_level = lg_cfg.get("level")
                if not lg_level:
                    continue
                if lg_name in logging_config["loggers"]:
                    logging_config["loggers"][lg_name]["level"] = lg_level
                else:
                    logging_config["loggers"][lg_name] = {"level": lg_level}

            logging.config.dictConfig(logging_config)
            logging.getLogger("webapi").info(f"Logging configured from {cfg_path}")
            return
    except Exception as e:
        logging.getLogger("webapi").warning(f"Failed to load logging.toml, fallback to defaults: {e}")

    log_dir = get_logs_dir(settings.RUNTIME_BASE_DIR)

    handler_class = "concurrent_log_handler.ConcurrentRotatingFileHandler" if _USE_CONCURRENT_HANDLER else "logging.handlers.RotatingFileHandler"

    logging_config = {
        "version": 1,
        "disable_existing_loggers": False,
        "filters": {"request_context": {"()": "app.core.logging_context.LoggingContextFilter"}},
        "formatters": {
            "default": {
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s trace=%(trace_id)s",
                "datefmt": "%Y-%m-%d %H:%M:%S",
            },
            "detailed": {
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(pathname)s:%(lineno)d - %(message)s trace=%(trace_id)s",
                "datefmt": "%Y-%m-%d %H:%M:%S",
            },
        },
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "formatter": "default",
                "level": log_level,
                "filters": ["request_context"],
                "stream": sys.stdout,
            },
            "file": {
                "class": handler_class,
                "formatter": "detailed",
                "level": "DEBUG",
                "filters": ["request_context"],
                "filename": str(log_dir / "webapi.log"),
                "maxBytes": 10485760,
                "backupCount": 5,
                "encoding": "utf-8",
            },
            "worker_file": {
                "class": handler_class,
                "formatter": "detailed",
                "level": "DEBUG",
                "filters": ["request_context"],
                "filename": str(log_dir / "worker.log"),
                "maxBytes": 10485760,
                "backupCount": 5,
                "encoding": "utf-8",
            },
            "error_file": {
                "class": handler_class,
                "formatter": "detailed",
                "level": "ERROR",
                "filters": ["request_context"],
                "filename": str(log_dir / "error.log"),
                "maxBytes": 10485760,
                "backupCount": 5,
                "encoding": "utf-8",
            },
        },
        "loggers": {
            "webapi": {"level": "INFO", "handlers": ["console", "file", "error_file"], "propagate": False},
            "app.routers": {"level": "INFO", "handlers": ["console", "file", "error_file"], "propagate": False},
            "app.middleware": {"level": "INFO", "handlers": ["console", "file", "error_file"], "propagate": False},
            "worker": {"level": "DEBUG", "handlers": ["console", "worker_file", "error_file"], "propagate": False},
            "uvicorn": {"level": "INFO", "handlers": ["console", "file", "error_file"], "propagate": False},
            "fastapi": {"level": "INFO", "handlers": ["console", "file", "error_file"], "propagate": False},
        },
        "root": {"level": log_level, "handlers": ["console", "file", "error_file"]},
    }

    logging.config.dictConfig(logging_config)
    logging.getLogger("webapi").info("Logging configured successfully (built-in)")
