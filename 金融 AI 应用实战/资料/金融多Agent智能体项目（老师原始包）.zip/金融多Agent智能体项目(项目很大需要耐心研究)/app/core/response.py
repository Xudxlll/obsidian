from typing import Any, Optional, Dict
from app.utils.timezone import now_tz

def ok(data: Any = None, message: str = "ok", data_code: Optional[int] = None) -> Dict[str, Any]:
    resp = {
        "success": True,
        "data": data,
        "message": message,
        "timestamp": now_tz().isoformat()
    }
    if data_code is not None:
        resp["data_code"] = data_code
    return resp

def fail(
    message: str = "error",
    code: int = 500,
    data: Any = None,
    data_code: Optional[int] = None,
) -> Dict[str, Any]:

    resp = {
        "success": False,
        "data": data,
        "message": message,
        "code": code,
        "timestamp": now_tz().isoformat()
    }
    if data_code is not None:
        resp["data_code"] = data_code
    return resp

def safe_error_message(e: Exception, default: str = "操作失败，请稍后重试") -> str:

    try:
        from app.core.config import settings
        if getattr(settings, "DEBUG", False):
            return f"{default}: {str(e)}"
    except ImportError:
        pass
    return default
