from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable, Optional, TypeVar

T = TypeVar("T")

_default_logger = logging.getLogger("app.error_handling")

def _resolve_logger(logger: Optional[logging.Logger]) -> logging.Logger:
    return logger if logger is not None else _default_logger

def _validate_catch(catch: tuple) -> None:
    if not catch:
        raise ValueError("catch 不能为空元组")
    if BaseException in catch and Exception not in catch:
        raise ValueError("禁止捕获 BaseException 但忽略 Exception")

def safe_execute(
    func: Callable[..., T],
    *args: Any,
    default: Any = None,
    log_level: int = logging.WARNING,
    context: str = "",
    logger: Optional[logging.Logger] = None,
    catch: tuple = (Exception,),
    **kwargs: Any,
) -> T:

    _validate_catch(catch)
    log = _resolve_logger(logger)
    ctx = context or f"{func.__module__}.{func.__qualname__}"
    try:
        return func(*args, **kwargs)
    except catch as exc:
        log.log(
            log_level,
            "safe_execute[%s] 异常: %s: %s",
            ctx,
            type(exc).__name__,
            exc,
            exc_info=log_level <= logging.DEBUG,
        )
        return default

async def safe_execute_async(
    coro: Awaitable[T],
    *,
    default: Any = None,
    log_level: int = logging.WARNING,
    context: str = "",
    logger: Optional[logging.Logger] = None,
    catch: tuple = (Exception,),
) -> T:

    _validate_catch(catch)
    log = _resolve_logger(logger)
    ctx = context or "anonymous"
    try:
        return await coro
    except catch as exc:
        log.log(
            log_level,
            "safe_execute_async[%s] 异常: %s: %s",
            ctx,
            type(exc).__name__,
            exc,
            exc_info=log_level <= logging.DEBUG,
        )
        return default
