import json
import os
import tempfile
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger("app.config_bridge")

async def bridge_config_to_env() -> bool:

    try:
        logger.info("开始桥接配置到环境变量...")
        bridged_count = 0

        mongodb_conn_str = os.getenv("MONGODB_CONNECTION_STRING")
        if mongodb_conn_str:
            os.environ["MONGODB_CONNECTION_STRING"] = mongodb_conn_str
            logger.info("  MONGODB_CONNECTION_STRING: 已配置")
            bridged_count += 1

        mongodb_db_name = os.getenv("MONGODB_DATABASE_NAME", "zhenshabi")
        os.environ["MONGODB_DATABASE_NAME"] = mongodb_db_name
        logger.info(f"  MONGODB_DATABASE_NAME={mongodb_db_name}")
        bridged_count += 1

        try:
            from app.services.config_service import config_service

            system_config = await config_service.get_system_config()
            if system_config:
                if system_config.default_llm:
                    os.environ["ZHENSHABI_DEFAULT_MODEL"] = system_config.default_llm
                    logger.info(f"  ZHENSHABI_DEFAULT_MODEL={system_config.default_llm}")
                    bridged_count += 1

                ss = system_config.system_settings or {}
                for model_key, env_name in [
                    ("analyst_model", "ZHENSHABI_ANALYST_MODEL"),
                    ("debate_model", "ZHENSHABI_DEBATE_MODEL"),
                ]:
                    val = ss.get(model_key)
                    if val:
                        os.environ[env_name] = val
                        logger.info(f"  {env_name}={val}")
                        bridged_count += 1
            else:
                logger.warning("  未找到激活的系统配置，模型将使用代码默认值")
        except Exception as e:
            logger.error(f"桥接系统配置失败: {e}", exc_info=True)

        logger.info(f"配置桥接完成，共桥接 {bridged_count} 项配置")
        return True
    except Exception as e:
        logger.error(f"配置桥接失败: {e}", exc_info=True)
        return False

def get_bridged_model(model_type: str = "default") -> Optional[str]:
    key = {"analyst": "ZHENSHABI_ANALYST_MODEL", "debate": "ZHENSHABI_DEBATE_MODEL"}.get(
        model_type, "ZHENSHABI_DEFAULT_MODEL"
    )
    return os.environ.get(key)

def clear_bridged_config():
    keys_to_clear = [
        "ZHENSHABI_DEFAULT_MODEL", "ZHENSHABI_ANALYST_MODEL",
        "ZHENSHABI_DEBATE_MODEL",
    ]
    for key in keys_to_clear:
        os.environ.pop(key, None)
    logger.info("已清除所有桥接的配置")

async def reload_bridged_config():
    logger.info("重新加载配置桥接...")
    clear_bridged_config()
    return await bridge_config_to_env()

async def sync_pricing_config_now() -> bool:
    try:
        from app.services.config_service import config_service
        system_config = await config_service.get_system_config()
        if not system_config:
            logger.warning("sync_pricing_config_now: 未找到系统配置")
            return False

        pricing_configs = []
        for cfg in system_config.llm_configs:
            if cfg.enabled:
                pricing_configs.append({
                    "provider": cfg.provider.value if hasattr(cfg.provider, "value") else str(cfg.provider),
                    "model_name": cfg.model_name,
                    "input_price_per_1k": cfg.input_price_per_1k or 0.0,
                    "output_price_per_1k": cfg.output_price_per_1k or 0.0,
                    "currency": cfg.currency or "CNY",
                })

        config_dir = Path(__file__).parent.parent.parent / "config"
        config_dir.mkdir(exist_ok=True)
        pricing_file = config_dir / "pricing.json"

        fd, tmp_path = tempfile.mkstemp(
            dir=str(config_dir), prefix=".pricing_", suffix=".json.tmp"
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(pricing_configs, f, ensure_ascii=False, indent=2)
            os.replace(tmp_path, str(pricing_file))
        except BaseException:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise

        logger.info(f"定价配置已写入 {pricing_file}: {len(pricing_configs)} 个模型")
        return True
    except Exception as e:
        logger.error(f"sync_pricing_config_now 失败: {e}", exc_info=True)
        return False

__all__ = [
    "bridge_config_to_env",
    "get_bridged_model",
    "clear_bridged_config",
    "reload_bridged_config",
    "sync_pricing_config_now",
]
