import shutil
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

def ensure_config_files():

    try:
        project_root = Path(__file__).resolve().parents[2]
        config_dir = project_root / "config"
        install_dir = project_root / "config" / "defaults"

        logger.info("=" * 60)
        logger.info("🔧 开始检查配置文件...")

        config_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"📁 配置目录: {config_dir}")

        initialized_count = 0
        skipped_count = 0

        for phase in range(1, 5):
            filename = f"phase{phase}_agents_config.yaml"
            agent_config_src = install_dir / filename
            agent_config_dst = config_dir / "agents" / filename
            
            if agent_config_src.exists():
                if _handle_config_file(agent_config_src, agent_config_dst, f"Agent配置(Phase{phase})"):
                    initialized_count += 1
                else:
                    skipped_count += 1

        mcp_config_src = install_dir / "mcp.json"
        mcp_config_dst = config_dir / "mcp.json"

        if _handle_config_file(mcp_config_src, mcp_config_dst, "MCP配置"):
            initialized_count += 1
        else:
            skipped_count += 1

        logger.info("=" * 60)
        if initialized_count > 0:
            logger.info(f"✅ 配置初始化完成: 初始化了 {initialized_count} 个配置文件")
        if skipped_count > 0:
            logger.info(f"🔒 已存在配置: 跳过了 {skipped_count} 个配置文件")
        logger.info("=" * 60)

        return True

    except Exception as e:
        logger.error(f"❌ 配置文件初始化失败: {e}")
        return False

def _handle_config_file(src: Path, dst: Path, config_name: str) -> bool:

    try:
        dst.parent.mkdir(parents=True, exist_ok=True)

        if dst.exists():
            logger.info(f"🔒 {config_name}已存在，跳过初始化: {dst.name}")
            return False

        if not src.exists():
            logger.warning(f"⚠️ 默认{config_name}文件不存在: {src}")
            return False

        shutil.copy2(src, dst)
        logger.info(f"✅ {config_name}初始化成功: {dst.name}")
        return True

    except Exception as e:
        logger.error(f"❌ {config_name}初始化失败: {e}")
        return False
