import asyncio
import functools
import logging
from typing import Any, Awaitable, Callable, Optional, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar("T")
R = TypeVar("R")

_main_loop: Optional[asyncio.AbstractEventLoop] = None

def set_main_loop(loop: asyncio.AbstractEventLoop) -> None:
    global _main_loop
    _main_loop = loop

def get_main_loop() -> Optional[asyncio.AbstractEventLoop]:
    return _main_loop

def run_async(coro: Awaitable[T]) -> T:

    main_loop = _main_loop
    if main_loop is not None and main_loop.is_running():
        try:
            current_loop = asyncio.get_running_loop()
        except RuntimeError:
            current_loop = None

        if current_loop is main_loop:
            raise RuntimeError(
                "run_async() 不能在主线程的事件循环中调用。"
                "请直接 await 协程，或使用 run_in_executor 在 worker thread 中调用 run_async。"
            )

        future = asyncio.run_coroutine_threadsafe(coro, main_loop)
        return future.result(timeout=60)

    return asyncio.run(coro)

def run_async_fire_and_forget(coro: Awaitable[T]) -> None:

    main_loop = _main_loop
    if main_loop is not None and main_loop.is_running():
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            asyncio.run_coroutine_threadsafe(coro, main_loop)
            return

    try:
        asyncio.run(coro)
    except Exception as e:
        logger.debug(f"run_async_fire_and_forget 执行失败: {e}")

async def ainvoke(llm: Any, messages: Any, **kwargs: Any) -> Any:

    if hasattr(llm, "ainvoke"):
        return await llm.ainvoke(messages, **kwargs)
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(
        None, lambda: llm.invoke(messages, **kwargs)
    )

def detect_nested_loop_and_raise(context: str = "") -> None:

    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return
    raise RuntimeError(
        f"检测到嵌套事件循环：当前线程已运行事件循环，禁止在 async 上下文中调用此同步函数。"
        f" context={context!r}。请改用对应的 async 版本，或通过 run_in_executor 调度。"
    )

def sync_only(func: Callable[..., T]) -> Callable[..., T]:

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> T:
        detect_nested_loop_and_raise(
            context=f"{func.__module__}.{func.__qualname__}"
        )
        return func(*args, **kwargs)

    return wrapper

async def run_in_thread(
    func: Callable[..., R], *args: Any, **kwargs: Any
) -> R:

    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(
        None, functools.partial(func, *args, **kwargs)
    )
