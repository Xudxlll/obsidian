import os
from typing import Any

def get_env(key: str, default: Any = None) -> Any:

    os_val = os.environ.get(key)
    if os_val is not None and os_val != "":
        return os_val

    try:
        from app.core.config import settings

        val = getattr(settings, key, None)
        if val is not None and val != "":
            return val
    except Exception:
        pass

    return default

def has_env_var(key: str) -> bool:

    return key in os.environ

def get_raw_env(key: str, default: Any = None) -> Any:

    return os.environ.get(key, default)
