import json
import logging
import threading
import uuid
from typing import Optional
from redis.asyncio import Redis

logger = logging.getLogger(__name__)

def get_redis():
    from app.core.database import get_redis_client
    client = get_redis_client()
    if client is None:
        raise RuntimeError("Redis 未初始化，请先调用 init_database()")
    return client

class RedisKeys:
    
    USER_PENDING_QUEUE = "user:{user_id}:pending"
    USER_PROCESSING_SET = "user:{user_id}:processing"
    GLOBAL_PENDING_QUEUE = "global:pending"
    GLOBAL_PROCESSING_SET = "global:processing"
    
    TASK_PROGRESS = "task:{task_id}:progress"
    TASK_RESULT = "task:{task_id}:result"
    TASK_LOCK = "task:{task_id}:lock"
    
    BATCH_PROGRESS = "batch:{batch_id}:progress"
    BATCH_TASKS = "batch:{batch_id}:tasks"
    BATCH_LOCK = "batch:{batch_id}:lock"
    
    USER_SESSION = "session:{session_id}"
    USER_RATE_LIMIT = "rate_limit:{user_id}:{endpoint}"
    USER_DAILY_QUOTA = "quota:{user_id}:{date}"
    
    QUEUE_STATS = "queue:stats"
    SYSTEM_CONFIG = "system:config"
    WORKER_HEARTBEAT = "worker:{worker_id}:heartbeat"
    
    SCREENING_CACHE = "screening:{cache_key}"
    ANALYSIS_CACHE = "analysis:{cache_key}"

class RedisService:

    def __init__(self):
        self._redis: Optional[Redis] = None

    @property
    def redis(self) -> Redis:
        current_client = get_redis()
        if self._redis is not current_client:
            self._redis = current_client
        return self._redis
    
    async def set_with_ttl(self, key: str, value: str, ttl: int = 3600):
        await self.redis.setex(key, ttl, value)
    
    async def get_json(self, key: str):
        value = await self.redis.get(key)
        if value:
            return json.loads(value)
        return None

    async def set_json(self, key: str, value: dict, ttl: int = None):
        json_str = json.dumps(value, ensure_ascii=False)
        if ttl:
            await self.redis.setex(key, ttl, json_str)
        else:
            await self.redis.set(key, json_str)
    
    async def increment_with_ttl(self, key: str, ttl: int = 3600) -> int:
        lua_script = """
        local count = redis.call('INCR', KEYS[1])
        if count == 1 then
            redis.call('EXPIRE', KEYS[1], ARGV[1])
        end
        return count
        """
        result = await self.redis.eval(lua_script, 1, key, ttl)
        return int(result)

    async def check_and_increment_quota(
        self, key: str, max_quota: int, ttl: int = 86400
    ) -> dict:

        lua_script = """
        local current = tonumber(redis.call('GET', KEYS[1]) or '0')
        local max_quota = tonumber(ARGV[1])
        local ttl = tonumber(ARGV[2])
        if current >= max_quota then
            return {0, current, max_quota}
        end
        local new_count = redis.call('INCR', KEYS[1])
        if new_count == 1 then
            redis.call('EXPIRE', KEYS[1], ttl)
        end
        return {1, new_count, max_quota}
        """
        result = await self.redis.eval(lua_script, 1, key, max_quota, ttl)
        return {
            "allowed": bool(result[0]),
            "current": int(result[1]),
            "max_quota": int(result[2]),
        }
    
    async def add_to_queue(self, queue_key: str, item: dict):
        await self.redis.lpush(queue_key, json.dumps(item, ensure_ascii=False))

    async def pop_from_queue(self, queue_key: str, timeout: int = 1):
        result = await self.redis.brpop(queue_key, timeout=timeout)
        if result:
            return json.loads(result[1])
        return None
    
    async def get_queue_length(self, queue_key: str):
        return await self.redis.llen(queue_key)
    
    async def add_to_set(self, set_key: str, value: str):
        await self.redis.sadd(set_key, value)
    
    async def remove_from_set(self, set_key: str, value: str):
        await self.redis.srem(set_key, value)
    
    async def is_in_set(self, set_key: str, value: str):
        return await self.redis.sismember(set_key, value)
    
    async def get_set_size(self, set_key: str):
        return await self.redis.scard(set_key)
    
    async def acquire_lock(self, lock_key: str, timeout: int = 30):
        lock_value = str(uuid.uuid4())
        acquired = await self.redis.set(lock_key, lock_value, nx=True, ex=timeout)
        if acquired:
            return lock_value
        return None

    async def extend_lock(self, lock_key: str, lock_value: str, additional_seconds: int = 30) -> bool:
        lua_script = """
        if redis.call("get", KEYS[1]) == ARGV[1] then
            return redis.call("expire", KEYS[1], ARGV[2])
        else
            return 0
        end
        """
        result = await self.redis.eval(lua_script, 1, lock_key, lock_value, additional_seconds)
        return bool(result)
    
    async def release_lock(self, lock_key: str, lock_value: str):
        lua_script = """
        if redis.call("get", KEYS[1]) == ARGV[1] then
            return redis.call("del", KEYS[1])
        else
            return 0
        end
        """
        return await self.redis.eval(lua_script, 1, lock_key, lock_value)

    async def ping(self) -> bool:
        try:
            return bool(await self.redis.ping())
        except Exception:
            return False

redis_service: Optional[RedisService] = None
_redis_service_lock = threading.Lock()

def get_redis_service() -> RedisService:
    global redis_service
    if redis_service is None:
        with _redis_service_lock:
            if redis_service is None:
                redis_service = RedisService()
    return redis_service
