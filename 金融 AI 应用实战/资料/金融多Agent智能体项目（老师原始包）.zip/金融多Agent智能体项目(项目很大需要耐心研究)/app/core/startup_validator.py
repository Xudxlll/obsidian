import os
import logging
from collections.abc import Callable
from typing import List, Optional
from dataclasses import dataclass
from enum import Enum

from app.utils.api_key_utils import is_valid_api_key
from app.core.config import settings

logger = logging.getLogger(__name__)

class ConfigLevel(Enum):
    REQUIRED = "required"
    RECOMMENDED = "recommended"
    OPTIONAL = "optional"

@dataclass
class ConfigItem:
    key: str
    level: ConfigLevel
    description: str
    example: Optional[str] = None
    help_url: Optional[str] = None
    validator: Optional[Callable] = None

@dataclass
class ValidationResult:
    success: bool
    missing_required: List[ConfigItem]
    missing_recommended: List[ConfigItem]
    invalid_configs: List[tuple[ConfigItem, str]]
    warnings: List[str]

class StartupValidator:
    
    REQUIRED_CONFIGS = []
    
    RECOMMENDED_CONFIGS = [
        ConfigItem(
            key="MONGODB_HOST",
            level=ConfigLevel.RECOMMENDED,
            description="MongoDB主机地址",
            example="localhost"
        ),
        ConfigItem(
            key="MONGODB_PORT",
            level=ConfigLevel.RECOMMENDED,
            description="MongoDB端口",
            example="27017",
            validator=lambda v: v.isdigit() and 1 <= int(v) <= 65535
        ),
        ConfigItem(
            key="MONGODB_DATABASE",
            level=ConfigLevel.RECOMMENDED,
            description="MongoDB数据库名称",
            example="zhenshabi"
        ),
        ConfigItem(
            key="REDIS_HOST",
            level=ConfigLevel.RECOMMENDED,
            description="Redis主机地址",
            example="localhost"
        ),
        ConfigItem(
            key="REDIS_PORT",
            level=ConfigLevel.RECOMMENDED,
            description="Redis端口",
            example="6379",
            validator=lambda v: v.isdigit() and 1 <= int(v) <= 65535
        ),
    ]
    
    def __init__(self):
        self.result = ValidationResult(
            success=True,
            missing_required=[],
            missing_recommended=[],
            invalid_configs=[],
            warnings=[]
        )

    def _is_valid_api_key(self, api_key: str) -> bool:
        return is_valid_api_key(api_key)

    def validate(self) -> ValidationResult:

        logger.info("🔍 开始验证启动配置...")
        
        self._validate_required_configs()
        
        self._validate_recommended_configs()
        
        self._check_security_configs()
        
        self.result.success = len(self.result.missing_required) == 0 and len(self.result.invalid_configs) == 0
        
        self._print_validation_result()
        
        return self.result
    
    def _validate_required_configs(self):
        for config in self.REQUIRED_CONFIGS:
            env_value = os.getenv(config.key)

            if not env_value:
                self.result.missing_required.append(config)
                logger.error(f"❌ 缺少必需配置: {config.key}（未在环境变量/.env 中设置）")
            elif config.validator and not config.validator(str(env_value)):
                self.result.invalid_configs.append((config, "配置值格式不正确"))
                logger.error(f"❌ 配置格式错误: {config.key}")
            else:
                logger.debug(f"✅ {config.key}: 已配置")
    
    def _validate_recommended_configs(self):
        for config in self.RECOMMENDED_CONFIGS:
            value = getattr(settings, config.key, None)

            if not value:
                self.result.missing_recommended.append(config)
                logger.debug(f"⚠️  缺少推荐配置: {config.key}")
            elif config.key.endswith(("_API_KEY", "_TOKEN")):
                if not self._is_valid_api_key(str(value)):
                    self.result.missing_recommended.append(config)
                    logger.debug(f"⚠️  {config.key} 配置为占位符，视为未配置")
                else:
                    logger.debug(f"✅ {config.key}: 已配置")
            else:
                logger.debug(f"✅ {config.key}: 已配置")
    
    def _check_security_configs(self):
        is_production = not bool(getattr(settings, "DEBUG", True))

        from app.core.config import is_using_default_secret

        for secret_key in ("JWT_SECRET", "CSRF_SECRET"):
            env_value = os.getenv(secret_key, "")

            if not env_value:
                self.result.warnings.append(
                    f"{secret_key} 未在环境变量中显式配置（将由 SecretService 自动生成并持久化）；"
                    f"建议在 .env 中显式设置以便多 worker 提前一致。"
                )
                continue

            if is_using_default_secret(secret_key):
                if is_production:
                    self.result.invalid_configs.append(
                        (
                            ConfigItem(
                                key=secret_key,
                                level=ConfigLevel.REQUIRED,
                                description="生产环境禁止使用默认/示例密钥",
                            ),
                            "使用了不安全的默认占位符（docker-*/change-me 等），请改为强随机值",
                        )
                    )
                    logger.error(
                        f"❌ {secret_key} 在生产模式下使用了不安全默认值，启动被拒绝"
                    )
                else:
                    self.result.warnings.append(
                        f"{secret_key} 使用了不安全默认值（{env_value[:16]}...），"
                        f"仅开发模式允许，生产部署前必须替换。"
                    )

        if is_production:
            logger.info("生产环境模式")
        else:
            logger.info("开发环境模式（DEBUG=true）")
    
    def _print_validation_result(self):
        logger.info("\n" + "=" * 70)
        logger.info("Zhenshabi Configuration Validation Result")
        logger.info("=" * 70)
        
        if self.result.missing_required:
            logger.info("\nMissing required configurations:")
            for config in self.result.missing_required:
                logger.info(f"   - {config.key}")
                logger.info(f"     Description: {config.description}")
                if config.example:
                    logger.info(f"     Example: {config.example}")
                if config.help_url:
                    logger.info(f"     Help: {config.help_url}")
        else:
            logger.info("\nAll required configurations are complete")

        if self.result.invalid_configs:
            logger.info("\nInvalid configurations:")
            for config, error in self.result.invalid_configs:
                logger.info(f"   - {config.key}: {error}")
                if config.example:
                    logger.info(f"     Example: {config.example}")

        if self.result.missing_recommended:
            logger.info("\nMissing recommended configurations (won't affect startup):")
            for config in self.result.missing_recommended:
                logger.info(f"   - {config.key}")
                logger.info(f"     Description: {config.description}")
                if config.help_url:
                    logger.info(f"     Get it from: {config.help_url}")

        if self.result.warnings:
            logger.info("\nSecurity warnings:")
            for warning in self.result.warnings:
                logger.info(f"   - {warning}")

        logger.info("\n" + "=" * 70)
        if self.result.success:
            logger.info("Configuration validation passed, system can start")
            if self.result.missing_recommended:
                logger.info("Tip: Configure recommended items for better functionality")
        else:
            logger.info("Configuration validation failed, please check the above items")
            logger.info("Configuration guide: docs/configuration_guide.md")
        logger.info("=" * 70 + "\n")
    
    def raise_if_failed(self):
        if not self.result.success:
            error_messages = []
            
            if self.result.missing_required:
                error_messages.append(
                    f"缺少必需配置: {', '.join(c.key for c in self.result.missing_required)}"
                )
            
            if self.result.invalid_configs:
                error_messages.append(
                    f"配置格式错误: {', '.join(c.key for c, _ in self.result.invalid_configs)}"
                )
            
            raise ConfigurationError(
                "配置验证失败:\n" + "\n".join(f"  • {msg}" for msg in error_messages) +
                "\n\n请检查 .env 文件并参考 docs/configuration_guide.md"
            )

class ConfigurationError(Exception):
    pass

def validate_startup_config() -> ValidationResult:

    validator = StartupValidator()
    result = validator.validate()
    validator.raise_if_failed()
    return result
