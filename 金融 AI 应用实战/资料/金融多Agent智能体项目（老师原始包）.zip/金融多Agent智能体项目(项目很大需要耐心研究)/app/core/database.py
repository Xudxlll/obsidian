import logging
import asyncio
import threading
from typing import Optional
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from pymongo import MongoClient
from pymongo.database import Database
from redis.asyncio import Redis, ConnectionPool
from .config import settings

logger = logging.getLogger(__name__)

mongo_client: Optional[AsyncIOMotorClient] = None
mongo_db: Optional[AsyncIOMotorDatabase] = None
redis_client: Optional[Redis] = None
redis_pool: Optional[ConnectionPool] = None

_sync_mongo_client: Optional[MongoClient] = None
_sync_mongo_db: Optional[Database] = None
_sync_mongo_lock = threading.Lock()

class DatabaseManager:

    def __init__(self):
        self.mongo_client: Optional[AsyncIOMotorClient] = None
        self.mongo_db: Optional[AsyncIOMotorDatabase] = None
        self.redis_client: Optional[Redis] = None
        self.redis_pool: Optional[ConnectionPool] = None
        self._mongo_healthy = False
        self._redis_healthy = False

    async def init_mongodb(self):
        try:
            logger.info("🔄 正在初始化MongoDB连接...")

            self.mongo_client = AsyncIOMotorClient(
                settings.MONGO_URI,
                maxPoolSize=settings.MONGO_MAX_CONNECTIONS,
                minPoolSize=settings.MONGO_MIN_CONNECTIONS,
                maxIdleTimeMS=30000,
                serverSelectionTimeoutMS=settings.MONGO_SERVER_SELECTION_TIMEOUT_MS,
                connectTimeoutMS=settings.MONGO_CONNECT_TIMEOUT_MS,
                socketTimeoutMS=settings.MONGO_SOCKET_TIMEOUT_MS,
                tz_aware=True,
            )

            self.mongo_db = self.mongo_client[settings.MONGO_DB]

            await self.mongo_client.admin.command('ping')
            self._mongo_healthy = True

            logger.info("✅ MongoDB连接成功建立")
            logger.info(f"📊 数据库: {settings.MONGO_DB}")
            logger.info(f"🔗 连接池: {settings.MONGO_MIN_CONNECTIONS}-{settings.MONGO_MAX_CONNECTIONS}")
            logger.info(f"⏱️  超时配置: connectTimeout={settings.MONGO_CONNECT_TIMEOUT_MS}ms, socketTimeout={settings.MONGO_SOCKET_TIMEOUT_MS}ms")

        except Exception as e:
            logger.error(f"❌ MongoDB连接失败: {e}")
            self._mongo_healthy = False
            raise

    async def init_redis(self):
        try:
            logger.info("🔄 正在初始化Redis连接...")

            self.redis_pool = ConnectionPool.from_url(
                settings.REDIS_URL,
                max_connections=settings.REDIS_MAX_CONNECTIONS,
                retry_on_timeout=settings.REDIS_RETRY_ON_TIMEOUT,
                decode_responses=True,
                socket_connect_timeout=5,
                socket_timeout=10,
                socket_keepalive=True,
            )

            self.redis_client = Redis(connection_pool=self.redis_pool)

            await self.redis_client.ping()
            self._redis_healthy = True

            logger.info("✅ Redis连接成功建立")
            logger.info(f"🔗 连接池大小: {settings.REDIS_MAX_CONNECTIONS}")

        except Exception as e:
            logger.error(f"❌ Redis连接失败: {e}")
            self._redis_healthy = False
            raise

    async def close_connections(self):
        global mongo_client, mongo_db, redis_client, redis_pool
        logger.info("🔄 正在关闭数据库连接...")

        if self.mongo_client:
            try:
                self.mongo_client.close()
                self._mongo_healthy = False
                self.mongo_client = None
                self.mongo_db = None
                mongo_client = None
                mongo_db = None
                logger.info("✅ MongoDB连接已关闭")
            except Exception as e:
                logger.error(f"❌ 关闭MongoDB连接时出错: {e}")

        if self.redis_client:
            try:
                await self.redis_client.close()
                self._redis_healthy = False
                self.redis_client = None
                redis_client = None
                logger.info("✅ Redis连接已关闭")
            except Exception as e:
                logger.error(f"❌ 关闭Redis连接时出错: {e}")

        if self.redis_pool:
            try:
                await self.redis_pool.disconnect()
                self.redis_pool = None
                redis_pool = None
                logger.info("✅ Redis连接池已关闭")
            except Exception as e:
                logger.error(f"❌ 关闭Redis连接池时出错: {e}")

    async def health_check(self) -> dict:
        health_status = {
            "mongodb": {"status": "unknown", "details": None},
            "redis": {"status": "unknown", "details": None}
        }

        try:
            if self.mongo_client:
                result = await self.mongo_client.admin.command('ping')
                health_status["mongodb"] = {
                    "status": "healthy",
                    "details": {"ping": result, "database": settings.MONGO_DB}
                }
                self._mongo_healthy = True
            else:
                health_status["mongodb"]["status"] = "disconnected"
        except Exception as e:
            logger.error(f"MongoDB health check failed: {e}")
            health_status["mongodb"] = {
                "status": "unhealthy",
                "details": {"error": "MongoDB 连接异常，请检查服务状态"}
            }
            self._mongo_healthy = False

        try:
            if self.redis_client:
                result = await self.redis_client.ping()
                health_status["redis"] = {
                    "status": "healthy",
                    "details": {"ping": result}
                }
                self._redis_healthy = True
            else:
                health_status["redis"]["status"] = "disconnected"
        except Exception as e:
            logger.error(f"Redis health check failed: {e}")
            health_status["redis"] = {
                "status": "unhealthy",
                "details": {"error": "Redis 连接异常，请检查服务状态"}
            }
            self._redis_healthy = False

        return health_status

    @property
    def is_healthy(self) -> bool:
        return self._mongo_healthy and self._redis_healthy

db_manager = DatabaseManager()

async def init_database():
    global mongo_client, mongo_db, redis_client, redis_pool

    try:
        mongo_task = db_manager.init_mongodb()
        redis_task = db_manager.init_redis()
        await asyncio.gather(mongo_task, redis_task)

        mongo_client = db_manager.mongo_client
        mongo_db = db_manager.mongo_db
        redis_client = db_manager.redis_client
        redis_pool = db_manager.redis_pool

        logger.info("🎉 所有数据库连接初始化完成")

        try:
            from app.core.config_initializer import ensure_config_files
            await asyncio.to_thread(ensure_config_files)
        except Exception as e:
            logger.warning(f"⚠️ 配置文件初始化失败: {e}")

        await init_database_views_and_indexes()

    except Exception as e:
        logger.error(f"💥 数据库初始化失败: {e}")
        raise

async def init_database_views_and_indexes():
    try:
        db = get_mongo_db()

        await asyncio.gather(
            create_stock_screening_view(db),
            create_database_indexes(db),
        )

        logger.info("✅ 数据库视图和索引初始化完成")

    except Exception as e:
        logger.warning(f"⚠️ 数据库视图和索引初始化失败: {e}")

async def create_stock_screening_view(db):

    pipeline = [
        {
            "$project": {
                "symbol": 1,
                "name": 1,
                "industry": 1,
                "area": 1,
                "market": 1,
                "list_date": 1,
                "data_source": 1,
                "total_mv": 1,
                "circ_mv": 1,
                "pe": 1,
                "pb": 1,
                "pe_ttm": 1,
                "pb_mrq": 1,
                "ps": 1,
                "ps_ttm": 1,
                "turnover_rate": 1,
                "volume_ratio": 1,
                "total_share": 1,
                "float_share": 1,
                "updated_at": 1
            }
        }
    ]

    try:
        await db.command({
            "collMod": "stock_screening_view",
            "viewOn": "stock_basic_info",
            "pipeline": pipeline,
        })
        logger.info("✅ 视图 stock_screening_view 已更新（collMod 幂等）")
    except Exception as e:
        msg = str(e)
        if "namespace not found" in msg or "ns doesn't exist" in msg or "code 26" in msg:
            try:
                await db.command({
                    "create": "stock_screening_view",
                    "viewOn": "stock_basic_info",
                    "pipeline": pipeline,
                })
                logger.info("✅ 视图 stock_screening_view 创建成功")
            except Exception as create_err:
                logger.warning(f"⚠️ 创建视图失败: {create_err}")
        else:
            logger.warning(f"⚠️ 更新视图失败（非命名空间错误，跳过）: {e}")

async def create_database_indexes(db):

    try:
        from app.data.storage.mongo.collections import get_all_collections
        from app.data.storage.mongo.index_definitions import (
            INDEX_DEFINITIONS,
            default_index_name,
            get_legacy_index_names,
        )

        legacy_index_names = get_legacy_index_names()

        for market in ("CN", "HK", "US"):
            try:
                collection_map = get_all_collections(market)
            except Exception as e:
                logger.warning(f"获取 {market} 市场集合映射失败: {e}")
                continue

            for data_type, collection_name in collection_map.items():
                collection = db[collection_name]

                legacy_names = ["code_1_source_1", "code_1"]
                legacy_names.extend(legacy_index_names.get(data_type, []))
                for idx_name in legacy_names:
                    try:
                        await collection.drop_index(idx_name)
                        logger.info(f"已删除旧索引 {collection_name}.{idx_name}")
                    except Exception:
                        pass

                for fields, unique in INDEX_DEFINITIONS.get(data_type, []):
                    try:
                        await collection.create_index(fields, unique=unique)
                    except Exception as e:
                        logger.warning(
                            f"索引 {collection_name}.{default_index_name(fields)} "
                            f"创建失败（可能存在重复数据，请运行去重迁移脚本）: {e}"
                        )
            logger.info(f"✅ {market} 市场业务集合索引创建完成")

        try:
            basic_info = db["stock_basic_info"]
            await basic_info.create_index([("industry", 1)])
            await basic_info.create_index([("total_mv", -1)])
            await basic_info.create_index([("pe", 1)])
            await basic_info.create_index([("pb", 1)])
        except Exception as e:
            logger.warning(f"创建 stock_basic_info 辅助索引失败: {e}")

        try:
            users = db["users"]
            await users.create_index([("username", 1)], unique=True)
            await users.create_index([("email", 1)], unique=True)
            logger.info("✅ users 集合索引创建完成")
        except Exception as e:
            logger.warning(f"⚠️ 创建 users 索引失败: {e}")

        try:
            tasks = db["analysis_tasks"]
            await tasks.create_index([("task_id", 1)], unique=True)
            await tasks.create_index([("user_id", 1), ("created_at", -1)])
            await tasks.create_index([("status", 1), ("created_at", -1)])
            logger.info("✅ analysis_tasks 集合索引创建完成")
        except Exception as e:
            logger.warning(f"⚠️ 创建 analysis_tasks 索引失败: {e}")

        try:
            events = db["analysis_events"]
            await events.create_index([("task_id", 1), ("seq", 1)])
            logger.info("✅ analysis_events 集合索引创建完成")
        except Exception as e:
            logger.warning(f"⚠️ 创建 analysis_events 索引失败: {e}")

        try:
            reports = db["analysis_reports"]
            await reports.create_index([("task_id", 1)])
            await reports.create_index([("analysis_id", 1)], unique=True)
            await reports.create_index([("stock_symbol", 1), ("created_at", -1)])
            await reports.create_index([("created_at", -1)])
            await reports.create_index([("market_type", 1)])
            await reports.create_index([("user_id", 1), ("created_at", -1)])
            logger.info("✅ analysis_reports 集合索引创建完成")
        except Exception as e:
            logger.warning(f"⚠️ 创建 analysis_reports 索引失败: {e}")

        try:
            op_logs = db["operation_logs"]
            await op_logs.create_index([("timestamp", -1)])
            await op_logs.create_index([("user_id", 1), ("timestamp", -1)])
            logger.info("✅ operation_logs 集合索引创建完成")
        except Exception as e:
            logger.warning(f"⚠️ 创建 operation_logs 索引失败: {e}")

        try:
            configs = db["system_configs"]
            await configs.create_index([("is_active", 1), ("version", -1)])
            logger.info("✅ system_configs 集合索引创建完成")
        except Exception as e:
            logger.warning(f"⚠️ 创建 system_configs 索引失败: {e}")

        try:
            providers = db["llm_providers"]
            await providers.create_index([("name", 1)], unique=True)
            logger.info("✅ llm_providers 集合索引创建完成")
        except Exception as e:
            logger.warning(f"⚠️ 创建 llm_providers 索引失败: {e}")

        try:
            notifs = db["notifications"]
            await notifs.create_index([("user_id", 1), ("created_at", -1)])
            await notifs.create_index([("user_id", 1), ("status", 1)])
            logger.info("✅ notifications 集合索引创建完成")
        except Exception as e:
            logger.warning(f"⚠️ 创建 notifications 索引失败: {e}")

        try:
            token_usage = db["token_usage"]
            await token_usage.create_index([("timestamp", -1), ("provider", 1)])
            logger.info("✅ token_usage 集合索引创建完成")
        except Exception as e:
            logger.warning(f"⚠️ 创建 token_usage 索引失败: {e}")

        logger.info("✅ 数据库索引创建完成")

    except Exception as e:
        logger.warning(f"⚠️ 创建索引失败: {e}")

async def close_database():
    global mongo_client, mongo_db, redis_client, redis_pool

    await db_manager.close_connections()
    close_mongo_db_sync()

    mongo_client = None
    mongo_db = None
    redis_client = None
    redis_pool = None

def get_mongo_client() -> AsyncIOMotorClient:
    if mongo_client is None:
        raise RuntimeError("MongoDB客户端未初始化")
    return mongo_client

def get_mongo_db() -> AsyncIOMotorDatabase:
    if mongo_db is None:
        raise RuntimeError("MongoDB数据库未初始化")
    return mongo_db

def get_mongo_db_sync() -> Database:
    global _sync_mongo_client, _sync_mongo_db

    if _sync_mongo_db is not None:
        return _sync_mongo_db

    with _sync_mongo_lock:
        if _sync_mongo_db is not None:
            return _sync_mongo_db

        if _sync_mongo_client is None:
            _sync_mongo_client = MongoClient(
                settings.MONGO_URI,
                maxPoolSize=min(10, settings.MONGO_MAX_CONNECTIONS),
                minPoolSize=min(1, settings.MONGO_MIN_CONNECTIONS),
                maxIdleTimeMS=30000,
                serverSelectionTimeoutMS=settings.MONGO_SERVER_SELECTION_TIMEOUT_MS,
                connectTimeoutMS=settings.MONGO_CONNECT_TIMEOUT_MS,
                socketTimeoutMS=settings.MONGO_SOCKET_TIMEOUT_MS,
            )

        _sync_mongo_db = _sync_mongo_client[settings.MONGO_DB]
        return _sync_mongo_db

def close_mongo_db_sync():
    global _sync_mongo_client, _sync_mongo_db

    with _sync_mongo_lock:
        try:
            if _sync_mongo_client is not None:
                _sync_mongo_client.close()
                _sync_mongo_client = None
                _sync_mongo_db = None
                logger.info("✅ 同步MongoDB连接已关闭")
        except Exception as exc:
            logger.error(f"❌ 关闭同步MongoDB连接失败: {exc}")

def get_redis_client() -> Redis:
    if redis_client is None:
        raise RuntimeError("Redis客户端未初始化")
    return redis_client

async def get_database_health() -> dict:
    return await db_manager.health_check()

init_db = init_database
close_db = close_database
