from pathlib import Path
from typing import Annotated, Dict, List
from urllib.parse import quote_plus
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict
import json
import logging as _logging
import os
import secrets
import shutil
import threading
import warnings

_IS_CONTAINER_ENV = os.getenv("DOCKER_CONTAINER", "").lower() in ("true", "1", "yes")
if not _IS_CONTAINER_ENV:
    _BOOT_ENV_PATH = Path(__file__).resolve().parent.parent.parent / ".env"
    _BOOT_ENV_EXAMPLE = _BOOT_ENV_PATH.parent / ".env.example"
    if not _BOOT_ENV_PATH.exists() and _BOOT_ENV_EXAMPLE.exists():
        shutil.copy2(_BOOT_ENV_EXAMPLE, _BOOT_ENV_PATH)
        _logging.getLogger("app.config").warning(
            "已自动从 .env.example 创建 .env，请根据需要调整数据库连接配置"
        )

_LEGACY_ENV_ALIASES = {
    "API_HOST": "HOST",
    "API_PORT": "PORT",
    "API_DEBUG": "DEBUG",
}
for _legacy, _new in _LEGACY_ENV_ALIASES.items():
    if _new not in os.environ and _legacy in os.environ:
        os.environ[_new] = os.environ[_legacy]
        warnings.warn(
            f"Environment variable {_legacy} is deprecated; use {_new} instead.",
            DeprecationWarning,
            stacklevel=2,
        )

_runtime_secret_cache: Dict[str, str] = {}
_runtime_secret_lock = threading.Lock()

def _runtime_secret(name: str) -> str:

    configured = os.getenv(name)
    if configured:
        return configured
    with _runtime_secret_lock:
        if name not in _runtime_secret_cache:
            _runtime_secret_cache[name] = secrets.token_urlsafe(32)
        return _runtime_secret_cache[name]

class Settings(BaseSettings):
    DEBUG: bool = Field(default=False)
    HOST: str = Field(default="0.0.0.0")
    PORT: int = Field(default=8000)
    ALLOWED_ORIGINS: Annotated[List[str], NoDecode] = Field(
        default_factory=lambda: ["http://localhost:3000", "http://127.0.0.1:3000"]
    )
    ALLOWED_HOSTS: Annotated[List[str], NoDecode] = Field(default_factory=lambda: ["*"])

    RUNTIME_BASE_DIR: str = Field(default="runtime")

    MONGODB_HOST: str = Field(default="localhost")
    MONGODB_PORT: int = Field(default=27017)
    MONGODB_USERNAME: str = Field(default="")
    MONGODB_PASSWORD: str = Field(default="")
    MONGODB_DATABASE: str = Field(default="zhenshabi")
    MONGODB_AUTH_SOURCE: str = Field(default="admin")
    MONGO_MAX_CONNECTIONS: int = Field(default=100)
    MONGO_MIN_CONNECTIONS: int = Field(default=10)
    MONGO_CONNECT_TIMEOUT_MS: int = Field(default=30000)
    MONGO_SOCKET_TIMEOUT_MS: int = Field(default=60000)
    MONGO_SERVER_SELECTION_TIMEOUT_MS: int = Field(default=5000)

    @property
    def JWT_SECRET(self) -> str:

        value = os.getenv("JWT_SECRET")
        if value:
            return value
        return _runtime_secret("JWT_SECRET")

    @property
    def CSRF_SECRET(self) -> str:

        value = os.getenv("CSRF_SECRET")
        if value:
            return value
        return _runtime_secret("CSRF_SECRET")

    @property
    def MONGO_URI(self) -> str:

        if self.MONGODB_USERNAME and self.MONGODB_PASSWORD:
            user = quote_plus(self.MONGODB_USERNAME)
            pwd = quote_plus(self.MONGODB_PASSWORD)
            return (
                f"mongodb://{user}:{pwd}@{self.MONGODB_HOST}:{self.MONGODB_PORT}/"
                f"{self.MONGODB_DATABASE}?authSource={self.MONGODB_AUTH_SOURCE}"
            )
        return (
            f"mongodb://{self.MONGODB_HOST}:{self.MONGODB_PORT}/"
            f"{self.MONGODB_DATABASE}"
        )

    @property
    def MONGO_DB(self) -> str:
        return self.MONGODB_DATABASE

    REDIS_HOST: str = Field(default="localhost")
    REDIS_PORT: int = Field(default=6379)
    REDIS_PASSWORD: str = Field(default="")
    REDIS_DB: int = Field(default=0)
    REDIS_MAX_CONNECTIONS: int = Field(default=20)
    REDIS_RETRY_ON_TIMEOUT: bool = Field(default=True)

    @property
    def REDIS_URL(self) -> str:
        if self.REDIS_PASSWORD:
            pwd = quote_plus(self.REDIS_PASSWORD)
            return f"redis://:{pwd}@{self.REDIS_HOST}:{self.REDIS_PORT}/{self.REDIS_DB}"
        else:
            return f"redis://{self.REDIS_HOST}:{self.REDIS_PORT}/{self.REDIS_DB}"

    JWT_ALGORITHM: str = Field(default="HS256")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(default=60)
    REFRESH_TOKEN_EXPIRE_DAYS: int = Field(default=30)

    QUEUE_MAX_SIZE: int = Field(default=10000)
    QUEUE_VISIBILITY_TIMEOUT: int = Field(default=300)
    QUEUE_MAX_RETRIES: int = Field(default=3)
    WORKER_HEARTBEAT_INTERVAL: int = Field(default=30)

    QUEUE_POLL_INTERVAL_SECONDS: float = Field(default=1.0)
    QUEUE_CLEANUP_INTERVAL_SECONDS: float = Field(default=60.0)

    DEFAULT_USER_CONCURRENT_LIMIT: int = Field(default=3)
    GLOBAL_CONCURRENT_LIMIT: int = Field(default=50)
    DEFAULT_DAILY_QUOTA: int = Field(default=1000)

    RATE_LIMIT_ENABLED: bool = Field(default=True)
    DEFAULT_RATE_LIMIT: int = Field(default=100)

    LOG_LEVEL: str = Field(default="INFO")
    LOG_FORMAT: str = Field(default="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    LOG_FILE: str = Field(
        default="logs/zhenshabi.log",
        description="日志文件名，实际落盘路径由 settings.log_file_path 解析到 runtime/ 下",
    )

    HTTP_PROXY: str = Field(default="")
    HTTPS_PROXY: str = Field(default="")
    NO_PROXY: str = Field(
        default="localhost,127.0.0.1,eastmoney.com,push2.eastmoney.com,82.push2.eastmoney.com,82.push2delay.eastmoney.com,gtimg.cn,sinaimg.cn,api.tushare.pro,baostock.com"
    )

    MAX_UPLOAD_SIZE: int = Field(default=10 * 1024 * 1024)
    UPLOAD_DIR: str = Field(default="uploads")

    CACHE_TTL: int = Field(default=3600)
    SCREENING_CACHE_TTL: int = Field(default=1800)

    BCRYPT_ROUNDS: int = Field(default=12)
    SESSION_EXPIRE_HOURS: int = Field(default=24)

    TRUSTED_PROXIES: str = Field(default="127.0.0.1,::1")

    SSE_POLL_TIMEOUT_SECONDS: float = Field(default=1.0)
    SSE_HEARTBEAT_INTERVAL_SECONDS: int = Field(default=10)
    SSE_TASK_MAX_IDLE_SECONDS: int = Field(default=300)
    SSE_BATCH_POLL_INTERVAL_SECONDS: float = Field(default=2.0)
    SSE_BATCH_MAX_IDLE_SECONDS: int = Field(default=600)

    METRICS_ENABLED: bool = Field(default=True)
    HEALTH_CHECK_INTERVAL: int = Field(default=60)

    CONFIG_SOT: str = Field(default="file")

    SYNC_STOCK_BASICS_ENABLED: bool = Field(default=True)
    SYNC_STOCK_BASICS_CRON: str = Field(default="")
    SYNC_STOCK_BASICS_TIME: str = Field(default="06:30")
    TIMEZONE: str = Field(default="Asia/Shanghai")

    QUOTES_INGEST_ENABLED: bool = Field(default=True)
    QUOTES_INGEST_INTERVAL_SECONDS: int = Field(
        default=360,
        description="实时行情采集间隔（秒）。默认360秒（6分钟），免费用户建议>=300秒，付费用户可设置5-60秒"
    )
    QUOTES_BACKFILL_ON_STARTUP: bool = Field(default=True)
    QUOTES_BACKFILL_ON_OFFHOURS: bool = Field(default=True)

    QUOTES_ROTATION_ENABLED: bool = Field(
        default=True,
        description="启用接口轮换机制（Tushare → AKShare东方财富 → AKShare新浪财经）"
    )
    QUOTES_TUSHARE_HOURLY_LIMIT: int = Field(
        default=2,
        description="Tushare rt_k接口每小时调用次数限制（免费用户2次，付费用户可设置更高）"
    )
    QUOTES_AUTO_DETECT_TUSHARE_PERMISSION: bool = Field(
        default=True,
        description="自动检测Tushare rt_k接口权限，付费用户自动切换到高频模式（5秒）"
    )

    TUSHARE_TOKEN: str = Field(default="", description="Tushare API Token 兜底字段（市场专属 Token 未配置时使用）")
    TUSHARE_CN_TOKEN: str = Field(default="", description="A 股 Tushare Token（优先于 TUSHARE_TOKEN）")
    TUSHARE_HK_TOKEN: str = Field(default="", description="港股 Tushare Token（优先于 TUSHARE_TOKEN；积分门槛 ≥ 2000）")
    TUSHARE_US_TOKEN: str = Field(default="", description="美股 Tushare Token（优先于 TUSHARE_TOKEN；积分门槛 ≥ 120）")
    TUSHARE_ENABLED: bool = Field(default=True, description="启用Tushare数据源")
    TUSHARE_TIER: str = Field(default="standard", description="Tushare积分等级 (free/basic/standard/premium/vip)")
    TUSHARE_RATE_LIMIT_SAFETY_MARGIN: float = Field(default=0.8, ge=0.1, le=1.0, description="速率限制安全边际")

    TUSHARE_UNIFIED_ENABLED: bool = Field(default=True)
    TUSHARE_BASIC_INFO_SYNC_ENABLED: bool = Field(default=True)
    TUSHARE_BASIC_INFO_SYNC_CRON: str = Field(default="0 2 * * *")
    TUSHARE_QUOTES_SYNC_ENABLED: bool = Field(default=True)
    TUSHARE_QUOTES_SYNC_CRON: str = Field(default="*/5 9-15 * * 1-5")
    TUSHARE_HISTORICAL_SYNC_ENABLED: bool = Field(default=True)
    TUSHARE_HISTORICAL_SYNC_CRON: str = Field(default="0 16 * * 1-5")
    TUSHARE_FINANCIAL_SYNC_ENABLED: bool = Field(default=True)
    TUSHARE_FINANCIAL_SYNC_CRON: str = Field(default="0 3 * * 0")
    TUSHARE_STATUS_CHECK_ENABLED: bool = Field(default=True)
    TUSHARE_STATUS_CHECK_CRON: str = Field(default="0 * * * *")

    TUSHARE_INIT_HISTORICAL_DAYS: int = Field(default=365, ge=1, le=3650, description="初始化历史数据天数")
    TUSHARE_INIT_BATCH_SIZE: int = Field(default=100, ge=10, le=1000, description="初始化批处理大小")
    TUSHARE_INIT_AUTO_START: bool = Field(default=False, description="应用启动时自动检查并初始化数据")

    AKSHARE_UNIFIED_ENABLED: bool = Field(default=True, description="启用AKShare统一数据同步")
    AKSHARE_BASIC_INFO_SYNC_ENABLED: bool = Field(default=True, description="启用基础信息同步")
    AKSHARE_BASIC_INFO_SYNC_CRON: str = Field(default="0 3 * * *", description="基础信息同步CRON表达式")
    AKSHARE_QUOTES_SYNC_ENABLED: bool = Field(default=True, description="启用行情同步")
    AKSHARE_QUOTES_SYNC_CRON: str = Field(default="*/30 9-15 * * 1-5", description="行情同步CRON表达式")
    AKSHARE_HISTORICAL_SYNC_ENABLED: bool = Field(default=True, description="启用历史数据同步")
    AKSHARE_HISTORICAL_SYNC_CRON: str = Field(default="0 17 * * 1-5", description="历史数据同步CRON表达式")
    AKSHARE_FINANCIAL_SYNC_ENABLED: bool = Field(default=True, description="启用财务数据同步")
    AKSHARE_FINANCIAL_SYNC_CRON: str = Field(default="0 4 * * 0", description="财务数据同步CRON表达式")
    AKSHARE_STATUS_CHECK_ENABLED: bool = Field(default=True, description="启用状态检查")
    AKSHARE_STATUS_CHECK_CRON: str = Field(default="30 * * * *", description="状态检查CRON表达式")

    AKSHARE_INIT_HISTORICAL_DAYS: int = Field(default=365, ge=1, le=3650, description="初始化历史数据天数")
    AKSHARE_INIT_BATCH_SIZE: int = Field(default=100, ge=10, le=1000, description="初始化批处理大小")
    AKSHARE_INIT_AUTO_START: bool = Field(default=False, description="应用启动时自动检查并初始化数据")

    MARKET_ANALYST_LOOKBACK_DAYS: int = Field(default=60, ge=5, le=365, description="市场分析回溯天数（用于技术分析）")

    BAOSTOCK_UNIFIED_ENABLED: bool = Field(default=True, description="启用BaoStock统一数据同步")

    BAOSTOCK_BASIC_INFO_SYNC_ENABLED: bool = Field(default=True, description="启用基础信息同步")
    BAOSTOCK_BASIC_INFO_SYNC_CRON: str = Field(default="0 4 * * *", description="基础信息同步CRON表达式")
    BAOSTOCK_DAILY_QUOTES_SYNC_ENABLED: bool = Field(default=True, description="启用日K线同步（注意：BaoStock不支持实时行情）")
    BAOSTOCK_DAILY_QUOTES_SYNC_CRON: str = Field(default="0 16 * * 1-5", description="日K线同步CRON表达式")
    BAOSTOCK_HISTORICAL_SYNC_ENABLED: bool = Field(default=True, description="启用历史数据同步")
    BAOSTOCK_HISTORICAL_SYNC_CRON: str = Field(default="0 18 * * 1-5", description="历史数据同步CRON表达式")
    BAOSTOCK_STATUS_CHECK_ENABLED: bool = Field(default=True, description="启用状态检查")
    BAOSTOCK_STATUS_CHECK_CRON: str = Field(default="45 * * * *", description="状态检查CRON表达式")

    BAOSTOCK_INIT_HISTORICAL_DAYS: int = Field(default=365, ge=1, le=3650, description="初始化历史数据天数")
    BAOSTOCK_INIT_BATCH_SIZE: int = Field(default=50, ge=10, le=500, description="初始化批处理大小")
    BAOSTOCK_INIT_AUTO_START: bool = Field(default=False, description="应用启动时自动检查并初始化数据")

    DATA_SYNC_CONCURRENCY: int = Field(default=8, ge=1, le=32, description="数据同步默认并发上限")
    CN_SYNC_CONCURRENCY: int = Field(default=8, ge=1, le=32, description="CN 数据同步并发上限")
    HK_SYNC_CONCURRENCY: int = Field(default=8, ge=1, le=32, description="HK 数据同步并发上限")
    US_SYNC_CONCURRENCY: int = Field(default=8, ge=1, le=32, description="US 数据同步并发上限")

    HK_UNIFIED_ENABLED: bool = Field(default=False, description="启用港股统一数据同步")
    HK_BASIC_INFO_SYNC_ENABLED: bool = Field(default=False, description="启用港股基础信息同步")
    HK_BASIC_INFO_SYNC_CRON: str = Field(default="0 3 * * *", description="港股基础信息同步CRON")
    HK_DAILY_QUOTES_SYNC_ENABLED: bool = Field(default=False, description="启用港股日线行情同步")
    HK_DAILY_QUOTES_SYNC_CRON: str = Field(default="0 17 * * 1-5", description="港股日线行情同步CRON")
    HK_STATUS_CHECK_ENABLED: bool = Field(default=False, description="启用港股状态检查")
    HK_STATUS_CHECK_CRON: str = Field(default="0 * * * *", description="港股状态检查CRON")
    HK_SYNC_BATCH_SIZE: int = Field(default=50, ge=10, le=200, description="港股同步批处理大小")
    HK_SYNC_RATE_LIMIT_DELAY: float = Field(default=0.5, ge=0.1, le=10.0, description="港股同步API间隔(秒)")

    US_UNIFIED_ENABLED: bool = Field(default=False, description="启用美股统一数据同步")
    US_BASIC_INFO_SYNC_ENABLED: bool = Field(default=False, description="启用美股基础信息同步")
    US_BASIC_INFO_SYNC_CRON: str = Field(default="0 4 * * *", description="美股基础信息同步CRON")
    US_DAILY_QUOTES_SYNC_ENABLED: bool = Field(default=False, description="启用美股日线行情同步")
    US_DAILY_QUOTES_SYNC_CRON: str = Field(default="0 5 * * 2-6", description="美股日线行情同步CRON")
    US_STATUS_CHECK_ENABLED: bool = Field(default=False, description="启用美股状态检查")
    US_STATUS_CHECK_CRON: str = Field(default="30 * * * *", description="美股状态检查CRON")
    US_SYNC_BATCH_SIZE: int = Field(default=50, ge=10, le=200, description="美股同步批处理大小")
    US_SYNC_RATE_LIMIT_DELAY: float = Field(default=1.0, ge=0.1, le=10.0, description="美股同步API间隔(秒)")

    ASYNC_THREAD_POOL_SIZE: int = Field(default=16, ge=1, le=64, description="默认异步线程池上限")
    ANALYSIS_THREAD_POOL_SIZE: int = Field(default=3, ge=1, le=16, description="分析任务线程池上限")
    QUEUE_MAX_RETRIES: int = Field(default=3, ge=1, le=10, description="队列任务最大重试次数")

    WEBSOCKET_MAX_CONNECTIONS_PER_TASK: int = Field(default=5, ge=1, le=50, description="单任务 WebSocket 最大连接数")
    WEBSOCKET_MAX_TOTAL_CONNECTIONS: int = Field(default=1000, ge=1, le=10000, description="全局 WebSocket 最大连接数")

    ZHENSHABI_DATA_DIR: str = Field(default="data")

    @property
    def runtime_dir(self) -> str:
        from app.utils.runtime_paths import get_runtime_base_dir
        return str(get_runtime_base_dir(self.RUNTIME_BASE_DIR))

    def resolve_runtime_path(self, path_value: str) -> str:
        from app.utils.runtime_paths import resolve_path
        return str(resolve_path(path_value, self.RUNTIME_BASE_DIR))

    @property
    def log_file_path(self) -> str:
        return self.resolve_runtime_path(self.LOG_FILE)

    @property
    def log_dir(self) -> str:
        return str(Path(self.log_file_path).parent)

    @property
    def upload_dir(self) -> str:
        return self.resolve_runtime_path(self.UPLOAD_DIR)

    @property
    def data_dir(self) -> str:
        return self.resolve_runtime_path(self.ZHENSHABI_DATA_DIR)

    HK_DATA_CACHE_HOURS: int = Field(default=24, ge=1, le=168, description="港股数据缓存时长（小时）")
    HK_DEFAULT_DATA_SOURCE: str = Field(default="yfinance", description="港股默认数据源（yfinance/akshare）")

    US_DATA_CACHE_HOURS: int = Field(default=24, ge=1, le=168, description="美股数据缓存时长（小时）")
    US_DEFAULT_DATA_SOURCE: str = Field(default="yfinance", description="美股默认数据源（yfinance/finnhub）")

    NEWS_SYNC_ENABLED: bool = Field(default=True)
    NEWS_SYNC_CRON: str = Field(default="0 */2 * * *")
    NEWS_SYNC_HOURS_BACK: int = Field(default=24)
    NEWS_SYNC_MAX_PER_SOURCE: int = Field(default=50)

    SKILL_AUTO_INSTALL: bool = Field(
        default=True,
        description="首次加载 skill 时自动 pip install 声明的依赖（仅在容器内执行）",
    )
    SKILL_ALLOWED_PACKAGES: str = Field(
        default="",
        description="允许自动安装的 PyPI 包名白名单（逗号分隔），空表示不限制",
    )
    SKILL_INSTALL_TIMEOUT: int = Field(
        default=300,
        ge=30,
        le=1800,
        description="单次 skill 依赖 pip install 的超时时间（秒）",
    )
    SKILL_REGISTRY_URL: str = Field(
        default="",
        description="（已弃用）中心化 skill 注册表地址，由 SKILL_MARKETPLACE_URL 取代",
    )
    SKILL_MARKETPLACE_URL: str = Field(
        default="https://clawhub.ai",
        description="ClawHub 市场地址（官方公开只读 API，第三方复用被明确允许）",
    )
    SKILL_MARKETPLACE_CACHE_TTL: int = Field(
        default=300,
        ge=0,
        description="市场只读请求的内存缓存 TTL（秒），0 表示不缓存",
    )
    SKILL_UPLOAD_MAX_SIZE_MB: int = Field(
        default=20,
        ge=1,
        description="上传 zip 安装包的总大小上限（MB）",
    )
    SKILL_GIT_TRUSTED_HOSTS: str = Field(
        default="github.com,gitee.com",
        description="允许从 Git URL 安装 skill 的可信主机白名单（逗号分隔；交互安装时提交的 URL 主机自动可信）",
    )

    MCP_AUTO_INSTALL_DEPS: bool = Field(
        default=True,
        description="添加 stdio MCP 服务器时自动 pip install 声明的 deps（仅在容器内执行）",
    )
    MCP_ALLOWED_PACKAGES: str = Field(
        default="",
        description="允许为 MCP 服务器安装的 PyPI 包名白名单（逗号分隔），空表示不限制",
    )
    MCP_INSTALL_TIMEOUT: int = Field(
        default=300,
        ge=30,
        le=1800,
        description="单次 MCP 依赖 pip install 的超时时间（秒）",
    )

    @field_validator("ALLOWED_ORIGINS", "ALLOWED_HOSTS", mode="before")
    @classmethod
    def _parse_str_list(cls, v):

        if v is None or isinstance(v, (list, tuple)):
            return v
        s = str(v).strip()
        if not s:
            return []
        try:
            parsed = json.loads(s)
        except ValueError:
            parsed = None
        if isinstance(parsed, list):
            return [str(item).strip() for item in parsed if str(item).strip()]
        if isinstance(parsed, str) and parsed.strip():
            s = parsed.strip()
        return [part.strip() for part in s.split(",") if part.strip()]

    @property
    def is_production(self) -> bool:
        return not self.DEBUG

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

settings = Settings()

_IS_DOCKER = os.getenv("DOCKER_CONTAINER", "").lower() in ("true", "1", "yes")

_REQUIRED_SECRETS = ("JWT_SECRET", "CSRF_SECRET")

for _key in _REQUIRED_SECRETS:
    if not os.getenv(_key):
        warnings.warn(
            f"安全提示: 未配置 {_key}，将在首次连接数据库后自动生成并持久化。",
            stacklevel=2,
        )

if settings.is_production:
    if "*" in settings.ALLOWED_ORIGINS:
        if not _IS_DOCKER:
            raise RuntimeError(
                "❌ 安全错误: 生产环境 ALLOWED_ORIGINS 不能包含 '*'，"
                "请在 .env 中显式配置允许的域名！"
            )
        else:
            warnings.warn(
                "⚠️ 安全提示: Docker 环境 ALLOWED_ORIGINS 包含 '*'，"
                "Nginx 反代已保证同源安全，但建议在 .env 中配置具体域名。",
                stacklevel=2,
            )
    if "*" in settings.ALLOWED_HOSTS:
        if not _IS_DOCKER:
            raise RuntimeError(
                "❌ 安全错误: 生产环境 ALLOWED_HOSTS 不能包含 '*'，"
                "请在 .env 中显式配置允许的主机名！"
            )
        else:
            warnings.warn(
                "⚠️ 安全提示: Docker 环境 ALLOWED_HOSTS 包含 '*'，"
                "Nginx 反代已保证同源安全，但建议在 .env 中配置具体主机名。",
                stacklevel=2,
            )

if settings.HTTP_PROXY:
    os.environ['HTTP_PROXY'] = settings.HTTP_PROXY
if settings.HTTPS_PROXY:
    os.environ['HTTPS_PROXY'] = settings.HTTPS_PROXY
if settings.NO_PROXY:
    os.environ['NO_PROXY'] = settings.NO_PROXY

def get_settings() -> Settings:
    return settings

DEFAULT_SECRET_PATTERNS: dict[str, str] = {
    "JWT_SECRET": "docker-jwt-secret-key-change-in-production",
    "CSRF_SECRET": "docker-csrf-secret-key-change-in-production",
}

_INSECURE_DEFAULT_PREFIXES: tuple[str, ...] = (
    "docker-jwt-secret-key-change-in-production",
    "docker-csrf-secret-key-change-in-production",
    "change-me",
    "change_me",
    "insecure-default",
    "please-change",
)

def is_using_default_secret(key: str) -> bool:

    value = os.getenv(key, "")
    if not value:
        return False
    lowered = value.lower()
    return any(lowered.startswith(p.lower()) for p in _INSECURE_DEFAULT_PREFIXES)

SAFE_ENV_KEYS: frozenset[str] = frozenset({
    "DEBUG", "LOG_LEVEL", "HOST", "PORT",
    "TIMEZONE", "TZ",
    "LANG", "LC_ALL", "LC_CTYPE",
    "PYTHONIOENCODING", "PYTHONUTF8",
    "PYTHONUNBUFFERED", "PYTHONDONTWRITEBYTECODE",
    "MONGODB_DATABASE", "REDIS_DB",
    "MONGODB_PORT", "REDIS_PORT",
    "QUOTES_INGEST_INTERVAL_SECONDS",
})

SENSITIVE_KEYWORDS: tuple[str, ...] = (
    "PASSWORD", "SECRET", "KEY", "TOKEN",
    "CREDENTIAL", "PRIVATE", "CERT", "AUTH",
)

def redact_env_line(line: str) -> str:

    stripped = line.strip()
    if not stripped or stripped.startswith("#"):
        return line
    if stripped.startswith("export "):
        stripped = stripped[len("export "):].lstrip()
    if "=" not in stripped:
        return line
    key = stripped.split("=", 1)[0].strip()
    if key in SAFE_ENV_KEYS:
        return line
    return f"{key}=***"
