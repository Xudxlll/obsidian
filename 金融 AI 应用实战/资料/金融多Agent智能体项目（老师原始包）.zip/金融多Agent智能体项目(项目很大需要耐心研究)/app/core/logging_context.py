import logging
import contextvars

trace_id_var: contextvars.ContextVar[str] = contextvars.ContextVar("trace_id", default="-")

class LoggingContextFilter(logging.Filter):

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            record.trace_id = trace_id_var.get()
        except Exception:
            record.trace_id = "-"
        return True
