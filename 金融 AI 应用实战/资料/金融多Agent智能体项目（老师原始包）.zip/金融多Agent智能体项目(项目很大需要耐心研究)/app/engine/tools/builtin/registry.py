import logging
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

@dataclass
class BuiltinToolSpec:

    tool_id: str
    display_name: str
    domains: List[str]
    markets: List[str]
    fn: Callable
    inject_args: Dict[str, Any]
    description: str
    non_standard: bool = False
    availability_check: Optional[str] = None

CALLABLE_TOOL_REGISTRY: List[BuiltinToolSpec] = []

_TOOL_ID_INDEX: Dict[str, BuiltinToolSpec] = {s.tool_id: s for s in CALLABLE_TOOL_REGISTRY}

def register_skill_entrypoint(spec: BuiltinToolSpec) -> bool:

    if spec.tool_id in _TOOL_ID_INDEX:
        logger.warning(f"[BuiltinRegistry] tool_id 已存在，拒绝覆盖: {spec.tool_id}")
        return False
    CALLABLE_TOOL_REGISTRY.append(spec)
    _TOOL_ID_INDEX[spec.tool_id] = spec
    logger.info(f"[BuiltinRegistry] 已注册 skill 入口: {spec.tool_id}")
    return True

def unregister_skill_entrypoints(prefix: str) -> int:

    full_prefix = prefix if prefix.endswith(".") else prefix + "."
    to_remove = [tid for tid in _TOOL_ID_INDEX if tid.startswith(full_prefix)]
    for tid in to_remove:
        spec = _TOOL_ID_INDEX.pop(tid)
        CALLABLE_TOOL_REGISTRY.remove(spec)
    if to_remove:
        logger.info(f"[BuiltinRegistry] 已卸载 {len(to_remove)} 个 skill 入口: {prefix}")
    return len(to_remove)

def is_skill_tool(tool_id: str) -> bool:
    return "." in tool_id and tool_id in _TOOL_ID_INDEX

def get_skill_entry_specs(tool_ids: List[str]) -> List[BuiltinToolSpec]:
    return [_TOOL_ID_INDEX[tid] for tid in tool_ids if tid in _TOOL_ID_INDEX]

def get_all_callable_specs() -> List[BuiltinToolSpec]:
    return list(CALLABLE_TOOL_REGISTRY)
