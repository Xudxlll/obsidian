import importlib
import logging
import os
import sys
from typing import Dict, List

from app.engine.tools.builtin.registry import (
    BuiltinToolSpec,
    register_skill_entrypoint,
    unregister_skill_entrypoints,
)
from app.engine.tools.skill.availability import check_skill_dependencies
from app.engine.tools.skill.registry import SkillRegistry

logger = logging.getLogger(__name__)

_FORBIDDEN_MODULES = frozenset(
    {
        "os",
        "sys",
        "subprocess",
        "shutil",
        "builtins",
        "importlib",
        "ctypes",
        "multiprocessing",
    }
)

def _validate_module_path(module: str, skill_dir: str) -> None:
    top_level = module.split(".")[0]
    if top_level in _FORBIDDEN_MODULES:
        raise ValueError(f"禁止导入模块: {module}（顶层 {top_level} 在黑名单中）")

    try:
        spec = importlib.util.find_spec(module)
    except (ModuleNotFoundError, ValueError, ImportError):
        return

    if spec is not None and spec.origin:
        real_origin = os.path.realpath(spec.origin)
        real_skill_dir = os.path.realpath(skill_dir)
        if not real_origin.startswith(real_skill_dir + os.sep):
            raise ValueError(f"模块 {module} 文件路径 {real_origin} 不在 skill 目录 {real_skill_dir} 内")

def _ensure_skill_on_path(skill_dir: str) -> None:
    if not skill_dir:
        return
    if skill_dir not in sys.path:
        sys.path.insert(0, skill_dir)

def _make_lazy_entry(skill_dir: str, module: str, function: str):

    _real_fn = None

    def wrapper(*args, **kwargs):
        nonlocal _real_fn
        if _real_fn is None:
            _ensure_skill_on_path(skill_dir)
            _validate_module_path(module, skill_dir)
            mod = importlib.import_module(module)
            _real_fn = getattr(mod, function)
        return _real_fn(*args, **kwargs)

    wrapper.__name__ = function
    wrapper.__qualname__ = function
    wrapper.__doc__ = ""
    wrapper._lazy_module = module
    wrapper._lazy_func_name = function
    wrapper._skill_dir = skill_dir
    return wrapper

def load_all_skill_entrypoints() -> Dict[str, List[str]]:

    registry = SkillRegistry.get_instance()
    all_skills = registry.list_all_skills()

    registered: Dict[str, List[str]] = {}
    unavailable: Dict[str, List[str]] = {}

    for skill_meta in all_skills:
        name = skill_meta["name"]
        if not skill_meta.get("has_manifest"):
            continue

        manifest = registry.get_manifest(name)
        if manifest is None or not manifest.entrypoints:
            continue

        availability = check_skill_dependencies(name)
        if not (availability.dependencies_satisfied and availability.env_satisfied):
            reason = (
                f"依赖未满足: 缺失 {[d.package for d in availability.dependencies if not d.satisfied]}"
                if not availability.dependencies_satisfied
                else f"环境变量缺失: {availability.missing_env}"
            )
            unavailable[name] = [reason]
            logger.info(f"[SkillEntry] 跳过 {name}（{reason}）")
            continue

        skill_dir = registry.get_skill_dir(name)
        if not skill_dir:
            unavailable[name] = ["skill_dir 不存在"]
            continue

        _ensure_skill_on_path(skill_dir)

        registered_names: List[str] = []
        for ep in manifest.entrypoints:
            tool_id = f"{name}.{ep.name}"
            try:
                fn = _make_lazy_entry(skill_dir, ep.module, ep.function)
                spec = BuiltinToolSpec(
                    tool_id=tool_id,
                    display_name=ep.display_name,
                    domains=ep.domains,
                    markets=[m.upper() for m in ep.markets],
                    fn=fn,
                    inject_args=ep.inject_args,
                    description=ep.description,
                    non_standard=True,
                )
                if register_skill_entrypoint(spec):
                    registered_names.append(ep.name)
            except Exception as e:
                logger.error(f"[SkillEntry] 注册 {tool_id} 失败: {e}")
                unavailable.setdefault(name, []).append(f"{ep.name}: {e}")

        if registered_names:
            registered[name] = registered_names

    total = sum(len(v) for v in registered.values())
    logger.info(
        f"[SkillEntry] 入口注册完成: {total} 个入口，"
        f"覆盖 {len(registered)} 个 skill；"
        f"{len(unavailable)} 个 skill 不可用"
    )
    return {"registered": registered, "unavailable": unavailable}

def unload_skill_entrypoints(skill_name: str) -> int:
    return unregister_skill_entrypoints(skill_name)
