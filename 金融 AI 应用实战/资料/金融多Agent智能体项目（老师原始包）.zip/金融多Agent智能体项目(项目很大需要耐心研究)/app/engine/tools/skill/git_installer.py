import logging
import shutil
import subprocess
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from app.core.config import settings
from app.engine.tools.skill.loader import get_cache_skills_dir, get_default_user_skills_dir

logger = logging.getLogger(__name__)

def _extract_host(url: str) -> str:
    try:
        parsed = urlparse(url)
        return parsed.hostname or ""
    except Exception:
        return ""

def _get_trusted_hosts() -> set:
    raw = getattr(settings, "SKILL_GIT_TRUSTED_HOSTS", "")
    if not raw:
        return set()
    return {h.strip().lower() for h in raw.split(",") if h.strip()}

def _validate_git_url(url: str, trusted_hosts: Optional[set] = None) -> Optional[str]:

    if not url:
        return "URL 为空"

    if not (url.startswith("https://") or url.startswith("git@") or url.startswith("ssh://")):
        return "仅允许 https/ssh 协议的 Git URL"

    host = _extract_host(url)
    if not host:
        return f"无法解析 URL 主机: {url}"

    if trusted_hosts is None:
        trusted_hosts = _get_trusted_hosts()
    if trusted_hosts and host.lower() not in trusted_hosts:
        return f"主机 {host} 不在可信白名单内（SKILL_GIT_TRUSTED_HOSTS={trusted_hosts}）"

    return None

def _rmtree_force(path: Path) -> None:

    def _onerror(func, p, _exc):
        import os
        import stat

        try:
            os.chmod(p, stat.S_IWRITE)
            func(p)
        except Exception:
            pass

    shutil.rmtree(path, onerror=_onerror)

def _clone_to_cache(url: str, skill_name: str) -> Path:

    cache_root = Path(get_cache_skills_dir())
    cache_root.mkdir(parents=True, exist_ok=True)

    target = cache_root / skill_name
    if target.exists():
        for _ in range(3):
            _rmtree_force(target)
            if not target.exists():
                break
        if target.exists():
            raise RuntimeError(f"缓存目录无法清空: {target}")

    args = [
        "git",
        "clone",
        "--depth",
        "1",
        url,
        str(target),
    ]

    try:
        proc = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=120,
            check=False,
        )
        if proc.returncode != 0:
            raise RuntimeError(f"git clone 失败: {proc.stderr[-500:]}")
    except subprocess.TimeoutExpired:
        raise RuntimeError("git clone 超时（120秒）")
    except FileNotFoundError:
        raise RuntimeError("git 命令未找到，请安装 git")

    git_dir = target / ".git"
    if git_dir.exists():
        _rmtree_force(git_dir)

    return target

def _move_to_user_dir(cache_path: Path, skill_name: str) -> Path:

    user_dir = Path(get_default_user_skills_dir())
    user_dir.mkdir(parents=True, exist_ok=True)

    target = user_dir / skill_name
    if target.exists():
        backup = target.with_name(f"{skill_name}.bak")
        if backup.exists():
            shutil.rmtree(backup, ignore_errors=True)
        target.rename(backup)
        logger.info(f"[SkillGitInstaller] 已备份原有 skill 到 {backup.name}")

    shutil.move(str(cache_path), str(target))
    return target

def install_from_git(url: str, trusted_hosts_override: Optional[list] = None) -> dict:

    merged_hosts = _get_trusted_hosts()
    if trusted_hosts_override:
        merged_hosts = merged_hosts.union({h.strip().lower() for h in trusted_hosts_override if h})

    return _do_install(url, merged_hosts)

def install_from_git_interactive(url: str, subdir: Optional[str] = None) -> dict:

    host = _extract_host(url)
    if not url.startswith("https://"):
        return {
            "success": False,
            "skill_name": "",
            "installed_path": "",
            "error": "仅允许 https:// 协议的 Git URL",
            "resolved_host": host,
        }
    trusted = _get_trusted_hosts() | {host.lower()} if host else None
    result = _do_install(url, trusted, subdir=subdir)
    result["resolved_host"] = host
    return result

def _do_install(
    url: str, trusted_hosts: Optional[set] = None, subdir: Optional[str] = None
) -> dict:
    err = _validate_git_url(url, trusted_hosts)
    if err:
        return {
            "success": False,
            "skill_name": "",
            "installed_path": "",
            "error": err,
        }

    try:
        temp_name = "_pending_install"
        repo_path = _clone_to_cache(url, temp_name)
    except Exception as e:
        return {
            "success": False,
            "skill_name": "",
            "installed_path": "",
            "error": str(e),
        }

    if subdir:
        candidates = [subdir, f"skills/{subdir.strip('/')}"]
        sub = None
        for cand in candidates:
            if cand and (repo_path / cand / "SKILL.md").exists():
                sub = repo_path / cand
                break
        if sub is None:
            shutil.rmtree(repo_path, ignore_errors=True)
            return {
                "success": False,
                "skill_name": "",
                "installed_path": "",
                "error": f"仓库子目录 {subdir}（及 skills/{subdir}）均缺少 SKILL.md",
            }
        extracted = repo_path.parent / "_pending_subdir"
        shutil.rmtree(extracted, ignore_errors=True)
        shutil.copytree(sub, extracted)
        shutil.rmtree(repo_path, ignore_errors=True)
        cache_path = extracted
    else:
        cache_path = repo_path

    from app.engine.tools.skill.package_validator import validate_skill_package

    skill_name, err = validate_skill_package(cache_path)
    if err:
        shutil.rmtree(cache_path, ignore_errors=True)
        return {
            "success": False,
            "skill_name": skill_name or "",
            "installed_path": "",
            "error": err,
        }

    if cache_path.name != skill_name:
        new_cache = cache_path.parent / skill_name
        if new_cache.exists():
            shutil.rmtree(new_cache, ignore_errors=True)
        cache_path = cache_path.rename(new_cache)

    try:
        final_path = _move_to_user_dir(cache_path, skill_name)
    except Exception as e:
        shutil.rmtree(cache_path, ignore_errors=True)
        return {
            "success": False,
            "skill_name": skill_name,
            "installed_path": "",
            "error": f"移动到用户目录失败: {e}",
        }

    try:
        from app.engine.tools.skill.local_installer import mark_skill_source

        mark_skill_source(final_path, "git", url=url, installed_by="git")
    except Exception as e:
        logger.warning(f"[SkillGitInstaller] 写入 source 标记失败: {e}")

    logger.info(f"[SkillGitInstaller] 已从 Git 安装 skill: {skill_name} <- {url}")

    try:
        from app.engine.tools.skill.registry import SkillRegistry

        registry = SkillRegistry.get_instance()
        registry.reload()
    except Exception as e:
        logger.warning(f"[SkillGitInstaller] reload registry 失败: {e}")

    return {
        "success": True,
        "skill_name": skill_name,
        "installed_path": str(final_path),
        "error": "",
    }

def uninstall_skill(skill_name: str, force: bool = False) -> dict:

    from app.engine.tools.skill.registry import SkillRegistry
    from app.engine.tools.skill.loader import get_builtin_skills_dir

    registry = SkillRegistry.get_instance()
    all_skills = {s["name"]: s for s in registry.list_all_skills()}

    if skill_name not in all_skills:
        return {"success": False, "removed_path": "", "error": f"skill 不存在: {skill_name}"}

    skill_meta = all_skills[skill_name]
    source_type = skill_meta.get("source_type", "local")
    skill_dir = skill_meta.get("skill_dir", "")

    if source_type == "builtin" or skill_dir.startswith(get_builtin_skills_dir()):
        return {"success": False, "removed_path": "", "error": "内置 skill 不允许卸载"}

    if source_type == "local" and not force:
        return {
            "success": False,
            "removed_path": "",
            "error": "本地 skill 需 force=true 才允许卸载（防止误删用户文件）",
        }

    if not skill_dir or not Path(skill_dir).exists():
        return {"success": False, "removed_path": "", "error": f"skill 目录不存在: {skill_dir}"}

    try:
        from app.engine.tools.skill.entrypoint_loader import unload_skill_entrypoints

        unload_skill_entrypoints(skill_name)
    except Exception as e:
        logger.warning(f"卸载 skill 入口失败 {skill_name}: {e}")

    try:
        shutil.rmtree(skill_dir)
    except Exception as e:
        return {"success": False, "removed_path": "", "error": f"删除目录失败: {e}"}

    try:
        registry.reload()
    except Exception as e:
        logger.warning(f"reload registry 失败: {e}")

    try:
        from app.engine.tools.skill.state_store import SkillStateStore

        store = SkillStateStore()
        import asyncio

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop is None:
            asyncio.run(store.delete_state(skill_name))
        else:
            task = asyncio.ensure_future(store.delete_state(skill_name))
            task.add_done_callback(
                lambda t: (
                    logger.error(f"删除 skill_state 异步失败: {t.exception()}")
                    if not t.cancelled() and t.exception()
                    else None
                )
            )
    except Exception as e:
        logger.warning(f"删除 skill_state 失败: {e}")

    logger.info(f"[SkillGitInstaller] 已卸载 skill: {skill_name} (source={source_type})")
    return {"success": True, "removed_path": skill_dir, "error": ""}
