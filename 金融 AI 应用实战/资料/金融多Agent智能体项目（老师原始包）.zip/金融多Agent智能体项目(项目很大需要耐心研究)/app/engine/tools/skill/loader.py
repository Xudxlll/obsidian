import logging
import re
from pathlib import Path
from typing import Optional

import yaml

logger = logging.getLogger(__name__)

_FRONTMATTER_PATTERN = re.compile(
    r"^---\s*\n(.*?)\n---\s*\n",
    re.DOTALL,
)

_DEFAULT_USER_SKILLS_DIR = str(Path(__file__).parent.parent.parent.parent.parent / "config" / "skills")

_BUILTIN_SKILLS_DIR = str(Path(__file__).parent / "builtin")

_CACHE_SKILLS_SUBDIR = ".cache"

def parse_skill_metadata(file_path: str) -> dict:

    path = Path(file_path)
    if not path.exists():
        logger.warning(f"Skill 文件不存在: {file_path}")
        return {"file_path": file_path}

    try:
        content = path.read_text(encoding="utf-8")
    except Exception as e:
        logger.error(f"读取 Skill 文件失败 {file_path}: {e}")
        return {"file_path": file_path}

    match = _FRONTMATTER_PATTERN.match(content)
    if not match:
        logger.warning(f"Skill 文件缺少 YAML frontmatter: {file_path}")
        return {"file_path": file_path}

    yaml_block = match.group(1)

    try:
        parsed = yaml.safe_load(yaml_block)
    except yaml.YAMLError as e:
        logger.error(f"Skill frontmatter YAML 解析失败 {file_path}: {e}")
        return {"file_path": file_path}

    if not isinstance(parsed, dict):
        logger.warning(f"Skill frontmatter 必须是字典 {file_path}")
        return {"file_path": file_path}

    metadata: dict = {
        "file_path": str(file_path),
        "name": None,
        "description": "",
        "version": "0.0.0",
        "user_invocable": True,
        "license": None,
        "compatibility": None,
        "metadata": {},
        "allowed_tools": [],
    }

    if "name" in parsed:
        metadata["name"] = str(parsed["name"]).strip()
    if "description" in parsed:
        metadata["description"] = str(parsed["description"]).strip()
    if "version" in parsed:
        metadata["version"] = str(parsed["version"]).strip()
    if "user-invocable" in parsed:
        metadata["user_invocable"] = bool(parsed["user-invocable"])
    elif "user_invocable" in parsed:
        metadata["user_invocable"] = bool(parsed["user_invocable"])
    if "license" in parsed:
        metadata["license"] = str(parsed["license"]).strip()
    if "compatibility" in parsed:
        metadata["compatibility"] = str(parsed["compatibility"]).strip()
    if "metadata" in parsed and isinstance(parsed["metadata"], dict):
        metadata["metadata"] = parsed["metadata"]
    if "allowed-tools" in parsed:
        at = parsed["allowed-tools"]
        if isinstance(at, str):
            metadata["allowed_tools"] = at.split()
        elif isinstance(at, list):
            metadata["allowed_tools"] = [str(x) for x in at]

    if metadata["name"] is None:
        metadata["name"] = path.parent.name if path.name == "SKILL.md" else path.stem

    return metadata

def _resolve_skill_path(skills_dir: str, skill_name: str) -> Optional[str]:

    if not skill_name or not re.match(r"^[a-zA-Z0-9][a-zA-Z0-9_-]*$", skill_name):
        logger.warning(f"skill_name 格式非法，拒绝: {skill_name!r}")
        return None

    base = Path(skills_dir)

    subdir_path = base / skill_name / "SKILL.md"
    if subdir_path.exists():
        return str(subdir_path.resolve())

    flat_path = base / f"{skill_name}.md"
    if flat_path.exists():
        return str(flat_path.resolve())

    return None

def load_skill_content(
    skill_name: str,
    skills_dir: Optional[str] = None,
) -> Optional[str]:

    if skills_dir is None:
        skills_dir = _DEFAULT_USER_SKILLS_DIR

    file_path = _resolve_skill_path(skills_dir, skill_name)
    if file_path is None:
        logger.warning(f"未找到技能文件: {skill_name}（目录: {skills_dir}）")
        return None

    try:
        content = Path(file_path).read_text(encoding="utf-8")
        logger.debug(f"成功加载技能内容: {skill_name} ({file_path})")
        return content
    except Exception as e:
        logger.error(f"读取技能内容失败 {skill_name}: {e}")
        return None

def get_default_user_skills_dir() -> str:
    return _DEFAULT_USER_SKILLS_DIR

def get_builtin_skills_dir() -> str:
    return _BUILTIN_SKILLS_DIR

def get_cache_skills_dir() -> str:
    return str(Path(_DEFAULT_USER_SKILLS_DIR) / _CACHE_SKILLS_SUBDIR)

def get_skill_dirs() -> list:

    return [
        _DEFAULT_USER_SKILLS_DIR,
        get_cache_skills_dir(),
        _BUILTIN_SKILLS_DIR,
    ]
