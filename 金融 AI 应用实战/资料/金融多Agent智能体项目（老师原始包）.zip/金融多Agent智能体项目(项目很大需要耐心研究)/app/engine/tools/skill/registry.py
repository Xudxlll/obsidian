import logging
import threading
from pathlib import Path
from typing import Callable, Dict, List, Optional

from app.engine.tools.skill.loader import (
    get_builtin_skills_dir,
    get_cache_skills_dir,
    get_default_user_skills_dir,
    load_skill_content,
    parse_skill_metadata,
)
from app.engine.tools.skill.manifest import load_manifest
from app.models.skill import SkillManifest

logger = logging.getLogger(__name__)

class SkillRegistry:

    _instance: Optional["SkillRegistry"] = None
    _lock = threading.Lock()

    def __init__(self, skills_dir: Optional[str] = None):

        self._user_skills_dir = skills_dir or get_default_user_skills_dir()
        self._cache_skills_dir = get_cache_skills_dir()
        self._builtin_skills_dir = get_builtin_skills_dir()

        self._skills: List[Dict] = []
        self._manifests: Dict[str, SkillManifest] = {}
        self._disabled: set = set()
        self._content_cache: Dict[str, str] = {}

        self._dependency_check_callback: Optional[Callable[[str], Dict]] = None
        self._dependency_install_callback: Optional[Callable[[str], Dict]] = None

        self._state_loaded: bool = False
        self._state_lock = threading.Lock()

        self.discover_skills()

    @classmethod
    def get_instance(cls) -> "SkillRegistry":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    @classmethod
    def reset_instance(cls) -> None:
        with cls._lock:
            cls._instance = None

    def set_dependency_callbacks(
        self,
        check_callback: Optional[Callable[[str], Dict]] = None,
        install_callback: Optional[Callable[[str], Dict]] = None,
    ) -> None:

        self._dependency_check_callback = check_callback
        self._dependency_install_callback = install_callback

    def discover_skills(self) -> List[Dict]:

        discovered: List[Dict] = []
        seen_names: set = set()

        for base_dir in [
            self._user_skills_dir,
            self._cache_skills_dir,
            self._builtin_skills_dir,
        ]:
            base = Path(base_dir)
            if not base.exists():
                continue

            try:
                for subdir in sorted(base.iterdir()):
                    if not subdir.is_dir():
                        continue
                    if subdir.name == ".cache" and base_dir == self._user_skills_dir:
                        continue
                    skill_md = subdir / "SKILL.md"
                    if not skill_md.exists():
                        continue

                    meta = parse_skill_metadata(str(skill_md))
                    name = meta.get("name")
                    if not name or name in seen_names:
                        continue

                    seen_names.add(name)

                    skill_dir = str(subdir.resolve())
                    manifest = load_manifest(skill_dir)
                    if manifest is not None:
                        self._manifests[name] = manifest

                    discovered.append(
                        {
                            "name": name,
                            "description": meta.get("description", ""),
                            "version": meta.get("version", "0.0.0"),
                            "user_invocable": meta.get("user_invocable", True),
                            "path": str(skill_md.resolve()),
                            "skill_dir": skill_dir,
                            "has_manifest": manifest is not None,
                            "has_scripts": (subdir / "scripts").is_dir(),
                            "source_type": self._refine_source_type(
                                manifest, base_dir
                            ),
                        }
                    )
            except Exception as e:
                logger.warning(f"扫描 skill 目录失败 {base_dir}: {e}")

            try:
                for md_file in sorted(base.glob("*.md")):
                    if md_file.name.upper() == "SKILL.MD":
                        continue
                    if not md_file.is_file():
                        continue

                    meta = parse_skill_metadata(str(md_file))
                    name = meta.get("name")
                    if not name or name in seen_names:
                        continue

                    seen_names.add(name)
                    discovered.append(
                        {
                            "name": name,
                            "description": meta.get("description", ""),
                            "version": meta.get("version", "0.0.0"),
                            "user_invocable": meta.get("user_invocable", True),
                            "path": str(md_file.resolve()),
                            "skill_dir": str(md_file.parent.resolve()),
                            "has_manifest": False,
                            "has_scripts": False,
                            "source_type": self._classify_source_dir(base_dir),
                        }
                    )
            except Exception as e:
                logger.warning(f"扫描扁平 skill 失败 {base_dir}: {e}")

        self._skills = discovered
        self._content_cache.clear()

        logger.info(f"技能发现完成: 共发现 {len(discovered)} 个技能（含 manifest={len(self._manifests)}）")
        return self._skills

    def _classify_source_dir(self, base_dir: str) -> str:
        if base_dir == self._user_skills_dir:
            return "local"
        if base_dir == self._cache_skills_dir:
            return "git"
        if base_dir == self._builtin_skills_dir:
            return "builtin"
        return "local"

    def _refine_source_type(self, manifest, base_dir: str) -> str:

        source = getattr(manifest, "source", None) if manifest is not None else None
        if source is None and isinstance(manifest, dict):
            source = manifest.get("source")
        source_type = getattr(source, "type", None) or (
            source.get("type") if isinstance(source, dict) else None
        )
        if source_type in ("git", "registry"):
            return source_type
        return self._classify_source_dir(base_dir)

    def get_skill_dir(self, name: str) -> Optional[str]:
        for s in self._skills:
            if s["name"] == name:
                return s.get("skill_dir")
        return None

    def get_manifest(self, name: str) -> Optional[SkillManifest]:
        return self._manifests.get(name)

    def get_entrypoints(self, name: str) -> List[Dict]:

        manifest = self._manifests.get(name)
        if manifest is None:
            return []
        return [ep.model_dump(by_alias=True) for ep in manifest.entrypoints]

    def get_skill_content(self, name: str) -> Optional[str]:

        if not self.is_enabled(name):
            logger.warning(f"技能已禁用: {name}")
            return None

        if name in self._content_cache:
            return self._content_cache[name]

        skill_path = None
        for s in self._skills:
            if s["name"] == name:
                skill_path = s.get("path")
                break

        if skill_path is None:
            content = load_skill_content(name, self._user_skills_dir)
        else:
            try:
                content = Path(skill_path).read_text(encoding="utf-8")
            except Exception as e:
                logger.error(f"读取技能内容失败 {name}: {e}")
                content = None

        if content is not None:
            self._content_cache[name] = content

        return content

    def list_skills(self) -> List[Dict]:

        return [
            {"name": s["name"], "description": s["description"]}
            for s in self._skills
            if s.get("user_invocable", True) and s["name"] not in self._disabled
        ]

    def list_all_skills(self) -> List[Dict]:

        return list(self._skills)

    def enable_skill(self, name: str) -> bool:

        skill_names = {s["name"] for s in self._skills}
        if name not in skill_names:
            logger.warning(f"尝试启用不存在的技能: {name}")
            return False

        with self._state_lock:
            self._disabled.discard(name)
            self._content_cache.pop(name, None)
        logger.info(f"技能已启用: {name}")
        return True

    def disable_skill(self, name: str) -> bool:

        skill_names = {s["name"] for s in self._skills}
        if name not in skill_names:
            logger.warning(f"尝试禁用不存在的技能: {name}")
            return False

        with self._state_lock:
            self._disabled.add(name)
        logger.info(f"技能已禁用: {name}")
        return True

    def set_disabled_from_store(self, disabled_names: set) -> None:

        self._disabled = set(disabled_names)

    def is_enabled(self, name: str) -> bool:
        skill_names = {s["name"] for s in self._skills}
        return name in skill_names and name not in self._disabled

    def check_dependencies(self, name: str) -> Dict:

        if self._dependency_check_callback is not None:
            return self._dependency_check_callback(name)
        if name not in self._manifests:
            return {"satisfied": True, "missing": [], "warnings": []}
        return {
            "satisfied": False,
            "missing": [],
            "warnings": ["依赖检查器未注入，无法确认依赖状态"],
        }

    def ensure_dependencies(self, name: str) -> Dict:

        if self._dependency_install_callback is None:
            return {
                "installed": False,
                "satisfied": True,
                "packages_installed": [],
                "error": "",
            }
        return self._dependency_install_callback(name)

    def reload(self) -> List[Dict]:
        self._content_cache.clear()
        self._manifests.clear()
        return self.discover_skills()

    @property
    def skills_dir(self) -> str:
        return self._user_skills_dir

    @property
    def total_count(self) -> int:
        return len(self._skills)
