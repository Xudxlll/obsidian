import logging
from typing import Any, Dict, List, Optional

from app.core.database import get_mongo_db
from app.models.skill import SkillInstallLog, SkillState
from app.utils.timezone import now_tz

logger = logging.getLogger(__name__)

_SKILL_STATE_COLLECTION = "skill_state"
_SKILL_INSTALL_LOG_COLLECTION = "skill_install_logs"

class SkillStateStore:

    async def load_all_states(self) -> Dict[str, SkillState]:

        try:
            db = get_mongo_db()
            cursor = db[_SKILL_STATE_COLLECTION].find({})
            result: Dict[str, SkillState] = {}
            async for doc in cursor:
                try:
                    state = SkillState.model_validate(doc)
                    result[state.name] = state
                except Exception as e:
                    logger.warning(f"解析 skill_state 文档失败: {e}, doc={doc}")
            return result
        except Exception as e:
            logger.warning(f"加载 skill_state 失败（将使用内存默认值）: {e}")
            return {}

    async def get_state(self, name: str) -> Optional[SkillState]:
        try:
            db = get_mongo_db()
            doc = await db[_SKILL_STATE_COLLECTION].find_one({"name": name})
            if doc is None:
                return None
            return SkillState.model_validate(doc)
        except Exception as e:
            logger.warning(f"获取 skill_state 失败 {name}: {e}")
            return None

    async def upsert_state(self, state: SkillState) -> bool:
        try:
            db = get_mongo_db()
            state.updated_at = now_tz()
            doc = state.model_dump(by_alias=True, exclude_none=False)
            await db[_SKILL_STATE_COLLECTION].update_one(
                {"name": state.name},
                {"$set": doc},
                upsert=True,
            )
            return True
        except Exception as e:
            logger.error(f"写入 skill_state 失败 {state.name}: {e}")
            return False

    async def set_enabled(self, name: str, enabled: bool) -> bool:
        try:
            db = get_mongo_db()
            await db[_SKILL_STATE_COLLECTION].update_one(
                {"name": name},
                {
                    "$set": {
                        "enabled": enabled,
                        "updated_at": now_tz(),
                    },
                    "$setOnInsert": {
                        "name": name,
                        "installed_dependencies": [],
                        "created_at": now_tz(),
                    },
                },
                upsert=True,
            )
            return True
        except Exception as e:
            logger.error(f"更新 skill 启停状态失败 {name}: {e}")
            return False

    async def record_installed_dependencies(
        self,
        name: str,
        packages: List[str],
    ) -> bool:
        try:
            db = get_mongo_db()
            await db[_SKILL_STATE_COLLECTION].update_one(
                {"name": name},
                {
                    "$set": {
                        "installed_dependencies": packages,
                        "last_installed_at": now_tz(),
                        "last_checked_at": now_tz(),
                        "updated_at": now_tz(),
                    },
                    "$setOnInsert": {
                        "name": name,
                        "enabled": True,
                        "created_at": now_tz(),
                    },
                },
                upsert=True,
            )
            return True
        except Exception as e:
            logger.error(f"记录 skill 已安装依赖失败 {name}: {e}")
            return False

    async def update_last_checked(self, name: str) -> bool:
        try:
            db = get_mongo_db()
            await db[_SKILL_STATE_COLLECTION].update_one(
                {"name": name},
                {"$set": {"last_checked_at": now_tz()}},
                upsert=True,
            )
            return True
        except Exception as e:
            logger.warning(f"更新 last_checked_at 失败 {name}: {e}")
            return False

    async def delete_state(self, name: str) -> bool:
        try:
            db = get_mongo_db()
            await db[_SKILL_STATE_COLLECTION].delete_one({"name": name})
            return True
        except Exception as e:
            logger.error(f"删除 skill_state 失败 {name}: {e}")
            return False

    async def write_install_log(self, log: SkillInstallLog) -> bool:
        try:
            db = get_mongo_db()
            doc = log.model_dump(by_alias=True, exclude_none=False, exclude={"id"})
            await db[_SKILL_INSTALL_LOG_COLLECTION].insert_one(doc)
            return True
        except Exception as e:
            logger.error(f"写入 skill_install_log 失败 {log.skill_name}: {e}")
            return False

    async def list_install_logs(
        self,
        skill_name: Optional[str] = None,
        limit: int = 100,
        kind: Optional[str] = None,
    ) -> List[SkillInstallLog]:
        try:
            db = get_mongo_db()
            query: Dict[str, Any] = {}
            if skill_name:
                query["skill_name"] = skill_name
            if kind:
                query["kind"] = kind
            cursor = db[_SKILL_INSTALL_LOG_COLLECTION].find(query).sort("installed_at", -1).limit(limit)
            result: List[SkillInstallLog] = []
            async for doc in cursor:
                try:
                    result.append(SkillInstallLog.model_validate(doc))
                except Exception as e:
                    logger.warning(f"解析 install_log 失败: {e}")
            return result
        except Exception as e:
            logger.warning(f"查询 install_logs 失败: {e}")
            return []
