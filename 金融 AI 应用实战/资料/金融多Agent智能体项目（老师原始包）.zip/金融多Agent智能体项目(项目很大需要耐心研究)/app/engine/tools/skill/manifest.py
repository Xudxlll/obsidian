import logging
from pathlib import Path
from typing import Optional

import yaml
from pydantic import ValidationError

from app.models.skill import SkillManifest

logger = logging.getLogger(__name__)

def load_manifest(skill_dir: str) -> Optional[SkillManifest]:

    manifest_path = Path(skill_dir) / "manifest.yaml"
    if not manifest_path.exists():
        manifest_path = Path(skill_dir) / "manifest.yml"
        if not manifest_path.exists():
            return None

    try:
        raw = manifest_path.read_text(encoding="utf-8")
    except Exception as e:
        logger.error(f"读取 manifest 失败 {manifest_path}: {e}")
        return None

    try:
        data = yaml.safe_load(raw)
    except yaml.YAMLError as e:
        logger.error(f"manifest YAML 解析失败 {manifest_path}: {e}")
        return None

    if not isinstance(data, dict):
        logger.error(f"manifest 顶层必须是字典 {manifest_path}")
        return None

    deps = data.get("dependencies") or {}
    if isinstance(deps, dict) and "python" in deps and "python_dependencies" not in data:
        data["python_dependencies"] = deps["python"]
    if isinstance(deps, dict) and "system" in deps and "system_dependencies" not in data:
        data["system_dependencies"] = deps["system"]

    try:
        manifest = SkillManifest.model_validate(data)
    except ValidationError as e:
        logger.error(f"manifest 校验失败 {manifest_path}: {e}")
        return None

    dir_name = Path(skill_dir).name
    if manifest.skill_name != dir_name:
        logger.warning(f"manifest.skill_name ({manifest.skill_name}) 与目录名 ({dir_name}) 不一致，将以目录名为准")
        manifest.skill_name = dir_name

    return manifest

def has_manifest(skill_dir: str) -> bool:
    return (Path(skill_dir) / "manifest.yaml").exists() or (Path(skill_dir) / "manifest.yml").exists()
