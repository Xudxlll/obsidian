import importlib.util
import logging
import os
from typing import Dict, List

from app.engine.tools.skill.registry import SkillRegistry
from app.models.skill import (
    SkillAvailability,
    SkillDependencyStatus,
    SkillManifest,
)

logger = logging.getLogger(__name__)

_PACKAGE_TO_MODULE = {
    "ta-lib": "talib",
    "ta_lib": "talib",
    "Pillow": "PIL",
    "pillow": "PIL",
    "pyyaml": "yaml",
    "mplfinance": "mplfinance",
    "pymupdf": "fitz",
    "beautifulsoup4": "bs4",
    "python-dateutil": "dateutil",
    "python-dotenv": "dotenv",
    "scikit-learn": "sklearn",
    "opencv-python": "cv2",
    "protobuf": "google.protobuf",
}

def _package_to_module(package_name: str) -> str:
    return _PACKAGE_TO_MODULE.get(package_name, package_name.replace("-", "_"))

def check_python_package(package: str) -> tuple:

    module_name = _package_to_module(package)
    try:
        spec = importlib.util.find_spec(module_name)
        if spec is None:
            return (False, "")
        try:
            mod = importlib.import_module(module_name)
            version = getattr(mod, "__version__", "") or getattr(mod, "VERSION", "")
            return (True, str(version))
        except Exception:
            return (False, "")
    except Exception as e:
        logger.debug(f"检查包 {package} (module={module_name}) 失败: {e}")
        return (False, "")

def check_env_var(name: str) -> bool:
    return bool(os.environ.get(name))

def check_skill_dependencies(name: str) -> SkillAvailability:

    registry = SkillRegistry.get_instance()
    manifest: SkillManifest | None = registry.get_manifest(name)

    enabled = registry.is_enabled(name)
    warnings: List[str] = []

    if manifest is None:
        return SkillAvailability(
            skill_name=name,
            enabled=enabled,
            dependencies_satisfied=True,
            dependencies=[],
            env_satisfied=True,
            missing_env=[],
            entrypoints_available=[],
            entrypoints_unavailable=[],
            warnings=["无 manifest，视为纯 prompt skill"],
        )

    dep_statuses: List[SkillDependencyStatus] = []
    all_satisfied = True
    missing_count = 0
    for dep in manifest.python_dependencies:
        satisfied, version = check_python_package(dep.package)
        if not satisfied:
            all_satisfied = False
            missing_count += 1
        dep_statuses.append(
            SkillDependencyStatus(
                package=dep.package,
                version_constraint=dep.version,
                satisfied=satisfied,
                installed_version=version,
                note=dep.note,
            )
        )

    missing_env: List[str] = []
    for env_req in manifest.env:
        if env_req.required and not check_env_var(env_req.name):
            missing_env.append(env_req.name)

    env_satisfied = len(missing_env) == 0
    if not env_satisfied:
        warnings.append(f"缺失必需环境变量: {', '.join(missing_env)}")

    for sys_dep in manifest.system_dependencies:
        desc = sys_dep.get("description", "") if isinstance(sys_dep, dict) else str(sys_dep)
        if desc:
            warnings.append(f"系统依赖（需手动确认）: {desc}")

    entrypoint_names = [ep.name for ep in manifest.entrypoints]
    if all_satisfied and env_satisfied:
        entrypoints_available = entrypoint_names
        entrypoints_unavailable = []
    else:
        entrypoints_available = []
        entrypoints_unavailable = entrypoint_names

    return SkillAvailability(
        skill_name=name,
        enabled=enabled,
        dependencies_satisfied=all_satisfied,
        dependencies=dep_statuses,
        env_satisfied=env_satisfied,
        missing_env=missing_env,
        entrypoints_available=entrypoints_available,
        entrypoints_unavailable=entrypoints_unavailable,
        warnings=warnings,
    )

def check_skill_dependencies_raw(name: str) -> Dict:

    try:
        availability = check_skill_dependencies(name)
        missing = [d.package for d in availability.dependencies if not d.satisfied]
        return {
            "satisfied": availability.dependencies_satisfied and availability.env_satisfied,
            "missing": missing + availability.missing_env,
            "warnings": availability.warnings,
            "availability": availability.model_dump(),
        }
    except Exception as e:
        logger.error(f"检查 skill 依赖失败 {name}: {e}")
        return {
            "satisfied": False,
            "missing": [],
            "warnings": [f"检查异常: {e}"],
            "availability": None,
        }
