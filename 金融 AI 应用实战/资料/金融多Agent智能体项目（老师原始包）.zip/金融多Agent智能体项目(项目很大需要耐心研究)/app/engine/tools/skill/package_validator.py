import logging
import re
from pathlib import Path
from typing import Optional, Tuple

import yaml

logger = logging.getLogger(__name__)

SKILL_NAME_PATTERN = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]*$")

def _read_raw_manifest_skill_name(dir_path: Path) -> Optional[str]:
    for name in ("manifest.yaml", "manifest.yml"):
        p = Path(dir_path) / name
        if not p.exists():
            continue
        try:
            data = yaml.safe_load(p.read_text(encoding="utf-8"))
        except Exception:
            return None
        if isinstance(data, dict) and data.get("skill_name"):
            return str(data["skill_name"]).strip()
        return None
    return None

def validate_skill_package(dir_path: Path) -> Tuple[Optional[str], Optional[str]]:

    from app.engine.tools.skill.loader import parse_skill_metadata

    skill_md = Path(dir_path) / "SKILL.md"
    if not skill_md.exists():
        return None, f"{Path(dir_path).name} 根目录缺少 SKILL.md，不是合法的 skill 包"

    meta = parse_skill_metadata(str(skill_md))
    skill_name = meta.get("name") or Path(dir_path).name

    if not SKILL_NAME_PATTERN.match(skill_name):
        logger.error(f"[SkillPackageValidator] skill_name 含非法字符，拒绝: {skill_name!r}")
        return skill_name, (
            f"skill_name 含非法字符（仅允许字母、数字、下划线、连字符）: {skill_name}"
        )

    manifest_name = _read_raw_manifest_skill_name(dir_path)
    if manifest_name is not None and manifest_name != skill_name:
        return skill_name, (
            f"manifest.skill_name ({manifest_name}) 与目录名 ({skill_name}) 不一致"
        )

    return skill_name, None
