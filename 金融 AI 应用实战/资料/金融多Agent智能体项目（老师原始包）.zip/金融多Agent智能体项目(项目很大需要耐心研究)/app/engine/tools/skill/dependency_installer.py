import asyncio
import logging
import sys
import tempfile
from pathlib import Path
from typing import Dict, List

from app.core.config import settings
from app.core.package_install import (
    build_pip_args as _build_pip_args_core,
    run_install as _run_install_core,
    validate_package_spec,
    write_requirements,
)
from app.engine.tools.skill.availability import check_skill_dependencies_raw
from app.engine.tools.skill.registry import SkillRegistry
from app.engine.tools.skill.state_store import SkillStateStore
from app.models.skill import SkillInstallLog, SkillManifest, SkillPythonDependency

logger = logging.getLogger(__name__)

def _is_auto_install_enabled() -> bool:
    return getattr(settings, "SKILL_AUTO_INSTALL", True)

def _get_allowed_packages() -> set:
    raw = getattr(settings, "SKILL_ALLOWED_PACKAGES", "")
    if not raw:
        return set()
    return {p.strip().lower() for p in raw.split(",") if p.strip()}

def _get_install_timeout() -> int:
    return int(getattr(settings, "SKILL_INSTALL_TIMEOUT", 300))

def _validate_against_whitelist(manifest: SkillManifest) -> List[str]:

    allowed = _get_allowed_packages()
    if not allowed:
        return []
    rejected = []
    for dep in manifest.python_dependencies:
        if dep.package.lower() not in allowed:
            rejected.append(dep.package)
    return rejected

def _build_pip_args(
    deps: List[SkillPythonDependency],
    requirements_file: Path,
) -> List[str]:
    return _build_pip_args_core(
        sys.executable,
        requirements_file,
        require_hashes=any(dep.hash for dep in deps),
    )

def _write_requirements(
    deps: List[SkillPythonDependency],
    requirements_file: Path,
) -> None:

    lines = []
    for dep in deps:
        validate_package_spec(dep.package, dep.version)
        if dep.hash:
            lines.append(f"{dep.package}{dep.version} --hash={dep.hash}")
        else:
            lines.append(f"{dep.package}{dep.version}")
    write_requirements(lines, requirements_file)

def _run_pip_install(args: List[str], timeout: int) -> Dict:
    return _run_install_core(args, timeout)

async def install_skill_dependencies(
    name: str,
    installed_by: str = "system",
) -> Dict:

    registry = SkillRegistry.get_instance()
    store = SkillStateStore()

    if not _is_auto_install_enabled():
        logger.info(f"[SkillInstaller] 自动安装已关闭，跳过 {name}")
        return {
            "installed": False,
            "satisfied": False,
            "packages_installed": [],
            "error": "",
            "skipped_reason": "auto_install_disabled",
        }

    manifest = registry.get_manifest(name)
    if manifest is None:
        return {
            "installed": False,
            "satisfied": True,
            "packages_installed": [],
            "error": "",
            "skipped_reason": "no_manifest",
        }

    if not manifest.python_dependencies:
        await store.record_installed_dependencies(name, [])
        return {
            "installed": False,
            "satisfied": True,
            "packages_installed": [],
            "error": "",
            "skipped_reason": "no_python_dependencies",
        }

    rejected = _validate_against_whitelist(manifest)
    if rejected:
        err = f"包被白名单拒绝: {', '.join(rejected)}"
        logger.warning(f"[SkillInstaller] {name} {err}")
        await store.write_install_log(
            SkillInstallLog(
                skill_name=name,
                source_url=manifest.source.url,
                source_commit=manifest.source.commit,
                packages=[],
                status="failed",
                error=err,
                installed_by=installed_by,
            )
        )
        return {
            "installed": False,
            "satisfied": False,
            "packages_installed": [],
            "error": err,
            "skipped_reason": "whitelist_rejected",
        }

    pre_check = check_skill_dependencies_raw(name)
    if pre_check["satisfied"]:
        await store.record_installed_dependencies(
            name,
            [d.package for d in manifest.python_dependencies],
        )
        return {
            "installed": False,
            "satisfied": True,
            "packages_installed": [],
            "error": "",
            "skipped_reason": "already_satisfied",
        }

    deps_to_install = manifest.python_dependencies
    logger.info(f"[SkillInstaller] 开始安装 {name} 的依赖: {[d.package for d in deps_to_install]}")

    requirements_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as tmp:
            requirements_path = Path(tmp.name)
        _write_requirements(deps_to_install, requirements_path)

        pip_args = _build_pip_args(deps_to_install, requirements_path)
        timeout = _get_install_timeout()
        result = _run_pip_install(pip_args, timeout)
    finally:
        if requirements_path is not None:
            try:
                requirements_path.unlink(missing_ok=True)
            except Exception:
                pass

    post_check = check_skill_dependencies_raw(name)
    availability_dict = post_check.get("availability") or {}
    deps_list = availability_dict.get("dependencies", []) if isinstance(availability_dict, dict) else []
    satisfied_packages = [d["package"] for d in deps_list if isinstance(d, dict) and d.get("satisfied")]

    status = "success" if result["success"] and post_check["satisfied"] else "failed"
    if result["success"] and not post_check["satisfied"]:
        status = "partial"

    await store.write_install_log(
        SkillInstallLog(
            skill_name=name,
            source_url=manifest.source.url,
            source_commit=manifest.source.commit,
            packages=[{"package": d.package, "version": d.version, "hash": d.hash} for d in deps_to_install],
            status=status,
            error=result["stderr_tail"][-500:] if not result["success"] else "",
            duration_seconds=result["duration_seconds"],
            installed_by=installed_by,
        )
    )

    if post_check["satisfied"]:
        await store.record_installed_dependencies(name, satisfied_packages)
        logger.info(f"[SkillInstaller] {name} 安装成功: {satisfied_packages} ({result['duration_seconds']}s)")
    else:
        logger.warning(
            f"[SkillInstaller] {name} 安装未完全成功: status={status}, stderr_tail={result['stderr_tail'][-200:]}"
        )

    return {
        "installed": True,
        "satisfied": post_check["satisfied"],
        "packages_installed": satisfied_packages,
        "error": "" if result["success"] else result["stderr_tail"][-500:],
        "skipped_reason": "",
    }

def install_skill_dependencies_sync(
    name: str,
    installed_by: str = "system",
) -> Dict:
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop is not None:
        future = asyncio.run_coroutine_threadsafe(install_skill_dependencies(name, installed_by), loop)
        return future.result(timeout=_get_install_timeout() + 30)

    return asyncio.run(install_skill_dependencies(name, installed_by))

async def ensure_all_skills_dependencies() -> Dict:

    registry = SkillRegistry.get_instance()
    all_skills = registry.list_all_skills()

    total = len(all_skills)
    installed_count = 0
    failed_count = 0
    skipped_count = 0
    details: Dict[str, Dict] = {}

    for skill in all_skills:
        name = skill["name"]
        if not skill.get("has_manifest"):
            skipped_count += 1
            details[name] = {"skipped_reason": "no_manifest"}
            continue

        try:
            result = await install_skill_dependencies(name, "system:startup")
            details[name] = result
            if result["installed"]:
                if result["satisfied"]:
                    installed_count += 1
                else:
                    failed_count += 1
            else:
                skipped_count += 1
        except Exception as e:
            logger.error(f"[SkillInstaller] 启动时安装 {name} 异常: {e}")
            failed_count += 1
            details[name] = {"installed": False, "satisfied": False, "error": str(e)}

    logger.info(
        f"[SkillInstaller] 启动依赖安装完成: "
        f"total={total}, installed={installed_count}, "
        f"failed={failed_count}, skipped={skipped_count}"
    )
    return {
        "total": total,
        "installed": installed_count,
        "failed": failed_count,
        "skipped": skipped_count,
        "details": details,
    }
