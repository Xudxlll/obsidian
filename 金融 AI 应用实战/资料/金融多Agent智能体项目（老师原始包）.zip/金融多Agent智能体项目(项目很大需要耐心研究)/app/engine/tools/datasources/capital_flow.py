import logging
from typing import Optional
from datetime import timedelta

from app.utils.time_utils import now_utc, get_current_date_compact
from app.engine.tools.common.tool_result import success_result, error_result, format_tool_result, ErrorCodes
from app.engine.tools.common.format import format_result
import pandas as pd

logger = logging.getLogger(__name__)

def get_money_flow(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    query_type: Optional[str] = None,
    ts_code: Optional[str] = None,
    content_type: Optional[str] = None,
    trade_date: Optional[str] = None,
) -> str:

    try:
        if not trade_date:
            if not end_date:
                end_date = get_current_date_compact()
            if not start_date:
                start_date = (now_utc() - timedelta(days=30)).strftime("%Y%m%d")

        symbol = ts_code or "market"
        if ts_code:
            symbol = (
                ts_code.replace(".SZ", "")
                .replace(".SH", "")
                .replace(".BJ", "")
                .replace(".sz", "")
                .replace(".sh", "")
                .replace(".bj", "")
                .zfill(6)
            )
        try:
            from app.engine.tools.common.data_access import read_with_refresh

            result = read_with_refresh(
                "CN", "money_flow", symbol=symbol, start_date=start_date, end_date=end_date
            )
            data = result.get("data") if result else None
            if data:
                df = pd.DataFrame(data) if isinstance(data, list) else data
                return format_tool_result(success_result(format_result(df, f"Money Flow: {ts_code or query_type}")))
        except Exception as e:
            logger.debug(f"资金流向数据获取失败: {e}")

        return format_tool_result(
            error_result(
                ErrorCodes.DATA_FETCH_ERROR,
                f"资金流向数据暂不可用: {ts_code or query_type}",
                suggestion="请先通过同步任务获取资金流向数据，或确认数据源已配置",
            )
        )
    except Exception as e:
        logger.error(f"get_money_flow failed: {e}")
        return format_tool_result(error_result(ErrorCodes.DATA_FETCH_ERROR, str(e)))

def get_margin_trade(
    data_type: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    ts_code: Optional[str] = None,
    exchange: Optional[str] = None,
) -> str:

    try:
        if not end_date:
            end_date = get_current_date_compact()
        if not start_date:
            start_date = (now_utc() - timedelta(days=30)).strftime("%Y%m%d")

        symbol = ts_code or "market"
        if ts_code:
            symbol = (
                ts_code.replace(".SZ", "")
                .replace(".SH", "")
                .replace(".BJ", "")
                .replace(".sz", "")
                .replace(".sh", "")
                .replace(".bj", "")
                .zfill(6)
            )
        try:
            from app.engine.tools.common.data_access import read_with_refresh

            result = read_with_refresh(
                "CN", "margin_trading", symbol=symbol, start_date=start_date, end_date=end_date
            )
            data = result.get("data") if result else None
            if data:
                df = pd.DataFrame(data) if isinstance(data, list) else data
                return format_tool_result(success_result(format_result(df, f"Margin Trade: {data_type}")))
        except Exception as e:
            logger.debug(f"融资融券数据获取失败: {e}")

        return format_tool_result(
            error_result(
                ErrorCodes.DATA_FETCH_ERROR,
                f"融资融券数据暂不可用: {data_type}",
                suggestion="请先通过同步任务获取融资融券数据，或确认数据源已配置",
            )
        )
    except Exception as e:
        logger.error(f"get_margin_trade failed: {e}")
        return format_tool_result(error_result(ErrorCodes.DATA_FETCH_ERROR, str(e)))
