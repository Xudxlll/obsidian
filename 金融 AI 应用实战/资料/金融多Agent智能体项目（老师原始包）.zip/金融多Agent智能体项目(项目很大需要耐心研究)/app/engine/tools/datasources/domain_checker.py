import logging
import time
import threading
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

class DomainAvailabilityChecker:

    async def check_domain(self, market: str, domain: str) -> bool:
        try:
            from app.data.core.interface import DataInterface

            di = DataInterface.get_instance()
            stats = await di.get_domain_stats(market, [domain])
            count = stats.get(domain, {}).get("records", 0)
            return count > 0
        except Exception as e:
            logger.debug(f"域可用性检查失败: {domain}: {e}")
            return False

    async def batch_check_domains(self, market: str, domains: List[str]) -> Dict[str, bool]:
        if not domains:
            return {}

        try:
            from app.data.core.interface import DataInterface

            di = DataInterface.get_instance()
            stats = await di.get_domain_stats(market, domains)
            return {d: stats.get(d, {}).get("records", 0) > 0 for d in domains}
        except Exception as e:
            logger.warning(f"批量域检测失败: {e}")
            return {d: False for d in domains}

    async def check_tool(self, spec, market: str, domain_status: Dict[str, bool]) -> bool:
        if market not in spec.markets:
            return False

        if spec.non_standard:
            return self._check_non_standard(spec)

        if not spec.domains:
            return True

        return all(domain_status.get(d, False) for d in spec.domains)

    async def batch_check(self, specs: list, market: str) -> Dict[str, bool]:
        standard_domains = set()
        for spec in specs:
            if not spec.non_standard:
                standard_domains.update(spec.domains)

        domain_status = await self.batch_check_domains(market, list(standard_domains))

        results = {}
        for spec in specs:
            results[spec.tool_id] = await self.check_tool(spec, market, domain_status)

        available_count = sum(1 for v in results.values() if v)
        logger.info(f"[DomainChecker] 市场={market}, 可用={available_count}/{len(results)}, 域状态={domain_status}")
        return results

    def _check_non_standard(self, spec) -> bool:
        check = spec.availability_check
        if check == "akshare_alive":
            from importlib.util import find_spec

            return find_spec("akshare") is not None
        return True

class AvailabilityCache:

    _instance: Optional["AvailabilityCache"] = None
    _lock = threading.Lock()

    def __init__(self):
        self._tool_availability: Dict[str, bool] = {}
        self._market: str = ""
        self._computed_at: float = 0

    @classmethod
    def get_instance(cls) -> "AvailabilityCache":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    @classmethod
    def reset_instance(cls):
        with cls._lock:
            cls._instance = None

    async def compute(self, market: str, specs: list) -> None:
        checker = DomainAvailabilityChecker()
        self._tool_availability = await checker.batch_check(specs, market)
        self._market = market
        self._computed_at = time.time()

        available = sum(1 for v in self._tool_availability.values() if v)
        unavailable = len(self._tool_availability) - available
        logger.info(
            f"[AvailabilityCache] 市场={market}, 可用={available}, 不可用={unavailable}, 详情={self._tool_availability}"
        )

    def is_available(self, tool_id: str) -> bool:

        if not self._tool_availability:
            return True
        return self._tool_availability.get(tool_id, False)

    def get_unavailable_ids(self, tool_ids: List[str]) -> List[str]:

        if not self._tool_availability:
            return []
        return [tid for tid in tool_ids if not self._tool_availability.get(tid, False)]

    def get_available_ids(self, tool_ids: List[str]) -> List[str]:

        if not self._tool_availability:
            return list(tool_ids)
        return [tid for tid in tool_ids if self._tool_availability.get(tid, False)]

    @property
    def market(self) -> str:
        return self._market

    @property
    def all_results(self) -> Dict[str, bool]:
        return dict(self._tool_availability)
