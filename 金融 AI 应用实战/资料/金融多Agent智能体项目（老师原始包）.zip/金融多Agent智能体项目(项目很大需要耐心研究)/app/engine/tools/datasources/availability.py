import logging
from typing import Dict, List, Set

logger = logging.getLogger(__name__)

def get_available_data_sources() -> Set[str]:

    try:
        from app.data.config import load_yaml

        cap_data = load_yaml("capability_matrix.yaml")
        sources = set()
        for market, domains in cap_data.items():
            if not isinstance(domains, dict):
                continue
            for domain, source_map in domains.items():
                if not isinstance(source_map, dict):
                    continue
                for source_name in source_map.keys():
                    name = source_name.lower()
                    if "tushare" in name:
                        sources.add("tushare")
                    elif "akshare" in name or "ak" in name:
                        sources.add("akshare")
                    elif "baostock" in name or "bst" in name:
                        sources.add("baostock")
                    elif "finnhub" in name:
                        sources.add("finnhub")
                    else:
                        sources.add(name)

        return sources
    except Exception as e:
        logger.warning(f"获取可用数据源失败: {e}")
        return set()

def check_tool_availability(tool_name: str, data_source_map: Dict[str, List[str]]) -> bool:

    required_sources = data_source_map.get(tool_name, [])
    if not required_sources:
        return True

    available = get_available_data_sources()

    for source in required_sources:
        if source.lower() in available:
            return True

    return False

def check_all_tools_availability(data_source_map: Dict[str, List[str]]) -> Dict[str, bool]:

    available = get_available_data_sources()

    result = {}
    for tool_name, required_sources in data_source_map.items():
        if not required_sources:
            result[tool_name] = True
            continue

        is_available = any(source.lower() in available for source in required_sources)
        result[tool_name] = is_available

    return result

def get_availability_summary(data_source_map: Dict[str, List[str]]) -> dict:

    available_sources = get_available_data_sources()
    availability = check_all_tools_availability(data_source_map)

    available_count = sum(1 for v in availability.values() if v)
    unavailable_count = sum(1 for v in availability.values() if not v)

    details = {}
    for tool_name, is_available in availability.items():
        details[tool_name] = {
            "available": is_available,
            "required_sources": data_source_map.get(tool_name, []),
        }

    return {
        "total": len(availability),
        "available": available_count,
        "unavailable": unavailable_count,
        "available_sources": sorted(available_sources),
        "details": details,
    }
