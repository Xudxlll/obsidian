import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from app.engine.tools.datasources.registry import (
    DATASOURCE_REGISTRY,
    DatasourceSpec,
    resolve_real_fn,
)

logger = logging.getLogger(__name__)

@dataclass
class ToolInfo:

    name: str
    description: str
    func: Callable
    metadata: Dict[str, Any] = field(default_factory=dict)

def load_datasource_tools(toolkit_config: Optional[Dict] = None) -> List[ToolInfo]:

    all_tools = []

    for spec in DATASOURCE_REGISTRY:
        try:
            real_fn = resolve_real_fn(spec.fn)

            tool = ToolInfo(
                name=spec.tool_id,
                description=spec.description,
                func=real_fn,
                metadata={
                    "tool_category": "builtin",
                    "tool_id": spec.tool_id,
                    "builtin_domains": spec.domains,
                },
            )
            all_tools.append(tool)

        except Exception as e:
            logger.error(f"❌ 包装工具 {spec.tool_id} 失败: {e}")

    logger.info(f"✅ 预注入数据源加载完成: {len(all_tools)} 个")
    return all_tools

def get_datasource_tool_specs() -> List[DatasourceSpec]:
    return list(DATASOURCE_REGISTRY)
