import json
import logging
from typing import Optional
from datetime import timedelta

from app.utils.time_utils import now_utc, get_current_date, get_current_date_compact
from app.engine.tools.common.tool_result import success_result, error_result, format_tool_result, ErrorCodes
from app.engine.tools.common.format import format_result
from app.engine.tools.common.data_access import read_with_refresh

logger = logging.getLogger(__name__)

def _to_json_str(data) -> str:
    import pandas as pd

    if isinstance(data, pd.DataFrame):
        return json.dumps(data.to_dict(orient="records"), ensure_ascii=False, default=str)
    return str(data)

def _normalize_symbol(symbol: str, market: str) -> str:
    if market == "CN":
        return (
            symbol.replace(".SZ", "")
            .replace(".SH", "")
            .replace(".BJ", "")
            .replace(".sz", "")
            .replace(".sh", "")
            .replace(".bj", "")
        )
    elif market == "HK":
        return symbol.replace(".HK", "").replace(".hk", "").zfill(5)
    return symbol.upper()

def _read_daily_quotes(market: str, symbol: str, start_date: str, end_date: str):
    clean_symbol = _normalize_symbol(symbol, market)
    result = read_with_refresh(
        market, "daily_quotes", symbol=clean_symbol, start_date=start_date, end_date=end_date
    )
    raw = result.get("data") if result else None
    if not raw:
        return None
    import pandas as pd

    return pd.DataFrame(raw) if isinstance(raw, list) and raw else raw

_MARKET_MAP = {
    "is_china": ("CN", "A股"),
    "is_hk": ("HK", "港股"),
    "is_us": ("US", "美股"),
}

def get_stock_data(
    stock_code: str,
    market_type: str = "cn",
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
) -> str:

    try:
        from app.utils.stock_utils import StockUtils

        market_info = StockUtils.get_market_info(stock_code)

        market_key = None
        for attr, (mkt, name) in _MARKET_MAP.items():
            if market_info.get(attr):
                market_key = mkt
                break

        if not market_key:
            if market_type == "hk":
                market_key = "HK"
            elif market_type == "us":
                market_key = "US"
            else:
                market_key = "CN"

        if not start_date:
            start_date = (now_utc() - timedelta(days=30)).strftime("%Y-%m-%d")
        if not end_date:
            end_date = get_current_date()

        data = _read_daily_quotes(market_key, stock_code, start_date, end_date)

        if data is not None:
            return format_tool_result(success_result(_to_json_str(data)))
        else:
            return format_tool_result(
                error_result(
                    ErrorCodes.UNKNOWN_MARKET,
                    f"无法获取 {stock_code} 的行情数据（请先同步 daily_quotes 数据）",
                    suggestion="请使用标准格式的股票代码，如 000001.SZ、00700.HK、AAPL",
                )
            )

    except Exception as e:
        logger.error(f"get_stock_data failed: {e}")
        return format_tool_result(error_result(ErrorCodes.DATA_FETCH_ERROR, f"获取股票数据失败: {str(e)}"))

def get_stock_data_minutes(
    market_type: str,
    stock_code: str,
    start_datetime: Optional[str] = None,
    end_datetime: Optional[str] = None,
    freq: str = "30min",
) -> str:

    try:
        if not end_datetime:
            end_datetime = now_utc().strftime("%Y-%m-%d %H:%M:%S")
        if not start_datetime:
            start_datetime = (now_utc() - timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")

        freq_map = {"1min": "1", "5min": "5", "15min": "15", "30min": "30", "60min": "60"}
        freq_short = freq_map.get(freq, "30")

        clean_symbol = _normalize_symbol(stock_code, "CN")
        result = read_with_refresh(
            "CN",
            "intraday_quotes",
            symbol=clean_symbol,
            start_date=start_datetime,
            end_date=end_datetime,
            filters={"freq": freq_short},
        )
        intraday_data = result.get("data") if result else None
        if intraday_data:
            import pandas as pd

            data = pd.DataFrame(intraday_data) if isinstance(intraday_data, list) else intraday_data
            return format_tool_result(success_result(format_result(data, f"{stock_code} {freq} Data")))

        return format_tool_result(
            error_result(
                ErrorCodes.DATA_FETCH_ERROR, f"无法获取分钟级行情数据: {stock_code}（请先同步 intraday_quotes 数据）"
            )
        )
    except Exception as e:
        logger.error(f"get_stock_data_minutes failed: {e}")
        return format_tool_result(error_result(ErrorCodes.DATA_FETCH_ERROR, str(e)))

def get_index_data(stock_code: str, start_date: Optional[str] = None, end_date: Optional[str] = None) -> str:

    try:
        from app.utils.stock_utils import StockUtils

        if not end_date:
            end_date = get_current_date_compact()
        if not start_date:
            start_date = (now_utc() - timedelta(days=90)).strftime("%Y%m%d")

        market_info = StockUtils.get_market_info(stock_code)
        market = "CN"
        for attr, (mkt, _) in _MARKET_MAP.items():
            if market_info.get(attr):
                market = mkt
                break

        clean_symbol = _normalize_symbol(stock_code, market)
        result = read_with_refresh(
            market, "market_quotes", symbol=clean_symbol, start_date=start_date, end_date=end_date
        )
        index_data = result.get("data") if result else None
        if index_data:
            import pandas as pd

            data = pd.DataFrame(index_data) if isinstance(index_data, list) else index_data
            return format_tool_result(success_result(format_result(data, f"Index: {stock_code}")))

        return format_tool_result(
            error_result(
                ErrorCodes.DATA_FETCH_ERROR, f"指数行情数据暂不可用: {stock_code}（请先同步 market_quotes 数据）"
            )
        )
    except Exception as e:
        logger.error(f"get_index_data failed: {e}")
        return format_tool_result(error_result(ErrorCodes.DATA_FETCH_ERROR, str(e)))

def get_stock_indicators(
    stock_code: str,
    market_type: str = "cn",
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
) -> str:

    try:
        from app.utils.stock_utils import StockUtils

        market_info = StockUtils.get_market_info(stock_code)

        market_key = None
        for attr, (mkt, name) in _MARKET_MAP.items():
            if market_info.get(attr):
                market_key = mkt
                break

        if not market_key:
            if market_type == "hk":
                market_key = "HK"
            elif market_type == "us":
                market_key = "US"
            else:
                market_key = "CN"

        if not start_date:
            start_date = (now_utc() - timedelta(days=30)).strftime("%Y-%m-%d")
        if not end_date:
            end_date = get_current_date()

        clean_symbol = _normalize_symbol(stock_code, market_key)
        result = read_with_refresh(
            market_key, "daily_indicators", symbol=clean_symbol, start_date=start_date, end_date=end_date
        )
        raw = result.get("data") if result else None

        if raw:
            import pandas as pd

            data = pd.DataFrame(raw) if isinstance(raw, list) and raw else raw
            return format_tool_result(success_result(format_result(data, f"{stock_code} Indicators")))

        return format_tool_result(
            error_result(
                ErrorCodes.DATA_FETCH_ERROR,
                f"无法获取 {stock_code} 的估值指标数据（请先同步 daily_indicators 数据）",
            )
        )

    except Exception as e:
        logger.error(f"get_stock_indicators failed: {e}")
        return format_tool_result(error_result(ErrorCodes.DATA_FETCH_ERROR, str(e)))
