import logging
from typing import Any

logger = logging.getLogger(__name__)

def format_result(data: Any, title: str, max_rows: int = 2000) -> str:
    if data is None:
        return f"# {title}\n\nNo data found."

    if isinstance(data, list) and not data:
        return f"# {title}\n\nNo data found."

    if isinstance(data, str):
        if "|" in data and data.count("\n") > max_rows + 5:
            lines = data.split("\n")
            header = lines[:2]
            content = lines[2:]
            if len(content) > max_rows:
                truncated_content = content[:max_rows]
                return "\n".join(header + truncated_content + [f"\n... (剩余 {len(content) - max_rows} 行已隐藏)"])
        max_chars = 8000
        if len(data) > max_chars:
            return data[:max_chars] + f"\n\n... (字符串过长，已截断至 {max_chars} 字符)"
        return data

    if isinstance(data, list) and len(data) > 0 and isinstance(data[0], dict):
        original_len = len(data)
        if original_len > max_rows:
            data = data[:max_rows]

        headers = list(data[0].keys())
        header_row = "| " + " | ".join(headers) + " |"
        separator_row = "| " + " | ".join(["---"] * len(headers)) + " |"

        rows = []
        for item in data:
            row = "| " + " | ".join([str(item.get(h, "")) for h in headers]) + " |"
            rows.append(row)

        result = f"# {title}\n\n{header_row}\n{separator_row}\n" + "\n".join(rows)

        if original_len > max_rows:
            result += f"\n\n... (剩余 {original_len - max_rows} 行已隐藏)"

        return result

    return f"# {title}\n\n{str(data)}"
