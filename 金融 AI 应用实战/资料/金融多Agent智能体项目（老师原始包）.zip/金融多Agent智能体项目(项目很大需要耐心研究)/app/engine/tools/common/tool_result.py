import json
from typing import Optional, Literal, TypedDict, Union

class ToolResult(TypedDict):

    status: Literal["success", "no_data", "error"]
    """状态标识：
    - success: 成功获取数据
    - no_data: 未找到数据（这是正常状态，AI 不应重试）
    - error: 发生错误（AI 可以根据建议决定是否重试）
    """

    data: str
    """返回的 Markdown 格式数据"""

    error_code: Optional[str]
    """错误代码，仅在 status=error 时有值"""

    suggestion: Optional[str]
    """给 AI 的建议，帮助 AI 决定下一步操作"""

def success_result(data: str) -> ToolResult:
    return {
        "status": "success",
        "data": data,
        "error_code": None,
        "suggestion": None,
    }

def no_data_result(
    message: str = "未找到相关数据",
    suggestion: str = "这是正常状态，不要重试或尝试其他参数",
) -> ToolResult:
    return {
        "status": "no_data",
        "data": message,
        "error_code": None,
        "suggestion": suggestion,
    }

def error_result(
    error_code: str,
    message: str,
    suggestion: Optional[str] = None,
) -> ToolResult:
    return {
        "status": "error",
        "data": message,
        "error_code": error_code,
        "suggestion": suggestion or "检查输入参数后重试，或使用其他工具",
    }

def format_tool_result(result: Union[ToolResult, str]) -> str:

    if isinstance(result, str):
        return result
    return json.dumps(result, ensure_ascii=False, indent=2)

class ErrorCodes:

    MISSING_PARAM = "MISSING_PARAM"
    INVALID_PARAM = "INVALID_PARAM"
    DATA_FETCH_ERROR = "DATA_FETCH_ERROR"
    NETWORK_ERROR = "NETWORK_ERROR"
    PARSE_ERROR = "PARSE_ERROR"
    UNKNOWN_MARKET = "UNKNOWN_MARKET"
    STOCK_CODE_INVALID = "STOCK_CODE_INVALID"
