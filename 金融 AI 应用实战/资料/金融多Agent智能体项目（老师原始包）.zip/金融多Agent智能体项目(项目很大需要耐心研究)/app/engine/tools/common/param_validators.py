import re
import logging
from datetime import datetime
from typing import Tuple

logger = logging.getLogger(__name__)

class ValidationResult:

    def __init__(self, is_valid: bool, error_message: str = ""):
        self.is_valid = is_valid
        self.error_message = error_message

    def __bool__(self):
        return self.is_valid

class MCPToolValidators:

    STOCK_CODE_CN = re.compile(r"^\d{6}$")
    STOCK_CODE_HK = re.compile(r"^\d{4,5}$")
    STOCK_CODE_US = re.compile(r"^[A-Z]{1,5}$")

    @staticmethod
    def validate_stock_code(code: str, market_type: str = "cn") -> ValidationResult:

        if not code or not isinstance(code, str):
            return ValidationResult(False, "股票代码不能为空")

        code = code.strip().upper()

        if "." in code:
            parts = code.split(".")
            code = parts[0]
            suffix = parts[1].upper()
            if suffix in ["SH", "SZ"]:
                market_type = "cn"
            elif suffix == "HK":
                market_type = "hk"
            elif suffix in ["US", "NYSE", "NASDAQ", "AMEX"]:
                market_type = "us"

        if market_type.lower() in ["cn", "a股", "a", "china"]:
            if not MCPToolValidators.STOCK_CODE_CN.match(code):
                return ValidationResult(False, f"A股代码格式错误：{code}，应为6位数字")
        elif market_type.lower() in ["hk", "港股", "hongkong"]:
            if not MCPToolValidators.STOCK_CODE_HK.match(code):
                return ValidationResult(False, f"港股代码格式错误：{code}，应为4-5位数字")
        elif market_type.lower() in ["us", "美股", "usa", "united states"]:
            if not MCPToolValidators.STOCK_CODE_US.match(code):
                return ValidationResult(False, f"美股代码格式错误：{code}，应为1-5位大写字母")
        else:
            if MCPToolValidators.STOCK_CODE_CN.match(code):
                return ValidationResult(True)
            elif MCPToolValidators.STOCK_CODE_HK.match(code):
                return ValidationResult(True)
            elif MCPToolValidators.STOCK_CODE_US.match(code):
                return ValidationResult(True)
            else:
                return ValidationResult(False, f"股票代码格式错误：{code}，无法识别市场类型")

        return ValidationResult(True)

    @staticmethod
    def validate_date(date_str: str) -> ValidationResult:

        if not date_str or not isinstance(date_str, str):
            return ValidationResult(False, "日期不能为空")

        date_str = date_str.strip()

        try:
            parsed_date = datetime.strptime(date_str, "%Y-%m-%d")
        except ValueError:
            return ValidationResult(False, f"日期格式错误：{date_str}，应为 YYYY-MM-DD")

        if parsed_date.year < 1900 or parsed_date.year > 2100:
            return ValidationResult(False, f"日期超出范围：{date_str}，应在 1900-2100 之间")

        return ValidationResult(True)

    @staticmethod
    def validate_date_range(start_date: str, end_date: str) -> ValidationResult:

        start_result = MCPToolValidators.validate_date(start_date)
        if not start_result:
            return start_result

        end_result = MCPToolValidators.validate_date(end_date)
        if not end_result:
            return end_result

        start = datetime.strptime(start_date.strip(), "%Y-%m-%d")
        end = datetime.strptime(end_date.strip(), "%Y-%m-%d")

        if start > end:
            return ValidationResult(False, f"开始日期不能晚于结束日期：{start_date} > {end_date}")

        delta = end - start
        if delta.days > 365:
            return ValidationResult(False, f"日期范围过大：{delta.days} 天，不应超过 365 天")

        return ValidationResult(True)

    @staticmethod
    def validate_limit(limit: int, min_val: int = 1, max_val: int = 1000) -> ValidationResult:

        if not isinstance(limit, int):
            try:
                limit = int(limit)
            except (ValueError, TypeError):
                return ValidationResult(False, f"限制值必须为整数：{limit}")

        if limit < min_val or limit > max_val:
            return ValidationResult(False, f"限制值超出范围：{limit}，应在 {min_val}-{max_val} 之间")

        return ValidationResult(True)

    @staticmethod
    def validate_string_length(value: str, max_length: int = 100, field_name: str = "字段") -> ValidationResult:

        if not isinstance(value, str):
            return ValidationResult(False, f"{field_name}必须为字符串")

        if len(value) > max_length:
            return ValidationResult(False, f"{field_name}长度超出限制：{len(value)} > {max_length}")

        return ValidationResult(True)

    @staticmethod
    def validate_period(period: str) -> ValidationResult:

        valid_periods = [
            "day",
            "week",
            "month",
            "minute",
            "5m",
            "15m",
            "30m",
            "60m",
            "1d",
            "1w",
            "1m",
        ]

        if not period or not isinstance(period, str):
            return ValidationResult(False, "周期不能为空")

        period = period.strip().lower()

        period_map = {
            "daily": "day",
            "d": "day",
            "weekly": "week",
            "w": "week",
            "monthly": "month",
            "m": "month",
            "minutely": "minute",
            "1min": "minute",
            "60min": "60m",
        }

        period = period_map.get(period, period)

        if period not in valid_periods:
            return ValidationResult(False, f"无效的周期：{period}，支持：{', '.join(valid_periods)}")

        return ValidationResult(True)

    @staticmethod
    def sanitize_input(input_str: str, max_length: int = 200) -> str:

        if not isinstance(input_str, str):
            return str(input_str)

        if len(input_str) > max_length:
            input_str = input_str[:max_length]
            logger.warning(f"输入字符串被截断到 {max_length} 字符")

        dangerous_patterns = [
            r"<script.*?>.*?</script>",
            r"[';\"-]",
            r"\.\./",
            r"\|\|.*&&",
        ]

        cleaned = input_str
        for pattern in dangerous_patterns:
            cleaned = re.sub(pattern, "", cleaned, flags=re.IGNORECASE)

        return cleaned.strip()

def validate_stock_code(code: str, market_type: str = "cn") -> Tuple[bool, str]:
    result = MCPToolValidators.validate_stock_code(code, market_type)
    return result.is_valid, result.error_message

def validate_date(date_str: str) -> Tuple[bool, str]:
    result = MCPToolValidators.validate_date(date_str)
    return result.is_valid, result.error_message

def validate_limit(limit: int, min_val: int = 1, max_val: int = 1000) -> Tuple[bool, str]:
    result = MCPToolValidators.validate_limit(limit, min_val, max_val)
    return result.is_valid, result.error_message

def validate_period(period: str) -> Tuple[bool, str]:
    result = MCPToolValidators.validate_period(period)
    return result.is_valid, result.error_message
