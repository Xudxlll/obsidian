import logging
from typing import Any, Dict, Optional

from app.core.async_utils import run_async

logger = logging.getLogger(__name__)

_REFRESH_TIMEOUT = 30

def read_with_refresh(
    market: str,
    domain: str,
    symbol: Optional[str] = None,
    timeout: int = _REFRESH_TIMEOUT,
    **read_kwargs: Any,
) -> Optional[Dict[str, Any]]:

    from app.data.core.interface import DataInterface

    di = DataInterface.get_instance()

    def _has_data(result: Optional[Dict[str, Any]]) -> bool:
        if not result:
            return False
        data = result.get("data")
        if data is None:
            return False
        if isinstance(data, (list, dict)):
            return len(data) > 0
        return bool(data)

    try:
        result = run_async(di.read(market, domain, symbol=symbol, **read_kwargs))
        if _has_data(result):
            return result
    except Exception as e:
        logger.warning(f"[data_access] 读取 {market}/{domain}/{symbol} 失败: {e}")

    if not symbol:
        return None
    try:
        refresh_result = run_async(
            di.refresh(market, symbol, domains=[domain], force=True, timeout=timeout)
        )
        if not (refresh_result and refresh_result.domains.get(domain)):
            logger.info(f"[data_access] {market}/{domain}/{symbol} 按需刷新无结果（可能不支持该域或源不可用）")
            return None
    except Exception as e:
        logger.warning(f"[data_access] {market}/{domain}/{symbol} 按需刷新失败: {e}")
        return None

    try:
        result = run_async(di.read(market, domain, symbol=symbol, **read_kwargs))
        if _has_data(result):
            return result
    except Exception as e:
        logger.warning(f"[data_access] 刷新后重读 {market}/{domain}/{symbol} 失败: {e}")

    return None
