import logging
import threading
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

TOOL_TYPE_BUILTIN = "builtin"
TOOL_TYPE_MCP = "mcp"
TOOL_TYPE_SKILL = "skill"

class ToolRegistry:

    def __init__(self):
        self._builtin_tools: List = []
        self._builtin_metas: Dict[str, Dict] = {}

        self._initialized = False

    @classmethod
    def get_instance(cls) -> "ToolRegistry":
        global _registry
        if _registry is None:
            with _registry_lock:
                if _registry is None:
                    _registry = cls()
        return _registry

    @classmethod
    def reset_instance(cls):
        global _registry
        with _registry_lock:
            _registry = None

    def initialize(self, toolkit_config: Optional[Dict] = None):

        if self._initialized:
            logger.info("[ToolRegistry] 已初始化，跳过重复初始化")
            return

        self._init_skill_registry()

        self._load_builtin_tools(toolkit_config)

        self._load_skill_entrypoints()

        self._initialized = True
        logger.info(f"[ToolRegistry] 初始化完成: 内置={len(self._builtin_tools)}")

    @property
    def is_initialized(self) -> bool:
        return self._initialized

    def ensure_initialized(self, toolkit_config: Optional[Dict] = None) -> None:
        if not self._initialized:
            self.initialize(toolkit_config)

    def _init_skill_registry(self):
        try:
            from app.engine.tools.skill.registry import SkillRegistry
            from app.engine.tools.skill.availability import check_skill_dependencies_raw
            from app.engine.tools.skill.dependency_installer import (
                install_skill_dependencies_sync,
            )

            registry = SkillRegistry.get_instance()
            registry.set_dependency_callbacks(
                check_callback=check_skill_dependencies_raw,
                install_callback=install_skill_dependencies_sync,
            )
            logger.debug("[ToolRegistry] SkillRegistry 依赖回调已注入")
        except Exception as e:
            logger.warning(f"[ToolRegistry] SkillRegistry 初始化失败（可忽略）: {e}")

    def _load_builtin_tools(self, toolkit_config: Optional[Dict] = None):
        try:
            from app.engine.tools.builtin.registry import CALLABLE_TOOL_REGISTRY
            from app.engine.tools.datasources import load_datasource_tools
            from app.engine.tools.datasources.loader import ToolInfo
            from app.engine.tools.datasources.registry import DATASOURCE_REGISTRY

            self._builtin_tools = load_datasource_tools(toolkit_config)

            self._builtin_tools.extend(
                ToolInfo(
                    name=spec.tool_id,
                    description=spec.description,
                    func=spec.fn,
                    metadata={
                        "tool_category": "builtin",
                        "tool_id": spec.tool_id,
                        "builtin_domains": spec.domains,
                    },
                )
                for spec in CALLABLE_TOOL_REGISTRY
            )

            self._builtin_metas = {}
            for spec in [*DATASOURCE_REGISTRY, *CALLABLE_TOOL_REGISTRY]:
                self._builtin_metas[spec.tool_id] = {
                    "tool_id": spec.tool_id,
                    "display_name": spec.display_name,
                    "domains": spec.domains,
                    "markets": spec.markets,
                    "non_standard": spec.non_standard,
                }

            logger.info(f"[ToolRegistry] 内置工具加载完成: {len(self._builtin_tools)} 个")
        except Exception as e:
            logger.error(f"[ToolRegistry] 内置工具加载失败: {e}")
            self._builtin_tools = []
            self._builtin_metas = {}

    def _load_skill_entrypoints(self):
        try:
            from app.engine.tools.skill.entrypoint_loader import (
                load_all_skill_entrypoints,
            )

            result = load_all_skill_entrypoints()
            registered_count = sum(len(v) for v in result["registered"].values())
            if registered_count > 0:
                self._load_builtin_tools()
                logger.info(f"[ToolRegistry] Skill 脚本入口已注册: {registered_count} 个")
        except Exception as e:
            logger.warning(f"[ToolRegistry] Skill 入口注册失败（可忽略）: {e}")

    def get_all_tools(self) -> List:
        return list(self._builtin_tools)

    def get_builtin_tools(self) -> List:
        return list(self._builtin_tools)

    def get_builtin_tool_metas(self) -> Dict[str, Dict]:
        return dict(self._builtin_metas)

_registry = None
_registry_lock = threading.Lock()

def get_all_tools(toolkit=None) -> List:

    registry = ToolRegistry.get_instance()

    if not registry.is_initialized:
        toolkit_config = {}
        if toolkit:
            if isinstance(toolkit, dict):
                toolkit_config = toolkit
            elif hasattr(toolkit, "config"):
                toolkit_config = toolkit.config
        registry.initialize(toolkit_config)

    return registry.get_all_tools()
