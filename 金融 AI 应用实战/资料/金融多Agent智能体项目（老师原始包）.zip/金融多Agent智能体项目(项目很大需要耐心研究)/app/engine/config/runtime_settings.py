#!/usr/bin/env python3

from __future__ import annotations

import threading
from typing import Any, Optional, Callable

from app.core.env import get_env

import logging
_logger = logging.getLogger("zhenshabi.config")

_cached_settings: dict = {}
_cache_lock = threading.Lock()

def set_cached_settings(settings: dict) -> None:
    global _cached_settings
    with _cache_lock:
        _cached_settings = dict(settings) if settings else {}
    _logger.info(f"[runtime_settings] 动态配置缓存已更新，共 {len(_cached_settings)} 项")

def _get_system_settings_sync() -> dict:
    if _cached_settings:
        return _cached_settings
    _logger.debug("动态配置缓存为空，使用环境变量和默认值")
    return {}

def _coerce(value: Any, caster: Callable[[Any], Any], default: Any) -> Any:
    try:
        if value is None:
            return default
        return caster(value)
    except Exception as e:
        _logger.debug(f"配置值转换失败，使用默认值: {e}")
        return default

def get_number(env_var: str, system_key: Optional[str], default: float | int, caster: Callable[[Any], Any]) -> float | int:
    if system_key:
        eff = _get_system_settings_sync()
        if isinstance(eff, dict) and system_key in eff:
            return _coerce(eff.get(system_key), caster, default)

    env_val = get_env(env_var)
    if env_val is not None and str(env_val).strip() != "":
        return _coerce(env_val, caster, default)

    return default

def get_float(env_var: str, system_key: Optional[str], default: float) -> float:
    return get_number(env_var, system_key, default, float)

def get_int(env_var: str, system_key: Optional[str], default: int) -> int:
    return get_number(env_var, system_key, default, int)

def get_bool(env_var: str, system_key: Optional[str], default: bool) -> bool:
    if system_key:
        eff = _get_system_settings_sync()
        if isinstance(eff, dict) and system_key in eff:
            v = eff.get(system_key)
            if isinstance(v, bool):
                return v
            if isinstance(v, (int, float)):
                return bool(v)
            if isinstance(v, str):
                return str(v).strip().lower() in ("1", "true", "yes", "on")
    env_val = get_env(env_var)
    if env_val is not None and str(env_val).strip() != "":
        return str(env_val).strip().lower() in ("1", "true", "yes", "on")
    return default

def use_app_cache_enabled(default: bool = False) -> bool:
    src = "default"
    env_val = get_env("TA_USE_APP_CACHE")
    try:
        eff = _get_system_settings_sync()
    except Exception as e:
        _logger.debug(f"获取系统设置失败: {e}")
        eff = {}
    if isinstance(eff, dict) and "ta_use_app_cache" in eff:
        src = "db"
    elif env_val is not None and str(env_val).strip() != "":
        src = "env"

    val = get_bool("TA_USE_APP_CACHE", "ta_use_app_cache", default)

    try:
        _logger.info(f"[runtime_settings] TA_USE_APP_CACHE evaluated -> {val} (source={src}, env={env_val})")
    except Exception as e:
        _logger.debug(f"日志写入失败: {e}")
        pass

from zoneinfo import ZoneInfo as _ZoneInfo

def get_timezone_name(default: str = "Asia/Shanghai") -> str:
    try:
        eff = _get_system_settings_sync()
        if isinstance(eff, dict):
            tz = eff.get("app_timezone") or eff.get("APP_TIMEZONE")
            if isinstance(tz, str) and tz.strip():
                return tz.strip()
    except Exception as e:
        _logger.debug(f"获取系统时区设置失败: {e}")
    for env_key in ("APP_TIMEZONE", "TIMEZONE", "TA_TIMEZONE"):
        val = get_env(env_key)
        if isinstance(val, str) and val.strip():
            return val.strip()

    return default

def get_zoneinfo(default: str = "Asia/Shanghai") -> _ZoneInfo:
    name = get_timezone_name(default)
    try:
        return _ZoneInfo(name)
    except Exception as e:
        _logger.debug(f"时区 '{name}' 无效，回退到 UTC: {e}")
        return _ZoneInfo("UTC")

__all__ = [
    "get_float",
    "get_int",
    "get_bool",
    "use_app_cache_enabled",
    "get_timezone_name",
    "get_zoneinfo",
    "set_cached_settings",
]
