#!/usr/bin/env python3

from dataclasses import dataclass

from app.models.config import LLMConfig as ModelConfig

@dataclass
class UsageRecord:
    timestamp: str
    provider: str
    model_name: str
    input_tokens: int
    output_tokens: int
    cost: float
    currency: str = "CNY"
    session_id: str = ""
    analysis_type: str = "stock_analysis"

@dataclass
class PricingConfig:
    provider: str
    model_name: str
    input_price_per_1k: float
    output_price_per_1k: float
    currency: str = "CNY"
