import os
import threading
import yaml
from typing import List, Dict, Any, Optional

from app.core.env import get_env
import logging

logger = logging.getLogger("analysts.dynamic")

class DynamicAnalystFactory:

    _config_cache = {}
    _config_mtime = {}
    _config_lock = threading.Lock()

    _LEGACY_KEYS = ("whenToUse", "groups", "source", "initial_task")

    @classmethod
    def _normalize_mode(cls, agent: Any) -> Any:

        if not isinstance(agent, dict):
            return agent
        if "tools" in agent and "data_tools" not in agent:
            data_tools: List[str] = []
            skills: List[str] = []
            for tid in agent.get("tools") or []:
                (skills if "." in str(tid) else data_tools).append(tid)
            agent["data_tools"] = data_tools
            if skills:
                agent.setdefault("skills", skills)
            agent.pop("tools", None)
        for key in cls._LEGACY_KEYS:
            agent.pop(key, None)
        return agent

    @classmethod
    def load_config(cls, config_path: str = None) -> Dict[str, Any]:
        if not config_path:
            env_dir = get_env("AGENT_CONFIG_DIR")
            if env_dir and os.path.exists(env_dir):
                config_path = os.path.join(env_dir, "phase1_agents_config.yaml")
            else:
                current_dir = os.path.dirname(os.path.abspath(__file__))
                config_path_candidate = ""
                probe = current_dir
                for _ in range(6):
                    probe = os.path.dirname(probe)
                    candidate = os.path.join(probe, "config", "agents", "phase1_agents_config.yaml")
                    if os.path.exists(candidate):
                        config_path_candidate = candidate
                        break

                if os.path.exists(config_path_candidate):
                    config_path = config_path_candidate
                else:
                    logger.warning(f"⚠️ 未找到配置文件: {config_path_candidate}")

        try:
            mtime = os.path.getmtime(config_path)
        except Exception as e:
            logger.debug(f"获取配置文件修改时间失败: {e}")
            mtime = None

        with cls._config_lock:
            if (
                config_path in cls._config_cache
                and config_path in cls._config_mtime
                and mtime is not None
                and cls._config_mtime.get(config_path) == mtime
            ):
                return cls._config_cache[config_path]

            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = yaml.safe_load(f)
                    cls._config_cache[config_path] = config or {}
                    if mtime is not None:
                        cls._config_mtime[config_path] = mtime
                    return cls._config_cache[config_path]
            except Exception as e:
                logger.error(f"❌ 加载配置文件失败: {config_path}, 错误: {e}")
                return {}

    @classmethod
    def get_agent_config(cls, slug_or_name: str, config_path: str = None) -> Optional[Dict[str, Any]]:

        config = cls.load_config(config_path)

        all_agents = config.get('customModes', []) + config.get('agents', [])

        for agent in all_agents:
            slug = agent.get('slug', '')
            name = agent.get('name', '')

            internal_key = slug.replace("-analyst", "").replace("-", "_")

            if slug == slug_or_name:
                return cls._normalize_mode(agent)
            if internal_key == slug_or_name:
                return cls._normalize_mode(agent)
            if name == slug_or_name:
                return cls._normalize_mode(agent)

        return None

    @classmethod
    def get_slug_by_name(cls, name: str, config_path: str = None) -> Optional[str]:

        config = cls.load_config(config_path)

        for agent in config.get('customModes', []):
            if agent.get('name') == name:
                return agent.get('slug')

        for agent in config.get('agents', []):
            if agent.get('name') == name:
                return agent.get('slug')

        return None

    @classmethod
    def get_all_agents(cls, config_path: str = None) -> List[Dict[str, Any]]:

        config = cls.load_config(config_path)
        agents = []

        agents.extend(cls._normalize_mode(a) for a in config.get('customModes', []))

        agents.extend(cls._normalize_mode(a) for a in config.get('agents', []))

        return agents

    @classmethod
    def build_lookup_map(cls, config_path: str = None) -> Dict[str, Dict[str, Any]]:

        agents = cls.get_all_agents(config_path)
        lookup = {}

        for agent in agents:
            slug = agent.get('slug', '')
            name = agent.get('name', '')

            if not slug:
                continue

            internal_key = slug.replace("-analyst", "").replace("-", "_")

            tool_key = cls._infer_tool_key(slug, name, agent_config=agent)

            config_info = {
                'internal_key': internal_key,
                'slug': slug,
                'tool_key': tool_key,
                'name': name,
                'display_name': internal_key.replace('_', ' ').title()
            }

            lookup[slug] = config_info
            lookup[internal_key] = config_info
            if name:
                lookup[name] = config_info

        return lookup

    @classmethod
    def _infer_tool_key(cls, slug: str, name: str = "", agent_config: dict = None) -> str:

        if agent_config and agent_config.get("tool_key"):
            return agent_config["tool_key"]

        search_key = slug.lower()

        if "news" in search_key or "新闻" in name:
            return "news"
        elif "social" in search_key or "sentiment" in search_key or "社交" in name or "情绪" in name:
            return "social"
        elif "fundamental" in search_key or "基本面" in name:
            return "fundamentals"
        else:
            return "market"

    @classmethod
    def _get_analyst_icon(cls, slug: str, name: str = "", agent_config: dict = None) -> str:

        if agent_config and agent_config.get("icon"):
            return agent_config["icon"]

        search_key = slug.lower()

        if "news" in search_key or "新闻" in name:
            return "📰"
        elif "social" in search_key or "sentiment" in search_key or "社交" in name or "情绪" in name:
            return "💬"
        elif "fundamental" in search_key or "基本面" in name:
            return "💼"
        elif "china" in search_key or "中国" in name:
            return "🇨🇳"
        elif "capital" in search_key or "资金" in name:
            return "💸"
        elif "market" in search_key or "市场" in name or "技术" in name:
            return "📊"
        else:
            return "🤖"

    @classmethod
    def build_node_mapping(cls, config_path: str = None) -> Dict[str, Optional[str]]:

        agents = cls.get_all_agents(config_path)
        node_mapping = {}

        for agent in agents:
            slug = agent.get('slug', '')
            name = agent.get('name', '')

            if not slug:
                continue

            internal_key = slug.replace("-analyst", "").replace("-", "_")

            formatted_name = internal_key.replace('_', ' ').title().replace(' ', '_')
            analyst_node_name = f"{formatted_name} Analyst"

            icon = cls._get_analyst_icon(slug, name, agent_config=agent)

            node_mapping[analyst_node_name] = f"{icon} {name}"

            node_mapping[f"tools_{internal_key}"] = None

            node_mapping[f"Msg Clear {formatted_name}"] = None

        node_mapping.update(cls._get_non_analyst_mappings())

        return node_mapping

    @classmethod
    def _get_non_analyst_mappings(cls) -> Dict[str, str]:
        return {
            'Bull Researcher': "🐂 看涨研究员",
            'Bear Researcher': "🐻 看跌研究员",
            'Research Manager': "👔 研究经理",
            'Trader': "💼 交易员决策",
            'Risky Analyst': "🔥 激进风险评估",
            'Safe Analyst': "🛡️ 保守风险评估",
            'Neutral Analyst': "⚖️ 中性风险评估",
            'Risk Judge': "🎯 风险经理",
            'Summary Agent': "📊 生成报告",
        }

    @classmethod
    def clear_cache(cls):
        cls._config_cache.clear()
        cls._config_mtime.clear()
        logger.info("🔄 已清除智能体配置缓存")
