from .utils.agent_utils import Toolkit
from .utils.memory import FinancialSituationMemory

from .stage_2.bear_researcher import create_bear_researcher
from .stage_2.bull_researcher import create_bull_researcher
from .stage_2.research_manager import create_research_manager
from .stage_2.trader import create_trader

from .stage_3.aggressive_debator import create_risky_debator
from .stage_3.conservative_debator import create_safe_debator
from .stage_3.neutral_debator import create_neutral_debator
from .stage_3.risk_manager import create_risk_manager

import logging
logger = logging.getLogger("default")

__all__ = [
    "FinancialSituationMemory",
    "Toolkit",
    "create_bear_researcher",
    "create_bull_researcher",
    "create_research_manager",
    "create_neutral_debator",
    "create_risky_debator",
    "create_risk_manager",
    "create_safe_debator",
    "create_trader",
]
