from app.engine.agents.stage_2.researcher_factory import create_researcher

def create_bull_researcher(llm, memory):
    return create_researcher(llm, memory, side="bull")
