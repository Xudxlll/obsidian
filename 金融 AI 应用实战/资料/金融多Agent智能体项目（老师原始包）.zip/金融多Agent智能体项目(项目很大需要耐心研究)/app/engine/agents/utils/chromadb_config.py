import platform
import chromadb
from chromadb.config import Settings

def is_windows_11() -> bool:

    if platform.system() != "Windows":
        return False
    
    version = platform.version()
    try:
        version_parts = version.split('.')
        if len(version_parts) >= 3:
            build_number = int(version_parts[2])
            return build_number >= 22000
    except (ValueError, IndexError):
        pass
    
    return False

def get_win10_chromadb_client():

    settings = Settings(
        allow_reset=True,
        anonymized_telemetry=False,
        is_persistent=False,
        chroma_db_impl="duckdb+parquet",
        chroma_api_impl="chromadb.api.segment.SegmentAPI",
        persist_directory=None
    )
    
    try:
        client = chromadb.Client(settings)
        return client
    except Exception:
        basic_settings = Settings(
            allow_reset=True,
            is_persistent=False
        )
        return chromadb.Client(basic_settings)

def get_win11_chromadb_client():

    settings = Settings(
        allow_reset=True,
        anonymized_telemetry=False,
        is_persistent=False,
        chroma_db_impl="duckdb+parquet",
        chroma_api_impl="chromadb.api.segment.SegmentAPI"
    )
    
    try:
        client = chromadb.Client(settings)
        return client
    except Exception:
        minimal_settings = Settings(
            allow_reset=True,
            anonymized_telemetry=False,
            is_persistent=False
        )
        return chromadb.Client(minimal_settings)

def get_optimal_chromadb_client():

    system = platform.system()
    
    if system == "Windows":
        if is_windows_11():
            return get_win11_chromadb_client()
        else:
            return get_win10_chromadb_client()
    else:
        settings = Settings(
            allow_reset=True,
            anonymized_telemetry=False,
            is_persistent=False
        )
        return chromadb.Client(settings)

__all__ = [
    'get_optimal_chromadb_client',
    'get_win10_chromadb_client',
    'get_win11_chromadb_client',
    'is_windows_11'
]
