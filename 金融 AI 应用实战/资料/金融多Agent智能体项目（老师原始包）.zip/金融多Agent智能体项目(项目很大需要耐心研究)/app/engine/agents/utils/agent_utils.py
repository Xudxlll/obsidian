from app.engine.default_config import DEFAULT_CONFIG
import logging

from .toolkit_news import (
    get_finnhub_news,
    get_reddit_stock_info,
    get_realtime_stock_news,
    get_stock_news_unified,
)
from .toolkit_market import get_china_market_overview, get_stock_market_data_unified
from .toolkit_fundamentals import get_stock_fundamentals_unified
from .toolkit_sentiment import get_stock_sentiment_unified

logger = logging.getLogger("agents")

class Toolkit:

    def __init__(self, config=None):
        self._config = {**DEFAULT_CONFIG, **(config or {})}

    @property
    def config(self):
        return self._config

    @property
    def enable_mcp(self):
        return self._config.get("enable_mcp", False)

    @property
    def mcp_tool_loader(self):
        return self._config.get("mcp_tool_loader", None)

    get_finnhub_news = staticmethod(get_finnhub_news)
    get_reddit_stock_info = staticmethod(get_reddit_stock_info)
    get_realtime_stock_news = staticmethod(get_realtime_stock_news)
    get_stock_news_unified = staticmethod(get_stock_news_unified)

    get_china_market_overview = staticmethod(get_china_market_overview)
    get_stock_market_data_unified = staticmethod(get_stock_market_data_unified)

    get_stock_fundamentals_unified = staticmethod(get_stock_fundamentals_unified)

    get_stock_sentiment_unified = staticmethod(get_stock_sentiment_unified)
