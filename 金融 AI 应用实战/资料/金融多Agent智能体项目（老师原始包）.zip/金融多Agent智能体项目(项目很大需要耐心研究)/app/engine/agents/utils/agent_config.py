import os
import re
import tempfile
import yaml
from typing import Optional

from app.core.env import get_env
import logging
from app.utils.stock_utils import StockUtils

logger = logging.getLogger("agents.config")

async def resolve_company_name(ticker: str, market_info: dict) -> str:

    try:
        if market_info["is_china"]:
            try:
                from app.data.core.interface import DataInterface
                _di = DataInterface.get_instance()
                _r = await _di.read("CN", "basic_info", symbol=ticker)
                data = _r.get("data")
                if data and isinstance(data, dict) and data.get("name"):
                    return data["name"]
                if data and isinstance(data, list) and data and data[0].get("name"):
                    return data[0]["name"]
            except Exception as e:
                logger.debug(f"获取A股公司名称失败: {e}")
                pass
            return f"股票代码{ticker}"

        if market_info["is_hk"]:
            try:
                from app.data.core.interface import DataInterface
                clean_ticker = ticker.replace(".HK", "").replace(".hk", "").zfill(5)
                di = DataInterface.get_instance()
                result = await di.read("HK", "basic_info", symbol=clean_ticker)
                data = result.get("data")
                if data:
                    name = data.get("name_zh") or data.get("name_en") if isinstance(data, dict) else None
                    if name:
                        return name
                    if isinstance(data, list) and data:
                        name = data[0].get("name_zh") or data[0].get("name_en")
                        if name:
                            return name
            except Exception as e:
                logger.debug(f"获取港股公司名称失败: {e}")
            clean_ticker = ticker.replace(".HK", "").replace(".hk", "")
            return f"港股{clean_ticker}"

        if market_info["is_us"]:
            try:
                from app.data.core.interface import DataInterface
                di = DataInterface.get_instance()
                result = await di.read("US", "basic_info", symbol=ticker.upper())
                data = result.get("data")
                if data:
                    doc = data[0] if isinstance(data, list) and data else data
                    company_name = doc.get("name") or doc.get("shortName") or doc.get("longName")
                    if company_name:
                        return company_name
            except Exception as e:
                logger.debug(f"获取美股公司名称失败: {e}")
            return StockUtils.US_STOCK_NAMES.get(ticker.upper(), f"美股{ticker}")

        return f"股票{ticker}"
    except Exception as exc:
        logger.error(f"❌ 获取公司名称失败: {exc}")
        return f"股票{ticker}"

def build_stage3_report_path(task_id: Optional[str], ticker: str, report_slug: str) -> str:
    safe_task_id = re.sub(r"[^A-Za-z0-9_-]+", "_", re.sub(r"\.\.", "_", task_id or ticker or "unknown"))
    safe_ticker = re.sub(r"[^A-Za-z0-9_-]+", "_", re.sub(r"\.\.", "_", ticker or "unknown"))
    report_dir = os.path.join(tempfile.gettempdir(), "zhenshabi_stage3_reports")
    os.makedirs(report_dir, exist_ok=True)
    return os.path.join(report_dir, f"{safe_task_id}_{safe_ticker}_{report_slug}.md")

def _find_agent_entry(slug: str) -> Optional[dict]:
    env_dir = get_env("AGENT_CONFIG_DIR")
    agents_dirs = []

    if env_dir and os.path.exists(env_dir):
        agents_dirs.append(env_dir)
    else:
        probe = os.path.dirname(os.path.abspath(__file__))
        for _ in range(8):
            candidate = os.path.join(probe, "config", "agents")
            if os.path.exists(candidate):
                agents_dirs.append(candidate)
                break
            nxt = os.path.dirname(probe)
            if nxt == probe:
                break
            probe = nxt

    config_files = [
        "phase1_agents_config.yaml",
        "phase2_agents_config.yaml",
        "phase3_agents_config.yaml",
    ]

    for agents_dir in agents_dirs:
        for config_file in config_files:
            yaml_path = os.path.join(agents_dir, config_file)
            if not os.path.exists(yaml_path):
                continue

            with open(yaml_path, "r", encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}

            for key in ("customModes", "agents"):
                for agent in config.get(key, []) or []:
                    if agent.get("slug") == slug:
                        return agent
    return None

def load_agent_config(slug: str) -> str:
    try:
        entry = _find_agent_entry(slug)
        if entry is None:
            logger.warning(f"在配置中未找到智能体: {slug}")
            return ""
        return entry.get("roleDefinition", "")
    except Exception as e:
        logger.error(f"加载配置文件失败: {e}")
        return ""

def load_agent_display_name(slug: str) -> str:
    try:
        entry = _find_agent_entry(slug)
        if entry is None:
            return ""
        return str(entry.get("name", "") or "")
    except Exception as e:
        logger.error(f"加载智能体显示名失败: {e}")
        return ""
