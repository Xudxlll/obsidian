from app.engine.agents.stage_3.debator_factory import create_debator

def create_neutral_debator(llm):
    return create_debator(llm, side="neutral")
