from app.engine.agents.stage_3.debator_factory import create_debator

def create_safe_debator(llm):
    return create_debator(llm, side="safe")
