from pathlib import Path

from app.core.env import get_env
from app.utils.runtime_paths import (
    get_cache_dir,
    get_data_dir,
    get_results_dir,
    get_runtime_base_dir,
    resolve_path,
)

_RUNTIME_BASE = get_runtime_base_dir()

def _resolve_env_path(env_key: str, default_path: Path) -> str:
    env_val = get_env(env_key)
    if env_val:
        return str(resolve_path(env_val, _RUNTIME_BASE))
    return str(default_path)

DEFAULT_CONFIG = {
    "project_dir": str(Path(__file__).resolve().parents[2]),
    "results_dir": _resolve_env_path("ZHENSHABI_RESULTS_DIR", get_results_dir(_RUNTIME_BASE)),
    "data_dir": _resolve_env_path("ZHENSHABI_DATA_DIR", get_data_dir(_RUNTIME_BASE)),
    "data_cache_dir": _resolve_env_path(
        "ZHENSHABI_CACHE_DIR",
        get_cache_dir(_RUNTIME_BASE) / "dataflows",
    ),
    "llm_provider": "openai",
    "debate_llm": "o4-mini",
    "analyst_llm": "gpt-4o-mini",
    "backend_url": "https://api.openai.com/v1",
    "max_debate_rounds": 1,
    "max_risk_discuss_rounds": 1,
    "max_recur_limit": 100,
    "online_tools": get_env("ONLINE_TOOLS_ENABLED", "false").lower() == "true",
    "online_news": get_env("ONLINE_NEWS_ENABLED", "true").lower() == "true", 
    "realtime_data": get_env("REALTIME_DATA_ENABLED", "false").lower() == "true",

}
