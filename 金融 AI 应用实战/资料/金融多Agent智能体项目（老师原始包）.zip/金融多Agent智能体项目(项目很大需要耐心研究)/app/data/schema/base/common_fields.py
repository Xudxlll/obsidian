import math
from dataclasses import dataclass, fields
from datetime import datetime, timezone
from typing import Any, Dict, Optional

def _is_nan_like(value: Any) -> bool:

    if isinstance(value, float):
        try:
            return math.isnan(value) or math.isinf(value)
        except (TypeError, ValueError):
            return False
    tname = type(value).__name__
    if value is None:
        return False
    if tname == "float" and hasattr(value, "__float__"):
        try:
            f = float(value)
            return math.isnan(f) or math.isinf(f)
        except (TypeError, ValueError):
            return False
    return False

@dataclass
class CommonFields:

    symbol: str
    market: str
    data_source: str
    updated_at: Optional[str] = None

    def to_db_doc(self) -> Dict[str, Any]:

        doc = {}
        for f in fields(self):
            val = getattr(self, f.name)
            if val is None:
                continue
            if _is_nan_like(val):
                continue
            doc[f.name] = val
        if "updated_at" not in doc or doc["updated_at"] is None:
            doc["updated_at"] = datetime.now(timezone.utc).isoformat()
        return doc

    @staticmethod
    def now_utc() -> str:
        return datetime.now(timezone.utc).isoformat()
