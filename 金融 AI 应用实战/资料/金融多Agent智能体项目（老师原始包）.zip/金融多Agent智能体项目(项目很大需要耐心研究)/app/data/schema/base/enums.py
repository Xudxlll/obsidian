from enum import Enum

class ListStatus(str, Enum):
    LISTED = "L"
    DELISTED = "D"
    SUSPENDED = "P"
    SUSPENDED_HK = "S"

class StatementType(str, Enum):
    INCOME = "income"
    BALANCE = "balance"
    CASHFLOW = "cashflow"
    INDICATOR = "indicator"

class ReportType(str, Enum):
    Q1 = "Q1"
    Q2 = "Q2"
    Q3 = "Q3"
    FY = "FY"
    H1 = "H1"
    H2 = "H2"
    CONSOLIDATED = "1"
    SINGLE_QUARTER = "2"
    PARENT = "4"

class ActionType(str, Enum):
    CASH_DIVIDEND = "cash_dividend"
    SPECIAL_DIVIDEND = "special_dividend"
    STOCK_SPLIT = "stock_split"
    REVERSE_SPLIT = "reverse_split"
    CONSOLIDATION = "consolidation"
    BONUS_ISSUE = "bonus_issue"
    RIGHTS_ISSUE = "rights_issue"
    MERGER = "merger"
    SPINOFF = "spinoff"
    PRIVATIZATION = "privatization"

class DataPeriod(str, Enum):
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"

class SupportLevel(str, Enum):
    FULL = "full"
    PARTIAL = "partial"
    NONE = "none"

class CircuitState(str, Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"

class RefreshStatus(str, Enum):
    FRESH = "fresh"
    REFRESHED = "refreshed"
    PARTIAL = "partial"
    TIMEOUT = "timeout"
    FAILED = "failed"
    SKIPPED = "skipped"

class FreshnessState(str, Enum):
    FRESH = "fresh"
    STALE = "stale"
    UNKNOWN = "unknown"

class QuoteSourceType(str, Enum):
    DELAYED = "delayed"
    REALTIME = "realtime"

class MarketSession(str, Enum):
    PRE_OPEN = "pre_open"
    MORNING = "morning"
    LUNCH_BREAK = "lunch_break"
    AFTERNOON = "afternoon"
    CLOSING_AUCTION = "closing_auction"
    PRE = "pre"
    REGULAR = "regular"
    POST = "post"
    CLOSED = "closed"
