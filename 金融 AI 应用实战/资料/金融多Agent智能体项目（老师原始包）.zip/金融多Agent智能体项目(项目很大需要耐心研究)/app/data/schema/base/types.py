from datetime import datetime
from typing import Optional

import numpy as np

DateStr = str
DecimalStr = str

def _safe_float(value) -> Optional[float]:
    if value is None or value == "":
        return None
    if isinstance(value, float) and (np.isnan(value) or np.isinf(value)):
        return None
    try:
        result = float(value)
        if np.isnan(result) or np.isinf(result):
            return None
        return result
    except (ValueError, TypeError):
        return None

def _safe_int(value) -> Optional[int]:
    if value is None or value == "":
        return None
    if isinstance(value, float) and (np.isnan(value) or np.isinf(value)):
        return None
    try:
        return int(value)
    except (ValueError, TypeError):
        return None

def _safe_str(value) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, float) and np.isnan(value):
        return None
    s = str(value).strip()
    if s.lower() in ("nan", "null", "none", "--", "-"):
        return None
    return s if s else None

def _parse_date(value) -> Optional[str]:
    if value is None:
        return None
    s = str(value).strip()
    if not s:
        return None
    if len(s) == 8 and s.isdigit():
        return f"{s[:4]}-{s[4:6]}-{s[6:8]}"
    if len(s) == 10 and s[4] == "-" and s[7] == "-":
        return s
    try:
        dt = datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
        return dt.strftime("%Y-%m-%d")
    except ValueError:
        pass
    try:
        dt = datetime.strptime(s, "%Y-%m-%dT%H:%M:%S")
        return dt.strftime("%Y-%m-%d")
    except ValueError:
        pass
    return s if len(s) == 10 else None

def _round_price(value: Optional[float], precision: int = 2) -> Optional[float]:
    if value is None:
        return None
    return round(value, precision)

def _round_ratio(value: Optional[float], precision: int = 4) -> Optional[float]:
    if value is None:
        return None
    return round(value, precision)
