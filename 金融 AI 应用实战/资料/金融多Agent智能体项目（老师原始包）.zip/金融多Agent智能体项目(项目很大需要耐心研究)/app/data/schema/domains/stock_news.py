import hashlib
from dataclasses import dataclass
from typing import Optional

from app.data.schema.base.common_fields import CommonFields

@dataclass
class StockNewsSchema(CommonFields):

    title: Optional[str] = None
    content: Optional[str] = None
    content_hash: Optional[str] = None
    source: Optional[str] = None
    author: Optional[str] = None
    publish_time: Optional[str] = None
    url: Optional[str] = None
    category: Optional[str] = None
    sentiment: Optional[str] = None
    importance: Optional[int] = None
    keywords: Optional[str] = None

    @staticmethod
    def compute_hash(title: str, publish_time: str) -> str:
        raw = f"{title}|{publish_time}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()
