from dataclasses import dataclass
from typing import Optional

from app.data.schema.base.common_fields import CommonFields

@dataclass
class StockBasicInfoSchema(CommonFields):

    name: Optional[str] = None
    full_symbol: Optional[str] = None
    exchange: Optional[str] = None
    industry: Optional[str] = None
    list_status: Optional[str] = None
    list_date: Optional[str] = None
    delist_date: Optional[str] = None
    currency: Optional[str] = None
