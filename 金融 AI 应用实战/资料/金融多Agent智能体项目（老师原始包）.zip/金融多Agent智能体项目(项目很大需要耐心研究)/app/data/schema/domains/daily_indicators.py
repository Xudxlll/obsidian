from dataclasses import dataclass
from typing import Optional

from app.data.schema.base.common_fields import CommonFields

@dataclass
class DailyIndicatorsSchema(CommonFields):

    trade_date: Optional[str] = None
    pe_ttm: Optional[float] = None
    pb: Optional[float] = None
    ps_ttm: Optional[float] = None
    turnover_rate: Optional[float] = None
    turnover_rate_f: Optional[float] = None
    total_mv: Optional[float] = None
    circ_mv: Optional[float] = None
    volume_ratio: Optional[float] = None
    dividend_yield: Optional[float] = None
    dividend_yield_ttm: Optional[float] = None
    shares_outstanding: Optional[float] = None
    float_shares: Optional[float] = None
    southbound_holding: Optional[float] = None
    southbound_holding_ratio: Optional[float] = None
