from dataclasses import dataclass
from typing import Any, Dict, Optional

@dataclass
class SyncCheckpointSchema:
    market: str
    domain: str
    source: str
    last_sync_date: Optional[str] = None
    last_sync_time: Optional[str] = None
    status: Optional[str] = None
    record_count: Optional[int] = None
    duration_ms: Optional[int] = None
    scope: Optional[str] = None
    trigger: Optional[str] = None
    symbol: Optional[str] = None

    def to_db_doc(self) -> Dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if v is not None}

@dataclass
class SyncEventSchema:
    market: str
    event_type: str
    domain: str
    source: Optional[str] = None
    source_from: Optional[str] = None
    source_to: Optional[str] = None
    reason: Optional[str] = None
    record_count: Optional[int] = None
    duration_ms: Optional[int] = None
    task_id: Optional[str] = None
    created_at: Optional[str] = None

    def to_db_doc(self) -> Dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if v is not None}

@dataclass
class SourceHealthSchema:
    market: str
    source: str
    domain: str
    success_rate_1h: Optional[float] = None
    avg_latency_ms_1h: Optional[float] = None
    circuit_state: Optional[str] = None
    last_success_time: Optional[str] = None
    consecutive_failures: Optional[int] = None
    total_calls_1h: Optional[int] = None
    total_failures_1h: Optional[int] = None
    updated_at: Optional[str] = None

    def to_db_doc(self) -> Dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if v is not None}
