from dataclasses import dataclass
from typing import Optional

from app.data.schema.base.common_fields import CommonFields

@dataclass
class MoneyFlowSchema(CommonFields):

    trade_date: Optional[str] = None
    main_net_inflow: Optional[float] = None
    main_net_inflow_pct: Optional[float] = None
    huge_net_inflow: Optional[float] = None
    large_net_inflow: Optional[float] = None
    medium_net_inflow: Optional[float] = None
    small_net_inflow: Optional[float] = None
