from dataclasses import dataclass
from typing import Optional

from app.data.schema.base.common_fields import CommonFields

@dataclass
class TradeCalendarSchema(CommonFields):

    exchange: Optional[str] = None
    cal_date: Optional[str] = None
    is_open: Optional[bool] = None
    pretrade_date: Optional[str] = None
