from dataclasses import dataclass
from typing import Optional

from app.data.schema.base.common_fields import CommonFields

@dataclass
class MarginTradingSchema(CommonFields):

    trade_date: Optional[str] = None
    margin_balance: Optional[float] = None
    short_balance: Optional[float] = None
    margin_buy_amount: Optional[float] = None
    short_sell_volume: Optional[float] = None
    total_balance: Optional[float] = None
    short_volume: Optional[float] = None
