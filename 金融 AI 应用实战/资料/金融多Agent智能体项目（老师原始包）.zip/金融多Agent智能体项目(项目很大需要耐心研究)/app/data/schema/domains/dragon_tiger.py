from dataclasses import dataclass
from typing import Optional

from app.data.schema.base.common_fields import CommonFields

@dataclass
class DragonTigerSchema(CommonFields):

    trade_date: Optional[str] = None
    name: Optional[str] = None
    close: Optional[float] = None
    pct_chg: Optional[float] = None
    reason: Optional[str] = None
    buy_amount: Optional[float] = None
    sell_amount: Optional[float] = None
    net_amount: Optional[float] = None
