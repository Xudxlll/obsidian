from dataclasses import dataclass
from typing import Optional

from app.data.schema.base.common_fields import CommonFields

@dataclass
class FinancialDataSchema(CommonFields):

    report_period: Optional[str] = None
    statement_type: Optional[str] = None
    report_type: Optional[str] = None
    fiscal_year: Optional[int] = None
    fiscal_period: Optional[str] = None
    announce_date: Optional[str] = None
    filing_url: Optional[str] = None

    revenue: Optional[float] = None
    revenue_hkd: Optional[float] = None
    net_profit: Optional[float] = None
    net_profit_hkd: Optional[float] = None
    total_assets: Optional[float] = None
    total_equity: Optional[float] = None
    operating_cashflow: Optional[float] = None
    free_cashflow: Optional[float] = None

    roe: Optional[float] = None
    roa: Optional[float] = None
    gross_margin: Optional[float] = None
    net_margin: Optional[float] = None
    debt_ratio: Optional[float] = None
    debt_to_equity: Optional[float] = None
    current_ratio: Optional[float] = None
    eps: Optional[float] = None
    eps_basic: Optional[float] = None
    eps_diluted: Optional[float] = None
    bps: Optional[float] = None
    dividend_per_share: Optional[float] = None
