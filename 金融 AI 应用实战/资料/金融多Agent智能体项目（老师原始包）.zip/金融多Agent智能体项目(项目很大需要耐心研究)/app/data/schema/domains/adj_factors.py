from dataclasses import dataclass
from typing import Optional

from app.data.schema.base.common_fields import CommonFields

@dataclass
class AdjFactorsSchema(CommonFields):

    trade_date: Optional[str] = None
    adj_factor: Optional[float] = None
    fore_adj_factor: Optional[float] = None
    back_adj_factor: Optional[float] = None
