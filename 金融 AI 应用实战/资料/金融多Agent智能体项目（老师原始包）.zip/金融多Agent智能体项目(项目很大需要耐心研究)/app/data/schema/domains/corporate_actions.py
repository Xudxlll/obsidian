from dataclasses import dataclass
from typing import Optional

from app.data.schema.base.common_fields import CommonFields

@dataclass
class CorporateActionsSchema(CommonFields):

    ex_date: Optional[str] = None
    record_date: Optional[str] = None
    pay_date: Optional[str] = None
    action_type: Optional[str] = None
    amount: Optional[float] = None
    currency: Optional[str] = None
    amount_hkd: Optional[float] = None
    ratio_from: Optional[float] = None
    ratio_to: Optional[float] = None
    rights_price: Optional[float] = None
    announce_date: Optional[str] = None
