from dataclasses import dataclass
from typing import Optional

from app.data.schema.base.common_fields import CommonFields

@dataclass
class BlockTradeSchema(CommonFields):

    trade_date: Optional[str] = None
    name: Optional[str] = None
    price: Optional[float] = None
    volume: Optional[float] = None
    amount: Optional[float] = None
    buyer: Optional[str] = None
    seller: Optional[str] = None
