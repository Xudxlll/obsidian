from dataclasses import dataclass
from typing import Optional

from app.data.schema.base.common_fields import CommonFields

@dataclass
class MarketQuotesSchema(CommonFields):

    open: Optional[float] = None
    high: Optional[float] = None
    low: Optional[float] = None
    close: Optional[float] = None
    pre_close: Optional[float] = None
    pct_chg: Optional[float] = None
    volume: Optional[float] = None
    amount: Optional[float] = None
    turnover_rate: Optional[float] = None

    last_price: Optional[float] = None
    last_volume: Optional[float] = None
    last_updated: Optional[str] = None

    trade_date: Optional[str] = None

    quote_source_type: Optional[str] = None
    bid_price: Optional[float] = None
    ask_price: Optional[float] = None
    bid_volume: Optional[float] = None
    ask_volume: Optional[float] = None

    pre_market_price: Optional[float] = None
    pre_market_change: Optional[float] = None
    pre_market_volume: Optional[float] = None
    post_market_price: Optional[float] = None
    post_market_change: Optional[float] = None
    post_market_volume: Optional[float] = None

    session: Optional[str] = None
