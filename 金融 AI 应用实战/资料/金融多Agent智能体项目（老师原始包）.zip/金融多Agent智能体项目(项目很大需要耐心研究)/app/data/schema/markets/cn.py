from dataclasses import dataclass
from typing import Optional

@dataclass
class CNBasicInfoFields:

    area: Optional[str] = None
    market_board: Optional[str] = None
