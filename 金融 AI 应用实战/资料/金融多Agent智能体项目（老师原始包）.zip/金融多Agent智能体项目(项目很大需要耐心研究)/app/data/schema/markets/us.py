from dataclasses import dataclass
from typing import Optional

@dataclass
class USBasicInfoFields:

    sector: Optional[str] = None
    country: Optional[str] = None
    market_cap_tier: Optional[str] = None
    isin: Optional[str] = None
    cik: Optional[str] = None
    is_adr: Optional[bool] = None
    home_country: Optional[str] = None

@dataclass
class USDailyQuotesFields:

    adj_close: Optional[float] = None

@dataclass
class USFinancialDataFields:

    eps_basic: Optional[float] = None
    eps_diluted: Optional[float] = None
    free_cashflow: Optional[float] = None
    debt_to_equity: Optional[float] = None
    ev_ebitda: Optional[float] = None

@dataclass
class USMarketQuotesFields:

    pre_market_price: Optional[float] = None
    pre_market_change: Optional[float] = None
    pre_market_volume: Optional[float] = None
    post_market_price: Optional[float] = None
    post_market_change: Optional[float] = None
    post_market_volume: Optional[float] = None
    session: Optional[str] = None
