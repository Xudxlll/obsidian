from dataclasses import dataclass
from typing import Optional

@dataclass
class HKBasicInfoFields:

    name_en: Optional[str] = None
    board: Optional[str] = None
    industry_l1: Optional[str] = None
    industry_l2: Optional[str] = None
    sector: Optional[str] = None
    connect_status: Optional[str] = None
    dual_listed: Optional[bool] = None
    dual_listed_us_symbol: Optional[str] = None
    dual_listed_a_symbol: Optional[str] = None
    weighted_voting_rights: Optional[bool] = None
    chinese_company: Optional[bool] = None

@dataclass
class HKDailyIndicatorsFields:

    dividend_yield: Optional[float] = None
    dividend_yield_ttm: Optional[float] = None
    southbound_holding: Optional[float] = None
    southbound_holding_ratio: Optional[float] = None

@dataclass
class HKCorporateActionsFields:

    amount_hkd: Optional[float] = None

@dataclass
class HKMarketQuotesFields:

    quote_source_type: Optional[str] = None
    bid_price: Optional[float] = None
    ask_price: Optional[float] = None
    bid_volume: Optional[float] = None
    ask_volume: Optional[float] = None
    session: Optional[str] = None

@dataclass
class HKFinancialDataFields:

    currency: Optional[str] = None
    revenue_hkd: Optional[float] = None
    net_profit_hkd: Optional[float] = None
    dividend_per_share: Optional[float] = None
