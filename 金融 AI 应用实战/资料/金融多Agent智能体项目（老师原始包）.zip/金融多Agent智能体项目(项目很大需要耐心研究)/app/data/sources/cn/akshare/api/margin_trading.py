import asyncio
import logging

import pandas as pd

from app.data.sources.base.exceptions import (
    DataFormatError,
    DataNotFoundError,
    DataSourceUnavailableError,
)
from app.data.sources.base.mappers import is_empty_result, map_network_exception

logger = logging.getLogger(__name__)

_DOMAIN = "margin_trading"

async def fetch_margin_trading(
    symbol: str,
) -> pd.DataFrame:

    try:
        import akshare as ak

        def _fetch():
            from app.data.sources.cn.akshare.api.anti_scraping import wait_rate_limit
            wait_rate_limit()
            code = symbol.zfill(6)
            for date in _recent_trade_dates(4):
                if code.startswith("6"):
                    df = ak.stock_margin_detail_sse(date=date)
                    if df is not None and not df.empty:
                        return df[
                            df["标的证券代码"].astype(str).str.zfill(6) == code
                        ]
                elif code.startswith("0") or code.startswith("3"):
                    df = ak.stock_margin_detail_szse(date=date)
                    if df is not None and not df.empty:
                        return df
                else:
                    return None
            return None

        df = await asyncio.to_thread(_fetch)
    except (asyncio.TimeoutError, ConnectionError, TimeoutError) as exc:
        raise map_network_exception(exc, "akshare", _DOMAIN)
    except (KeyError, IndexError, AttributeError, ValueError) as exc:
        raise DataFormatError("akshare", _DOMAIN, f"symbol={symbol}: {exc}")
    except Exception as exc:
        raise DataSourceUnavailableError("akshare", _DOMAIN, f"symbol={symbol}: {exc}")

    if is_empty_result(df):
        logger.warning(f"AKShare 融资融券返回空: symbol={symbol}")
        raise DataNotFoundError("akshare", _DOMAIN, f"symbol={symbol} 无融资融券数据")

    if symbol.startswith("0") or symbol.startswith("3"):
        col = "证券代码" if "证券代码" in df.columns else "代码"
        df = df[df[col].astype(str).str.zfill(6) == symbol.zfill(6)]

    logger.debug(f"AKShare 融资融券: {symbol} {len(df)} 条")
    return df

def _recent_trade_dates(n: int = 4) -> list:

    from datetime import datetime, timedelta

    dates, day, offset = [], datetime.now(), 0
    while len(dates) < n and offset < 14:
        d = day - timedelta(days=offset)
        if d.weekday() < 5:
            dates.append(d.strftime("%Y%m%d"))
        offset += 1
    return dates
