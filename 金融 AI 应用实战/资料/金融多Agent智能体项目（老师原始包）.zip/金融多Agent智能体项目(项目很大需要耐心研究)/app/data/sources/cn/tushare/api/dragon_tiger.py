import asyncio
import logging
from datetime import timedelta
from typing import Optional

import pandas as pd

from app.core.lru_cache import BoundedLRUCache
from app.data.sources.base.exceptions import DataNotFoundError, DataSourceUnavailableError
from app.data.sources.base.mappers import (
    map_network_exception,
    map_tushare_code,
)
from app.data.sources.tushare_common.caller import call_tushare
from app.utils.time_utils import now_config_tz

from .connection import TushareConnection

logger = logging.getLogger(__name__)

_DOMAIN = "dragon_tiger"

_SYMBOL_THROTTLE_SECONDS = 0.3

_symbol_cache: BoundedLRUCache = BoundedLRUCache(
    maxsize=128,
    ttl=3600.0,
    name="dragon_tiger_by_symbol",
)
_NOT_FOUND_SENTINEL = "__not_found__"

async def fetch_dragon_tiger(
    conn: TushareConnection,
    trade_date: str = None,
    start_date: str = None,
    end_date: str = None,
    ts_code: str = None,
) -> Optional[pd.DataFrame]:

    if not conn.is_available():
        return None

    if ts_code:
        cached = _symbol_cache.get(ts_code)
        if cached is _NOT_FOUND_SENTINEL:
            raise DataNotFoundError(
                "tushare",
                _DOMAIN,
                f"ts_code={ts_code} 近 30 天无记录（缓存命中）",
            )
        if cached is not None:
            logger.debug(f"Tushare 龙虎榜({ts_code}): 缓存命中 {len(cached)} 条")
            return cached
        df = await _fetch_by_symbol(conn, ts_code)
        _symbol_cache.set(ts_code, df)
        return df

    return await _fetch_by_date(conn, trade_date, start_date, end_date)

async def _fetch_by_date(
    conn: TushareConnection,
    trade_date: str = None,
    start_date: str = None,
    end_date: str = None,
) -> Optional[pd.DataFrame]:
    kwargs = {}
    if trade_date:
        kwargs["trade_date"] = str(trade_date).replace("-", "")
    elif start_date:
        kwargs["start_date"] = str(start_date).replace("-", "")
        kwargs["end_date"] = str(end_date or start_date).replace("-", "")

    return await call_tushare(conn, "top_list", "tushare", _DOMAIN, str(kwargs), **kwargs)

async def _fetch_by_symbol(
    conn: TushareConnection,
    ts_code: str,
) -> Optional[pd.DataFrame]:

    symbol = ts_code.split(".")[0] if "." in ts_code else ts_code

    last_business_error: Optional[Exception] = None

    for days_back in range(0, 30):
        check_date = (now_config_tz() - timedelta(days=days_back)).strftime("%Y%m%d")
        try:
            df = await asyncio.to_thread(conn.api.top_list, trade_date=check_date)
        except (asyncio.TimeoutError, ConnectionError, TimeoutError) as exc:
            last_business_error = map_network_exception(exc, "tushare", _DOMAIN)
            await asyncio.sleep(_SYMBOL_THROTTLE_SECONDS)
            continue
        except Exception as exc:
            error_code = getattr(exc, "code", None) or getattr(exc, "error_code", None)
            mapped = map_tushare_code(error_code, "tushare", _DOMAIN, str(exc))
            if mapped is not None:
                raise mapped
            last_business_error = DataSourceUnavailableError("tushare", _DOMAIN, f"{check_date}: {exc}")
            await asyncio.sleep(_SYMBOL_THROTTLE_SECONDS)
            continue

        if df is not None and not df.empty:
            filtered = df[df["ts_code"].astype(str).str.split(".").str[0] == symbol]
            if not filtered.empty:
                logger.info(f"Tushare 龙虎榜({ts_code}): {len(filtered)} 条 ({check_date})")
                return filtered
        await asyncio.sleep(_SYMBOL_THROTTLE_SECONDS)

    logger.debug(f"Tushare 龙虎榜: {ts_code} 近 30 天无记录")
    _symbol_cache.set(ts_code, _NOT_FOUND_SENTINEL)
    if last_business_error is not None:
        raise DataNotFoundError(
            "tushare",
            _DOMAIN,
            f"ts_code={ts_code} 近 30 天无记录 (last_err={last_business_error})",
        )
    raise DataNotFoundError("tushare", _DOMAIN, f"ts_code={ts_code} 近 30 天无记录")
