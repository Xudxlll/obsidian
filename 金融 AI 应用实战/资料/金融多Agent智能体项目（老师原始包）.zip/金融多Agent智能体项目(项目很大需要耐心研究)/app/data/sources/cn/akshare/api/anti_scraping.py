import logging
import threading

logger = logging.getLogger(__name__)

_session = None
_rate_limiter = None
_init_lock = threading.Lock()

def get_anti_scraping_session():
    global _session
    if _session is None:
        with _init_lock:
            if _session is None:
                try:
                    from app.data.sources.cn.eastmoney.direct import AntiScrapingSession
                    _session = AntiScrapingSession()
                except ImportError:
                    logger.debug("AntiScrapingSession 不可用，使用标准请求")
    return _session

def get_rate_limiter():
    global _rate_limiter
    if _rate_limiter is None:
        with _init_lock:
            if _rate_limiter is None:
                try:
                    from app.data.sources.cn.eastmoney.direct import ThreadSafeRateLimiter
                    _rate_limiter = ThreadSafeRateLimiter(min_interval=0.3, burst=3)
                except ImportError:
                    _rate_limiter = None
    return _rate_limiter

def wait_rate_limit():
    limiter = get_rate_limiter()
    if limiter:
        limiter.acquire()
