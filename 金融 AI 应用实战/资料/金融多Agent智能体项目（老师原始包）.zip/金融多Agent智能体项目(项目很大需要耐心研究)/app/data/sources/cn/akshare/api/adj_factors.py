import asyncio
import logging

import pandas as pd

from app.data.sources.base.exceptions import (
    DataFormatError,
    DataNotFoundError,
    DataSourceUnavailableError,
)
from app.data.sources.base.mappers import is_empty_result, map_network_exception

logger = logging.getLogger(__name__)

_DOMAIN = "adj_factors"

def _to_sina_symbol(symbol: str) -> str:
    code = str(symbol).zfill(6)
    if code.startswith(("60", "68", "90")):
        return f"sh{code}"
    elif code.startswith(("0", "3", "20")):
        return f"sz{code}"
    elif code.startswith(("4", "8")):
        return f"bj{code}"
    return f"sh{code}"

async def fetch_adj_factors(
    symbol: str,
    start_date: str = None,
    end_date: str = None,
) -> pd.DataFrame:

    try:
        import akshare as ak

        from app.data.sources.cn.akshare.api.anti_scraping import wait_rate_limit

        sina_code = _to_sina_symbol(symbol)

        def _fetch_qfq():
            wait_rate_limit()
            return ak.stock_zh_a_daily(symbol=sina_code, adjust="qfq-factor")

        def _fetch_hfq():
            wait_rate_limit()
            return ak.stock_zh_a_daily(symbol=sina_code, adjust="hfq-factor")

        qfq_df, hfq_df = await asyncio.gather(
            asyncio.to_thread(_fetch_qfq),
            asyncio.to_thread(_fetch_hfq),
        )
    except (asyncio.TimeoutError, ConnectionError, TimeoutError) as exc:
        raise map_network_exception(exc, "akshare", _DOMAIN)
    except (KeyError, IndexError, AttributeError, ValueError) as exc:
        raise DataFormatError("akshare", _DOMAIN, f"symbol={symbol}: {exc}")
    except Exception as exc:
        raise DataSourceUnavailableError("akshare", _DOMAIN, f"symbol={symbol}: {exc}")

    if is_empty_result(qfq_df):
        logger.warning(f"AKShare 前复权因子为空: {symbol}")
        raise DataNotFoundError("akshare", _DOMAIN, f"symbol={symbol} 无前复权因子")

    if qfq_df.index.name == "date":
        qfq_df = qfq_df.reset_index()
    if hfq_df is not None and not hfq_df.empty and hfq_df.index.name == "date":
        hfq_df = hfq_df.reset_index()

    date_col = "date"
    qfq_df[date_col] = pd.to_datetime(qfq_df[date_col], errors="coerce").dt.strftime("%Y%m%d")
    qfq_df = qfq_df.dropna(subset=[date_col])

    if hfq_df is not None and not hfq_df.empty:
        hfq_df[date_col] = pd.to_datetime(hfq_df[date_col], errors="coerce").dt.strftime("%Y%m%d")
        hfq_df = hfq_df.dropna(subset=[date_col])
        merged = qfq_df.merge(hfq_df[[date_col, "hfq_factor"]], on=date_col, how="outer")
    else:
        merged = qfq_df.copy()
        merged["hfq_factor"] = None

    def _norm_date(s: str) -> str:
        return str(s).replace("-", "")

    if start_date:
        merged = merged[merged[date_col] >= _norm_date(start_date)]
    if end_date:
        merged = merged[merged[date_col] <= _norm_date(end_date)]

    merged = merged.rename(columns={date_col: "trade_date"})
    merged["symbol"] = str(symbol).zfill(6)
    merged["adj_factor"] = merged.get("qfq_factor")

    if merged.empty:
        raise DataNotFoundError("akshare", _DOMAIN, f"symbol={symbol} 合并后无数据")

    logger.debug(f"AKShare 复权因子: {symbol} {len(merged)} 条")
    return merged[["symbol", "trade_date", "adj_factor", "qfq_factor", "hfq_factor"]]
