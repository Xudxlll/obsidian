import asyncio
import logging
import time

import pandas as pd

from app.data.sources.base.exceptions import (
    DataFormatError,
    DataNotFoundError,
    DataSourceUnavailableError,
)
from app.data.sources.base.mappers import is_empty_result, map_network_exception

logger = logging.getLogger(__name__)

_DOMAIN = "stock_basic"

_stock_list_cache = None
_stock_list_cache_time = 0
_CACHE_TTL = 3600

async def fetch_stock_list() -> pd.DataFrame:

    global _stock_list_cache, _stock_list_cache_time

    if _stock_list_cache is not None and (time.time() - _stock_list_cache_time) < _CACHE_TTL:
        return _stock_list_cache

    try:
        import akshare as ak

        def _fetch():
            from app.data.sources.cn.akshare.api.anti_scraping import wait_rate_limit
            wait_rate_limit()
            return ak.stock_info_a_code_name()

        df = await asyncio.to_thread(_fetch)
    except (asyncio.TimeoutError, ConnectionError, TimeoutError) as exc:
        raise map_network_exception(exc, "akshare", _DOMAIN)
    except (KeyError, IndexError, AttributeError, ValueError) as exc:
        raise DataFormatError("akshare", _DOMAIN, f"{exc}")
    except Exception as exc:
        raise DataSourceUnavailableError("akshare", _DOMAIN, f"{exc}")

    if is_empty_result(df):
        logger.warning("AKShare 股票列表返回空")
        raise DataNotFoundError("akshare", _DOMAIN, "无股票列表数据")

    _stock_list_cache = df
    _stock_list_cache_time = time.time()
    logger.info(f"AKShare 获取股票列表: {len(df)} 只")
    return df

async def fetch_stock_basic_info(code: str) -> dict:

    try:
        import akshare as ak

        def _fetch():
            from app.data.sources.cn.akshare.api.anti_scraping import wait_rate_limit
            wait_rate_limit()
            return ak.stock_individual_info_em(symbol=code)

        df = await asyncio.to_thread(_fetch)
    except (asyncio.TimeoutError, ConnectionError, TimeoutError) as exc:
        raise map_network_exception(exc, "akshare", _DOMAIN)
    except (KeyError, IndexError, AttributeError, ValueError) as exc:
        raise DataFormatError("akshare", _DOMAIN, f"code={code}: {exc}")
    except Exception as exc:
        raise DataSourceUnavailableError("akshare", _DOMAIN, f"code={code}: {exc}")

    if is_empty_result(df):
        logger.warning(f"AKShare 基础信息返回空: code={code}")
        raise DataNotFoundError("akshare", _DOMAIN, f"code={code} 无基础信息")

    result = {}
    for _, row in df.iterrows():
        result[str(row.iloc[0]).strip()] = row.iloc[1]
    return result
