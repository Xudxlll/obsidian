import logging
from typing import Dict, Optional

logger = logging.getLogger(__name__)

_name_cache: Dict[str, str] = {}

async def get_stock_name(symbol: str) -> Optional[str]:

    if symbol in _name_cache:
        return _name_cache[symbol]

    try:
        from app.data.core.interface import DataInterface

        di = DataInterface.get_instance()
        result = await di.read("CN", "basic_info", symbol=symbol)
        data = result.get("data")
        if data:
            doc = data[0] if isinstance(data, list) and data else data
            name = doc.get("name")
            if name:
                _name_cache[symbol] = name
                return name
    except Exception as e:
        logger.debug(f"DataInterface 获取股票名称失败: {e}")

    return await _tencent_name_async(symbol)

async def _tencent_name_async(symbol: str) -> Optional[str]:
    import asyncio

    return await asyncio.to_thread(_tencent_name_sync, symbol)

def _tencent_name_sync(symbol: str) -> Optional[str]:
    if symbol in _name_cache:
        return _name_cache[symbol]

    import requests as req

    if symbol.startswith(("6", "9")):
        code = f"sh{symbol}"
    elif symbol.startswith(("4", "8")):
        code = f"bj{symbol}"
    else:
        code = f"sz{symbol}"

    try:
        resp = req.get(f"http://qt.gtimg.cn/q={code}", timeout=5)
        parts = resp.text.split("~")
        if len(parts) > 1 and parts[1]:
            name = parts[1].strip()
            _name_cache[symbol] = name
            return name
    except Exception as e:
        logger.debug(f"腾讯行情接口获取股票名称失败: {e}")

    return None

def infer_exchange(symbol: str) -> str:

    if symbol.startswith(("60", "68", "90")):
        return "SSE"
    elif symbol.startswith(("00", "30", "20")):
        return "SZSE"
    elif symbol.startswith(("4", "8")):
        return "BSE"
    return ""

def get_stock_name_sync(symbol: str) -> Optional[str]:

    if symbol in _name_cache:
        return _name_cache[symbol]

    name = _tencent_name_sync(symbol)
    if name:
        return name

    try:
        from app.data.core.interface import DataInterface

        async def _read():
            di = DataInterface.get_instance()
            result = await di.read("CN", "basic_info", symbol=symbol)
            data = result.get("data")
            if data:
                doc = data[0] if isinstance(data, list) and data else data
                return doc.get("name")
            return None

        from app.core.async_utils import run_async
        name = run_async(_read())
        if name:
            _name_cache[symbol] = name
            return name
    except Exception as e:
        logger.debug(f"DataInterface 获取股票名称失败: {e}")

    return None
