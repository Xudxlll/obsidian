import asyncio
import logging
from typing import Dict, List, Optional, Any

from app.data.sources.base.exceptions import DataNotFoundError

logger = logging.getLogger(__name__)

_DOMAIN = "quotes_batch"

async def fetch_batch_quotes(codes: List[str]) -> Dict[str, Dict[str, Any]]:

    for strategy_name, strategy_fn in [
        ("em_direct", _fetch_em_spot_direct),
        ("tencent_batch", _fetch_tencent_batch),
        ("ak_api", _fetch_ak_spot),
        ("sina_spot", _fetch_sina_spot),
    ]:
        try:
            result = await strategy_fn(codes)
            if result:
                logger.debug(f"AKShare 批量行情: {strategy_name} 返回 {len(result)} 只")
                return result
        except Exception as e:
            logger.debug(f"AKShare 批量行情 {strategy_name} 失败: {e}")
            continue

    logger.warning(f"AKShare 批量行情: 所有策略失败 codes_count={len(codes)}")
    raise DataNotFoundError("akshare", _DOMAIN, f"所有策略链均无数据 (codes={len(codes)})")

async def _fetch_em_spot_direct(codes: List[str]) -> Optional[Dict[str, Dict[str, Any]]]:
    try:
        from app.data.sources.cn.eastmoney.direct import fetch_em_spot_direct
        data = await asyncio.to_thread(fetch_em_spot_direct)
        if not data:
            return None
        result = {}
        for code in codes:
            code6 = str(code).zfill(6)
            if code6 in data:
                result[code6] = data[code6]
        return result if result else None
    except ImportError:
        return None

async def _fetch_tencent_batch(codes: List[str]) -> Optional[Dict[str, Dict[str, Any]]]:
    try:
        from app.data.sources.cn.eastmoney.direct import fetch_tencent_spot_batch
        data = await asyncio.to_thread(fetch_tencent_spot_batch, codes)
        return data
    except (ImportError, Exception):
        return None

async def _fetch_ak_spot(codes: List[str]) -> Optional[Dict[str, Dict[str, Any]]]:
    try:
        import akshare as ak

        def _fetch():
            from app.data.sources.cn.akshare.api.anti_scraping import wait_rate_limit
            wait_rate_limit()
            return ak.stock_zh_a_spot_em()

        df = await asyncio.to_thread(_fetch)
        if df is None or df.empty:
            return None

        result = {}
        code_set = {str(c).zfill(6) for c in codes}
        for _, row in df.iterrows():
            code = str(row.get("代码", "")).zfill(6)
            if code in code_set:
                result[code] = row.to_dict()
        return result if result else None
    except Exception as e:
        logger.debug(f"AKShare批量获取行情失败: {e}")
        return None

async def _fetch_sina_spot(codes: List[str]) -> Optional[Dict[str, Dict[str, Any]]]:
    try:
        import akshare as ak

        def _fetch():
            from app.data.sources.cn.akshare.api.anti_scraping import wait_rate_limit
            wait_rate_limit()
            return ak.stock_zh_a_spot()

        df = await asyncio.to_thread(_fetch)
        if df is None or df.empty:
            return None

        result = {}
        code_set = {str(c).zfill(6) for c in codes} or None
        for _, row in df.iterrows():
            code = str(row.get("代码", "")).zfill(6)
            if code_set is None or code in code_set:
                result[code] = row.to_dict()
        return result if result else None
    except Exception as e:
        logger.debug(f"AKShare新浪快照失败: {e}")
        return None
