import asyncio
import logging

import pandas as pd

from app.data.sources.base.exceptions import (
    DataFormatError,
    DataNotFoundError,
    DataSourceUnavailableError,
)
from app.data.sources.base.mappers import is_empty_result, map_network_exception

logger = logging.getLogger(__name__)

_DOMAIN = "dragon_tiger"

async def fetch_dragon_tiger(
    start_date: str,
    end_date: str,
) -> pd.DataFrame:

    try:
        import akshare as ak

        def _fetch():
            from app.data.sources.cn.akshare.api.anti_scraping import wait_rate_limit
            wait_rate_limit()
            return ak.stock_lhb_detail_em(start_date=start_date, end_date=end_date)

        df = await asyncio.to_thread(_fetch)
    except (asyncio.TimeoutError, ConnectionError, TimeoutError) as exc:
        raise map_network_exception(exc, "akshare", _DOMAIN)
    except (KeyError, IndexError, AttributeError, ValueError) as exc:
        raise DataFormatError(
            "akshare", _DOMAIN,
            f"start_date={start_date}, end_date={end_date}: {exc}",
        )
    except Exception as exc:
        raise DataSourceUnavailableError(
            "akshare", _DOMAIN,
            f"start_date={start_date}, end_date={end_date}: {exc}",
        )

    if is_empty_result(df):
        logger.warning(
            f"AKShare 龙虎榜返回空: start_date={start_date}, end_date={end_date}"
        )
        raise DataNotFoundError(
            "akshare", _DOMAIN,
            f"start_date={start_date}, end_date={end_date} 无龙虎榜数据",
        )

    logger.debug(f"AKShare 龙虎榜: {start_date}-{end_date} {len(df)} 条")
    return df
