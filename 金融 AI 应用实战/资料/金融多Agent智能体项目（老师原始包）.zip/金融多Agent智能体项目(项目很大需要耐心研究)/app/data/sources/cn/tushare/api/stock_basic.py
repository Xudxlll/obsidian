import logging
from typing import Any, Dict, Optional

import pandas as pd

from app.data.sources.tushare_common.caller import call_tushare

from .connection import TushareConnection

logger = logging.getLogger(__name__)

_DOMAIN = "stock_basic"
_SOURCE = "tushare"

_STOCK_BASIC_FIELDS = (
    "ts_code,symbol,name,area,industry,market,exchange,list_date,is_hs"
)

async def fetch_stock_list(conn: TushareConnection, market: str = None) -> Optional[pd.DataFrame]:
    params: Dict[str, Any] = {"list_status": "L", "fields": _STOCK_BASIC_FIELDS}
    if market == "CN":
        params["exchange"] = "SSE,SZSE"

    return await call_tushare(conn, "stock_basic", _SOURCE, _DOMAIN, **params)

async def fetch_stock_basic_info(
    conn: TushareConnection, ts_code: str
) -> Optional[pd.DataFrame]:
    return await call_tushare(
        conn,
        "stock_basic",
        _SOURCE,
        _DOMAIN,
        f"ts_code={ts_code}",
        ts_code=ts_code,
        fields=_STOCK_BASIC_FIELDS + ",act_name,act_ent_type",
    )
