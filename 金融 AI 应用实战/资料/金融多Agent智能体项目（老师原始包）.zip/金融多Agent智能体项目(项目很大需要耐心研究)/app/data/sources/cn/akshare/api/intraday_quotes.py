import asyncio
import logging

import pandas as pd

from app.data.sources.base.exceptions import (
    DataFormatError,
    DataNotFoundError,
    DataSourceUnavailableError,
)
from app.data.sources.base.mappers import is_empty_result, map_network_exception

logger = logging.getLogger(__name__)

_DOMAIN = "intraday_quotes"

async def fetch_intraday_quotes(
    code: str,
    period: str = "30",
) -> pd.DataFrame:

    try:
        import akshare as ak

        def _fetch():
            from app.data.sources.cn.akshare.api.anti_scraping import wait_rate_limit
            wait_rate_limit()
            try:
                return ak.stock_zh_a_hist_min_em(symbol=code, period=period, adjust="")
            except Exception as exc:
                if not isinstance(exc, (ConnectionError, TimeoutError)) and type(
                    exc
                ).__name__ not in (
                    "ConnectionError",
                    "ConnectTimeout",
                    "ReadTimeout",
                    "ChunkedEncodingError",
                    "ProtocolError",
                ):
                    raise
                from app.data.sources.cn.akshare.api.adj_factors import _to_sina_symbol
                wait_rate_limit()
                return ak.stock_zh_a_minute(
                    symbol=_to_sina_symbol(code), period=period
                )

        df = await asyncio.to_thread(_fetch)
    except (asyncio.TimeoutError, ConnectionError, TimeoutError) as exc:
        raise map_network_exception(exc, "akshare", _DOMAIN)
    except (KeyError, IndexError, AttributeError, ValueError) as exc:
        raise DataFormatError("akshare", _DOMAIN, f"code={code}: {exc}")
    except Exception as exc:
        raise DataSourceUnavailableError("akshare", _DOMAIN, f"code={code}: {exc}")

    if is_empty_result(df):
        logger.warning(f"AKShare 分钟线返回空: code={code}")
        raise DataNotFoundError("akshare", _DOMAIN, f"code={code} 无分钟线数据")

    logger.debug(f"AKShare 分钟线: {code} freq={period} {len(df)} 条")
    return df
