import logging
import threading
from typing import Optional

from app.data.sources.tushare_common.client import TushareClient

logger = logging.getLogger(__name__)

class TushareConnection:

    def __init__(self, client: Optional[TushareClient] = None):
        self._client = client or TushareClient(
            source_name="tushare",
            probe_endpoint="stock_basic",
            probe_kwargs={"list_status": "L", "limit": 1},
            min_credits=120,
        )

    @property
    def api(self):
        return self._client.api

    @property
    def connected(self) -> bool:
        return self._client.connected

    @property
    def token_source(self) -> Optional[str]:
        return self._client.token_source

    def connect_sync(self) -> bool:
        return self._client.connect_sync()

    async def connect(self) -> bool:
        return await self._client.connect()

    def is_available(self) -> bool:
        return self._client.is_available()

    def invalidate(self) -> None:
        self._client.invalidate()

    def query(self, api_name: str, **kwargs):
        return self._client.query(api_name, **kwargs)

_instance: Optional[TushareConnection] = None
_instance_lock = threading.Lock()

def get_tushare_api() -> TushareConnection:
    global _instance
    if _instance is None:
        with _instance_lock:
            if _instance is None:
                _instance = TushareConnection()
                _instance.connect_sync()
    return _instance
