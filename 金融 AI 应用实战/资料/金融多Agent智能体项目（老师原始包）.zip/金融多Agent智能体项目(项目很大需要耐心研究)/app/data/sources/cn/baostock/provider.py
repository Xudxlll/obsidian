import logging
from datetime import datetime
from typing import Optional, Tuple

import pandas as pd

from app.data.sources.base.provider import BaseProvider

logger = logging.getLogger(__name__)

def _derive_year_quarter(start_date: str, end_date: str) -> Tuple[Optional[int], Optional[int]]:

    ref = end_date or start_date
    if not ref:
        return None, None
    try:
        dt = datetime.strptime(str(ref).replace("-", "")[:8], "%Y%m%d")
    except ValueError:
        return None, None
    month = dt.month
    if month <= 3:
        return dt.year - 1, 4
    elif month <= 6:
        return dt.year, 1
    elif month <= 9:
        return dt.year, 2
    else:
        return dt.year, 3

class BaoStockCNProvider(BaseProvider):

    def __init__(self):
        super().__init__(name="baostock", market="CN")

    async def connect(self) -> bool:
        try:
            from .api.connection import is_available
            if not is_available():
                return False
            self.connected = True
            return True
        except Exception as e:
            logger.error(f"BaoStock 连接失败: {e}")
            return False

    def is_available(self) -> bool:
        try:
            from .api.connection import is_available
            return is_available()
        except Exception as e:
            logger.debug(f"BaoStock可用性检查失败: {e}")
            return False

    async def get_stock_list(self, **kwargs) -> pd.DataFrame:
        from .api.stock_basic import fetch_stock_list
        return await fetch_stock_list()

    async def get_daily_quotes(
        self, symbol: str, start_date: str, end_date: str, **kwargs
    ) -> pd.DataFrame:
        from .api.daily_quotes import fetch_daily_quotes
        return await fetch_daily_quotes(symbol, start_date, end_date)

    async def get_financial_data(
        self, symbol: str, start_date: str, end_date: str,
        statement_type: str = "", **kwargs
    ) -> pd.DataFrame:
        from .api.financial import fetch_financial_data
        year, quarter = _derive_year_quarter(start_date, end_date)
        return await fetch_financial_data(symbol, year=year, quarter=quarter)

    async def get_adj_factors(
        self, symbol: str, start_date: str, end_date: str, **kwargs
    ) -> pd.DataFrame:
        from .api.daily_quotes import fetch_adj_factors
        return await fetch_adj_factors(symbol, start_date, end_date)
