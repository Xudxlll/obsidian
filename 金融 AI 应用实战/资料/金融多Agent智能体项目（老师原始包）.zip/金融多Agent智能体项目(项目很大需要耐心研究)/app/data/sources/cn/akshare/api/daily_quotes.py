import asyncio
import logging

import pandas as pd

from app.data.sources.base.exceptions import (
    DataFormatError,
    DataNotFoundError,
    DataSourceUnavailableError,
)
from app.data.sources.base.mappers import is_empty_result, map_network_exception

logger = logging.getLogger(__name__)

_DOMAIN = "daily_quotes"

async def fetch_daily_quotes(
    code: str,
    start_date: str,
    end_date: str,
    period: str = "daily",
    adjust: str = "qfq",
) -> pd.DataFrame:

    try:
        import akshare as ak

        period_map = {"daily": "daily", "weekly": "weekly", "monthly": "monthly"}
        ak_period = period_map.get(period, "daily")

        def _fetch():
            from app.data.sources.cn.akshare.api.anti_scraping import wait_rate_limit
            wait_rate_limit()
            try:
                return ak.stock_zh_a_hist(
                    symbol=code, period=ak_period,
                    start_date=start_date.replace("-", ""),
                    end_date=end_date.replace("-", ""),
                    adjust=adjust,
                )
            except Exception as exc:
                if period != "daily" or not isinstance(
                    exc, (ConnectionError, TimeoutError)
                ) and type(exc).__name__ not in (
                    "ConnectionError",
                    "ConnectTimeout",
                    "ReadTimeout",
                    "ChunkedEncodingError",
                    "ProtocolError",
                ):
                    raise
                from app.data.sources.cn.akshare.api.adj_factors import _to_sina_symbol
                wait_rate_limit()
                sina_df = ak.stock_zh_a_daily(
                    symbol=_to_sina_symbol(code), adjust=adjust if adjust != "" else "",
                    start_date=start_date.replace("-", ""),
                    end_date=end_date.replace("-", ""),
                )
                if sina_df is not None and not sina_df.empty:
                    sina_df = sina_df.reset_index() if sina_df.index.name == "date" else sina_df
                return sina_df

        df = await asyncio.to_thread(_fetch)
    except (asyncio.TimeoutError, ConnectionError, TimeoutError) as exc:
        raise map_network_exception(exc, "akshare", _DOMAIN)
    except (KeyError, IndexError, AttributeError, ValueError) as exc:
        raise DataFormatError("akshare", _DOMAIN, f"code={code}: {exc}")
    except Exception as exc:
        raise DataSourceUnavailableError("akshare", _DOMAIN, f"code={code}: {exc}")

    if is_empty_result(df):
        logger.warning(f"AKShare 行情返回空: code={code}")
        raise DataNotFoundError("akshare", _DOMAIN, f"code={code} 无行情数据")

    df = df.copy()
    df["symbol"] = code

    logger.debug(f"AKShare 行情: {code} {len(df)} 条")
    return df
