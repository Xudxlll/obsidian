import asyncio
import logging
import threading
from contextlib import asynccontextmanager

logger = logging.getLogger(__name__)

try:
    import baostock as bs
    BAOSTOCK_AVAILABLE = True
except ImportError:
    BAOSTOCK_AVAILABLE = False
    bs = None

_session_lock = threading.Lock()
_session_refcount = 0
_session_logged_in = False
_session_login_in_progress = False

_LOGIN_WAIT_INTERVAL = 0.05
_LOGIN_WAIT_MAX_RETRIES = 60

@asynccontextmanager
async def baostock_session():

    global _session_refcount, _session_logged_in, _session_login_in_progress

    if not BAOSTOCK_AVAILABLE:
        raise RuntimeError("BaoStock 库未安装")

    with _session_lock:
        _session_refcount += 1
        if _session_logged_in:
            need_login = False
            is_waiter = False
        elif _session_login_in_progress:
            need_login = False
            is_waiter = True
        else:
            need_login = True
            is_waiter = False
            _session_login_in_progress = True

    if need_login:
        try:
            await asyncio.to_thread(bs.login)
            with _session_lock:
                _session_login_in_progress = False
                _session_logged_in = True
            logger.debug("BaoStock 首次 login 成功")
        except Exception:
            with _session_lock:
                _session_refcount -= 1
                _session_login_in_progress = False
                _session_logged_in = False
            raise

    elif is_waiter:
        success = False
        for _ in range(_LOGIN_WAIT_MAX_RETRIES):
            with _session_lock:
                if _session_logged_in:
                    success = True
                    break
                if not _session_login_in_progress:
                    break
            await asyncio.sleep(_LOGIN_WAIT_INTERVAL)

        if not success:
            with _session_lock:
                _session_refcount -= 1
            raise RuntimeError("BaoStock 并发首登等待超时或失败")

    try:
        yield
    finally:
        with _session_lock:
            _session_refcount -= 1
            if _session_refcount < 0:
                _session_refcount = 0
            need_logout = _session_refcount == 0 and _session_logged_in
            if need_logout:
                _session_logged_in = False
                _session_login_in_progress = False

        if need_logout:
            try:
                await asyncio.to_thread(bs.logout)
                logger.debug("BaoStock 最后一个引用 logout")
            except Exception as exc:
                logger.warning(f"BaoStock logout 失败: {exc}")

def is_available() -> bool:
    return BAOSTOCK_AVAILABLE
