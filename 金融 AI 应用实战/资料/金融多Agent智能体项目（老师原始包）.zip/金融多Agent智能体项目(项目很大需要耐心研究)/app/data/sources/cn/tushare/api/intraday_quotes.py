import logging
from typing import Optional

import pandas as pd

from app.data.sources.tushare_common.caller import call_tushare

from .connection import TushareConnection

logger = logging.getLogger(__name__)

_DOMAIN = "intraday_quotes"
_SOURCE = "tushare"

async def fetch_intraday_quotes(
    conn: TushareConnection,
    ts_code: str,
    freq: str = "30min",
    limit: int = 500,
) -> Optional[pd.DataFrame]:

    freq_map = {"1min": "1", "5min": "5", "15min": "15", "30min": "30", "60min": "60"}
    freq_code = freq_map.get(freq, "30")

    return await call_tushare(
        conn,
        "stk_mins",
        _SOURCE,
        _DOMAIN,
        f"ts_code={ts_code} ({freq})",
        ts_code=ts_code,
        freq=freq_code,
        limit=limit,
    )
