import logging
from typing import Optional

import pandas as pd

from app.data.sources.tushare_common.caller import call_tushare

logger = logging.getLogger(__name__)

_DOMAIN = "financial_data"
_SOURCE = "tushare_us"

_API_METHOD_MAP = {
    "income": "us_income",
    "balance": "us_balancesheet",
    "cashflow": "us_cashflow",
    "indicator": "us_fina_indicator",
}

def _compact_date(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    cleaned = str(value).strip().replace("-", "")
    return cleaned or None

async def fetch_financial_data(
    api,
    ts_code: str,
    statement_type: str = "income",
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    period: Optional[str] = None,
) -> Optional[pd.DataFrame]:

    method_name = _API_METHOD_MAP.get(statement_type, "us_income")

    params = {"ts_code": ts_code}
    start_compact = _compact_date(start_date)
    end_compact = _compact_date(end_date)
    if start_compact:
        params["start_date"] = start_compact
    if end_compact:
        params["end_date"] = end_compact
    if period:
        params["period"] = _compact_date(period)

    return await call_tushare(
        api,
        method_name,
        _SOURCE,
        _DOMAIN,
        f"{ts_code} ({statement_type})",
        **params,
    )
