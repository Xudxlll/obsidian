import logging
from typing import Optional

import pandas as pd

from app.data.sources.tushare_common.caller import call_tushare

logger = logging.getLogger(__name__)

_DOMAIN = "basic_info"
_SOURCE = "tushare_us"

async def fetch_stock_list(api) -> Optional[pd.DataFrame]:

    return await call_tushare(api, "us_basic", _SOURCE, _DOMAIN)
