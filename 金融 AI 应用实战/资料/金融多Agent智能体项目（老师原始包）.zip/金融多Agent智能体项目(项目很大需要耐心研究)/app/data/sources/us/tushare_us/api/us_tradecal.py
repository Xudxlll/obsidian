import logging
from typing import Optional

import pandas as pd

from app.data.sources.tushare_common.caller import call_tushare

logger = logging.getLogger(__name__)

_DOMAIN = "trade_calendar"
_SOURCE = "tushare_us"

async def fetch_trade_calendar(
    api,
    exchange: str = "NYSE",
    start_date: str = None,
    end_date: str = None,
) -> Optional[pd.DataFrame]:

    params: dict = {"exchange": exchange}
    if start_date:
        params["start_date"] = start_date.replace("-", "")
    if end_date:
        params["end_date"] = end_date.replace("-", "")
    return await call_tushare(api, "us_tradecal", _SOURCE, _DOMAIN, exchange, **params)
