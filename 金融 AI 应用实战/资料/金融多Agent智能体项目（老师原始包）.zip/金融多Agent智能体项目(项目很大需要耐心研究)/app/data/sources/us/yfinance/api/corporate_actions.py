import asyncio
import logging
from typing import Optional

import pandas as pd

from app.data.sources.base.exceptions import (
    DataNotFoundError,
    DataSourceUnavailableError,
)
from app.data.sources.base.mappers import (
    map_network_exception,
)

logger = logging.getLogger(__name__)

_DOMAIN = "corporate_actions"

async def fetch_corporate_actions(
    symbol: str,
    start_date: str,
    end_date: str,
) -> Optional[pd.DataFrame]:

    try:
        import yfinance as yf

        ticker = symbol.upper().strip()

        def _fetch():
            t = yf.Ticker(ticker)
            return {"dividends": t.dividends, "splits": t.splits}

        result = await asyncio.to_thread(_fetch)
    except (asyncio.TimeoutError, ConnectionError, TimeoutError) as exc:
        raise map_network_exception(exc, "yfinance", _DOMAIN)
    except (KeyError, IndexError, ValueError, AttributeError) as exc:
        from app.data.sources.base.exceptions import DataFormatError
        raise DataFormatError("yfinance", _DOMAIN, f"symbol={symbol}: {exc}")
    except Exception as exc:
        raise DataSourceUnavailableError("yfinance", _DOMAIN, f"symbol={symbol}: {exc}")

    records = []

    divs = result.get("dividends")
    if divs is not None and not divs.empty:
        for date, val in divs.items():
            ds = str(date)[:10]
            if start_date <= ds <= end_date:
                records.append({
                    "date": ds,
                    "action_type": "cash_dividend",
                    "amount": val,
                    "symbol": ticker,
                })

    splits = result.get("splits")
    if splits is not None and not splits.empty:
        for date, val in splits.items():
            ds = str(date)[:10]
            if start_date <= ds <= end_date:
                action = "stock_split" if val > 1 else "reverse_split"
                records.append({
                    "date": ds,
                    "action_type": action,
                    "ratio": val,
                    "symbol": ticker,
                })

    if not records:
        logger.warning(f"yfinance 返回空数据: {symbol} 公司行为")
        raise DataNotFoundError("yfinance", _DOMAIN, f"{symbol} 无公司行为数据")

    df = pd.DataFrame(records)
    logger.info(f"yfinance 获取成功: {symbol} {len(df)} 条")
    return df
