import logging
from typing import Optional

import pandas as pd

from app.data.sources.tushare_common.caller import call_tushare
from app.data.sources.us.tushare_us.code_resolver import get_us_ts_code

logger = logging.getLogger(__name__)

_DOMAIN = "fina_indicator"
_SOURCE = "tushare_us"

async def fetch_fina_indicator(
    api,
    ts_code: str,
) -> Optional[pd.DataFrame]:
    if api is None:
        return None
    us_code = await get_us_ts_code(ts_code, api=api)
    return await call_tushare(
        api, "us_fina_indicator", _SOURCE, _DOMAIN, us_code, ts_code=us_code
    )
