from app.data.sources.tushare_common.base_provider import TushareBaseProvider
from app.data.sources.us.tushare_us.code_resolver import get_us_ts_code

class TushareUSProvider(TushareBaseProvider):

    DOMAIN_ENDPOINTS = {
        "basic_info": "us_basic",
        "trade_calendar": "us_tradecal",
        "daily_quotes": "us_daily",
        "daily_indicators": "us_daily_adj",
        "adj_factors": "us_adjfactor",
    }
    FINANCIAL_ENDPOINTS = {
        "income": "us_income",
        "balance": "us_balancesheet",
        "cashflow": "us_cashflow",
        "indicator": "us_fina_indicator",
    }
    DEFAULT_EXCHANGE = "NYSE"
    PROBE_ENDPOINT = "us_basic"
    MIN_CREDITS = 120

    def __init__(self):
        super().__init__(name="tushare_us", market="US")

    async def _resolve_ts_code(self, symbol: str) -> str:
        return await get_us_ts_code(symbol, api=self._get_api())
