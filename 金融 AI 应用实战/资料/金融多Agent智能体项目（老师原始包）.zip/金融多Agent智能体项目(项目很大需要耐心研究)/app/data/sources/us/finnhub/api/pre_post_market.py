import logging
from typing import Optional

import pandas as pd

logger = logging.getLogger(__name__)

_DOMAIN = "pre_post_market"

async def fetch_pre_post_market(
    symbol: str,
    start_date: str,
    end_date: str,
) -> Optional[pd.DataFrame]:

    logger.debug(f"Finnhub-US 盘前盘后行情暂不支持（免费层）: {symbol}")
    return None
