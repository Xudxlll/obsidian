import asyncio
import logging
from datetime import datetime
from typing import Optional

import pandas as pd

from app.data.sources.base.exceptions import (
    DataNotFoundError,
    DataSourceUnavailableError,
)
from app.data.sources.base.mappers import (
    is_empty_result,
    map_network_exception,
)

logger = logging.getLogger(__name__)

_DOMAIN = "daily_indicators"

async def fetch_daily_indicators(symbol: str) -> Optional[pd.DataFrame]:

    try:
        import yfinance as yf

        ticker = symbol.upper().strip()

        def _fetch():
            t = yf.Ticker(ticker)
            info = t.info
            if not info:
                return None
            record = {
                "symbol": ticker,
                "trade_date": datetime.now().strftime("%Y-%m-%d"),
                "pe_ttm": info.get("trailingPE"),
                "pb": info.get("priceToBook"),
                "ps_ttm": info.get("priceToSalesTrailing12Months"),
                "dividend_yield": info.get("dividendYield"),
                "market_cap": info.get("marketCap"),
                "shares_outstanding": info.get("sharesOutstanding"),
                "float_shares": info.get("floatShares"),
            }
            return pd.DataFrame([record])

        df = await asyncio.to_thread(_fetch)
    except (asyncio.TimeoutError, ConnectionError, TimeoutError) as exc:
        raise map_network_exception(exc, "yfinance", _DOMAIN)
    except (KeyError, IndexError, ValueError, AttributeError) as exc:
        from app.data.sources.base.exceptions import DataFormatError
        raise DataFormatError("yfinance", _DOMAIN, f"symbol={symbol}: {exc}")
    except Exception as exc:
        raise DataSourceUnavailableError("yfinance", _DOMAIN, f"symbol={symbol}: {exc}")

    if is_empty_result(df):
        logger.warning(f"yfinance 返回空数据: {symbol} 指标")
        raise DataNotFoundError("yfinance", _DOMAIN, f"{symbol} 无指标数据")

    logger.debug(f"yfinance 获取成功: {symbol} 指标")
    return df
