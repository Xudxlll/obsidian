import logging
from typing import Optional

import pandas as pd

from app.data.sources.tushare_common.caller import call_tushare
from app.data.sources.us.tushare_us.code_resolver import get_us_ts_code

logger = logging.getLogger(__name__)

_DOMAIN = "daily_quotes"
_SOURCE = "tushare_us"

async def fetch_daily_adj(
    api,
    ts_code: str,
    start_date: str,
    end_date: str,
) -> Optional[pd.DataFrame]:
    if api is None:
        return None
    us_code = await get_us_ts_code(ts_code, api=api)
    return await call_tushare(
        api,
        "us_daily_adj",
        _SOURCE,
        _DOMAIN,
        us_code,
        ts_code=us_code,
        start_date=start_date.replace("-", ""),
        end_date=end_date.replace("-", ""),
    )
