import asyncio
import logging
from typing import Dict, Optional

import pandas as pd

from app.data.storage.cache.memory_cache import TTLCache
from app.data.storage.redis.locks import DistributedLock

logger = logging.getLogger(__name__)

_EXCHANGE_SUFFIX: Dict[str, str] = {
    "NASDAQ": ".O",
    "NYSE": ".N",
    "AMEX": ".A",
}
_DEFAULT_SUFFIX = ".O"

_MEM_CACHE_KEY = "us_code_resolver:map"
_LOCK_KEY = "us_code_resolver:refresh"
_TTL_SECONDS = 300

class USCodeResolver:

    _instance: Optional["USCodeResolver"] = None

    def __new__(cls) -> "USCodeResolver":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._cache = TTLCache(default_ttl=_TTL_SECONDS)
        return cls._instance

    @classmethod
    def reset_instance(cls) -> None:
        cls._instance = None

    async def resolve(self, symbol: str, api=None) -> str:

        s = str(symbol).upper().strip()
        if "." in s:
            return s

        mapping = await self._get_mapping(api)
        exchange = mapping.get(s)
        if exchange:
            suffix = _EXCHANGE_SUFFIX.get(exchange.upper(), _DEFAULT_SUFFIX)
            if suffix == _DEFAULT_SUFFIX and exchange.upper() not in _EXCHANGE_SUFFIX:
                logger.warning(
                    "USCodeResolver: symbol=%s 命中未知 exchange=%s，fallback=%s",
                    s,
                    exchange,
                    suffix,
                )
            return f"{s}{suffix}"

        logger.debug(
            "USCodeResolver: symbol=%s 未在映射中找到，fallback=%s",
            s,
            _DEFAULT_SUFFIX,
        )
        return f"{s}{_DEFAULT_SUFFIX}"

    async def _get_mapping(self, api=None) -> Dict[str, str]:
        cached = self._cache.get(_MEM_CACHE_KEY)
        if cached is not None:
            return cached

        from_db = await self._load_from_db()
        if from_db:
            self._cache.set(_MEM_CACHE_KEY, from_db, ttl=_TTL_SECONDS)
            return from_db

        if api is None:
            return {}

        lock = DistributedLock(_LOCK_KEY, ttl=30)
        got = await lock.acquire()
        try:
            if not got:
                await asyncio.sleep(0.5)
                cached = self._cache.get(_MEM_CACHE_KEY)
                if cached is not None:
                    return cached
                return {}

            try:
                from app.data.sources.us.tushare_us.api.us_basic import (
                    fetch_stock_list,
                )
                df = await fetch_stock_list(api)
                mapping = self._df_to_mapping(df)
                self._cache.set(_MEM_CACHE_KEY, mapping, ttl=_TTL_SECONDS)
                return mapping
            except Exception as e:
                logger.warning(f"USCodeResolver: us_basic() 拉取失败: {e}")
                return {}
        finally:
            if got:
                await lock.release()

    @staticmethod
    def _df_to_mapping(df) -> Dict[str, str]:
        if df is None or not isinstance(df, pd.DataFrame) or df.empty:
            return {}
        mapping: Dict[str, str] = {}
        for _, row in df.iterrows():
            ts_code = str(row.get("ts_code", ""))
            exchange = str(row.get("exchange", "") or "")
            if not ts_code or not exchange:
                continue
            symbol = ts_code.split(".")[0].upper()
            mapping[symbol] = exchange
        return mapping

    async def _load_from_db(self) -> Dict[str, str]:
        try:
            from app.data.storage.mongo.client import get_motor_db
            from app.data.storage.mongo.collections import get_collection_name
            db = get_motor_db()
            coll_name = get_collection_name("basic_info", "US")
            cursor = db[coll_name].find(
                {"market": "US", "data_source": "tushare_us"},
                {"symbol": 1, "exchange": 1, "_id": 0},
            )
            docs = await cursor.to_list(length=None)
            if not docs:
                return {}
            mapping: Dict[str, str] = {}
            for doc in docs:
                sym = doc.get("symbol")
                ex = doc.get("exchange")
                if sym and ex:
                    mapping[str(sym).upper()] = str(ex)
            return mapping
        except Exception as e:
            logger.debug(f"USCodeResolver: MongoDB 读取失败: {e}")
            return {}

async def get_us_ts_code(symbol: str, api=None) -> str:
    resolver = USCodeResolver()
    return await resolver.resolve(symbol, api=api)
