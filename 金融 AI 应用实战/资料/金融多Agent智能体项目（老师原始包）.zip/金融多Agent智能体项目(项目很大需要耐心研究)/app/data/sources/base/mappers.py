from __future__ import annotations

import logging
from typing import Any, Optional, Union

from app.data.sources.base.exceptions import (
    DataSourceError,
    DataSourceUnavailableError,
    DataNotFoundError,
    InsufficientCreditsError,
    NetworkError,
    RateLimitedError,
    TokenInvalidError,
)

logger = logging.getLogger(__name__)

__all__ = [
    "map_http_status_to_error",
    "map_tushare_code",
    "map_tushare_response",
    "map_network_exception",
    "is_empty_result",
]

_HTTP_RATE_LIMITED = {429}
_HTTP_AUTH_FAILED = {401, 403}
_HTTP_SERVER_ERROR = {500, 502, 503, 504}
_HTTP_CLIENT_ERROR = {400, 404, 409, 422}
_HTTP_TIMEOUT = {408, 504}

def map_http_status_to_error(
    status: int,
    source: str,
    domain: str,
    message: str = "",
    retry_after: int = 0,
) -> DataSourceError:

    if status in _HTTP_RATE_LIMITED:
        return RateLimitedError(source, domain, message, retry_after=retry_after)
    if status in _HTTP_AUTH_FAILED:
        return TokenInvalidError(source, domain, message)
    if status in _HTTP_TIMEOUT:
        return NetworkError(source, domain, message or f"HTTP {status} 超时")
    if status in _HTTP_SERVER_ERROR:
        return DataSourceUnavailableError(source, domain, message or f"HTTP {status}")
    if status in _HTTP_CLIENT_ERROR:
        return DataNotFoundError(source, domain, message or f"HTTP {status} 客户端错误")
    return DataSourceUnavailableError(source, domain, message or f"HTTP {status}")

_TUSHARE_RATE_LIMITED_CODES = frozenset({
    5003,
    5004,
})
_TUSHARE_AUTH_FAILED_CODES = frozenset({
    10001,
    10002,
})
_TUSHARE_INSUFFICIENT_CREDITS_CODES = frozenset({
    40203,
    40204,
})
_TUSHARE_DATA_NOT_FOUND_CODES = frozenset({
    40001,
    40002,
})

def map_tushare_code(
    code: Union[int, str, None],
    source: str,
    domain: str,
    message: str = "",
) -> Optional[DataSourceError]:

    if code is None or code == 0:
        return None
    try:
        code_int = int(code)
    except (ValueError, TypeError):
        return None

    if code_int in _TUSHARE_RATE_LIMITED_CODES:
        return RateLimitedError(source, domain, message)
    if code_int in _TUSHARE_AUTH_FAILED_CODES:
        return TokenInvalidError(source, domain, message)
    if code_int in _TUSHARE_INSUFFICIENT_CREDITS_CODES:
        return InsufficientCreditsError(source, domain, message)
    if code_int in _TUSHARE_DATA_NOT_FOUND_CODES:
        return DataNotFoundError(source, domain, message)
    return None

def map_tushare_response(
    response: Any,
    source: str,
    domain: str,
) -> Optional[DataSourceError]:

    if response is None:
        return DataNotFoundError(source, domain, "Tushare 返回 None")
    if isinstance(response, dict):
        code = response.get("code")
        msg = response.get("msg", "")
        err = map_tushare_code(code, source, domain, msg)
        if err is not None:
            return err
        data = response.get("data") or response.get("items")
        if data is None or (isinstance(data, (list, dict)) and len(data) == 0):
            return DataNotFoundError(source, domain, "Tushare 返回空数据")
    return None

def map_network_exception(
    exc: Exception,
    source: str,
    domain: str,
    message: str = "",
) -> NetworkError:

    exc_name = type(exc).__name__
    exc_msg = str(exc) or exc_name
    final_msg = message or f"{exc_name}: {exc_msg}"
    logger.debug(f"网络异常映射 [{source}/{domain}]: {final_msg}")
    return NetworkError(source, domain, final_msg)

def is_empty_result(result: Any) -> bool:

    if result is None:
        return True
    empty_attr = getattr(result, "empty", None)
    if empty_attr is not None:
        try:
            return bool(empty_attr)
        except Exception as exc:
            logger.debug("is_empty_result.empty_attr 访问异常: %s", exc)
    if isinstance(result, (list, dict, str)) and len(result) == 0:
        return True
    return False
