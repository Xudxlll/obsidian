from enum import Enum

class DataErrorCode(str, Enum):
    RATE_LIMITED = "rate_limited"
    AUTH_FAILED = "auth_failed"
    TOKEN_INVALID = "token_invalid"
    INSUFFICIENT_CREDITS = "insufficient_credits"
    NETWORK_TIMEOUT = "network_timeout"
    CONNECTION_ERROR = "connection_error"
    SERVICE_UNAVAILABLE = "service_unavailable"
    SERVER_ERROR = "server_error"
    DATA_INVALID = "data_invalid"
    EMPTY_RESULT = "empty_result"
    SYMBOL_NOT_FOUND = "symbol_not_found"
    NOT_SUPPORTED = "not_supported"
    UNKNOWN = "unknown"
