import logging
from abc import ABC
from typing import Any, List

from app.data.schema.domains.basic_info import StockBasicInfoSchema
from app.data.schema.domains.trade_calendar import TradeCalendarSchema
from app.data.schema.domains.daily_quotes import DailyQuotesSchema
from app.data.schema.domains.daily_indicators import DailyIndicatorsSchema
from app.data.schema.domains.adj_factors import AdjFactorsSchema
from app.data.schema.domains.corporate_actions import CorporateActionsSchema
from app.data.schema.domains.financial_data import FinancialDataSchema
from app.data.schema.domains.market_quotes import MarketQuotesSchema
from app.data.schema.domains.stock_news import StockNewsSchema
from app.data.schema.domains.money_flow import MoneyFlowSchema
from app.data.schema.domains.margin_trading import MarginTradingSchema
from app.data.schema.domains.dragon_tiger import DragonTigerSchema
from app.data.schema.domains.block_trade import BlockTradeSchema
from app.data.schema.domains.intraday_quotes import IntradayQuotesSchema

class BaseAdapter(ABC):

    def __init__(self, provider, market: str, source_name: str):
        self.provider = provider
        self.market = market
        self.source_name = source_name
        self.logger = logging.getLogger(f"adapter.{market}.{source_name}")

    def adapt_basic_info(self, raw: Any) -> List[StockBasicInfoSchema]:
        raise NotImplementedError(f"{self.source_name} 不支持 basic_info")

    def adapt_trade_calendar(self, raw: Any) -> List[TradeCalendarSchema]:
        raise NotImplementedError(f"{self.source_name} 不支持 trade_calendar")

    def adapt_daily_quotes(self, raw: Any) -> List[DailyQuotesSchema]:
        raise NotImplementedError(f"{self.source_name} 不支持 daily_quotes")

    def adapt_daily_indicators(self, raw: Any) -> List[DailyIndicatorsSchema]:
        raise NotImplementedError(f"{self.source_name} 不支持 daily_indicators")

    def adapt_financial_data(self, raw: Any) -> List[FinancialDataSchema]:
        raise NotImplementedError(f"{self.source_name} 不支持 financial_data")

    def adapt_adj_factors(self, raw: Any) -> List[AdjFactorsSchema]:
        raise NotImplementedError(f"{self.source_name} 不支持 adj_factors")

    def adapt_corporate_actions(self, raw: Any) -> List[CorporateActionsSchema]:
        raise NotImplementedError(f"{self.source_name} 不支持 corporate_actions")

    def adapt_news(self, raw: Any) -> List[StockNewsSchema]:
        raise NotImplementedError(f"{self.source_name} 不支持 news")

    def adapt_market_quotes(self, raw: Any) -> List[MarketQuotesSchema]:
        raise NotImplementedError(f"{self.source_name} 不支持 market_quotes")

    def adapt_intraday_quotes(self, raw: Any) -> List[IntradayQuotesSchema]:
        raise NotImplementedError(f"{self.source_name} 不支持 intraday_quotes")

    def adapt_money_flow(self, raw: Any) -> List[MoneyFlowSchema]:
        raise NotImplementedError(f"{self.source_name} 不支持 money_flow")

    def adapt_margin_trading(self, raw: Any) -> List[MarginTradingSchema]:
        raise NotImplementedError(f"{self.source_name} 不支持 margin_trading")

    def adapt_dragon_tiger(self, raw: Any) -> List[DragonTigerSchema]:
        raise NotImplementedError(f"{self.source_name} 不支持 dragon_tiger")

    def adapt_block_trade(self, raw: Any) -> List[BlockTradeSchema]:
        raise NotImplementedError(f"{self.source_name} 不支持 block_trade")
