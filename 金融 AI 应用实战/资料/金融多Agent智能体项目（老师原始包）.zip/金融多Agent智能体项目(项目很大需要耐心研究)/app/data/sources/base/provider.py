import logging
from abc import ABC, abstractmethod
from typing import List, Optional

import pandas as pd

class BaseProvider(ABC):

    def __init__(self, name: str, market: str):
        self.name = name
        self.market = market
        self.connected = False
        self.logger = logging.getLogger(f"sources.{market}.{name}")

    @abstractmethod
    async def connect(self) -> bool:
        pass

    @abstractmethod
    def is_available(self) -> bool:
        pass

    async def get_stock_list(self, **kwargs) -> pd.DataFrame:

        raise NotImplementedError(f"{self.name} 不支持 get_stock_list")

    async def get_trade_calendar(self, exchange: str, start_date: str, end_date: str, **kwargs) -> pd.DataFrame:

        raise NotImplementedError(f"{self.name} 不支持 get_trade_calendar")

    async def get_daily_quotes(self, symbol: str, start_date: str, end_date: str, **kwargs) -> pd.DataFrame:

        raise NotImplementedError(f"{self.name} 不支持 get_daily_quotes")

    async def get_daily_indicators(self, symbol: str, start_date: str, end_date: str, **kwargs) -> pd.DataFrame:

        raise NotImplementedError(f"{self.name} 不支持 get_daily_indicators")

    async def get_daily_indicators_batch(self, trade_date: str, **kwargs) -> pd.DataFrame:

        raise NotImplementedError(f"{self.name} 不支持 get_daily_indicators_batch")

    async def get_financial_data(self, symbol: str, start_date: str, end_date: str,
                                statement_type: str = "", **kwargs) -> pd.DataFrame:

        raise NotImplementedError(f"{self.name} 不支持 get_financial_data")

    async def get_adj_factors(self, symbol: str, start_date: str, end_date: str, **kwargs) -> pd.DataFrame:

        raise NotImplementedError(f"{self.name} 不支持 get_adj_factors")

    async def get_corporate_actions(self, symbol: str, start_date: str, end_date: str, **kwargs) -> pd.DataFrame:

        raise NotImplementedError(f"{self.name} 不支持 get_corporate_actions")

    async def get_news(self, symbol: str, start_date: str, end_date: str, **kwargs) -> pd.DataFrame:

        raise NotImplementedError(f"{self.name} 不支持 get_news")

    async def get_market_quotes(self, symbols: Optional[List[str]] = None, **kwargs) -> pd.DataFrame:

        raise NotImplementedError(f"{self.name} 不支持 get_market_quotes")

    async def get_intraday_quotes(self, symbol: str, start_date: str, end_date: str, **kwargs) -> pd.DataFrame:

        raise NotImplementedError(f"{self.name} 不支持 get_intraday_quotes")

    async def get_money_flow(self, symbol: str, start_date: str, end_date: str, **kwargs) -> pd.DataFrame:

        raise NotImplementedError(f"{self.name} 不支持 get_money_flow")

    async def get_margin_trading(self, symbol: str, start_date: str, end_date: str, **kwargs) -> pd.DataFrame:

        raise NotImplementedError(f"{self.name} 不支持 get_margin_trading")

    async def get_dragon_tiger(self, symbol: str, start_date: str, end_date: str, **kwargs) -> pd.DataFrame:

        raise NotImplementedError(f"{self.name} 不支持 get_dragon_tiger")

    async def get_block_trade(self, symbol: str, start_date: str, end_date: str, **kwargs) -> pd.DataFrame:

        raise NotImplementedError(f"{self.name} 不支持 get_block_trade")
