import asyncio
import logging
import threading
from typing import Any, Dict, List, Optional

from app.data.sources.base.exceptions import (
    InsufficientCreditsError,
    TokenInvalidError,
)
from app.data.sources.base.mappers import map_tushare_code

try:
    import tushare as ts

    TUSHARE_AVAILABLE = True
except ImportError:
    TUSHARE_AVAILABLE = False
    ts = None

logger = logging.getLogger(__name__)

_TOKEN_INVALID_KEYWORDS = ("token", "登录", "未登录", "权限")
_CREDITS_KEYWORDS = ("积分", "credit")

def classify_tushare_error(
    exc: Exception,
    source: str,
    domain: str,
    min_credits: int = 0,
) -> Optional[Exception]:

    error_code = getattr(exc, "code", None) or getattr(exc, "error_code", None)
    mapped = map_tushare_code(error_code, source, domain, str(exc))
    if mapped is not None:
        return mapped

    msg = str(exc).lower()
    if any(kw in msg for kw in _TOKEN_INVALID_KEYWORDS):
        return TokenInvalidError(source, domain, f"Token 无效: {exc}")
    if any(kw in str(exc) for kw in _CREDITS_KEYWORDS) or "credit" in msg:
        return InsufficientCreditsError(source, domain, f"积分不足(需≥{min_credits}): {exc}", required=min_credits)
    return None

class TushareClient:

    def __init__(
        self,
        source_name: str,
        env_chain: Optional[List[str]] = None,
        probe_endpoint: str = "stock_basic",
        probe_kwargs: Optional[Dict[str, Any]] = None,
        min_credits: int = 0,
    ):
        self.source_name = source_name
        self.env_chain = env_chain
        self.probe_endpoint = probe_endpoint
        self.probe_kwargs = probe_kwargs or {}
        self.min_credits = min_credits

        self.api = None
        self.connected = False
        self.token_source: Optional[str] = None
        self._token: Optional[str] = None
        self._rebuild_count = 0
        self._lock = threading.Lock()

    def resolve_token(self) -> Optional[str]:

        from app.utils.ds_key_utils import get_datasource_api_key

        token = get_datasource_api_key(self.source_name)
        if token:
            self.token_source = "ds_key_utils"
            return token
        if self.env_chain:
            from app.core.env import get_env

            for env_key in self.env_chain:
                val = get_env(env_key)
                if val and val.strip() and not val.startswith("your_"):
                    self.token_source = f"env:{env_key}"
                    return val.strip()
        return None

    def connect_sync(self) -> bool:
        if not TUSHARE_AVAILABLE:
            logger.error(f"{self.source_name}: tushare 库不可用")
            return False

        token = self._token or self.resolve_token()
        if not token:
            logger.warning(f"{self.source_name}: Token 未配置，无法连接")
            return False

        try:
            ts.set_token(token)
            api = ts.pro_api()
        except Exception as e:
            logger.error(f"{self.source_name}: set_token/pro_api 失败: {e}")
            return False

        probe = getattr(api, self.probe_endpoint, None)
        if probe is None:
            logger.error(f"{self.source_name}: 试探接口不存在: {self.probe_endpoint}")
            return False

        try:
            result = probe(**self.probe_kwargs)
            if result is not None and not getattr(result, "empty", True):
                with self._lock:
                    self.api = api
                    self.connected = True
                    self._token = token
                    self._rebuild_count = 0
                logger.info(f"{self.source_name} 连接成功 (Token 来源: {self.token_source})")
                return True
            logger.warning(f"{self.source_name} 试探 {self.probe_endpoint} 返回空数据")
            return False
        except Exception as e:
            classified = classify_tushare_error(e, self.source_name, self.probe_endpoint, self.min_credits)
            if classified is not None:
                raise classified
            logger.error(f"{self.source_name} 连接失败: {e}")
            return False

    async def connect(self) -> bool:
        return await asyncio.to_thread(self.connect_sync)

    def is_available(self) -> bool:
        return TUSHARE_AVAILABLE and self.connected and self.api is not None

    def get_api(self):

        if self.api is not None:
            return self.api
        if self._rebuild_count >= 1:
            return None
        with self._lock:
            if self.api is not None:
                return self.api
            if self._rebuild_count >= 1:
                return None
            self._rebuild_count += 1
        try:
            if self.connect_sync():
                return self.api
        except Exception as e:
            logger.debug(f"{self.source_name} 重建连接失败: {e}")
        return None

    def invalidate(self) -> None:
        with self._lock:
            self.api = None
            self.connected = False

    def query(self, api_name: str, **kwargs):
        if not self.is_available():
            return None
        try:
            method = getattr(self.api, api_name, None)
            if method:
                return method(**kwargs)
            return self.api.query(api_name, **kwargs)
        except Exception as e:
            logger.error(f"{self.source_name} query({api_name}) 失败: {e}")
            raise
