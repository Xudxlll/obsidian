import asyncio
import logging
from typing import Any, Optional

from app.data.sources.base.exceptions import (
    DataNotFoundError,
    DataSourceUnavailableError,
)
from app.data.sources.base.mappers import (
    is_empty_result,
    map_network_exception,
    map_tushare_code,
)

logger = logging.getLogger(__name__)

def _class_attr(obj: Any, name: str):

    for klass in type(obj).__mro__:
        if name in vars(klass):
            return vars(klass)[name]
    return None

def _resolve_api(api_or_client: Any):

    if api_or_client is None:
        return None
    get_api = _class_attr(api_or_client, "get_api")
    if callable(get_api):
        return get_api(api_or_client)
    is_available = _class_attr(api_or_client, "is_available")
    if callable(is_available):
        if not is_available(api_or_client):
            return None
        return getattr(api_or_client, "api", None)
    is_available = _class_attr(api_or_client, "is_available")
    if callable(is_available):
        if not is_available(api_or_client):
            return None
        return getattr(api_or_client, "api", None)
    return api_or_client

async def call_tushare(
    api_or_client: Any,
    method_name: str,
    source: str,
    domain: str,
    context: str = "",
    **params,
) -> Optional[Any]:

    api = _resolve_api(api_or_client)
    if api is None:
        return None

    method = getattr(api, method_name, None)
    if method is None:
        logger.error(f"{source} 不支持的接口: {method_name}")
        return None

    try:
        df = await asyncio.to_thread(method, **params)
    except (asyncio.TimeoutError, ConnectionError, TimeoutError) as exc:
        raise map_network_exception(exc, source, domain)
    except Exception as exc:
        error_code = getattr(exc, "code", None) or getattr(exc, "error_code", None)
        mapped = map_tushare_code(error_code, source, domain, str(exc))
        if mapped is not None:
            raise mapped
        raise DataSourceUnavailableError(source, domain, f"{f'{context}: ' if context else ''}{exc}")

    if is_empty_result(df):
        logger.warning(f"{source} {domain} 返回空数据: {context or method_name}")
        raise DataNotFoundError(source, domain, f"{context or method_name} 无数据")

    logger.info(f"{source} {domain}({method_name}): {context or ''} {len(df)} 条".strip())
    return df
