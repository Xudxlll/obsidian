import logging
from typing import Dict, Optional

import pandas as pd

from app.data.sources.base.exceptions import DataSourceError
from app.data.sources.base.provider import BaseProvider
from app.data.sources.tushare_common.caller import call_tushare
from app.data.sources.tushare_common.client import TushareClient

logger = logging.getLogger(__name__)

def _compact(date_str) -> str:
    return str(date_str).replace("-", "") if date_str else ""

class TushareBaseProvider(BaseProvider):

    DOMAIN_ENDPOINTS: Dict[str, str] = {}
    FINANCIAL_ENDPOINTS: Dict[str, str] = {}
    DEFAULT_EXCHANGE: str = "SSE"
    TRADE_CAL_OMIT_EXCHANGE: bool = False
    PROBE_ENDPOINT: str = "stock_basic"
    MIN_CREDITS: int = 0

    def __init__(self, name: str, market: str, client: Optional[TushareClient] = None):
        super().__init__(name=name, market=market)
        self._client = client or TushareClient(
            source_name=name,
            probe_endpoint=self.PROBE_ENDPOINT,
            probe_kwargs={"limit": 1} if self.PROBE_ENDPOINT != "stock_basic" else {"list_status": "L", "limit": 1},
            min_credits=self.MIN_CREDITS,
        )

    def _get_api(self):
        return self._client.get_api()

    async def connect(self) -> bool:
        try:
            ok = await self._client.connect()
            self.connected = ok
            return ok
        except DataSourceError:
            self.connected = False
            raise
        except Exception as e:
            logger.error(f"{self.name} 连接失败: {e}")
            self.connected = False
            return False

    def is_available(self) -> bool:
        return self.connected and self._get_api() is not None

    async def _resolve_ts_code(self, symbol: str) -> str:
        return symbol

    async def _delegate(self, coro, label: str) -> Optional[pd.DataFrame]:
        try:
            return await coro
        except DataSourceError as e:
            logger.debug(f"{self.name} {label} 失败: {e}")
            return None
        except Exception as e:
            logger.error(f"{self.name} {label} 失败: {e}")
            return None

    async def _call(self, domain: str, context: str = "", **params) -> Optional[pd.DataFrame]:
        endpoint = self.DOMAIN_ENDPOINTS.get(domain)
        if endpoint is None:
            raise NotImplementedError(f"{self.name} 不支持 {domain}")
        return await call_tushare(self._get_api(), endpoint, self.name, domain, context, **params)

    async def get_stock_list(self, **kwargs) -> pd.DataFrame:
        return await self._delegate(self._call("basic_info", "全市场"), "股票列表")

    async def get_trade_calendar(
        self,
        exchange: str = None,
        start_date: str = None,
        end_date: str = None,
        **kwargs,
    ) -> pd.DataFrame:
        params: Dict[str, str] = {}
        if not self.TRADE_CAL_OMIT_EXCHANGE:
            params["exchange"] = exchange or self.DEFAULT_EXCHANGE
        if start_date:
            params["start_date"] = _compact(start_date)
        if end_date:
            params["end_date"] = _compact(end_date)
        return await self._delegate(self._call("trade_calendar", exchange or self.DEFAULT_EXCHANGE, **params), "交易日历")

    async def get_daily_quotes(self, symbol: str, start_date: str, end_date: str, **kwargs) -> pd.DataFrame:
        ts_code = await self._resolve_ts_code(symbol)
        return await self._delegate(
            self._call(
                "daily_quotes",
                ts_code,
                ts_code=ts_code,
                start_date=_compact(start_date),
                end_date=_compact(end_date),
            ),
            f"行情 {symbol}",
        )

    async def get_daily_indicators(self, symbol: str, start_date: str, end_date: str, **kwargs) -> pd.DataFrame:
        ts_code = await self._resolve_ts_code(symbol)
        return await self._delegate(
            self._call(
                "daily_indicators",
                ts_code,
                ts_code=ts_code,
                start_date=_compact(start_date),
                end_date=_compact(end_date),
            ),
            f"每日指标 {symbol}",
        )

    async def get_adj_factors(self, symbol: str, start_date: str, end_date: str, **kwargs) -> pd.DataFrame:
        ts_code = await self._resolve_ts_code(symbol)
        return await self._delegate(
            self._call(
                "adj_factors",
                ts_code,
                ts_code=ts_code,
                start_date=_compact(start_date),
                end_date=_compact(end_date),
            ),
            f"复权因子 {symbol}",
        )

    async def get_financial_data(
        self,
        symbol: str,
        start_date: str,
        end_date: str,
        statement_type: str = "",
        **kwargs,
    ) -> pd.DataFrame:
        ts_code = await self._resolve_ts_code(symbol)
        stmt = statement_type or "income"
        endpoint = self.FINANCIAL_ENDPOINTS.get(stmt, self.FINANCIAL_ENDPOINTS.get("income"))
        params: Dict[str, str] = {"ts_code": ts_code}
        if start_date:
            params["start_date"] = _compact(start_date)
        if end_date:
            params["end_date"] = _compact(end_date)
        return await self._delegate(
            call_tushare(
                self._get_api(),
                endpoint,
                self.name,
                "financial_data",
                f"{ts_code} ({stmt})",
                **params,
            ),
            f"财务 {symbol} ({stmt})",
        )

    async def get_market_quotes(self, symbols=None, **kwargs) -> pd.DataFrame:
        if "market_quotes" not in self.DOMAIN_ENDPOINTS:
            raise NotImplementedError(f"{self.name} 不支持 get_market_quotes")
        return await self._delegate(self._call("market_quotes", "全市场"), "实时行情")
