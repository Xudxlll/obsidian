import asyncio
import logging
from typing import Optional

import pandas as pd

from app.data.sources.base.exceptions import (
    DataFormatError,
    DataNotFoundError,
    DataSourceUnavailableError,
)
from app.data.sources.base.mappers import is_empty_result, map_network_exception

logger = logging.getLogger(__name__)

_DOMAIN = "daily_quotes"

def _to_yfinance_symbol(symbol: str) -> str:
    code = str(symbol).replace(".HK", "").lstrip("0").zfill(4)
    return f"{code}.HK"

async def fetch_daily_quotes(
    symbol: str,
    start_date: str,
    end_date: str,
) -> Optional[pd.DataFrame]:

    try:
        import yfinance as yf

        hk_symbol = _to_yfinance_symbol(symbol)
        end = pd.to_datetime(end_date) + pd.DateOffset(days=1)
        end_str = end.strftime("%Y-%m-%d")

        def _fetch():
            ticker = yf.Ticker(hk_symbol)
            df = ticker.history(start=start_date, end=end_str)
            if df is not None and not df.empty and "Close" in df.columns:
                df["pre_close"] = df["Close"].shift(1)
            return df

        df = await asyncio.to_thread(_fetch)
    except (asyncio.TimeoutError, ConnectionError, TimeoutError) as exc:
        raise map_network_exception(exc, "yfinance_hk", _DOMAIN)
    except (KeyError, IndexError, AttributeError, ValueError) as exc:
        raise DataFormatError("yfinance_hk", _DOMAIN, f"{symbol}: {exc}")
    except Exception as exc:
        raise DataSourceUnavailableError("yfinance_hk", _DOMAIN, f"{symbol}: {exc}")

    if is_empty_result(df):
        logger.warning(f"yfinance_hk 返回空行情: {symbol}")
        raise DataNotFoundError("yfinance_hk", _DOMAIN, f"{symbol} 无行情数据")

    logger.info(f"yfinance_hk 获取行情: {symbol} {len(df)} 条")
    return df
