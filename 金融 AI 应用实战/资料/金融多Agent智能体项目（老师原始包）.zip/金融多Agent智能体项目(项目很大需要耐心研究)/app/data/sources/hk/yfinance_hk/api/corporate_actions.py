import asyncio
import logging
from typing import Optional

import pandas as pd

from app.data.sources.base.exceptions import (
    DataFormatError,
    DataNotFoundError,
    DataSourceUnavailableError,
)
from app.data.sources.base.mappers import map_network_exception

logger = logging.getLogger(__name__)

_DOMAIN = "corporate_actions"

def _to_yfinance_symbol(symbol: str) -> str:
    code = str(symbol).replace(".HK", "").lstrip("0").zfill(4)
    return f"{code}.HK"

async def fetch_corporate_actions(
    symbol: str,
    start_date: str,
    end_date: str,
) -> Optional[pd.DataFrame]:

    try:
        import yfinance as yf

        hk_symbol = _to_yfinance_symbol(symbol)

        def _fetch():
            ticker = yf.Ticker(hk_symbol)
            return {
                "dividends": ticker.dividends,
                "splits": ticker.splits,
            }

        result = await asyncio.to_thread(_fetch)
    except (asyncio.TimeoutError, ConnectionError, TimeoutError) as exc:
        raise map_network_exception(exc, "yfinance_hk", _DOMAIN)
    except (KeyError, IndexError, AttributeError, ValueError) as exc:
        raise DataFormatError("yfinance_hk", _DOMAIN, f"{symbol}: {exc}")
    except Exception as exc:
        raise DataSourceUnavailableError("yfinance_hk", _DOMAIN, f"{symbol}: {exc}")

    records = []

    dividends = result.get("dividends") if result else None
    if dividends is not None and not dividends.empty:
        for date, val in dividends.items():
            date_str = str(date)[:10]
            if start_date <= date_str <= end_date:
                records.append({
                    "date": date,
                    "action_type": "cash_dividend",
                    "amount": float(val),
                    "symbol": symbol,
                })

    splits = result.get("splits") if result else None
    if splits is not None and not splits.empty:
        for date, val in splits.items():
            date_str = str(date)[:10]
            if start_date <= date_str <= end_date:
                records.append({
                    "date": date,
                    "action_type": "stock_split",
                    "ratio": float(val),
                    "symbol": symbol,
                })

    if not records:
        logger.debug(
            f"yfinance_hk 无公司行为: {symbol} {start_date}~{end_date}"
        )
        raise DataNotFoundError(
            "yfinance_hk",
            _DOMAIN,
            f"{symbol} 日期范围 {start_date}~{end_date} 无公司行为",
        )

    logger.info(f"yfinance_hk 公司行为: {symbol} {len(records)} 条")
    return pd.DataFrame(records)
