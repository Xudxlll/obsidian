import logging

import pandas as pd

from app.data.sources.base.provider import BaseProvider
from app.data.sources.base.exceptions import DataNotFoundError, DataSourceError

logger = logging.getLogger(__name__)

def _filter_by_date(
    df: pd.DataFrame,
    start_date: str,
    end_date: str,
    date_cols: list[str] | None = None,
) -> pd.DataFrame:

    if df is None or df.empty:
        return df
    if not start_date and not end_date:
        return df

    if date_cols is None:
        date_cols = ["公告日期", "除净日", "date", "trade_date", "日期"]

    sd = start_date.replace("-", "") if start_date else ""
    ed = end_date.replace("-", "") if end_date else ""

    date_col = None
    for col in date_cols:
        if col in df.columns:
            date_col = col
            break
    if date_col is None:
        return df

    def _norm(val) -> str:
        s = str(val)[:10].replace("-", "")
        return s

    normed = df[date_col].apply(_norm)
    mask = pd.Series(True, index=df.index)
    if sd:
        mask &= normed >= sd
    if ed:
        mask &= normed <= ed
    return df[mask].copy()

def _normalize_hk_symbol(symbol: str) -> str:
    return str(symbol).replace(".HK", "").lstrip("0").zfill(5)

class AKShareHKProvider(BaseProvider):

    def __init__(self):
        super().__init__(name="akshare_hk", market="HK")

    async def connect(self) -> bool:
        self.connected = True
        return True

    def is_available(self) -> bool:
        try:
            import akshare as ak

            return True
        except ImportError:
            return False

    async def get_stock_list(self, **kwargs) -> pd.DataFrame:
        try:
            from app.data.sources.hk.akshare_hk.api.basic_info import fetch_stock_list

            return await fetch_stock_list()
        except (DataNotFoundError, DataSourceError) as e:
            logger.debug(f"AKShare-HK 股票列表失败: {e}")
            return None
        except Exception as e:
            logger.error(f"AKShare-HK 股票列表失败: {e}")
            return None

    async def get_daily_quotes(
        self, symbol: str, start_date: str, end_date: str, **kwargs
    ) -> pd.DataFrame:
        try:
            from app.data.sources.hk.akshare_hk.api.daily_quotes import (
                fetch_daily_quotes,
            )

            return await fetch_daily_quotes(symbol, start_date, end_date)
        except (DataNotFoundError, DataSourceError) as e:
            logger.debug(f"AKShare-HK 行情失败 {symbol}: {e}")
            return None
        except Exception as e:
            logger.error(f"AKShare-HK 行情失败 {symbol}: {e}")
            return None

    async def get_corporate_actions(
        self, symbol: str, start_date: str, end_date: str, **kwargs
    ) -> pd.DataFrame:
        try:
            from app.data.sources.hk.akshare_hk.api.corporate_actions import (
                fetch_corporate_actions,
            )

            normalized = _normalize_hk_symbol(symbol)
            df = await fetch_corporate_actions(normalized)
            return _filter_by_date(
                df,
                start_date,
                end_date,
                date_cols=["除净日", "公告日期", "date", "日期"],
            )
        except (DataNotFoundError, DataSourceError) as e:
            logger.debug(f"AKShare-HK 公司行为失败 {symbol}: {e}")
            return None
        except Exception as e:
            logger.debug(f"AKShare-HK 公司行为失败 {symbol}: {e}")
            return None

    async def get_news(
        self, symbol: str, start_date: str, end_date: str, **kwargs
    ) -> pd.DataFrame:
        if not symbol:
            from app.data.sources.cn.akshare.api.news import fetch_market_news

            result = await fetch_market_news(limit=100)
            return pd.DataFrame(result) if result else None
        try:
            from app.data.sources.hk.akshare_hk.api.news import fetch_news

            normalized = _normalize_hk_symbol(symbol)
            df = await fetch_news(normalized)
            return _filter_by_date(
                df,
                start_date,
                end_date,
                date_cols=["公告日期", "除净日", "date", "日期"],
            )
        except (DataNotFoundError, DataSourceError) as e:
            logger.debug(f"AKShare-HK 新闻失败 {symbol}: {e}")
            return None
        except Exception as e:
            logger.debug(f"AKShare-HK 新闻失败 {symbol}: {e}")
            return None

    async def get_market_quotes(self, symbols=None, **kwargs) -> pd.DataFrame:
        df = await self.get_stock_list()
        if df is None or df.empty:
            return df
        if not symbols:
            return df
        normalized_symbols = {_normalize_hk_symbol(s) for s in symbols}
        sym_col = None
        for col in ("symbol", "代码", "股票代码"):
            if col in df.columns:
                sym_col = col
                break
        if sym_col is None:
            return df
        return df[
            df[sym_col].apply(
                lambda v: _normalize_hk_symbol(str(v)) in normalized_symbols
            )
        ].copy()
