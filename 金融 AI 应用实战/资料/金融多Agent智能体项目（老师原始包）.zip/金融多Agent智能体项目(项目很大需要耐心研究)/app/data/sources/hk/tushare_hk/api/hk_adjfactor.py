import logging
from typing import Optional

import pandas as pd

from app.data.sources.tushare_common.caller import call_tushare

logger = logging.getLogger(__name__)

_DOMAIN = "adj_factors"
_SOURCE = "tushare_hk"

def _format_compact(date_str: str) -> str:
    return str(date_str).replace("-", "") if date_str else ""

async def fetch_adj_factors(
    api,
    ts_code: str,
    start_date: str,
    end_date: str,
) -> Optional[pd.DataFrame]:

    return await call_tushare(
        api,
        "hk_adjfactor",
        _SOURCE,
        _DOMAIN,
        ts_code,
        ts_code=ts_code,
        start_date=_format_compact(start_date),
        end_date=_format_compact(end_date),
    )
