import logging
from typing import Optional

import pandas as pd

from app.data.sources.tushare_common.caller import call_tushare

logger = logging.getLogger(__name__)

_DOMAIN = "realtime_quotes"
_SOURCE = "tushare_hk"

async def fetch_realtime_quotes(api) -> Optional[pd.DataFrame]:

    return await call_tushare(api, "rt_hk_k", _SOURCE, _DOMAIN)
