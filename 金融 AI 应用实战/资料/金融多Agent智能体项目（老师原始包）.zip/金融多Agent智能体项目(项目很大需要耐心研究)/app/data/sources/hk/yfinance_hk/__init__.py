from .adapter import YFinanceHKAdapter
from .provider import YFinanceHKProvider

__all__ = ["YFinanceHKAdapter", "YFinanceHKProvider"]

def get_yfinance_hk_adapter():
    return YFinanceHKAdapter()
