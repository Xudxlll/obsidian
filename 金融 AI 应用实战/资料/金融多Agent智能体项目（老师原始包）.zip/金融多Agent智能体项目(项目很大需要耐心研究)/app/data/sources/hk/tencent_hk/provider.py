import logging

import pandas as pd

from app.data.sources.base.exceptions import DataNotFoundError, DataSourceUnavailableError
from app.data.sources.base.provider import BaseProvider

logger = logging.getLogger(__name__)

class TencentHKProvider(BaseProvider):

    def __init__(self):
        super().__init__(name="tencent_hk", market="HK")

    async def connect(self) -> bool:
        self.connected = True
        return True

    def is_available(self) -> bool:
        return True

    async def get_market_quotes(
        self, symbols=None, **kwargs
    ) -> pd.DataFrame:
        from app.data.sources.hk.tencent_hk.api.market_quotes import fetch_market_quotes

        try:
            return await fetch_market_quotes(list(symbols) if symbols else [])
        except DataNotFoundError:
            return None
        except DataSourceUnavailableError as e:
            logger.debug(f"Tencent HK 行情失败: {e}")
            return None
