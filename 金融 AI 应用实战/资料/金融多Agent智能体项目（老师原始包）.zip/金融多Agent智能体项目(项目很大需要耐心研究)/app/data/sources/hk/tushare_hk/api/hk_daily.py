import logging
from typing import Optional

import pandas as pd

from app.data.sources.tushare_common.caller import call_tushare

logger = logging.getLogger(__name__)

_DOMAIN = "daily_quotes"
_SOURCE = "tushare_hk"

def _format_compact(date_str: str) -> str:
    return str(date_str).replace("-", "") if date_str else ""

async def fetch_daily_quotes(
    api,
    ts_code: str,
    start_date: str,
    end_date: str,
) -> Optional[pd.DataFrame]:

    start_str = _format_compact(start_date)
    end_str = _format_compact(end_date)
    return await call_tushare(
        api,
        "hk_daily",
        _SOURCE,
        _DOMAIN,
        f"ts_code={ts_code} {start_str}-{end_str}",
        ts_code=ts_code,
        start_date=start_str,
        end_date=end_str,
    )
