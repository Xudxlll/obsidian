import pandas as pd

from app.data.sources.hk.tushare_hk.api.hk_basic import fetch_stock_list
from app.data.sources.hk.tushare_hk.api.hk_daily import fetch_daily_quotes
from app.data.sources.hk.tushare_hk.api.hk_financials import fetch_financial_data
from app.data.sources.tushare_common.base_provider import TushareBaseProvider

class TushareHKProvider(TushareBaseProvider):

    DOMAIN_ENDPOINTS = {
        "basic_info": "hk_basic",
        "trade_calendar": "hk_tradecal",
        "daily_quotes": "hk_daily",
        "daily_indicators": "hk_daily_adj",
        "adj_factors": "hk_adjfactor",
        "market_quotes": "rt_hk_k",
    }
    FINANCIAL_ENDPOINTS = {
        "income": "hk_income",
        "balance": "hk_balancesheet",
        "cashflow": "hk_cashflow",
        "indicator": "hk_fina_indicator",
    }
    DEFAULT_EXCHANGE = "HKEX"
    TRADE_CAL_OMIT_EXCHANGE = True
    PROBE_ENDPOINT = "hk_basic"
    MIN_CREDITS = 2000

    def __init__(self):
        super().__init__(name="tushare_hk", market="HK")

    async def _resolve_ts_code(self, symbol: str) -> str:
        return self._to_hk_ts_code(symbol)

    @staticmethod
    def _to_hk_ts_code(symbol: str) -> str:
        code = str(symbol).replace(".HK", "").zfill(5)
        return f"{code}.HK"

    async def get_stock_list(self, **kwargs) -> pd.DataFrame:
        return await self._delegate(fetch_stock_list(self._get_api()), "股票列表")

    async def get_daily_quotes(self, symbol: str, start_date: str, end_date: str, **kwargs) -> pd.DataFrame:
        ts_code = await self._resolve_ts_code(symbol)
        return await self._delegate(
            fetch_daily_quotes(self._get_api(), ts_code, start_date, end_date),
            f"行情 {symbol}",
        )

    async def get_financial_data(
        self,
        symbol: str,
        start_date: str,
        end_date: str,
        statement_type: str = "",
        **kwargs,
    ) -> pd.DataFrame:
        ts_code = await self._resolve_ts_code(symbol)
        return await self._delegate(
            fetch_financial_data(
                self._get_api(),
                ts_code,
                statement_type or "income",
                start_date,
                end_date,
            ),
            f"财务 {symbol} ({statement_type or 'income'})",
        )
