import asyncio
import logging
from typing import Optional

import pandas as pd

from app.data.sources.base.exceptions import (
    DataFormatError,
    DataNotFoundError,
    DataSourceUnavailableError,
)
from app.data.sources.base.mappers import is_empty_result, map_network_exception

logger = logging.getLogger(__name__)

_DOMAIN = "daily_quotes"

async def fetch_daily_quotes(
    symbol: str,
    start_date: str,
    end_date: str,
) -> Optional[pd.DataFrame]:

    try:
        import akshare as ak

        normalized = str(symbol).replace(".HK", "").lstrip("0").zfill(5)
        df = await asyncio.to_thread(ak.stock_hk_daily, symbol=normalized, adjust="qfq")
    except (asyncio.TimeoutError, ConnectionError, TimeoutError) as exc:
        raise map_network_exception(exc, "akshare_hk", _DOMAIN)
    except (KeyError, IndexError, AttributeError, ValueError) as exc:
        raise DataFormatError("akshare_hk", _DOMAIN, f"{symbol}: {exc}")
    except Exception as exc:
        raise DataSourceUnavailableError("akshare_hk", _DOMAIN, f"{symbol}: {exc}")

    if is_empty_result(df):
        logger.warning(f"akshare_hk 返回空行情: {symbol}")
        raise DataNotFoundError("akshare_hk", _DOMAIN, f"{symbol} 无行情数据")

    date_col = "日期" if "日期" in df.columns else "date"
    if date_col in df.columns:
        df[date_col] = pd.to_datetime(df[date_col])
        start = pd.to_datetime(start_date)
        end = pd.to_datetime(end_date)
        df = df[(df[date_col] >= start) & (df[date_col] <= end)]
        if df.empty:
            logger.warning(
                f"akshare_hk 日期过滤后无数据: {symbol} {start_date}~{end_date}"
            )
            raise DataNotFoundError(
                "akshare_hk",
                _DOMAIN,
                f"{symbol} 日期范围 {start_date}~{end_date} 无数据",
            )

    logger.info(f"akshare_hk 获取行情: {symbol} {len(df)} 条")
    return df
