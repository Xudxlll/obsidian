import asyncio
import logging
from typing import Optional

from app.data.sources.base.exceptions import (
    DataFormatError,
    DataNotFoundError,
    DataSourceUnavailableError,
)
from app.data.sources.base.mappers import is_empty_result, map_network_exception

logger = logging.getLogger(__name__)

_DOMAIN = "basic_info"

def _to_yfinance_symbol(symbol: str) -> str:
    code = str(symbol).replace(".HK", "").lstrip("0").zfill(4)
    return f"{code}.HK"

async def fetch_basic_info(symbol: str) -> Optional[dict]:

    try:
        import yfinance as yf

        hk_symbol = _to_yfinance_symbol(symbol)

        def _fetch():
            ticker = yf.Ticker(hk_symbol)
            return ticker.info

        info = await asyncio.to_thread(_fetch)
    except (asyncio.TimeoutError, ConnectionError, TimeoutError) as exc:
        raise map_network_exception(exc, "yfinance_hk", _DOMAIN)
    except (KeyError, IndexError, AttributeError, ValueError) as exc:
        raise DataFormatError("yfinance_hk", _DOMAIN, f"{symbol}: {exc}")
    except Exception as exc:
        raise DataSourceUnavailableError("yfinance_hk", _DOMAIN, f"{symbol}: {exc}")

    if is_empty_result(info):
        logger.warning(f"yfinance_hk 基础信息返回空: {symbol}")
        raise DataNotFoundError("yfinance_hk", _DOMAIN, f"{symbol} 无基础信息")

    logger.info(f"yfinance_hk 基础信息: {symbol}")
    return info
