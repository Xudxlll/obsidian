import asyncio
import logging
from typing import Optional

import pandas as pd

from app.data.sources.base.exceptions import (
    DataFormatError,
    DataNotFoundError,
    DataSourceUnavailableError,
)
from app.data.sources.base.mappers import is_empty_result, map_network_exception

logger = logging.getLogger(__name__)

_DOMAIN = "financial_data"

def _to_yfinance_symbol(symbol: str) -> str:
    code = str(symbol).replace(".HK", "").lstrip("0").zfill(4)
    return f"{code}.HK"

async def fetch_financial_data(
    symbol: str,
    statement_type: str = "income",
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
) -> Optional[pd.DataFrame]:

    try:
        import yfinance as yf

        hk_symbol = _to_yfinance_symbol(symbol)

        def _fetch():
            ticker = yf.Ticker(hk_symbol)
            return ticker.financials

        df = await asyncio.to_thread(_fetch)
    except (asyncio.TimeoutError, ConnectionError, TimeoutError) as exc:
        raise map_network_exception(exc, "yfinance_hk", _DOMAIN)
    except (KeyError, IndexError, AttributeError, ValueError) as exc:
        raise DataFormatError("yfinance_hk", _DOMAIN, f"{symbol}: {exc}")
    except Exception as exc:
        raise DataSourceUnavailableError("yfinance_hk", _DOMAIN, f"{symbol}: {exc}")

    if is_empty_result(df):
        logger.warning(f"yfinance_hk 返回空财务数据: {symbol}")
        raise DataNotFoundError("yfinance_hk", _DOMAIN, f"{symbol} 无财务数据")

    if start_date and end_date:
        try:
            cols = pd.to_datetime(df.columns)
            mask = (cols >= pd.to_datetime(start_date)) & (
                cols <= pd.to_datetime(end_date)
            )
            df = df.loc[:, mask]
            if df.empty:
                logger.warning(
                    f"yfinance_hk 日期过滤后无财务数据: {symbol} "
                    f"{start_date}~{end_date}"
                )
                raise DataNotFoundError(
                    "yfinance_hk",
                    _DOMAIN,
                    f"{symbol} 日期范围 {start_date}~{end_date} 无财务数据",
                )
        except DataNotFoundError:
            raise
        except Exception as exc:
            raise DataFormatError("yfinance_hk", _DOMAIN, f"{symbol}: {exc}")

    df.attrs["symbol"] = str(symbol).replace(".HK", "").lstrip("0").zfill(5)
    df.attrs["statement_type"] = statement_type
    logger.info(f"yfinance_hk 获取财务数据: {symbol} {len(df.columns)} 期")
    return df
