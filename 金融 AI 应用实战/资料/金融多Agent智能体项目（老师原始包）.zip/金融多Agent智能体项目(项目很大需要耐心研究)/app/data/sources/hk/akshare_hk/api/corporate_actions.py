import asyncio
import logging
from typing import Optional

import pandas as pd

from app.data.sources.base.exceptions import (
    DataFormatError,
    DataNotFoundError,
    DataSourceUnavailableError,
)
from app.data.sources.base.mappers import is_empty_result, map_network_exception

logger = logging.getLogger(__name__)

_DOMAIN = "corporate_actions"

async def fetch_corporate_actions(symbol: str) -> Optional[pd.DataFrame]:

    try:
        import akshare as ak

        normalized = str(symbol).replace(".HK", "").lstrip("0").zfill(5)
        df = await asyncio.to_thread(ak.stock_hk_dividend_payout_em, symbol=normalized)
    except (asyncio.TimeoutError, ConnectionError, TimeoutError) as exc:
        raise map_network_exception(exc, "akshare_hk", _DOMAIN)
    except (KeyError, IndexError, AttributeError, ValueError) as exc:
        raise DataFormatError("akshare_hk", _DOMAIN, f"{symbol}: {exc}")
    except Exception as exc:
        raise DataSourceUnavailableError("akshare_hk", _DOMAIN, f"{symbol}: {exc}")

    if is_empty_result(df):
        logger.warning(f"akshare_hk 公司行为返回空: {symbol}")
        raise DataNotFoundError("akshare_hk", _DOMAIN, f"{symbol} 无公司行为数据")

    logger.info(f"akshare_hk 公司行为: {symbol} {len(df)} 条")
    return df
