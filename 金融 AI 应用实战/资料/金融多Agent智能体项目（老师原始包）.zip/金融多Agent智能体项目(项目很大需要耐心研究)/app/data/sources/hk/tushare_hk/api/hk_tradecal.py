import logging
from typing import Optional

import pandas as pd

from app.data.sources.tushare_common.caller import call_tushare

logger = logging.getLogger(__name__)

_DOMAIN = "trade_calendar"
_SOURCE = "tushare_hk"

def _format_compact(date_str: str) -> str:
    return str(date_str).replace("-", "") if date_str else ""

async def fetch_trade_calendar(
    api,
    exchange: str = "HKEX",
    start_date: str = None,
    end_date: str = None,
) -> Optional[pd.DataFrame]:

    params: dict = {}
    if start_date:
        params["start_date"] = _format_compact(start_date)
    if end_date:
        params["end_date"] = _format_compact(end_date)
    return await call_tushare(api, "hk_tradecal", _SOURCE, _DOMAIN, exchange, **params)
