import logging
from typing import Optional

import pandas as pd

from app.data.sources.tushare_common.caller import call_tushare

logger = logging.getLogger(__name__)

_DOMAIN = "southbound_holding"
_SOURCE = "tushare_hk"

def _format_compact(date_str: str) -> str:
    return str(date_str).replace("-", "") if date_str else ""

async def fetch_southbound_holdings(
    api,
    ts_code: str = None,
    start_date: str = None,
    end_date: str = None,
) -> Optional[pd.DataFrame]:

    params: dict = {}
    if ts_code:
        params["ts_code"] = ts_code
    if start_date:
        params["start_date"] = _format_compact(start_date)
    if end_date:
        params["end_date"] = _format_compact(end_date)
    return await call_tushare(
        api, "hk_hold", _SOURCE, _DOMAIN, ts_code or "全市场", **params
    )
