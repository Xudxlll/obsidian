import logging
from typing import Optional

import pandas as pd

from app.data.sources.base.exceptions import DataNotFoundError

logger = logging.getLogger(__name__)

_DOMAIN = "daily_indicators"

async def fetch_daily_indicators(symbol: str) -> Optional[pd.DataFrame]:

    logger.debug(f"yfinance_hk 每日指标暂不支持: {symbol}")
    raise DataNotFoundError("yfinance_hk", _DOMAIN, f"{symbol} 接口未实现")
