import logging
from typing import Optional

import pandas as pd

from app.data.sources.tushare_common.caller import call_tushare

logger = logging.getLogger(__name__)

_DOMAIN = "fina_indicator"
_SOURCE = "tushare_hk"

async def fetch_fina_indicator(
    api,
    ts_code: str,
) -> Optional[pd.DataFrame]:

    return await call_tushare(
        api, "hk_fina_indicator", _SOURCE, _DOMAIN, ts_code, ts_code=ts_code
    )
