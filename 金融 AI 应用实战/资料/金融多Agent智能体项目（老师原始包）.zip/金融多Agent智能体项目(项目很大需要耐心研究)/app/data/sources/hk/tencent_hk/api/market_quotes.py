import asyncio
import logging
import socket
import urllib.error
import urllib.request
from typing import List, Optional

import pandas as pd

from app.data.sources.base.exceptions import (
    DataFormatError,
    DataNotFoundError,
    DataSourceUnavailableError,
)
from app.data.sources.base.mappers import map_network_exception

logger = logging.getLogger(__name__)

_DOMAIN = "market_quotes"

TENCENT_QUOTE_HOST = "https://qt.gtimg.cn"

async def fetch_market_quotes(symbols: List[str]) -> Optional[pd.DataFrame]:

    if not symbols:
        return None

    try:
        codes = ",".join([f"r_hk{str(s).zfill(5)}" for s in symbols])
        url = f"{TENCENT_QUOTE_HOST}/q={codes}"

        def _fetch():
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                return resp.read().decode("gbk")

        text = await asyncio.to_thread(_fetch)
    except (
        asyncio.TimeoutError,
        ConnectionError,
        TimeoutError,
        urllib.error.URLError,
        socket.timeout,
    ) as exc:
        raise map_network_exception(exc, "tencent_hk", _DOMAIN)
    except Exception as exc:
        raise DataSourceUnavailableError("tencent_hk", _DOMAIN, str(exc))

    records = []
    candidates = 0

    for line in text.strip().split(";"):
        line = line.strip()
        if not line or "~" not in line:
            continue
        parts = line.split("~")
        if len(parts) < 50:
            continue
        candidates += 1
        try:
            records.append({
                "symbol": parts[2] if len(parts) > 2 else "",
                "name": parts[1] if len(parts) > 1 else "",
                "price": float(parts[3]) if parts[3] else None,
                "last_close": float(parts[4]) if parts[4] else None,
                "open": float(parts[5]) if parts[5] else None,
                "volume": float(parts[6]) if parts[6] else None,
                "high": float(parts[33]) if len(parts) > 33 and parts[33] else None,
                "low": float(parts[34]) if len(parts) > 34 and parts[34] else None,
                "bid": float(parts[9]) if len(parts) > 9 and parts[9] else None,
                "ask": float(parts[10]) if len(parts) > 10 and parts[10] else None,
                "update_time": parts[30] if len(parts) > 30 else "",
            })
        except (ValueError, IndexError) as exc:
            logger.debug(f"tencent_hk 行情单行解析失败: {exc}")
            continue

    if candidates > 0 and not records:
        raise DataFormatError(
            "tencent_hk",
            _DOMAIN,
            f"无法解析任何行情记录，候选 {candidates} 行",
        )

    if not records:
        logger.warning(f"tencent_hk 行情无数据: {len(symbols)} 只")
        raise DataNotFoundError(
            "tencent_hk", _DOMAIN, f"symbols={symbols} 无数据"
        )

    logger.info(f"tencent_hk 行情: {len(records)} 只")
    return pd.DataFrame(records)
