import asyncio
import logging
from typing import Optional

import pandas as pd

from app.data.sources.base.exceptions import (
    DataFormatError,
    DataNotFoundError,
    DataSourceUnavailableError,
)
from app.data.sources.base.mappers import is_empty_result, map_network_exception

logger = logging.getLogger(__name__)

_DOMAIN = "basic_info"

async def fetch_stock_list() -> Optional[pd.DataFrame]:

    try:
        import akshare as ak

        df = await asyncio.to_thread(ak.stock_hk_spot_em)
    except (asyncio.TimeoutError, ConnectionError, TimeoutError) as exc:
        raise map_network_exception(exc, "akshare_hk", _DOMAIN)
    except (KeyError, IndexError, AttributeError, ValueError) as exc:
        raise DataFormatError("akshare_hk", _DOMAIN, str(exc))
    except Exception as exc:
        raise DataSourceUnavailableError("akshare_hk", _DOMAIN, str(exc))

    if is_empty_result(df):
        logger.warning("akshare_hk 股票列表返回空数据")
        raise DataNotFoundError("akshare_hk", _DOMAIN, "港股列表无数据")

    logger.info(f"akshare_hk 获取股票列表: {len(df)} 只")
    return df
