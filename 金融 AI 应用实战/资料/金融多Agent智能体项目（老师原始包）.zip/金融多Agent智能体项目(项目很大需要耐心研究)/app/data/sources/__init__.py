def get_adapter(market: str, source_name: str):

    if market == "CN":
        from .cn import get_cn_adapter
        return get_cn_adapter(source_name)
    elif market == "HK":
        from .hk import get_hk_adapter
        return get_hk_adapter(source_name)
    elif market == "US":
        from .us import get_us_adapter
        return get_us_adapter(source_name)
    else:
        raise ValueError(f"不支持的市场: {market}")
