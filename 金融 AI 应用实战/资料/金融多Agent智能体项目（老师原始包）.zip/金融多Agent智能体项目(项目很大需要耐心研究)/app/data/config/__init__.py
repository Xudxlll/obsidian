import os
import functools
from typing import Any, Dict

import yaml

_CONFIG_DIR = os.path.dirname(os.path.abspath(__file__))

@functools.lru_cache(maxsize=16)
def load_yaml(filename: str) -> Dict[str, Any]:

    filepath = os.path.join(_CONFIG_DIR, filename)
    if not os.path.exists(filepath):
        return {}
    with open(filepath, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

def get_enabled_sources(market: str) -> list:
    matrix = load_yaml("capability_matrix.yaml")
    market_data = matrix.get(market, {})
    sources = set()
    for _domain, src_map in market_data.items():
        for src, level in src_map.items():
            if level and level != "none":
                sources.add(src)
    return sorted(sources)
