import logging
from typing import Optional

from app.data.storage.mongo.repositories.metadata_repo import MetadataRepo

logger = logging.getLogger(__name__)

class CheckpointManager:

    def __init__(self):
        self._repo = MetadataRepo()

    async def get_checkpoint(self, market: str, domain: str, source: str) -> Optional[str]:
        cp = await self._repo.get_checkpoint(market, domain, source)
        return cp.get("last_sync_date") if cp else None

    async def get_checkpoint_doc(self, market: str, domain: str, source: str) -> Optional[dict]:

        return await self._repo.get_checkpoint(market, domain, source)

    async def update_checkpoint(
        self, market: str, domain: str, source: str, date: str, count: int
    ) -> None:
        await self._repo.update_checkpoint(market, domain, source, date, count)

    async def reset_checkpoint(self, market: str, domain: str, source: str) -> None:
        await self._repo.update_checkpoint(market, domain, source, "1970-01-01", 0)
