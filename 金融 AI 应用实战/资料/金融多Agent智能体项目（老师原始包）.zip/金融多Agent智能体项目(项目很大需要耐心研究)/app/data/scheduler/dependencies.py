import logging
from typing import Dict, List, Set

logger = logging.getLogger(__name__)

class DependencyGraph:

    def __init__(self):
        self._deps: Dict[str, Set[str]] = {}

    def add_dependency(self, domain: str, depends_on: str) -> None:
        if domain not in self._deps:
            self._deps[domain] = set()
        self._deps[domain].add(depends_on)

    def get_execution_order(self, domains: List[str]) -> List[List[str]]:

        remaining = set(domains)
        result = []
        completed = set()

        while remaining:
            ready = []
            for d in remaining:
                deps = self._deps.get(d, set())
                if not deps or all(dep in completed or dep not in remaining for dep in deps):
                    ready.append(d)

            if not ready:
                ready = list(remaining)

            result.append(ready)
            completed.update(ready)
            remaining -= set(ready)

        return result
