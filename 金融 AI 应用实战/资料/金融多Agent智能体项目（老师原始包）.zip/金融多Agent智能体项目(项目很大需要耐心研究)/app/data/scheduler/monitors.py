import asyncio
import logging
import threading
import time
from collections import defaultdict
from datetime import datetime, timezone
from typing import Dict, List, Optional

from apscheduler.schedulers.asyncio import AsyncIOScheduler

logger = logging.getLogger(__name__)

class SchedulerMonitor:

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        self._running_tasks: Dict[str, Dict] = {}
        self._timeout_warned_at: Dict[str, float] = {}
        self._task_stats: Dict[str, Dict] = defaultdict(
            lambda: {
                "total_runs": 0,
                "success_count": 0,
                "failure_count": 0,
                "total_latency_ms": 0,
                "last_run_at": None,
                "last_status": None,
            }
        )
        self._dict_lock = threading.Lock()
        self._timeout_threshold_seconds = 3600
        self._staleness_threshold_seconds = 86400 * 3
        self._scheduler: Optional[AsyncIOScheduler] = None
        self._monitor_thread: Optional[threading.Thread] = None
        self._running = False
        self._monitor_interval = 60
        self._stale_check_interval = 60
        self._loop_count = 0
        self._main_loop: Optional[asyncio.AbstractEventLoop] = None

    def start(self, scheduler: AsyncIOScheduler) -> None:
        self._scheduler = scheduler
        try:
            self._main_loop = asyncio.get_running_loop()
        except RuntimeError:
            try:
                self._main_loop = asyncio.get_event_loop()
            except RuntimeError:
                self._main_loop = None
        self._running = True
        self._monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._monitor_thread.start()
        logger.info("调度监控已启动")

    def stop(self) -> None:
        self._running = False
        if self._monitor_thread:
            self._monitor_thread.join(timeout=5)

    def on_task_start(self, market: str, domain: str) -> None:
        task_id = f"{market}:{domain}"
        with self._dict_lock:
            self._running_tasks[task_id] = {
                "market": market,
                "domain": domain,
                "started_at": time.time(),
                "started_at_iso": datetime.now(timezone.utc).isoformat(),
            }

    def on_task_complete(
        self, market: str, domain: str, success: bool, latency_ms: int = 0
    ) -> None:
        task_id = f"{market}:{domain}"
        with self._dict_lock:
            self._running_tasks.pop(task_id, None)
            self._timeout_warned_at.pop(task_id, None)

            stats = self._task_stats[task_id]
            stats["total_runs"] += 1
            stats["total_latency_ms"] += latency_ms
            stats["last_run_at"] = datetime.now(timezone.utc).isoformat()
            stats["last_status"] = "success" if success else "failure"

            if success:
                stats["success_count"] += 1
            else:
                stats["failure_count"] += 1

    def get_task_stats(self, market: Optional[str] = None) -> List[Dict]:
        results = []
        with self._dict_lock:
            snapshot = list(self._task_stats.items())
        for task_id, stats in snapshot:
            if market and not task_id.startswith(f"{market}:"):
                continue
            total = stats["total_runs"]
            avg_latency = stats["total_latency_ms"] / total if total > 0 else 0
            results.append(
                {
                    "task_id": task_id,
                    "total_runs": total,
                    "success_count": stats["success_count"],
                    "failure_count": stats["failure_count"],
                    "success_rate": round(stats["success_count"] / total, 4)
                    if total > 0
                    else 0,
                    "avg_latency_ms": round(avg_latency, 1),
                    "last_run_at": stats["last_run_at"],
                    "last_status": stats["last_status"],
                }
            )
        return results

    def get_running_tasks(self) -> List[Dict]:
        now = time.time()
        results = []
        with self._dict_lock:
            snapshot = list(self._running_tasks.items())
        for task_id, info in snapshot:
            elapsed = int((now - info["started_at"]) * 1000)
            results.append(
                {
                    "task_id": task_id,
                    "market": info["market"],
                    "domain": info["domain"],
                    "started_at": info["started_at_iso"],
                    "elapsed_ms": elapsed,
                    "is_timeout": elapsed > self._timeout_threshold_seconds * 1000,
                }
            )
        return results

    def check_stale_tasks(self) -> None:

        from app.data.scheduler.checkpoint import CheckpointManager

        async def _check():
            try:
                results = []
                checkpoint = CheckpointManager()
                with self._dict_lock:
                    task_snapshot = list(self._task_stats.items())
                for task_id, stats in task_snapshot:
                    parts = task_id.split(":")
                    if len(parts) != 2:
                        continue
                    market, domain = parts
                    cp = await checkpoint.get_checkpoint_doc(market, domain, "scheduled")
                    if cp:
                        from datetime import datetime as _dt

                        try:
                            last_sync = _dt.fromisoformat(cp.get("last_sync_time", ""))
                            if last_sync.tzinfo is None:
                                last_sync = last_sync.replace(tzinfo=timezone.utc)
                            age = (_dt.now(timezone.utc) - last_sync).total_seconds()
                            if age > self._staleness_threshold_seconds:
                                results.append(
                                    {
                                        "task_id": task_id,
                                        "market": market,
                                        "domain": domain,
                                        "last_sync_time": str(last_sync),
                                        "staleness_hours": round(age / 3600, 1),
                                    }
                                )
                        except (ValueError, TypeError) as parse_err:
                            logger.debug(
                                "跳过检查点 %s:%s 的时间解析: %s",
                                market, domain, parse_err,
                            )
                for t in results:
                    logger.warning(
                        "检测到卡住的任务: %s, 已停滞 %s 小时",
                        t["task_id"], t["staleness_hours"],
                    )
            except Exception as e:
                logger.debug(f"卡住任务检测失败: {e}")

        from app.core.async_utils import run_async_fire_and_forget

        run_async_fire_and_forget(_check())

    def _monitor_loop(self) -> None:
        while self._running:
            time.sleep(self._monitor_interval)
            self._loop_count += 1
            try:
                self._check_timeouts()
                if self._loop_count % self._stale_check_interval == 0:
                    self.check_stale_tasks()
            except Exception as e:
                logger.error(f"监控循环异常: {e}")

    def _check_timeouts(self) -> None:
        now = time.time()
        with self._dict_lock:
            snapshot = list(self._running_tasks.items())
        for task_id, info in snapshot:
            elapsed = now - info["started_at"]
            if elapsed > self._timeout_threshold_seconds:
                last_warn = self._timeout_warned_at.get(task_id, 0.0)
                if now - last_warn >= 600:
                    self._timeout_warned_at[task_id] = now
                    logger.warning(f"任务超时: {task_id}, 已运行 {int(elapsed / 60)} 分钟")
                self._record_timeout_event(info, elapsed)

    def _record_timeout_event(self, info: Dict, elapsed: float) -> None:

        from app.data.storage.mongo.repositories.metadata_repo import MetadataRepo

        async def _record():
            try:
                repo = MetadataRepo()
                await repo.insert_event(
                    {
                        "event_type": "TASK_TIMEOUT",
                        "market": info["market"],
                        "domain": info["domain"],
                        "elapsed_seconds": int(elapsed),
                        "started_at": info["started_at_iso"],
                    }
                )
            except Exception as e:
                logger.debug(f"超时事件记录失败: {e}")

        from app.core.async_utils import run_async_fire_and_forget

        run_async_fire_and_forget(_record())
