import hashlib
import logging
import threading
import time
import uuid
from collections import defaultdict
from typing import Dict, Tuple

logger = logging.getLogger(__name__)

_memory_counters: Dict[str, list] = defaultdict(list)
_memory_counters_lock = threading.Lock()
_token_hash_map: Dict[str, list] = defaultdict(list)

_LUA_TRY_INCREMENT = """
local key = KEYS[1]
local now = tonumber(ARGV[1])
local cutoff = tonumber(ARGV[2])
local member = ARGV[3]
local limit = tonumber(ARGV[4])
local expire = tonumber(ARGV[5])

redis.call('ZREMRANGEBYSCORE', key, 0, cutoff)
local count = redis.call('ZCARD', key)
if count >= limit then
    -- 已超配额：不写入，告知调用方等待 60 秒（与默认窗口对齐）
    return {0, 60}
end
redis.call('ZADD', key, now, member)
redis.call('EXPIRE', key, expire)
return {1, 0}
"""

class SlidingWindowCounter:

    def __init__(self, window_seconds: int = 60):
        self.window_seconds = window_seconds

    async def increment(self, key: str) -> int:
        now = time.time()
        cutoff = now - self.window_seconds

        try:
            redis = None
            try:
                from app.data.storage.redis.client import get_redis
                redis = get_redis()
            except Exception as e:
                logger.debug(f"获取 Redis 连接失败: {e}")

            if redis:
                pipe = redis.pipeline()
                pipe.zadd(key, {str(now): now})
                pipe.zremrangebyscore(key, 0, cutoff)
                pipe.zcard(key)
                pipe.expire(key, self.window_seconds * 2)
                results = await pipe.execute()
                return results[2]
        except Exception as e:
            logger.debug(f"Redis 计数器失败，降级内存: {e}")

        with _memory_counters_lock:
            _memory_counters[key] = [t for t in _memory_counters[key] if t > cutoff]
            _memory_counters[key].append(now)
            return len(_memory_counters[key])

    async def get_count(self, key: str) -> int:

        now = time.time()
        cutoff = now - self.window_seconds

        try:
            redis = None
            try:
                from app.data.storage.redis.client import get_redis
                redis = get_redis()
            except Exception as e:
                logger.debug(f"获取 Redis 连接失败: {e}")

            if redis:
                pipe = redis.pipeline()
                pipe.zremrangebyscore(key, 0, cutoff)
                pipe.zcard(key)
                pipe.expire(key, self.window_seconds * 2)
                results = await pipe.execute()
                return results[1]
        except Exception as e:
            logger.debug(f"Redis 计数器查询失败，降级内存: {e}")

        with _memory_counters_lock:
            _memory_counters[key] = [t for t in _memory_counters[key] if t > cutoff]
            return len(_memory_counters[key])

    async def try_increment(
        self, key: str, limit: int
    ) -> Tuple[bool, float]:

        now = time.time()
        cutoff = now - self.window_seconds
        member = f"{now:.6f}_{uuid.uuid4().hex}"

        try:
            redis = None
            try:
                from app.data.storage.redis.client import get_redis
                redis = get_redis()
            except Exception as e:
                logger.debug(f"获取 Redis 连接失败: {e}")

            if redis:
                result = await redis.eval(
                    _LUA_TRY_INCREMENT,
                    1,
                    key,
                    str(now),
                    str(cutoff),
                    member,
                    int(limit),
                    self.window_seconds * 2,
                )
                def _coerce(v):
                    if isinstance(v, bytes):
                        return v.decode("utf-8", errors="replace")
                    return v
                if isinstance(result, (list, tuple)):
                    allowed = bool(int(_coerce(result[0])))
                    retry = float(_coerce(result[1]) or 0)
                else:
                    allowed = bool(int(_coerce(result)))
                    retry = 0.0
                return allowed, retry
        except Exception as e:
            logger.debug(f"Redis try_increment 失败，降级内存: {e}")

        with _memory_counters_lock:
            _memory_counters[key] = [t for t in _memory_counters[key] if t > cutoff]
            current_list = _memory_counters[key]
            if len(current_list) >= limit:
                if current_list:
                    wait = current_list[0] + self.window_seconds - now
                else:
                    wait = 0.0
                return False, max(0.1, wait)
            current_list.append(now)
            return True, 0.0

    async def try_decrement(self, key: str) -> bool:

        now = time.time()
        cutoff = now - self.window_seconds

        try:
            redis = None
            try:
                from app.data.storage.redis.client import get_redis
                redis = get_redis()
            except Exception as e:
                logger.debug(f"获取 Redis 连接失败: {e}")

            if redis:
                removed = await redis.zpopmin(key, count=1)
                return bool(removed)
        except Exception as e:
            logger.debug(f"Redis try_decrement 失败，降级内存: {e}")

        with _memory_counters_lock:
            _memory_counters[key] = [t for t in _memory_counters[key] if t > cutoff]
            if not _memory_counters[key]:
                return False
            _memory_counters[key].pop()
            return True

class RateLimiterQuota:

    @staticmethod
    def register_token(source: str, token: str) -> str:
        token_hash = hashlib.sha256(token.encode()).hexdigest()[:8]
        _token_hash_map[token_hash].append(source)
        return token_hash

    @staticmethod
    def get_sources_by_token_hash(token_hash: str) -> list:
        return _token_hash_map.get(token_hash, [])

    @staticmethod
    def clear():
        _token_hash_map.clear()
