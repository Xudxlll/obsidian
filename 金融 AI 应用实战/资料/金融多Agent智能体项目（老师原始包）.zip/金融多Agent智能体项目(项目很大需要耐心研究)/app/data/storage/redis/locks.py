import asyncio
import logging
import uuid
from collections import OrderedDict
from typing import Optional

logger = logging.getLogger(__name__)

_MEMORY_LOCK_MAX_ENTRIES = 1000
_MEMORY_LOCK_EVICT_BATCH = 100
_async_memory_locks: "OrderedDict[str, asyncio.Lock]" = OrderedDict()
_memory_lock_owners: dict = {}
_memory_lock_timers: dict = {}

def _evict_memory_locks_if_full() -> None:

    scanned = 0
    while (
        len(_async_memory_locks) > _MEMORY_LOCK_MAX_ENTRIES
        and scanned < _MEMORY_LOCK_EVICT_BATCH
    ):
        scanned += 1
        try:
            key, lock = next(iter(_async_memory_locks.items()))
        except StopIteration:
            return
        if not lock.locked():
            _async_memory_locks.pop(key, None)
            _memory_lock_owners.pop(key, None)
            timer = _memory_lock_timers.pop(key, None)
            if timer is not None:
                try:
                    timer.cancel()
                except Exception:
                    pass
        else:
            _async_memory_locks.move_to_end(key)
            if all(lk.locked() for lk in _async_memory_locks.values()):
                return

class DistributedLock:

    def __init__(self, lock_key: str, ttl: int = 30):
        self.lock_key = lock_key
        self.ttl = ttl
        self.owner_id = str(uuid.uuid4())
        self._redis_lock = None
        self._timer_handle: Optional[asyncio.TimerHandle] = None

    async def acquire(self) -> bool:
        try:
            from app.data.storage.redis.client import get_redis
            redis = None
            try:
                redis = get_redis()
            except Exception as e:
                logger.debug(f"获取 Redis 连接失败: {e}")

            if redis:
                result = await redis.set(
                    self.lock_key, self.owner_id, nx=True, ex=self.ttl
                )
                return result is not None
        except Exception as e:
            logger.debug(f"Redis 锁获取失败，降级内存锁: {e}")

        _evict_memory_locks_if_full()
        lock_obj = _async_memory_locks.setdefault(self.lock_key, asyncio.Lock())
        _async_memory_locks.move_to_end(self.lock_key)

        try:
            await asyncio.wait_for(
                lock_obj.acquire(),
                timeout=0.1,
            )
            _memory_lock_owners[self.lock_key] = self.owner_id
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                loop = asyncio.get_event_loop()
            def _ttl_release(owner_id: str = self.owner_id) -> None:
                lock_obj = _async_memory_locks.get(self.lock_key)
                current_owner = _memory_lock_owners.get(self.lock_key)
                if (
                    lock_obj is not None
                    and lock_obj.locked()
                    and current_owner == owner_id
                ):
                    try:
                        lock_obj.release()
                    except RuntimeError:
                        pass
                    _memory_lock_owners.pop(self.lock_key, None)
                    _async_memory_locks.pop(self.lock_key, None)
                _memory_lock_timers.pop(self.lock_key, None)
            self._timer_handle = loop.call_later(self.ttl, _ttl_release)
            _memory_lock_timers[self.lock_key] = self._timer_handle
            return True
        except asyncio.TimeoutError:
            return False

    async def release(self) -> None:
        if self._timer_handle is not None:
            try:
                self._timer_handle.cancel()
            except Exception:
                pass
            self._timer_handle = None
            _memory_lock_timers.pop(self.lock_key, None)

        try:
            from app.data.storage.redis.client import get_redis
            redis = None
            try:
                redis = get_redis()
            except Exception as e:
                logger.debug(f"获取 Redis 连接失败: {e}")

            if redis:
                lua = "if redis.call('get',KEYS[1]) == ARGV[1] then return redis.call('del',KEYS[1]) else return 0 end"
                await redis.eval(lua, 1, self.lock_key, self.owner_id)
                return
        except Exception as e:
            logger.debug(f"Redis 锁释放失败: {e}")

        lock_obj = _async_memory_locks.get(self.lock_key)
        if lock_obj is not None and _memory_lock_owners.get(self.lock_key) == self.owner_id:
            try:
                lock_obj.release()
            except RuntimeError:
                pass
            _memory_lock_owners.pop(self.lock_key, None)
            _async_memory_locks.pop(self.lock_key, None)
        else:
            logger.warning(
                "DistributedLock.release: owner 不匹配，跳过释放 key=%s "
                "expected=%s current=%s",
                self.lock_key,
                self.owner_id,
                _memory_lock_owners.get(self.lock_key),
            )

    async def acquire_with_wait(self, max_wait: int = 30) -> bool:
        delay = 0.1
        elapsed = 0.0
        while elapsed < max_wait:
            if await self.acquire():
                return True
            await asyncio.sleep(delay)
            elapsed += delay
            delay = min(delay * 1.5, 2.0)
        return False
