_redis_client = None

def get_redis():

    global _redis_client
    if _redis_client is None:
        try:
            from app.core.database import get_redis_client
            _redis_client = get_redis_client()
        except RuntimeError:
            return None
    return _redis_client

def reset_client():
    global _redis_client
    _redis_client = None
