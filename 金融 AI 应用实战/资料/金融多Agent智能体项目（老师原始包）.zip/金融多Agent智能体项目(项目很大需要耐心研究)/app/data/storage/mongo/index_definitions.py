from typing import Dict, List, Tuple

INDEX_DEFINITIONS: Dict[str, List[Tuple[List[tuple], bool]]] = {
    "basic_info": [
        ([("symbol", 1)], True),
        ([("data_source", 1)], False),
        ([("updated_at", -1)], False),
    ],
    "trade_calendar": [
        ([("exchange", 1), ("cal_date", 1)], True),
        ([("cal_date", 1)], False),
    ],
    "daily_quotes": [
        ([("symbol", 1), ("trade_date", -1), ("period", 1)], True),
        ([("trade_date", -1)], False),
    ],
    "daily_indicators": [
        ([("symbol", 1), ("trade_date", -1)], True),
        ([("trade_date", -1)], False),
    ],
    "adj_factors": [
        ([("symbol", 1), ("trade_date", -1)], True),
    ],
    "corporate_actions": [
        ([("symbol", 1), ("ex_date", -1), ("action_type", 1)], True),
        ([("ex_date", -1)], False),
    ],
    "financial_data": [
        ([("symbol", 1), ("report_period", -1), ("statement_type", 1)], True),
        ([("symbol", 1), ("announce_date", -1)], False),
        ([("report_period", -1)], False),
    ],
    "market_quotes": [
        ([("symbol", 1)], True),
        ([("updated_at", -1)], False),
    ],
    "news": [
        ([("content_hash", 1)], True),
        ([("symbol", 1), ("pub_date", -1)], False),
    ],
    "connect_status": [
        ([("symbol", 1), ("trade_date", -1)], True),
    ],
    "southbound_holding": [
        ([("symbol", 1), ("trade_date", -1)], True),
    ],
    "pre_post_market": [
        ([("symbol", 1), ("trade_date", -1), ("session_type", 1)], True),
    ],
    "intraday_quotes": [
        ([("symbol", 1), ("datetime", -1), ("freq", 1)], True),
        ([("datetime", -1)], False),
    ],
    "money_flow": [
        ([("symbol", 1), ("trade_date", -1)], True),
    ],
    "margin_trading": [
        ([("symbol", 1), ("trade_date", -1)], True),
    ],
    "dragon_tiger": [
        ([("symbol", 1), ("trade_date", -1), ("reason", 1)], True),
        ([("trade_date", -1)], False),
    ],
    "block_trade": [
        ([("symbol", 1), ("trade_date", -1), ("buyer", 1), ("seller", 1)], True),
        ([("trade_date", -1)], False),
    ],
    "tushare_universe": [
        ([("symbol", 1), ("trade_date", -1)], True),
    ],
    "sync_checkpoints": [
        ([("market", 1), ("domain", 1), ("source", 1)], True),
        ([("last_sync_time", -1)], False),
    ],
    "sync_events": [
        ([("market", 1), ("created_at", -1)], False),
        ([("event_type", 1)], False),
        ([("domain", 1), ("timestamp", -1)], False),
    ],
    "source_health": [
        ([("market", 1), ("source", 1), ("domain", 1)], True),
        ([("updated_at", -1)], False),
    ],
    "system_configs": [
        ([("version", -1)], False),
        ([("is_active", 1)], False),
    ],
    "system_secrets": [
        ([("name", 1)], True),
    ],
}

_LEGACY_UNIQUE_WITH_SOURCE: Dict[str, List[tuple]] = {
    "daily_quotes": [("symbol", 1), ("trade_date", -1), ("period", 1), ("data_source", 1)],
    "daily_indicators": [("symbol", 1), ("trade_date", -1), ("data_source", 1)],
    "adj_factors": [("symbol", 1), ("trade_date", -1), ("data_source", 1)],
    "corporate_actions": [
        ("symbol", 1), ("ex_date", -1), ("action_type", 1), ("data_source", 1),
    ],
    "financial_data": [
        ("symbol", 1), ("report_period", -1), ("statement_type", 1), ("data_source", 1),
    ],
    "connect_status": [("symbol", 1), ("trade_date", -1), ("data_source", 1)],
    "southbound_holding": [("symbol", 1), ("trade_date", -1), ("data_source", 1)],
    "pre_post_market": [
        ("symbol", 1), ("trade_date", -1), ("session_type", 1), ("data_source", 1),
    ],
    "intraday_quotes": [("symbol", 1), ("datetime", -1), ("freq", 1), ("data_source", 1)],
    "money_flow": [("symbol", 1), ("trade_date", -1), ("data_source", 1)],
    "margin_trading": [("symbol", 1), ("trade_date", -1), ("data_source", 1)],
    "dragon_tiger": [("symbol", 1), ("trade_date", -1), ("reason", 1), ("data_source", 1)],
    "block_trade": [
        ("symbol", 1), ("trade_date", -1), ("buyer", 1), ("seller", 1), ("data_source", 1),
    ],
    "basic_info": [("symbol", 1), ("data_source", 1)],
}

_LEGACY_NAMED_INDEXES: Dict[str, List[str]] = {
    "market_quotes": ["symbol_unique", "last_price_idx", "updated_at_idx"],
}

def default_index_name(fields: List[tuple]) -> str:
    return "_".join(f"{k}_{v}" for k, v in fields)

def get_legacy_index_names() -> Dict[str, List[str]]:
    result = {
        domain: [default_index_name(fields)] if len(fields) else []
        for domain, fields in _LEGACY_UNIQUE_WITH_SOURCE.items()
    }
    for domain, names in _LEGACY_NAMED_INDEXES.items():
        result.setdefault(domain, []).extend(names)
    return result

def get_unique_key(domain: str) -> List[str]:

    for fields, unique in INDEX_DEFINITIONS[domain]:
        if unique:
            return [k for k, _ in fields]
    raise KeyError(f"domain {domain} 未定义唯一索引")
