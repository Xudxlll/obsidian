from typing import Dict

_BUSINESS_COLLECTIONS: Dict[str, str] = {
    "basic_info": "stock_basic_info",
    "trade_calendar": "trade_calendar",
    "daily_quotes": "stock_daily_quotes",
    "daily_indicators": "stock_daily_indicators",
    "adj_factors": "stock_adj_factors",
    "corporate_actions": "stock_corporate_actions",
    "financial_data": "stock_financial_data",
    "market_quotes": "market_quotes",
    "news": "stock_news",
    "connect_status": "stock_connect_status",
    "southbound_holding": "stock_southbound_holding",
    "pre_post_market": "stock_pre_post_market",
    "intraday_quotes": "stock_intraday_quotes",
    "money_flow": "stock_money_flow",
    "margin_trading": "stock_margin_trading",
    "dragon_tiger": "stock_dragon_tiger",
    "block_trade": "stock_block_trade",
    "tushare_universe": "stock_tushare_universe",
}

_METADATA_COLLECTIONS: Dict[str, str] = {
    "sync_checkpoints": "sync_checkpoints",
    "sync_events": "sync_events",
    "source_health": "source_health",
    "system_configs": "system_configs",
    "system_secrets": "system_secrets",
}

_MARKET_SUFFIX = {
    "CN": "",
    "HK": "_hk",
    "US": "_us",
}

def get_collection_name(domain: str, market: str) -> str:

    if domain in _METADATA_COLLECTIONS:
        return _METADATA_COLLECTIONS[domain]

    if domain in _BUSINESS_COLLECTIONS:
        base = _BUSINESS_COLLECTIONS[domain]
        if market == "CN":
            return base
        suffix = _MARKET_SUFFIX.get(market, "")
        return f"{base}{suffix}"

    raise KeyError(f"未知的 domain: {domain}")

def get_all_collections(market: str) -> Dict[str, str]:
    result = {}
    suffix = "" if market == "CN" else _MARKET_SUFFIX.get(market, "")
    for domain, base in _BUSINESS_COLLECTIONS.items():
        result[domain] = f"{base}{suffix}"
    for domain, name in _METADATA_COLLECTIONS.items():
        result[domain] = name
    return result

def is_metadata_collection(domain: str) -> bool:
    return domain in _METADATA_COLLECTIONS

def get_all_domains() -> list:
    return list(_BUSINESS_COLLECTIONS.keys())
