from typing import Optional

from motor.motor_asyncio import AsyncIOMotorDatabase

_motor_db: Optional[AsyncIOMotorDatabase] = None

def get_motor_db() -> AsyncIOMotorDatabase:
    global _motor_db
    if _motor_db is None:
        from app.core.database import get_mongo_db
        _motor_db = get_mongo_db()
    return _motor_db

def reset_client():
    global _motor_db
    _motor_db = None
