from typing import Dict, List

from app.data.storage.mongo.index_definitions import INDEX_DEFINITIONS

def get_domain_key(domain: str) -> List[str]:
    for fields, unique in INDEX_DEFINITIONS[domain]:
        if unique:
            return [k for k, _ in fields]
    raise KeyError(f"domain {domain} 未定义唯一键")

def get_domain_keys() -> Dict[str, List[str]]:
    result: Dict[str, List[str]] = {}
    for domain, specs in INDEX_DEFINITIONS.items():
        for fields, unique in specs:
            if unique:
                result[domain] = [k for k, _ in fields]
                break
    return result

def build_filter(domain: str, record: dict) -> dict:

    filter_doc = {}
    for field in get_domain_key(domain):
        value = record.get(field)
        if value is None:
            raise KeyError(f"{domain} 记录缺少唯一键字段 {field}")
        filter_doc[field] = value
    return filter_doc
