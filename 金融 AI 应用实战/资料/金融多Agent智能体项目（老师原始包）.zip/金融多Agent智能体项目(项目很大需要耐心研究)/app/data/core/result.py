from dataclasses import dataclass, field
from typing import Dict, Optional

from app.data.schema.base.enums import RefreshStatus

@dataclass
class DomainRefreshResult:
    domain: str
    status: str
    record_count: int = 0
    source: Optional[str] = None
    fallback_from: Optional[str] = None
    error: Optional[str] = None
    latency_ms: int = 0

@dataclass
class RefreshResult:
    status: str = RefreshStatus.FAILED
    symbol: str = ""
    market: str = ""
    domains: Dict[str, DomainRefreshResult] = field(default_factory=dict)
    source_used: Optional[str] = None
    fallback_from: Optional[str] = None
    total_latency_ms: int = 0
    error: Optional[str] = None

    def compute_status(self) -> str:

        if not self.domains:
            return RefreshStatus.FAILED

        statuses = [d.status for d in self.domains.values()]

        non_skipped = [s for s in statuses if s != RefreshStatus.SKIPPED]
        if not non_skipped:
            self.status = RefreshStatus.SKIPPED
            return self.status

        all_fresh = all(s == "fresh" for s in non_skipped)
        all_success = all(s in ("fresh", "refreshed") for s in non_skipped)
        any_failed = "failed" in non_skipped
        any_timeout = "timeout" in non_skipped

        if all_fresh:
            self.status = RefreshStatus.FRESH
        elif all_success:
            self.status = RefreshStatus.REFRESHED
        elif any_failed or any_timeout:
            if any(s in ("fresh", "refreshed") for s in non_skipped):
                self.status = RefreshStatus.PARTIAL
            else:
                self.status = RefreshStatus.FAILED
        else:
            self.status = RefreshStatus.FAILED
        return self.status
