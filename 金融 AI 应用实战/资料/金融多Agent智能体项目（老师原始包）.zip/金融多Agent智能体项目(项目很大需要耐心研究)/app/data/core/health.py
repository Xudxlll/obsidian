import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

logger = logging.getLogger(__name__)

_CONFIG_PATH = Path(__file__).parent.parent / "config" / "data_health.yaml"
_FRESHNESS_PATH = Path(__file__).parent.parent / "config" / "freshness_rules.yaml"

HEALTH_SNAPSHOT_MAX_AGE_HOURS = 2.0

def _load_yaml(path: Path) -> Dict:
    try:
        with open(path, encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except Exception as exc:
        logger.warning(f"加载 {path.name} 失败: {exc}")
        return {}

class DomainHealthCalculator:

    def __init__(self, config: Optional[Dict] = None):
        self._config = config or _load_yaml(_CONFIG_PATH)
        self._freshness_rules = _load_yaml(_FRESHNESS_PATH)

    def _defaults(self) -> Dict:
        return self._config.get("defaults", {})

    def _is_coverage_exempt(self, domain: str) -> bool:
        return domain in (self._config.get("coverage_exempt_domains") or [])

    def _stale_budget_hours(self, market: str, domain: str) -> Optional[float]:

        market_cfg = self._freshness_rules.get(market, {})
        rule = market_cfg.get(domain) or {}
        rule_type = rule.get("rule_type", "time_window")
        if rule_type == "time_window":
            hours = rule.get("threshold_hours")
            if hours:
                return float(hours)
            minutes = rule.get("threshold_minutes")
            if minutes:
                return float(minutes) / 60.0
            return None
        override = (
            self._config.get("markets", {})
            .get(market, {})
            .get("stale_after_hours", {})
            .get("trading_day_default")
        )
        if override is None:
            override = (self._config.get("stale_after_hours") or {}).get(
                "trading_day_default", 72
            )
        return float(override)

    def evaluate(
        self,
        market: str,
        domain: str,
        record_count: int,
        last_sync_time: Optional[str],
        checkpoint_success: bool,
        sources: Optional[List[Dict]] = None,
        coverage: Optional[float] = None,
        monitoring_available: bool = True,
        now=None,
    ) -> Dict[str, Any]:
        from datetime import datetime, timezone

        now = now or datetime.now(timezone.utc)
        sources = sources or []

        expected_hours = self._stale_budget_hours(market, domain)
        actual_hours = self._age_hours(last_sync_time, now)

        status, reason = self._decide(
            record_count=record_count,
            checkpoint_success=checkpoint_success,
            sources=sources,
            coverage=None if self._is_coverage_exempt(domain) else coverage,
            monitoring_available=monitoring_available,
            actual_hours=actual_hours,
            expected_hours=expected_hours,
        )

        return {
            "domain": domain,
            "status": status,
            "reason": reason,
            "record_count": record_count,
            "coverage": None if self._is_coverage_exempt(domain) else coverage,
            "last_sync_time": last_sync_time,
            "freshness": {
                "expected_hours": expected_hours,
                "actual_hours": actual_hours,
                "budget_hours": expected_hours,
            },
            "sources": [self._serialize_source(s) for s in sources],
        }

    def _decide(
        self,
        record_count: int,
        checkpoint_success: bool,
        sources: List[Dict],
        coverage: Optional[float],
        monitoring_available: bool,
        actual_hours: Optional[float],
        expected_hours: Optional[float],
    ):
        defaults = self._defaults()
        min_samples = defaults.get("min_samples", 20)
        min_rate = defaults.get("min_success_rate", 0.5)
        warn_rate = defaults.get("warn_success_rate", 0.8)
        max_latency = defaults.get("max_latency_ms", 5000)
        min_coverage = defaults.get("min_coverage", 0.8)

        if not monitoring_available:
            return "unknown", "健康监控数据不可用（监控失联）"

        has_source_signal = bool(sources) and any(
            (s.get("total_calls") or 0) > 0 for s in sources
        )

        if record_count == 0 and not checkpoint_success:
            return "no_data", "库内无记录且无成功同步检查点"

        if has_source_signal:
            open_sources = [s for s in sources if s.get("circuit_state") == "open"]
            closed_sources = [s for s in sources if s.get("circuit_state") == "closed"]
            if open_sources and not closed_sources:
                names = ", ".join(s.get("source", "?") for s in open_sources)
                return "unhealthy", f"全部数据源熔断开启（{names}）"
            for s in sources:
                calls = s.get("total_calls_1h") or s.get("total_calls") or 0
                rate = s.get("success_rate_1h")
                if rate is not None and calls >= min_samples and rate < min_rate:
                    return "unhealthy", (
                        f"源 {s.get('source')} 窗口成功率 {rate:.0%} 低于 {min_rate:.0%}"
                        f"（{calls} 次调用）"
                    )

        if (
            actual_hours is not None
            and expected_hours is not None
            and actual_hours > expected_hours
        ):
            return "stale", (
                f"最近更新 {actual_hours:.0f} 小时前，超出预算 {expected_hours:.0f} 小时"
            )

        if has_source_signal:
            if open_sources:
                names = ", ".join(s.get("source", "?") for s in open_sources)
                return "degraded", f"部分源熔断（{names}），已降级到备用源"
            if any(s.get("circuit_state") == "half_open" for s in sources):
                return "degraded", "存在半开熔断源（恢复探测中）"
            for s in sources:
                calls = s.get("total_calls_1h") or s.get("total_calls") or 0
                rate = s.get("success_rate_1h")
                if rate is not None and calls >= min_samples and rate < warn_rate:
                    return "degraded", (
                        f"源 {s.get('source')} 窗口成功率 {rate:.0%} 低于 {warn_rate:.0%}"
                    )
            for s in sources:
                latency = s.get("avg_latency_1h")
                if latency is not None and latency > max_latency:
                    return "degraded", f"源 {s.get('source')} 平均延迟 {latency:.0f}ms 超标"
        if coverage is not None and coverage < min_coverage:
            return "degraded", f"覆盖率 {coverage:.0%} 低于 {min_coverage:.0%}"

        if not has_source_signal:
            return "healthy", "数据存在且新鲜（无运行时源调用信号，按数据判定）"
        return "healthy", "数据存在、新鲜、源运行正常"

    @staticmethod
    def _serialize_source(s: Dict) -> Dict:
        no_signal = (s.get("total_calls") or 0) == 0
        rate = s.get("success_rate_1h")
        latency = s.get("avg_latency_1h")
        return {
            "source": s.get("source", ""),
            "circuit_state": "unknown" if no_signal else s.get("circuit_state", "closed"),
            "success_rate_1h": None if (no_signal or rate is None) else rate,
            "avg_latency_1h": None if (no_signal or latency is None) else latency,
            "total_calls": s.get("total_calls") or 0,
            "consecutive_failures": s.get("consecutive_failures", 0),
        }

    @staticmethod
    def _age_hours(ts: Optional[str], now) -> Optional[float]:
        from datetime import datetime, timezone

        if not ts:
            return None
        try:
            if isinstance(ts, datetime):
                updated = ts
            else:
                s = str(ts)
                s = s.replace("Z", "+00:00") if s.endswith("Z") else s
                updated = datetime.fromisoformat(s)
            if updated.tzinfo is None:
                updated = updated.replace(tzinfo=timezone.utc)
            if now.tzinfo is None:
                now = now.replace(tzinfo=timezone.utc)
            return (now - updated).total_seconds() / 3600.0
        except (ValueError, TypeError):
            return None

    @staticmethod
    def summarize(domain_health: List[Dict]) -> Dict[str, Any]:
        counts: Dict[str, int] = {}
        for d in domain_health:
            counts[d["status"]] = counts.get(d["status"], 0) + 1
        if any(counts.get(k) for k in ("unhealthy", "no_data")):
            overall = "partial_outage"
        elif any(counts.get(k) for k in ("stale", "degraded")):
            overall = "degraded"
        elif counts.get("healthy"):
            overall = "all_healthy" if not counts.get("unknown") else "degraded"
        else:
            overall = "unknown"
        return {
            "overall": overall,
            "healthy_domains": counts.get("healthy", 0),
            "warning_domains": counts.get("degraded", 0) + counts.get("stale", 0),
            "problem_domains": counts.get("unhealthy", 0) + counts.get("no_data", 0),
            "unknown_domains": counts.get("unknown", 0),
            "total_domains": len(domain_health),
        }
