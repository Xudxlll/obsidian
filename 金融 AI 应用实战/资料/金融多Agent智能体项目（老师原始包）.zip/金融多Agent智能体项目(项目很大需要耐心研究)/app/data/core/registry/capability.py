import logging
from typing import Dict, List, Optional, Tuple

from app.data.schema.base.enums import SupportLevel
from app.data.storage.cache.memory_cache import TTLCache

logger = logging.getLogger(__name__)

_user_priority_cache = TTLCache(default_ttl=30)

class CapabilityRegistry:

    def __init__(self):
        self._capabilities: Dict[Tuple[str, str], Dict[str, SupportLevel]] = {}
        self._load_from_default_yaml()

    def _load_from_default_yaml(self) -> None:
        from app.data.config import load_yaml
        data = load_yaml("capability_matrix.yaml")
        if data:
            self.load_from_yaml(data)

    def register(self, market: str, domain: str, source: str, level: SupportLevel) -> None:
        key = (market, domain)
        if key not in self._capabilities:
            self._capabilities[key] = {}
        self._capabilities[key][source] = level
        logger.debug(f"注册能力: {market}/{domain}/{source} = {level.value}")

    def load_from_yaml(self, yaml_data: dict) -> None:
        for market, domains in yaml_data.items():
            for domain, sources in domains.items():
                for source, level_str in sources.items():
                    level = SupportLevel(level_str)
                    self.register(market, domain, source, level)

    def get_sources(self, market: str, domain: str) -> List[Tuple[str, SupportLevel]]:
        key = (market, domain)
        if key not in self._capabilities:
            return []
        return list(self._capabilities[key].items())

    def get_ordered_sources(
        self,
        market: str,
        domain: str,
        user_priority: Optional[List[str]] = None,
        disabled_sources: Optional[List[str]] = None,
    ) -> List[str]:

        sources = self.get_sources(market, domain)
        disabled = set(disabled_sources or [])

        available = [(s, level) for s, level in sources if s not in disabled and level != SupportLevel.NONE]

        if user_priority:
            priority_set = {s: i for i, s in enumerate(user_priority)}
            available.sort(key=lambda x: priority_set.get(x[0], 999))

        return [s for s, _ in available]

    def remove_source(self, market: str, domain: str, source: str) -> None:
        key = (market, domain)
        if key in self._capabilities and source in self._capabilities[key]:
            del self._capabilities[key][source]
            logger.info(f"移除能力: {market}/{domain}/{source}")

    def is_supported(self, market: str, domain: str, source: str) -> bool:
        key = (market, domain)
        return key in self._capabilities and source in self._capabilities[key] and self._capabilities[key][source] != SupportLevel.NONE

    def get_available_sources(self, domain: str, market: Optional[str] = None) -> List[str]:
        sources = set()
        for (m, d), src_map in self._capabilities.items():
            if d == domain and (market is None or m == market):
                for s, level in src_map.items():
                    if level != SupportLevel.NONE:
                        sources.add(s)
        return sorted(sources)

    def get_support_level(self, domain: str, source: str, market: Optional[str] = None) -> SupportLevel:
        for (m, d), src_map in self._capabilities.items():
            if d == domain and source in src_map and (market is None or m == market):
                return src_map[source]
        return SupportLevel.NONE

    def set_user_priority(self, market: str, domain: str, sources: List[str]) -> None:

        cache_key = f"priority:{market}:{domain}"
        _user_priority_cache.set(cache_key, sources)
        logger.info(f"用户优先级已更新: {market}/{domain} → {sources}")

    def get_matrix_summary(self, market: Optional[str] = None) -> Dict[str, Dict[str, str]]:
        summary: Dict[str, Dict[str, str]] = {}
        for (m, domain), src_map in self._capabilities.items():
            if market is not None and m != market:
                continue
            if domain not in summary:
                summary[domain] = {}
            for source, level in src_map.items():
                summary[domain][source] = level.value
        return summary

    def get_domains(self, market: str) -> List[str]:
        return sorted({d for (m, d) in self._capabilities if m == market})
