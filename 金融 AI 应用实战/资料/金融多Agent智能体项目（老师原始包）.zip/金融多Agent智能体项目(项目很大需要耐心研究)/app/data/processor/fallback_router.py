import asyncio
import logging
import threading
import time
from typing import Dict, List, Optional

from app.data.processor.circuit_breaker import (
    CircuitBreaker,
    load_source_cooldown_config,
)
from app.data.processor.rate_limiter import RateLimiter
from app.data.processor.retry_policy import RetryPolicy
from app.data.processor.normalizer import Normalizer
from app.data.processor.validator import Validator
from app.data.core.registry.capability import CapabilityRegistry
from app.data.core.registry.priority import PriorityConfig
from app.data.monitoring.source_health import SourceHealthMonitor
from app.data.sources.base.exceptions import DataSourceError
from app.data.sources.base.provider import BaseProvider

logger = logging.getLogger(__name__)

_instance: Optional["FallbackRouter"] = None
_instance_lock = threading.Lock()

def _ensure_singleton() -> "FallbackRouter":

    global _instance
    if _instance is None:
        with _instance_lock:
            if _instance is None:
                _instance = FallbackRouter(
                    CapabilityRegistry(),
                    PriorityConfig(),
                )
    return _instance

def reset_singleton() -> None:
    global _instance
    with _instance_lock:
        _instance = None

class FetchResult:

    def __init__(self):
        self.success: bool = False
        self.records: List[Dict] = []
        self.source: Optional[str] = None
        self.fallback_from: Optional[str] = None
        self.error: Optional[str] = None
        self.latency_ms: int = 0
        self.validation_errors: Optional[Dict] = None

    @property
    def data(self) -> List[Dict]:
        return self.records

class FallbackRouter:

    def __init__(
        self,
        registry: CapabilityRegistry,
        priority: PriorityConfig,
        circuit_breaker: Optional[CircuitBreaker] = None,
        rate_limiter: Optional[RateLimiter] = None,
        retry_max_retries: int = 2,
    ):
        self._registry = registry
        self._priority = priority
        self._circuit = circuit_breaker or self._create_default_circuit_breaker()
        self._rate_limiter = rate_limiter or self._create_default_rate_limiter()
        self._normalizer = Normalizer()
        self._validator = Validator()
        self._health_monitor = SourceHealthMonitor()
        self._retry_max_retries = retry_max_retries
        self._retry_config: Dict[str, dict] = self._load_retry_config()

    @classmethod
    def get_instance(cls) -> "FallbackRouter":

        return _ensure_singleton()

    @classmethod
    def reset_instance(cls) -> None:
        reset_singleton()

    @staticmethod
    def _create_default_circuit_breaker() -> CircuitBreaker:
        try:
            steps_by_source = load_source_cooldown_config()
        except Exception as e:
            logger.warning(f"加载熔断冷却配置失败，使用默认阶梯: {e}")
            steps_by_source = {}
        return CircuitBreaker(source_cooldown_config=steps_by_source)

    @staticmethod
    def _create_default_rate_limiter() -> RateLimiter:

        limiter = RateLimiter()

        try:
            from app.data.core.registry.source_metadata import SOURCE_METADATA

            for source, meta in SOURCE_METADATA.items():
                limiter.configure(
                    source,
                    rate_per_minute=meta.rate_per_minute,
                    polite_interval_ms=meta.polite_interval_ms,
                    rate_per_day=meta.rate_per_day,
                )
        except Exception as e:
            logger.warning(f"加载限流配置失败: {e}")

        return limiter

    @staticmethod
    def _load_retry_config() -> Dict[str, dict]:

        import yaml
        from pathlib import Path

        config_path = Path(__file__).parent.parent / "config" / "source_limits.yaml"
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                limits_config = yaml.safe_load(f) or {}
        except Exception as e:
            logger.warning(f"加载重试配置失败，使用全局默认: {e}")
            return {}

        result: Dict[str, dict] = {}
        for source, cfg in limits_config.items():
            if not isinstance(cfg, dict):
                continue
            retry = cfg.get("retry")
            if isinstance(retry, dict):
                result[source] = {
                    "max_retries": int(retry.get("max_retries", 2)),
                    "backoff_base": float(retry.get("backoff_base", 1.0)),
                }
        return result

    async def fetch(
        self,
        market: str,
        domain: str,
        symbol: str,
        start_date: str = "1970-01-01",
        end_date: str = "2099-12-31",
        preferred_sources: Optional[List[str]] = None,
    ) -> FetchResult:
        result = FetchResult()
        start = time.time()

        priority_list = await self._priority.get_priority(market, domain)
        sources = self._registry.get_ordered_sources(market, domain, user_priority=priority_list)
        if preferred_sources:
            preferred_order = {name: i for i, name in enumerate(preferred_sources)}
            original_order = {name: i for i, name in enumerate(sources)}
            sources.sort(
                key=lambda name: (
                    preferred_order.get(name, 999),
                    original_order.get(name, 999),
                )
            )

        if not sources:
            result.error = f"无可用数据源: {market}/{domain}"
            return result

        fallback_chain = []
        default_exchange = {"CN": "SSE", "HK": "HKEX", "US": "NYSE"}.get(market, "SSE")

        for source_name in sources:
            status, records, verrs = await self.fetch_source(
                market, domain, source_name,
                lambda p: self._fetch_raw(
                    p, domain, symbol, start_date, end_date, default_exchange
                ),
            )
            if status == "failed":
                fallback_chain.append(source_name)
                continue
            if status == "skip":
                continue

            result.success = True
            result.records = records
            result.source = source_name
            result.latency_ms = int((time.time() - start) * 1000)
            if verrs:
                result.validation_errors = verrs
            if fallback_chain:
                result.fallback_from = " → ".join(fallback_chain)
            return result

        result.error = f"所有源失败: {', '.join(fallback_chain)}"
        result.latency_ms = int((time.time() - start) * 1000)
        return result

    async def fetch_source(
        self,
        market: str,
        domain: str,
        source_name: str,
        raw_fetch,
    ):

        source_start = time.time()

        if self._circuit.is_open(source_name, domain=domain, market=market):
            logger.debug(f"熔断跳过: {source_name}/{domain}")
            return "skip", [], None

        allowed, wait = await self._rate_limiter.acquire(source_name, domain)
        if not allowed:
            await asyncio.sleep(wait)
            if self._circuit.is_open(source_name, domain=domain, market=market):
                await self._rate_limiter.release(source_name, domain)
                return "skip", [], None

        if self._circuit.is_open(source_name, domain=domain, market=market):
            await self._rate_limiter.release(source_name, domain)
            return "skip", [], None

        provider, adapter = await self._get_provider_adapter(market, source_name)
        if not provider or not adapter:
            self._circuit.clear_probe(source_name, domain=domain, market=market)
            return "skip", [], None

        retry_cfg = self._retry_config.get(source_name, {})
        retry_policy = RetryPolicy(
            max_retries=retry_cfg.get("max_retries", self._retry_max_retries),
            backoff_base=retry_cfg.get("backoff_base", 1.0),
        )
        try:
            raw_data = await retry_policy.execute_with_retry(raw_fetch, provider)

            if raw_data is self._BATCH_NOT_SUPPORTED:
                logger.debug(f"源 {source_name}/{domain} 不支持批量模式，跳过")
                self._circuit.clear_probe(source_name, domain=domain, market=market)
                return "skip", [], None

            if raw_data is None or (hasattr(raw_data, "empty") and raw_data.empty):
                self._circuit.record_failure(source_name, domain=domain, market=market)
                self._health_monitor.record_call(
                    market,
                    source_name,
                    domain,
                    success=False,
                    latency_ms=int((time.time() - source_start) * 1000),
                    error="empty data",
                    circuit_state=self._circuit.get_state(source_name, domain=domain, market=market).value,
                )
                return "failed", [], None

            normalize_result = await asyncio.to_thread(
                self._normalizer.normalize_with_status, raw_data, domain, adapter
            )
            records = normalize_result.records
            if not records:
                if normalize_result.status == "error":
                    self._circuit.record_failure(source_name, domain=domain, market=market)
                self._health_monitor.record_call(
                    market,
                    source_name,
                    domain,
                    success=normalize_result.status != "error",
                    latency_ms=int((time.time() - source_start) * 1000),
                    error=f"normalize {normalize_result.status}",
                    circuit_state=self._circuit.get_state(source_name, domain=domain, market=market).value,
                )
                return "failed", [], None

            valid, errors = await asyncio.to_thread(
                self._validator.validate, records, domain, market
            )

            dropped = len(records) - len(valid)
            if errors:
                logger.warning(
                    "数据校验剔除 %d/%d 条记录: market=%s domain=%s source=%s errors=%s",
                    dropped,
                    len(records),
                    market,
                    domain,
                    source_name,
                    errors[:5],
                )

            self._circuit.record_success(source_name, domain=domain, market=market)
            self._health_monitor.record_call(
                market,
                source_name,
                domain,
                success=True,
                latency_ms=int((time.time() - source_start) * 1000),
                circuit_state="closed",
            )
            validation_errors = None
            if errors:
                validation_errors = {
                    "dropped": dropped,
                    "total": len(records),
                    "samples": errors[:5],
                }
            return "success", valid, validation_errors

        except DataSourceError as e:
            self._circuit.record_failure(source_name, domain=domain, market=market, error_code=e.code)
            self._health_monitor.record_call(
                market,
                source_name,
                domain,
                success=False,
                latency_ms=int((time.time() - source_start) * 1000),
                error=str(e),
                circuit_state=self._circuit.get_state(source_name, domain=domain, market=market).value,
            )
            logger.warning(f"源 {source_name}/{domain} 失败: {e}")
            return "failed", [], None
        except NotImplementedError as e:
            logger.debug(f"源 {source_name}/{domain} 不支持该域，跳过: {e}")
            self._circuit.clear_probe(source_name, domain=domain, market=market)
            return "skip", [], None
        except Exception as e:
            self._circuit.record_failure(source_name, domain=domain, market=market)
            self._health_monitor.record_call(
                market,
                source_name,
                domain,
                success=False,
                latency_ms=int((time.time() - source_start) * 1000),
                error=str(e),
                circuit_state=self._circuit.get_state(source_name, domain=domain, market=market).value,
            )
            logger.warning(f"源 {source_name}/{domain} 异常: {e}")
            return "failed", [], None

    async def _fetch_raw(
        self,
        provider,
        domain: str,
        symbol: str,
        start: str,
        end: str,
        exchange: str = "SSE",
    ):
        method_map = {
            "basic_info": lambda: provider.get_stock_list(),
            "trade_calendar": lambda: provider.get_trade_calendar(exchange, start, end),
            "daily_quotes": lambda: provider.get_daily_quotes(symbol, start, end),
            "daily_indicators": lambda: self._fetch_daily_indicators(provider, symbol, start, end),
            "financial_data": lambda: provider.get_financial_data(symbol, start, end),
            "adj_factors": lambda: provider.get_adj_factors(symbol, start, end),
            "corporate_actions": lambda: provider.get_corporate_actions(symbol, start, end),
            "news": lambda: provider.get_news(None if symbol == "__all__" else symbol, start, end),
            "market_quotes": lambda: provider.get_market_quotes([symbol]),
            "intraday_quotes": lambda: provider.get_intraday_quotes(symbol, start, end),
            "money_flow": lambda: provider.get_money_flow(symbol, start, end),
            "margin_trading": lambda: provider.get_margin_trading(symbol, start, end),
            "dragon_tiger": lambda: provider.get_dragon_tiger(symbol, start, end),
            "block_trade": lambda: provider.get_block_trade(symbol, start, end),
        }
        method = method_map.get(domain)
        if method:
            return await method()
        return None

    _BATCH_NOT_SUPPORTED = object()

    async def _fetch_daily_indicators(self, provider, symbol: str, start: str, end: str):
        if symbol == "__all__":
            base_method = BaseProvider.get_daily_indicators_batch
            provider_method = type(provider).get_daily_indicators_batch
            if provider_method is base_method:
                return self._BATCH_NOT_SUPPORTED

            from datetime import date

            trade_date = end if end != "2099-12-31" else date.today().strftime("%Y-%m-%d")
            return await provider.get_daily_indicators_batch(trade_date)
        return await provider.get_daily_indicators(symbol, start, end)

    async def _get_provider_adapter(self, market: str, source_name: str):
        try:
            if market == "CN":
                from app.data.sources.cn import get_cn_provider, get_cn_adapter

                return get_cn_provider(source_name), get_cn_adapter(source_name)
            elif market == "HK":
                from app.data.sources.hk import get_hk_provider, get_hk_adapter

                return get_hk_provider(source_name), get_hk_adapter(source_name)
            elif market == "US":
                from app.data.sources.us import get_us_provider, get_us_adapter

                return get_us_provider(source_name), get_us_adapter(source_name)
        except Exception as e:
            logger.debug(f"获取 Provider/Adapter 失败: {e}")
        return None, None
