from __future__ import annotations

import asyncio
import collections
import hashlib
import logging
import time
from datetime import datetime, timedelta
from typing import Deque, Dict, Optional, Tuple

from app.data.storage.redis.counters import SlidingWindowCounter

logger = logging.getLogger(__name__)

_FAIL_OPEN_THRESHOLD = 3
_PROBE_INTERVAL = 10.0
_REDIS_DOWN_BACKOFF = 5.0
_TOKEN_CACHE_TTL = 300.0
_DAILY_KEY_PREFIX = "ratelimit_day"

def _bucket_key(source: str, token: Optional[str]) -> str:

    if token:
        digest = hashlib.sha256(token.encode("utf-8")).hexdigest()[:8]
        return f"ratelimit:{digest}"
    return f"ratelimit:{source}"

class RateLimiter:

    def __init__(self):
        self._counters: Dict[str, SlidingWindowCounter] = {}
        self._limits: Dict[str, dict] = {}
        self._locks: Dict[str, asyncio.Lock] = {}
        self._lock_loop: Optional[asyncio.AbstractEventLoop] = None
        self._state_lock: Optional[asyncio.Lock] = None
        self._redis_fail_count = 0
        self._fail_open_mode = False
        self._last_probe_time = 0.0
        self._memory_counters: Dict[str, Deque[float]] = {}
        self._memory_daily: Dict[str, int] = {}
        self._token_cache: Dict[str, Tuple[Optional[str], float]] = {}

    def configure(self, source: str, rate_per_minute: int = 60, **kwargs) -> None:
        self._limits[source] = {
            "rate_per_minute": rate_per_minute,
            "rate_per_day": kwargs.get("rate_per_day"),
            "last_request_time": 0,
            "polite_interval_ms": kwargs.get("polite_interval_ms", 1000),
        }
        if source not in self._counters:
            self._counters[source] = SlidingWindowCounter(window_seconds=60)

    async def _resolve_token(self, source: str, token: Optional[str]) -> Optional[str]:
        if token is not None:
            return token or None
        cached = self._token_cache.get(source)
        now = time.time()
        if cached is not None and now - cached[1] < _TOKEN_CACHE_TTL:
            return cached[0]
        try:
            from app.utils.ds_key_utils import get_datasource_api_key

            resolved = await asyncio.to_thread(get_datasource_api_key, source)
        except Exception as exc:
            logger.debug(f"[ratelimit] 解析 {source} Token 失败: {exc}")
            resolved = None
        self._token_cache[source] = (resolved, now)
        return resolved

    def _ensure_lock(self, source: str) -> asyncio.Lock:

        current_loop = asyncio.get_running_loop()
        if self._lock_loop is not current_loop:
            self._locks.clear()
            self._state_lock = None
            self._lock_loop = current_loop
        if source not in self._locks:
            self._locks[source] = asyncio.Lock()
        return self._locks[source]

    def _ensure_state_lock(self) -> asyncio.Lock:
        if self._state_lock is None:
            self._state_lock = asyncio.Lock()
        return self._state_lock

    async def _daily_quota_check(self, source: str, bucket: str, rate_per_day: int) -> Tuple[bool, float]:

        now = datetime.now()
        day = now.strftime("%Y%m%d")
        key = f"{_DAILY_KEY_PREFIX}:{bucket}:{day}"
        try:
            from app.data.storage.redis.client import get_redis

            redis = get_redis()
            count = await redis.incr(key)
            if count == 1:
                await redis.expire(key, 48 * 3600)
        except Exception as exc:
            logger.debug(f"[ratelimit] 日配额 Redis 计数失败，降级内存: {exc}")
            count = self._memory_daily.get(key, 0) + 1
            self._memory_daily[key] = count

        if count > rate_per_day:
            wait = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0) - now
            logger.warning(
                "[ratelimit] 源 %s 日配额触顶: %d/%d（bucket=%s），拒绝请求至次日零点",
                source,
                rate_per_day,
                count - 1,
                bucket,
            )
            return False, max(1.0, wait.total_seconds())
        return True, 0

    async def acquire(self, source: str, domain: str = "", token: Optional[str] = None) -> Tuple[bool, float]:

        limits = self._limits.get(source)
        if not limits:
            return True, 0

        lock = self._ensure_lock(source)

        async with lock:
            interval_s = limits.get("polite_interval_ms", 1000) / 1000
            elapsed = time.time() - limits.get("last_request_time", 0)
            if elapsed < interval_s:
                return False, interval_s - elapsed
            limits["last_request_time"] = time.time()

        state_lock = self._ensure_state_lock()
        async with state_lock:
            fail_open = self._fail_open_mode
            need_probe = fail_open and (time.time() - self._last_probe_time >= _PROBE_INTERVAL)
            if need_probe:
                self._last_probe_time = time.time()

        if fail_open:
            if need_probe:
                recovered = await self._probe_redis(source)
                if recovered:
                    async with state_lock:
                        logger.info(f"[ratelimit] Redis 已恢复，从 fail-open 切回正常路径 source={source}")
                        self._fail_open_mode = False
                        self._redis_fail_count = 0
                else:
                    return await self._memory_acquire(source, limits, token)
            else:
                return await self._memory_acquire(source, limits, token)

        bucket = _bucket_key(source, await self._resolve_token(source, token))
        counter = self._counters.get(source)
        if counter:
            try:
                allowed, retry = await counter.try_increment(
                    bucket,
                    limits["rate_per_minute"],
                )
                if allowed:
                    async with state_lock:
                        self._redis_fail_count = 0
                    rate_per_day = limits.get("rate_per_day")
                    if rate_per_day:
                        day_ok, day_wait = await self._daily_quota_check(source, bucket, int(rate_per_day))
                        if not day_ok:
                            return False, day_wait
                    return True, 0
                return False, retry
            except Exception as exc:
                async with state_lock:
                    self._redis_fail_count += 1
                    fail_count = self._redis_fail_count
                    if fail_count >= _FAIL_OPEN_THRESHOLD:
                        self._fail_open_mode = True
                        self._last_probe_time = time.time()
                        logger.warning(
                            f"[ratelimit] Redis 连续失败 {fail_count} 次，"
                            f"切换到 fail-open 内存计数 source={source}/{domain}: "
                            f"{type(exc).__name__}: {exc}"
                        )
                        return await self._memory_acquire(source, limits, token)
                logger.warning(
                    f"[ratelimit] Redis 临时故障 {fail_count}/{_FAIL_OPEN_THRESHOLD} "
                    f"source={source}/{domain}: {type(exc).__name__}: {exc}"
                )
                return False, _REDIS_DOWN_BACKOFF

        return True, 0

    async def _memory_acquire(self, source: str, limits: dict, token: Optional[str] = None) -> Tuple[bool, float]:

        rate = limits["rate_per_minute"]
        window = 60.0
        now = time.time()
        cutoff = now - window

        bucket = _bucket_key(source, await self._resolve_token(source, token))
        deque_ = self._memory_counters.get(bucket)
        if deque_ is None:
            deque_ = collections.deque(maxlen=max(1, rate))
            self._memory_counters[bucket] = deque_

        while deque_ and deque_[0] < cutoff:
            deque_.popleft()

        if len(deque_) >= rate:
            wait = deque_[0] + window - now
            return False, max(0.1, wait)

        deque_.append(now)

        rate_per_day = limits.get("rate_per_day")
        if rate_per_day:
            day = datetime.now().strftime("%Y%m%d")
            key = f"{_DAILY_KEY_PREFIX}:{bucket}:{day}"
            count = self._memory_daily.get(key, 0) + 1
            self._memory_daily[key] = count
            if count > int(rate_per_day):
                logger.warning(
                    "[ratelimit] 源 %s 日配额触顶（内存兜底）: %d（bucket=%s）",
                    source,
                    int(rate_per_day),
                    bucket,
                )
                return False, 60.0
        return True, 0

    async def _probe_redis(self, source: str) -> bool:
        counter = self._counters.get(source)
        if not counter:
            return False
        try:
            await counter.get_count(f"ratelimit:{source}")
            return True
        except Exception:
            return False

    async def wait_and_acquire(
        self, source: str, domain: str = "", max_wait: float = 30, token: Optional[str] = None
    ) -> bool:
        start = time.time()
        while time.time() - start < max_wait:
            allowed, wait = await self.acquire(source, domain, token=token)
            if allowed:
                return True
            await asyncio.sleep(min(wait, 1.0))
        return False

    async def release(self, source: str, domain: str = "", token: Optional[str] = None) -> bool:

        limits = self._limits.get(source)
        if not limits:
            return False

        state_lock = self._ensure_state_lock()
        async with state_lock:
            fail_open = self._fail_open_mode

        bucket = _bucket_key(source, await self._resolve_token(source, token))

        if fail_open:
            deque_ = self._memory_counters.get(bucket)
            if deque_:
                try:
                    deque_.pop()
                    return True
                except IndexError:
                    return False
            return False

        counter = self._counters.get(source)
        if not counter:
            return False
        try:
            return await counter.try_decrement(bucket)
        except Exception as exc:
            logger.debug(f"[ratelimit] release 失败 source={source}/{domain}: {exc}")
            return False
