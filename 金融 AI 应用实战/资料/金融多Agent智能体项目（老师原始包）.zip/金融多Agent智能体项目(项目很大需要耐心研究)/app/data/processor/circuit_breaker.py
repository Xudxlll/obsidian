import logging
import threading
import time
from typing import Dict, List, Optional, Tuple

from app.data.schema.base.enums import CircuitState
from app.data.sources.base.error_codes import DataErrorCode

logger = logging.getLogger(__name__)

FAILURE_THRESHOLD = 3
WINDOW_SECONDS = 300
COOLDOWN_STEPS: List[int] = [60, 120, 300, 600]
_HALF_OPEN_PROBE_TIMEOUT = 60.0
_ABSOLUTE_MAX_COOLDOWN = 3600

_ERROR_COOLDOWN_MULTIPLIERS = {
    DataErrorCode.RATE_LIMITED: 2,
    DataErrorCode.AUTH_FAILED: 5,
    DataErrorCode.TOKEN_INVALID: 5,
    DataErrorCode.NETWORK_TIMEOUT: 1,
    DataErrorCode.CONNECTION_ERROR: 1,
    DataErrorCode.SERVICE_UNAVAILABLE: 1.5,
    DataErrorCode.SERVER_ERROR: 1.5,
    DataErrorCode.DATA_INVALID: 1,
    DataErrorCode.INSUFFICIENT_CREDITS: 5,
}

def _build_cooldown_steps(initial: int, max_cooldown: int) -> List[int]:

    initial = max(1, int(initial))
    max_cooldown = max(initial, int(max_cooldown))
    mid = min(initial * 2, max_cooldown)
    return [initial, mid, max_cooldown]

def load_source_cooldown_config() -> Dict[str, List[int]]:

    import yaml
    from pathlib import Path

    config_path = Path(__file__).parent.parent / "config" / "source_limits.yaml"
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            limits_config = yaml.safe_load(f) or {}
    except Exception as e:
        logger.warning(f"加载熔断冷却配置失败，使用默认阶梯: {e}")
        return {}

    result: Dict[str, List[int]] = {}
    for source, cfg in limits_config.items():
        if not isinstance(cfg, dict):
            continue
        initial = cfg.get("circuit_initial_cooldown")
        max_cd = cfg.get("circuit_max_cooldown")
        if initial is None or max_cd is None:
            continue
        result[source] = _build_cooldown_steps(int(initial), int(max_cd))
    return result

class CircuitBreaker:

    def __init__(self, source_cooldown_config: Optional[Dict[str, List[int]]] = None):
        self._states: Dict[Tuple[str, str, str], dict] = {}
        self._lock = threading.Lock()
        self._half_open_probing: Dict[Tuple[str, str, str], float] = {}
        self._probe_granted: Dict[Tuple[str, str, str], bool] = {}
        if source_cooldown_config is None:
            try:
                source_cooldown_config = load_source_cooldown_config()
            except Exception as e:
                logger.warning(f"熔断冷却配置加载失败，全部源使用默认阶梯: {e}")
                source_cooldown_config = {}
        self._source_steps: Dict[str, List[int]] = source_cooldown_config or {}

    def _get_steps(self, source: str) -> List[int]:
        return self._source_steps.get(source) or COOLDOWN_STEPS

    def _get_state(self, source: str, domain: str = "", market: str = "") -> dict:
        key = (source, domain, market)
        if key not in self._states:
            steps = self._get_steps(source)
            self._states[key] = {
                "state": CircuitState.CLOSED,
                "failures": [],
                "trip_count": 0,
                "opened_at": 0,
                "cooldown": steps[0],
                "last_success": 0,
            }
        return self._states[key]

    def is_open(self, source: str, domain: str = "", market: str = "") -> bool:

        with self._lock:
            state = self._get_state(source, domain, market)
            key = (source, domain, market)

            if state["state"] == CircuitState.CLOSED:
                return False

            if self._probe_granted.get(key):
                return False

            if state["state"] == CircuitState.OPEN:
                elapsed = time.time() - state["opened_at"]
                if elapsed >= state["cooldown"]:
                    state["state"] = CircuitState.HALF_OPEN
                    logger.info(f"熔断器半开: {source}/{domain}")
                    probe_started = self._half_open_probing.get(key)
                    if probe_started is not None and (time.time() - probe_started) < _HALF_OPEN_PROBE_TIMEOUT:
                        return True
                    self._half_open_probing[key] = time.time()
                    self._probe_granted[key] = True
                    return False
                return True

            if state["state"] == CircuitState.HALF_OPEN:
                probe_started = self._half_open_probing.get(key)
                if probe_started is not None and (time.time() - probe_started) < _HALF_OPEN_PROBE_TIMEOUT:
                    return True
                self._half_open_probing[key] = time.time()
                self._probe_granted[key] = True
                return False

    def get_state(self, source: str, domain: str = "", market: str = "") -> CircuitState:
        with self._lock:
            return self._get_state(source, domain, market)["state"]

    def record_success(self, source: str, domain: str = "", market: str = "") -> None:
        with self._lock:
            state = self._get_state(source, domain, market)
            state["state"] = CircuitState.CLOSED
            state["failures"] = []
            state["last_success"] = time.time()
            state["trip_count"] = max(0, state["trip_count"] - 1)
            self._half_open_probing.pop((source, domain, market), None)
            self._probe_granted.pop((source, domain, market), None)

    def record_failure(
        self, source: str, domain: str = "", error_code: Optional[DataErrorCode] = None, market: str = ""
    ) -> None:

        with self._lock:
            state = self._get_state(source, domain, market)
            now = time.time()

            state["failures"] = [t for t in state["failures"] if now - t < WINDOW_SECONDS]
            state["failures"].append(now)

            if state["state"] == CircuitState.HALF_OPEN:
                self._trip(source, domain, market, error_code)
                self._half_open_probing.pop((source, domain, market), None)
                self._probe_granted.pop((source, domain, market), None)
                return

            if len(state["failures"]) >= FAILURE_THRESHOLD:
                self._trip(source, domain, market, error_code)

    def _trip(self, source: str, domain: str, market: str, error_code: Optional[DataErrorCode] = None) -> None:
        state = self._get_state(source, domain, market)
        steps = self._get_steps(source)
        state["state"] = CircuitState.OPEN
        state["opened_at"] = time.time()
        state["trip_count"] += 1

        idx = min(state["trip_count"] - 1, len(steps) - 1)
        base_cooldown = steps[idx]
        multiplier = _ERROR_COOLDOWN_MULTIPLIERS.get(error_code, 1)
        source_cap = steps[-1]
        cap = min(source_cap, _ABSOLUTE_MAX_COOLDOWN)
        state["cooldown"] = min(int(base_cooldown * multiplier), cap)

        logger.warning(f"熔断器打开: {source}/{market}/{domain}, 冷却 {state['cooldown']}s (错误: {error_code})")

    def clear_probe(self, source: str, domain: str = "", market: str = "") -> None:

        with self._lock:
            self._probe_granted.pop((source, domain, market), None)

    def get_trip_count(self, source: str, domain: str = "", market: str = "") -> int:
        with self._lock:
            return self._get_state(source, domain, market).get("trip_count", 0)

    def reset(self, source: str, domain: str = "", market: str = "") -> None:
        with self._lock:
            state = self._get_state(source, domain, market)
            steps = self._get_steps(source)
            state["state"] = CircuitState.CLOSED
            state["failures"] = []
            state["trip_count"] = 0
            state["opened_at"] = 0
            state["cooldown"] = steps[0]
            logger.info(f"熔断器已重置: {source}/{market}/{domain}")
