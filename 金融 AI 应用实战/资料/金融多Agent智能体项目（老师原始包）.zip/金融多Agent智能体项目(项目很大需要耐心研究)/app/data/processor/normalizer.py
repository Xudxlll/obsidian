import logging
from dataclasses import dataclass
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

DOMAIN_METHOD_MAP = {
    "basic_info": "adapt_basic_info",
    "trade_calendar": "adapt_trade_calendar",
    "daily_quotes": "adapt_daily_quotes",
    "daily_indicators": "adapt_daily_indicators",
    "financial_data": "adapt_financial_data",
    "adj_factors": "adapt_adj_factors",
    "corporate_actions": "adapt_corporate_actions",
    "news": "adapt_news",
    "market_quotes": "adapt_market_quotes",
    "intraday_quotes": "adapt_intraday_quotes",
    "money_flow": "adapt_money_flow",
    "margin_trading": "adapt_margin_trading",
    "dragon_tiger": "adapt_dragon_tiger",
    "block_trade": "adapt_block_trade",
}

NORMALIZE_UNSUPPORTED = "unsupported"
NORMALIZE_EMPTY = "empty"
NORMALIZE_ERROR = "error"
NORMALIZE_OK = "ok"

@dataclass
class NormalizeResult:

    records: List[Dict]
    status: str

class Normalizer:

    def normalize(self, raw_data: Any, domain: str, adapter) -> List[Dict]:

        return self.normalize_with_status(raw_data, domain, adapter).records

    def normalize_with_status(
        self, raw_data: Any, domain: str, adapter
    ) -> NormalizeResult:

        method_name = DOMAIN_METHOD_MAP.get(domain)
        if not method_name:
            logger.warning(f"未知域: {domain}")
            return NormalizeResult([], NORMALIZE_UNSUPPORTED)

        method = getattr(adapter, method_name, None)
        if not method:
            logger.warning(f"Adapter {adapter.source_name} 无方法 {method_name}")
            return NormalizeResult([], NORMALIZE_UNSUPPORTED)

        try:
            schemas = method(raw_data)
            if not schemas:
                return NormalizeResult([], NORMALIZE_EMPTY)
            results = []
            for s in schemas:
                if isinstance(s, dict):
                    results.append(s)
                elif hasattr(s, "to_db_doc"):
                    results.append(s.to_db_doc())
                else:
                    logger.warning(
                        f"标准化 {domain} 时跳过无效对象 (type={type(s).__name__})，"
                        f"期望 dict 或含 to_db_doc() 的 Schema 对象"
                    )
            if not results:
                return NormalizeResult([], NORMALIZE_EMPTY)
            return NormalizeResult(results, NORMALIZE_OK)
        except NotImplementedError:
            logger.debug(f"Adapter {adapter.source_name} 不支持 {domain}")
            return NormalizeResult([], NORMALIZE_UNSUPPORTED)
        except Exception as e:
            logger.warning(f"标准化 {domain} 失败 ({adapter.source_name}): {e}")
            return NormalizeResult([], NORMALIZE_ERROR)
