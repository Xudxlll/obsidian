from __future__ import annotations

import logging
from datetime import date, datetime
from typing import Any, Dict, Optional

from app.core.lru_cache import BoundedLRUCache
from app.data.storage.mongo.collections import get_collection_name

logger = logging.getLogger(__name__)

_NOT_FOUND_SENTINEL = -1.0
_DEFAULT_LOOKBACK_DAYS = 5

class PrevCloseLookup:

    def __init__(
        self,
        db: Any,
        market: str,
        cache_size: int = 512,
        cache_ttl: float = 3600.0,
        lookback_days: int = _DEFAULT_LOOKBACK_DAYS,
    ):
        self._db = db
        self._market = market
        self._lookback = max(1, lookback_days)
        self._coll_name = get_collection_name("daily_quotes", market)
        self._cache: BoundedLRUCache = BoundedLRUCache(
            maxsize=cache_size,
            ttl=cache_ttl,
            name=f"prev_close_{market.lower()}",
        )

    async def get(self, symbol: str, ex_date: Any) -> Optional[float]:

        if not symbol or ex_date is None:
            return None

        ex_date_str = _normalize_ex_date(ex_date)
        cache_key = (symbol, ex_date_str)
        cached = self._cache.get(cache_key)
        if cached is not None:
            return float(cached) if cached > 0 else None

        try:
            cursor = self._db[self._coll_name].find(
                {
                    "symbol": symbol,
                    "trade_date": {"$lt": ex_date_str},
                },
                {"close": 1, "trade_date": 1, "_id": 0},
            ).sort("trade_date", -1).limit(self._lookback)
            docs = await cursor.to_list(self._lookback)
        except Exception as exc:
            logger.warning(
                "PrevCloseLookup 查询失败 symbol=%s ex_date=%s: %s",
                symbol,
                ex_date_str,
                exc,
            )
            return None

        for doc in docs:
            close = doc.get("close")
            if close is None:
                continue
            try:
                value = float(close)
            except (TypeError, ValueError):
                continue
            if value > 0:
                self._cache.set(cache_key, value)
                return value

        self._cache.set(cache_key, _NOT_FOUND_SENTINEL)
        return None

    def stats(self) -> Dict[str, Any]:
        return self._cache.stats()

def _normalize_ex_date(ex_date: Any) -> str:

    if isinstance(ex_date, datetime):
        return ex_date.strftime("%Y-%m-%d")
    if isinstance(ex_date, date):
        return ex_date.strftime("%Y-%m-%d")
    text = str(ex_date).strip()
    if len(text) >= 10 and text[4] in ("-", "/"):
        return text[:10].replace("/", "-")
    if len(text) == 8 and text.isdigit():
        return f"{text[:4]}-{text[4:6]}-{text[6:8]}"
    return text[:10] if len(text) >= 10 else text
