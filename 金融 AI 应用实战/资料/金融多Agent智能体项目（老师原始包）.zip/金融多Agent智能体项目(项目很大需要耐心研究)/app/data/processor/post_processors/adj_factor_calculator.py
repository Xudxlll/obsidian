import logging
from typing import TYPE_CHECKING, Dict, List, Optional

if TYPE_CHECKING:
    from app.data.processor.post_processors.prev_close_lookup import PrevCloseLookup

logger = logging.getLogger(__name__)

_ACTION_TYPES_NEED_PREV_CLOSE = frozenset({
    "cash_dividend",
    "special_dividend",
    "rights_issue",
    "share_buyback",
    "capital_reduction",
})

class AdjFactorCalculator:

    def calculate_from_corporate_actions(
        self, actions: List[Dict], base_factor: float = 1.0
    ) -> List[Dict]:

        if not actions:
            return []

        actions = sorted(actions, key=lambda a: str(a.get("ex_date", "")))

        result: List[Dict] = []
        factor = float(base_factor)

        for action in actions:
            action_type = action.get("action_type")
            new_factor = self._apply_single_action(factor, action)
            if new_factor is None:
                logger.warning(
                    "复权因子计算跳过 action_type=%s symbol=%s ex_date=%s "
                    "（字段缺失或为零）",
                    action_type,
                    action.get("symbol"),
                    action.get("ex_date"),
                )
                continue
            factor = new_factor

            result.append({
                "symbol": action.get("symbol"),
                "trade_date": action.get("ex_date"),
                "adj_factor": round(factor, 6),
                "fore_adj_factor": round(factor, 6),
                "market": action.get("market", "US"),
                "data_source": "local_derived",
                "updated_at": action.get("updated_at"),
            })

        _normalize_fore_adj_factor(result)
        return result

    async def calculate_from_corporate_actions_async(
        self,
        actions: List[Dict],
        base_factor: float = 1.0,
        lookup: Optional["PrevCloseLookup"] = None,
    ) -> List[Dict]:

        if not actions:
            return []

        actions = sorted(actions, key=lambda a: str(a.get("ex_date", "")))

        result: List[Dict] = []
        factor = float(base_factor)

        for action in actions:
            action_type = action.get("action_type")

            if (
                lookup is not None
                and action_type in _ACTION_TYPES_NEED_PREV_CLOSE
                and not _has_valid_prev_close(action)
            ):
                symbol = action.get("symbol")
                ex_date = action.get("ex_date")
                prev_close = await lookup.get(symbol, ex_date) if symbol and ex_date else None
                if prev_close is not None:
                    action = {**action, "prev_close": prev_close}

            new_factor = self._apply_single_action(factor, action)
            if new_factor is None:
                logger.warning(
                    "复权因子计算跳过 action_type=%s symbol=%s ex_date=%s "
                    "（字段缺失或为零，prev_close 查询无结果）",
                    action_type,
                    action.get("symbol"),
                    action.get("ex_date"),
                )
                continue
            factor = new_factor

            result.append({
                "symbol": action.get("symbol"),
                "trade_date": action.get("ex_date"),
                "adj_factor": round(factor, 6),
                "fore_adj_factor": round(factor, 6),
                "market": action.get("market", "US"),
                "data_source": "local_derived",
                "updated_at": action.get("updated_at"),
            })

        _normalize_fore_adj_factor(result)
        return result

    def _apply_single_action(
        self, current_factor: float, action: Dict
    ) -> Optional[float]:

        action_type = action.get("action_type")

        if action_type in ("cash_dividend", "special_dividend"):
            return self._apply_cash_dividend(current_factor, action)

        if action_type in ("bonus_issue", "capital_reserve_increase"):
            return self._apply_bonus_issue(current_factor, action)

        if action_type == "rights_issue":
            return self._apply_rights_issue(current_factor, action)

        if action_type in ("share_buyback", "capital_reduction"):
            return self._apply_share_buyback(current_factor, action)

        if action_type in ("stock_split", "reverse_split"):
            return self._apply_stock_split(current_factor, action)

        logger.debug("未知 action_type=%s，复权因子不变", action_type)
        return current_factor

    def _apply_cash_dividend(
        self, current_factor: float, action: Dict
    ) -> Optional[float]:
        amount = action.get("amount", 0) or 0
        prev_close = action.get("prev_close")
        if amount <= 0:
            return current_factor
        if not prev_close or prev_close <= 0:
            return None
        return current_factor * (prev_close - amount) / prev_close

    def _apply_bonus_issue(
        self, current_factor: float, action: Dict
    ) -> Optional[float]:

        ratio_from = action.get("ratio_from") or 0
        ratio_to = action.get("ratio_to") or 0
        if ratio_from <= 0 or ratio_to <= 0:
            return None
        return current_factor * ratio_from / (ratio_from + ratio_to)

    def _apply_rights_issue(
        self, current_factor: float, action: Dict
    ) -> Optional[float]:
        ratio_from = action.get("ratio_from") or 0
        ratio_to = action.get("ratio_to") or 0
        rights_price = action.get("rights_price") or 0
        prev_close = action.get("prev_close")
        if ratio_from <= 0 or ratio_to <= 0 or rights_price <= 0:
            return None
        if not prev_close or prev_close <= 0:
            return None
        numerator = ratio_from * prev_close + ratio_to * rights_price
        denominator = (ratio_from + ratio_to) * prev_close
        if denominator <= 0:
            return None
        return current_factor * numerator / denominator

    def _apply_share_buyback(
        self, current_factor: float, action: Dict
    ) -> Optional[float]:
        ratio_from = action.get("ratio_from") or 0
        ratio_to = action.get("ratio_to") or 0
        buyback_price = action.get("buyback_price") or 0
        prev_close = action.get("prev_close")
        if ratio_from <= 0 or ratio_to <= 0 or buyback_price <= 0:
            return None
        if ratio_from - ratio_to <= 0:
            return None
        if not prev_close or prev_close <= 0:
            return None
        numerator = ratio_from * prev_close - ratio_to * buyback_price
        denominator = (ratio_from - ratio_to) * prev_close
        if denominator <= 0:
            return None
        return current_factor * numerator / denominator

    def _apply_stock_split(
        self, current_factor: float, action: Dict
    ) -> Optional[float]:

        ratio_from = action.get("ratio_from") or 0
        ratio_to = action.get("ratio_to") or 0
        if ratio_from <= 0 or ratio_to <= 0:
            return None
        return current_factor * ratio_to / ratio_from

def _has_valid_prev_close(action: Dict) -> bool:
    value = action.get("prev_close")
    if value is None:
        return False
    try:
        return float(value) > 0
    except (TypeError, ValueError):
        return False

def _normalize_fore_adj_factor(result: List[Dict]) -> None:

    if not result:
        return
    latest = result[-1].get("fore_adj_factor") or 0.0
    if latest <= 0:
        logger.warning(
            "fore_adj_factor 归一化跳过：最新一日因子非正 (%s)，symbol=%s",
            latest,
            result[-1].get("symbol"),
        )
        return
    norm = 1.0 / float(latest)
    for row in result:
        raw = row.get("fore_adj_factor") or 0.0
        row["fore_adj_factor"] = round(float(raw) * norm, 6)
