import logging
import threading
import time
from collections import deque
from datetime import datetime, timezone
from typing import Deque, Dict, List, Optional, Tuple

from app.data.storage.mongo.repositories.metadata_repo import MetadataRepo

logger = logging.getLogger(__name__)

_WINDOW_SECONDS = 3600
_MAX_EVENTS_PER_KEY = 10000

class SourceHealthMonitor:

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        self._stats: Dict[str, Dict] = {}
        self._events: Dict[str, Deque[Tuple[float, bool, int]]] = {}
        self._stats_lock = threading.Lock()
        self._repo = MetadataRepo()
        self._flush_interval = 30
        self._flush_thread: Optional[threading.Thread] = None
        self._running = False

    def start(self):
        self._running = True
        self._flush_thread = threading.Thread(target=self._flush_loop, daemon=True)
        self._flush_thread.start()
        logger.info("健康监控已启动")

    def stop(self):
        self._running = False
        self._flush_to_mongo()

    def record_call(
        self,
        market: str,
        source: str,
        domain: str,
        success: bool,
        latency_ms: int = 0,
        error: Optional[str] = None,
        circuit_state: str = "closed",
    ):
        key = f"{market}:{source}:{domain}"
        now = time.time()
        with self._stats_lock:
            if key not in self._stats:
                self._stats[key] = {
                    "market": market,
                    "source": source,
                    "domain": domain,
                    "success_count": 0,
                    "failure_count": 0,
                    "total_latency_ms": 0,
                    "call_count": 0,
                    "last_success_at": None,
                    "last_failure_at": None,
                    "last_error": None,
                    "consecutive_failures": 0,
                    "circuit_state": "closed",
                }
                self._events[key] = deque(maxlen=_MAX_EVENTS_PER_KEY)

            s = self._stats[key]
            s["call_count"] += 1
            s["total_latency_ms"] += latency_ms
            s["circuit_state"] = circuit_state
            if circuit_state == "open":
                s["open_count"] = s.get("open_count", 0) + 1

            if success:
                s["success_count"] += 1
                s["last_success_at"] = datetime.now(timezone.utc).isoformat()
                s["consecutive_failures"] = 0
            else:
                s["failure_count"] += 1
                s["last_failure_at"] = datetime.now(timezone.utc).isoformat()
                s["consecutive_failures"] = s.get("consecutive_failures", 0) + 1
                if error:
                    s["last_error"] = error

            events = self._events[key]
            events.append((now, success, latency_ms))
            cutoff = now - _WINDOW_SECONDS
            while events and events[0][0] < cutoff:
                events.popleft()

    def get_health(self, market: str, source: str, domain: str) -> Optional[Dict]:
        key = f"{market}:{source}:{domain}"
        with self._stats_lock:
            stats = self._stats.get(key)
            if not stats:
                return None
            stats_copy = dict(stats)
            events_copy = list(self._events.get(key, ()))
        return self._compute_health(stats_copy, events_copy)

    def get_all_health(self, market: Optional[str] = None) -> List[Dict]:
        results = []
        with self._stats_lock:
            snapshots = []
            for key, stats in self._stats.items():
                if market and stats["market"] != market:
                    continue
                snapshots.append((dict(stats), list(self._events.get(key, ()))))
        for stats_copy, events_copy in snapshots:
            results.append(self._compute_health(stats_copy, events_copy))
        return results

    def _compute_health(self, stats: Dict, events: list) -> Dict:

        total = stats["success_count"] + stats["failure_count"]
        success_rate = stats["success_count"] / total if total > 0 else 0.0
        avg_latency = (
            stats["total_latency_ms"] / stats["call_count"]
            if stats["call_count"] > 0
            else 0
        )

        window_success = 0
        window_total = 0
        window_latency_sum = 0
        if events:
            now = time.time()
            cutoff = now - _WINDOW_SECONDS
            for ts, ok, lat in events:
                if ts >= cutoff:
                    window_total += 1
                    if ok:
                        window_success += 1
                    window_latency_sum += lat
        success_rate_1h = (
            window_success / window_total if window_total > 0 else 0.0
        )
        avg_latency_1h = (
            window_latency_sum / window_total if window_total > 0 else 0.0
        )

        return {
            "market": stats["market"],
            "source": stats["source"],
            "domain": stats["domain"],
            "circuit_state": stats.get("circuit_state", "closed"),
            "success_rate": round(success_rate, 4),
            "success_rate_1h": round(success_rate_1h, 4),
            "success_rate_total": round(success_rate, 4),
            "success_count": stats["success_count"],
            "failure_count": stats["failure_count"],
            "avg_latency_ms": round(avg_latency, 1),
            "avg_latency_1h": round(avg_latency_1h, 1),
            "avg_latency_total": round(avg_latency, 1),
            "total_calls": stats["call_count"],
            "total_calls_1h": window_total,
            "consecutive_failures": stats.get("consecutive_failures", 0),
            "open_count": stats.get("open_count", 0),
            "last_success_at": stats["last_success_at"],
            "last_failure_at": stats["last_failure_at"],
            "last_error": stats["last_error"],
        }

    def _flush_loop(self):
        while self._running:
            time.sleep(self._flush_interval)
            try:
                self._flush_to_mongo()
            except Exception as e:
                logger.error(f"健康度刷入失败: {e}")

    def _flush_to_mongo(self):

        if not self._stats:
            return

        async def _do_flush():
            with self._stats_lock:
                snapshots = [
                    (dict(s), list(self._events.get(k, ())))
                    for k, s in self._stats.items()
                ]
            for stats_copy, events_copy in snapshots:
                health = self._compute_health(stats_copy, events_copy)
                try:
                    await self._repo.upsert_health(
                        stats_copy["market"],
                        stats_copy["source"],
                        stats_copy["domain"],
                        health,
                    )
                except Exception as e:
                    logger.debug(f"刷入健康度失败: {e}")

        try:
            from app.core.async_utils import run_async, get_main_loop

            main_loop = get_main_loop()
            if main_loop is None or not main_loop.is_running():
                return
            run_async(_do_flush())
        except Exception as e:
            logger.debug(f"健康度刷入失败: {e}")
