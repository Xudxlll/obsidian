import logging
import re
from typing import Any, Dict, List, Optional, Tuple

from app.data.storage.mongo.client import get_motor_db
from app.data.storage.mongo.collections import get_collection_name

logger = logging.getLogger(__name__)

_BASIC_INFO_FIELDS = {
    "symbol", "code", "name", "industry", "area", "market", "list_date",
}

_INDICATOR_FIELDS = {
    "total_mv", "circ_mv", "market_cap",
    "pe", "pb", "pe_ttm", "pb_mrq",
    "turnover_rate", "volume_ratio",
    "roe",
}

_QUOTE_FIELDS = {
    "pct_chg", "amount", "close", "volume",
}

_INDICATOR_FIELD_MAP = {
    "total_mv": "total_mv",
    "circ_mv": "circ_mv",
    "market_cap": "total_mv",
    "pe": "pe_ttm",
    "pb": "pb",
    "pe_ttm": "pe_ttm",
    "pb_mrq": "pb_mrq",
    "turnover_rate": "turnover_rate",
    "volume_ratio": "volume_ratio",
    "roe": "roe",
}

class ScreeningQueryService:

    _ALL_SUPPORTED_FIELDS = _BASIC_INFO_FIELDS | _INDICATOR_FIELDS | _QUOTE_FIELDS

    _OPERATORS = {
        ">": "$gt",
        "<": "$lt",
        ">=": "$gte",
        "<=": "$lte",
        "==": "$eq",
        "!=": "$ne",
        "in": "$in",
        "not_in": "$nin",
        "contains": "$regex",
    }

    async def screen_stocks(
        self,
        conditions: List[Dict[str, Any]],
        limit: int = 50,
        offset: int = 0,
        order_by: Optional[List[Dict[str, str]]] = None,
        source: Optional[str] = None,
    ) -> Tuple[List[Dict[str, Any]], int]:
        try:
            db = get_motor_db()
            if not source:
                source = await self._resolve_preferred_source()
            logger.info(f"[database_screening] 使用数据源: {source}")

            basic_conds, indicator_conds, quote_conds = self._classify_conditions(conditions)
            basic_coll = db[get_collection_name("basic_info", "CN")]
            indicator_coll = db[get_collection_name("daily_indicators", "CN")]

            matched_symbols: Optional[List[str]] = None

            if indicator_conds:
                indicator_symbols = await self._query_indicators(
                    indicator_coll, indicator_conds, source
                )
                matched_symbols = indicator_symbols
                logger.info(f"[阶段1a] indicators 匹配 {len(indicator_symbols)} 只股票")

            if basic_conds:
                basic_symbols = await self._query_basic_info(basic_coll, basic_conds, source)
                logger.info(f"[阶段1b] basic_info 匹配 {len(basic_symbols)} 只股票")
                if matched_symbols is not None:
                    basic_set = set(basic_symbols)
                    matched_symbols = [s for s in matched_symbols if s in basic_set]
                else:
                    matched_symbols = basic_symbols

            if matched_symbols is not None and len(matched_symbols) == 0:
                logger.info("[database_screening] 无匹配股票，返回空")
                return [], 0

            basic_map = await self._fetch_basic_info(basic_coll, matched_symbols, source)
            logger.info(f"[阶段2] basic_info 获取 {len(basic_map)} 条记录")

            final_symbols = (
                matched_symbols if matched_symbols is not None else list(basic_map.keys())
            )

            quotes_coll = db[get_collection_name("market_quotes", "CN")]
            quotes_map = await self._fetch_quotes(quotes_coll, final_symbols, quote_conds)
            logger.info(f"[阶段3] market_quotes 获取 {len(quotes_map)} 条记录")

            indicators_map = await self._fetch_latest_indicators(
                indicator_coll, final_symbols, source
            )
            logger.info(f"[阶段3.5] daily_indicators 获取 {len(indicators_map)} 条记录")

            financial_coll = db[get_collection_name("financial_data", "CN")]
            roe_map = await self._fetch_latest_roe(financial_coll, final_symbols, source)
            logger.info(f"[阶段4] financial_data ROE 获取 {len(roe_map)} 条记录")

            results = self._merge_results(
                final_symbols, basic_map, indicators_map, quotes_map, source, roe_map
            )

            results = self._sort_results(results, order_by)

            total_count = len(results)
            page_items = results[offset: offset + limit]

            logger.info(
                f"[database_screening] 完成: total={total_count}, "
                f"返回={len(page_items)}, 数据源={source}"
            )
            return page_items, total_count

        except Exception as e:
            logger.error(f"[database_screening] 筛选失败: {e}", exc_info=True)
            raise RuntimeError(f"数据库筛选失败: {str(e)}") from e

    async def screen(
        self,
        market: str,
        stage: str,
        filters: Optional[Dict] = None,
        projection: Optional[Dict] = None,
        sort: Optional[List[Tuple[str, int]]] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> Dict:

        db = get_motor_db()
        coll = db[get_collection_name(stage, market)]

        proj = dict(projection) if projection else {"_id": 0}
        if "_id" not in proj:
            proj["_id"] = 0

        query = dict(filters) if filters else {}
        cursor = coll.find(query, proj)
        if sort:
            cursor = cursor.sort(sort)
        if skip > 0:
            cursor = cursor.skip(skip)
        if limit and limit > 0:
            cursor = cursor.limit(limit)

        items = await cursor.to_list(length=None)
        total = await coll.count_documents(query)
        return {"items": items, "total": total}

    async def _resolve_preferred_source(self) -> str:
        from app.data.core.registry.priority import PriorityConfig
        pc = PriorityConfig()
        enabled_sources = await pc.get_priority("CN", "basic_info")
        return enabled_sources[0] if enabled_sources else "tushare"

    async def can_handle_conditions(self, conditions: List[Dict[str, Any]]) -> bool:
        for condition in conditions:
            field = condition.get("field") if isinstance(condition, dict) else condition.field
            operator = condition.get("operator") if isinstance(condition, dict) else condition.operator
            if field not in self._ALL_SUPPORTED_FIELDS:
                logger.debug(f"字段 {field} 不支持数据库筛选")
                return False
            if operator not in self._OPERATORS and operator != "between":
                logger.debug(f"操作符 {operator} 不支持数据库筛选")
                return False
        return True

    def _classify_conditions(
        self, conditions: List[Dict[str, Any]]
    ) -> Tuple[List[Dict], List[Dict], List[Dict]]:
        basic_conds, indicator_conds, quote_conds = [], [], []
        for cond in conditions:
            field = cond.get("field") if isinstance(cond, dict) else cond.field
            if field in _BASIC_INFO_FIELDS:
                basic_conds.append(cond)
            elif field in _INDICATOR_FIELDS:
                indicator_conds.append(cond)
            elif field in _QUOTE_FIELDS:
                quote_conds.append(cond)
            else:
                logger.warning(f"未知字段 {field}，归入 indicator 条件")
                indicator_conds.append(cond)
        return basic_conds, indicator_conds, quote_conds

    async def _query_indicators(
        self, coll, conditions: List[Dict], source: str
    ) -> Optional[List[str]]:

        if not conditions:
            return None

        match_doc = self._build_indicator_match(conditions)

        pipeline = [
            {"$match": {"data_source": source}},
            {"$sort": {"symbol": 1, "trade_date": -1}},
            {"$group": {
                "_id": "$symbol",
                "symbol": {"$first": "$symbol"},
                "trade_date": {"$first": "$trade_date"},
                "pe_ttm": {"$first": "$pe_ttm"},
                "pb": {"$first": "$pb"},
                "total_mv": {"$first": "$total_mv"},
                "circ_mv": {"$first": "$circ_mv"},
                "turnover_rate": {"$first": "$turnover_rate"},
                "volume_ratio": {"$first": "$volume_ratio"},
                "roe": {"$first": "$roe"},
            }},
            {"$match": match_doc},
            {"$project": {"symbol": 1, "_id": 0}},
        ]

        symbols = []
        async for doc in coll.aggregate(pipeline):
            s = doc.get("symbol")
            if s:
                symbols.append(s)
        return symbols

    def _build_indicator_match(self, conditions: List[Dict]) -> Dict[str, Any]:

        match: Dict[str, Any] = {}
        for cond in conditions:
            field = cond.get("field") if isinstance(cond, dict) else cond.field
            operator = cond.get("operator") if isinstance(cond, dict) else cond.operator
            value = cond.get("value") if isinstance(cond, dict) else cond.value

            db_field = _INDICATOR_FIELD_MAP.get(field, field)

            if db_field == "total_mv" and value is not None:
                if isinstance(value, list):
                    value = [v * 1e8 if isinstance(v, (int, float)) else v for v in value]
                elif isinstance(value, (int, float)):
                    value = value * 1e8

            self._apply_condition(match, db_field, operator, value)
        return match

    async def _query_basic_info(
        self, coll, conditions: List[Dict], source: str
    ) -> Optional[List[str]]:
        if not conditions:
            return None

        query: Dict[str, Any] = {"data_source": source}
        for cond in conditions:
            field = cond.get("field") if isinstance(cond, dict) else cond.field
            operator = cond.get("operator") if isinstance(cond, dict) else cond.operator
            value = cond.get("value") if isinstance(cond, dict) else cond.value

            db_field = "symbol" if field == "code" else field
            self._apply_condition(query, db_field, operator, value)

        symbols = []
        cursor = coll.find(query, {"symbol": 1, "_id": 0})
        async for doc in cursor:
            s = doc.get("symbol")
            if s:
                symbols.append(s)
        return symbols

    async def _fetch_basic_info(
        self, coll, symbols: Optional[List[str]], source: str
    ) -> Dict[str, Dict]:
        query: Dict[str, Any] = {"data_source": source}
        if symbols is not None:
            query["symbol"] = {"$in": symbols}

        result_map: Dict[str, Dict] = {}
        cursor = coll.find(query, {"_id": 0})
        async for doc in cursor:
            s = doc.get("symbol")
            if s:
                result_map[s] = doc
        return result_map

    async def _fetch_quotes(
        self, coll, symbols: Optional[List[str]],
        quote_conditions: List[Dict],
    ) -> Dict[str, Dict]:
        if symbols is None:
            return {}

        query: Dict[str, Any] = {"symbol": {"$in": symbols}}
        cursor = coll.find(query, {"_id": 0})
        quotes_map: Dict[str, Dict] = {}
        async for doc in cursor:
            s = doc.get("symbol")
            if s:
                quotes_map[s] = {
                    "close": doc.get("close") or doc.get("last_price"),
                    "pct_chg": doc.get("pct_chg"),
                    "amount": doc.get("amount"),
                    "volume": doc.get("volume") or doc.get("last_volume"),
                }

        if quote_conditions:
            filtered: Dict[str, Dict] = {}
            for sym, qd in quotes_map.items():
                if self._check_quote_conditions(qd, quote_conditions):
                    filtered[sym] = qd
            return filtered

        return quotes_map

    def _check_quote_conditions(
        self, quote_data: Dict, conditions: List[Dict]
    ) -> bool:
        for cond in conditions:
            field = cond.get("field") if isinstance(cond, dict) else cond.field
            operator = cond.get("operator") if isinstance(cond, dict) else cond.operator
            value = cond.get("value") if isinstance(cond, dict) else cond.value
            fv = quote_data.get(field)
            if fv is None:
                return False
            if not self._compare(fv, operator, value):
                return False
        return True

    async def _fetch_latest_indicators(
        self, coll, symbols: Optional[List[str]], source: str
    ) -> Dict[str, Dict]:
        if symbols is not None and not symbols:
            return {}

        match_stage: Dict[str, Any] = {"data_source": source}
        if symbols is not None:
            match_stage["symbol"] = {"$in": symbols}

        pipeline = [
            {"$match": match_stage},
            {"$sort": {"trade_date": -1}},
            {"$group": {
                "_id": "$symbol",
                "total_mv": {"$first": "$total_mv"},
                "circ_mv": {"$first": "$circ_mv"},
                "pe_ttm": {"$first": "$pe_ttm"},
                "pb": {"$first": "$pb"},
                "turnover_rate": {"$first": "$turnover_rate"},
                "volume_ratio": {"$first": "$volume_ratio"},
                "roe": {"$first": "$roe"},
            }},
        ]

        result_map: Dict[str, Dict] = {}
        async for doc in coll.aggregate(pipeline):
            s = doc.get("_id")
            if s:
                result_map[s] = {
                    "total_mv": doc.get("total_mv"),
                    "circ_mv": doc.get("circ_mv"),
                    "pe_ttm": doc.get("pe_ttm"),
                    "pb": doc.get("pb"),
                    "turnover_rate": doc.get("turnover_rate"),
                    "volume_ratio": doc.get("volume_ratio"),
                    "roe": doc.get("roe"),
                }
        return result_map

    async def _fetch_latest_roe(
        self, coll, symbols: Optional[List[str]], source: str
    ) -> Dict[str, float]:
        if symbols is not None and not symbols:
            return {}

        match_stage: Dict[str, Any] = {
            "roe": {"$exists": True, "$ne": None},
        }
        if symbols is not None:
            match_stage["symbol"] = {"$in": symbols}
        if source:
            match_stage["data_source"] = source

        pipeline = [
            {"$match": match_stage},
            {"$sort": {"report_period": -1}},
            {"$group": {
                "_id": "$symbol",
                "roe": {"$first": "$roe"},
            }},
        ]

        result_map: Dict[str, float] = {}
        async for doc in coll.aggregate(pipeline):
            s = doc.get("_id")
            if s:
                result_map[s] = doc.get("roe")
        return result_map

    def _merge_results(
        self,
        symbols: Optional[List[str]],
        basic_map: Dict[str, Dict],
        indicators_map: Dict[str, Dict],
        quotes_map: Dict[str, Dict],
        source: str,
        roe_map: Optional[Dict[str, float]] = None,
    ) -> List[Dict[str, Any]]:
        results: List[Dict[str, Any]] = []

        symbol_list = symbols if symbols is not None else list(basic_map.keys())

        for sym in symbol_list:
            bi = basic_map.get(sym, {})
            ind = indicators_map.get(sym, {})
            q = quotes_map.get(sym, {})

            raw_total_mv = ind.get("total_mv")
            raw_circ_mv = ind.get("circ_mv")
            total_mv_yi = round(raw_total_mv / 1e8, 2) if isinstance(raw_total_mv, (int, float)) else None
            circ_mv_yi = round(raw_circ_mv / 1e8, 2) if isinstance(raw_circ_mv, (int, float)) else None

            roe_value = None
            if roe_map:
                roe_value = roe_map.get(sym)
            if roe_value is None:
                roe_value = ind.get("roe")

            results.append({
                "symbol": sym,
                "name": bi.get("name"),
                "industry": bi.get("industry"),
                "area": bi.get("area"),
                "market": "A股",
                "board": bi.get("market"),
                "exchange": bi.get("exchange"),
                "list_date": bi.get("list_date"),

                "total_mv": total_mv_yi,
                "circ_mv": circ_mv_yi,
                "pe": ind.get("pe_ttm"),
                "pb": ind.get("pb"),
                "pe_ttm": ind.get("pe_ttm"),
                "pb_mrq": None,
                "roe": roe_value,
                "turnover_rate": ind.get("turnover_rate"),
                "volume_ratio": ind.get("volume_ratio"),

                "close": q.get("close"),
                "pct_chg": q.get("pct_chg"),
                "amount": q.get("amount"),
                "volume": q.get("volume"),

                "ma20": None,
                "rsi14": None,
                "kdj_k": None,
                "kdj_d": None,
                "kdj_j": None,
                "dif": None,
                "dea": None,
                "macd_hist": None,

                "data_source": source,
                "updated_at": bi.get("updated_at"),
            })

        return results

    def _sort_results(
        self, results: List[Dict[str, Any]], order_by: Optional[List[Dict[str, str]]]
    ) -> List[Dict[str, Any]]:
        if not order_by:
            return results

        for order in reversed(order_by):
            field = order.get("field", "")
            direction = order.get("direction", "desc").lower()

            db_field = _INDICATOR_FIELD_MAP.get(field, field)
            if direction == "desc":
                results.sort(
                    key=lambda x, _f=db_field: (
                        x.get(_f) is None,
                        -(x.get(_f) or 0),
                    ),
                )
            else:
                results.sort(
                    key=lambda x, _f=db_field: (
                        x.get(_f) is None,
                        x.get(_f) if x.get(_f) is not None else 0,
                    ),
                )
        return results

    async def get_field_statistics(self, field: str) -> Dict[str, Any]:
        try:
            db = get_motor_db()

            if field in _INDICATOR_FIELDS:
                db_field = _INDICATOR_FIELD_MAP.get(field, field)
                coll = db[get_collection_name("daily_indicators", "CN")]
                pipeline = [
                    {"$match": {db_field: {"$exists": True, "$ne": None}}},
                    {"$sort": {"trade_date": -1}},
                    {"$group": {
                        "_id": "$symbol",
                        db_field: {"$first": f"${db_field}"},
                    }},
                    {"$group": {
                        "_id": None,
                        "min": {"$min": f"${db_field}"},
                        "max": {"$max": f"${db_field}"},
                        "avg": {"$avg": f"${db_field}"},
                        "count": {"$sum": 1},
                    }},
                ]
            elif field in _BASIC_INFO_FIELDS:
                coll = db[get_collection_name("basic_info", "CN")]
                db_field = field if field != "code" else "symbol"
                pipeline = [
                    {"$match": {db_field: {"$exists": True, "$ne": None}}},
                    {"$group": {
                        "_id": None,
                        "min": {"$min": f"${db_field}"},
                        "max": {"$max": f"${db_field}"},
                        "avg": {"$avg": f"${db_field}"},
                        "count": {"$sum": 1},
                    }},
                ]
            else:
                return {}

            result = await coll.aggregate(pipeline).to_list(length=1)
            if result:
                stats = result[0]
                avg_value = stats.get("avg")
                return {
                    "field": field,
                    "min": stats.get("min"),
                    "max": stats.get("max"),
                    "avg": round(avg_value, 2) if isinstance(avg_value, (int, float)) else None,
                    "count": stats.get("count", 0),
                }
            return {"field": field, "count": 0}

        except Exception as e:
            logger.error(f"获取字段统计失败: {e}")
            return {"field": field, "error": str(e)}

    async def get_available_values(self, field: str, limit: int = 100) -> List[str]:
        try:
            if field in _BASIC_INFO_FIELDS:
                db = get_motor_db()
                coll = db[get_collection_name("basic_info", "CN")]
                db_field = field if field != "code" else "symbol"
                values = await coll.distinct(db_field)
                values = [v for v in values if v is not None]
                values.sort()
                return values[:limit]
            return []
        except Exception as e:
            logger.error(f"获取字段可选值失败: {e}")
            return []

    def _apply_condition(
        self, query: Dict[str, Any], db_field: str, operator: str, value: Any
    ) -> None:
        if operator == "between":
            if isinstance(value, list) and len(value) == 2:
                if db_field in query:
                    query[db_field].update({"$gte": value[0], "$lte": value[1]})
                else:
                    query[db_field] = {"$gte": value[0], "$lte": value[1]}
        elif operator == "contains":
            safe_value = re.escape(str(value))
            if db_field in query:
                query[db_field].update({"$regex": safe_value, "$options": "i"})
            else:
                query[db_field] = {"$regex": safe_value, "$options": "i"}
        elif operator in self._OPERATORS:
            mongo_op = self._OPERATORS[operator]
            if db_field in query:
                query[db_field][mongo_op] = value
            else:
                query[db_field] = {mongo_op: value}

    @staticmethod
    def _compare(field_value: Any, operator: str, value: Any) -> bool:
        try:
            if operator == "between" and isinstance(value, list) and len(value) == 2:
                return value[0] <= field_value <= value[1]
            elif operator == ">":
                return field_value > value
            elif operator == "<":
                return field_value < value
            elif operator == ">=":
                return field_value >= value
            elif operator == "<=":
                return field_value <= value
            elif operator == "==":
                return field_value == value
            elif operator == "!=":
                return field_value != value
            elif operator == "in":
                return isinstance(value, list) and field_value in value
            elif operator == "not_in":
                return isinstance(value, list) and field_value not in value
        except (TypeError, ValueError):
            return False
        return True

_screening_query_service: Optional[ScreeningQueryService] = None

def get_screening_query_service() -> ScreeningQueryService:
    global _screening_query_service
    if _screening_query_service is None:
        _screening_query_service = ScreeningQueryService()
    return _screening_query_service
