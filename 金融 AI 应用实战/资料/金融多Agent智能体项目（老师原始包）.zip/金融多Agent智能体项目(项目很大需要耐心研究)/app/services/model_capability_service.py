from typing import Tuple, Dict, Optional, Any
from app.constants.model_capabilities import (
    DEFAULT_MODEL_CAPABILITIES,
    ModelRole,
    ModelFeature
)
import logging

logger = logging.getLogger(__name__)

class ModelCapabilityService:

    @staticmethod
    def _get_llm_configs_from_db() -> list:
        try:
            from app.core.database import get_mongo_db_sync
            from app.models.config import LLMConfig
            db = get_mongo_db_sync()
            doc = db.system_configs.find_one({"is_active": True}, sort=[("version", -1)])
            if doc and "llm_configs" in doc:
                result = []
                for c in doc["llm_configs"]:
                    try:
                        result.append(LLMConfig(**c))
                    except Exception as e:
                        logger.debug(f"解析LLM配置失败: {e}")
                        continue
                return result
        except Exception as e:
            logger.warning(f"从 DB 读取 LLM 配置失败: {e}")
        return []

    @staticmethod
    def _get_system_setting(key: str, default: str = "") -> str:
        try:
            from app.core.database import get_mongo_db_sync
            db = get_mongo_db_sync()
            doc = db.system_configs.find_one({"is_active": True}, sort=[("version", -1)])
            settings = (doc or {}).get("system_settings", {})
            return settings.get(key, default)
        except Exception as e:
            logger.debug(f"获取系统设置失败: {e}")
            return default

    def _parse_aggregator_model_name(self, model_name: str) -> Tuple[Optional[str], str]:

        if "/" in model_name:
            parts = model_name.split("/", 1)
            if len(parts) == 2:
                provider_hint = parts[0].lower()
                original_model = parts[1]

                provider_map = {
                    "openai": "openai",
                    "anthropic": "anthropic",
                    "google": "google",
                    "deepseek": "deepseek",
                    "alibaba": "qwen",
                    "qwen": "qwen",
                    "zhipu": "zhipu",
                    "baidu": "baidu",
                    "moonshot": "moonshot"
                }

                provider = provider_map.get(provider_hint)
                return provider, original_model

        return None, model_name

    def _get_model_capability_with_mapping(self, model_name: str) -> Tuple[int, Optional[str]]:

        if model_name in DEFAULT_MODEL_CAPABILITIES:
            return DEFAULT_MODEL_CAPABILITIES[model_name]["capability_level"], None

        provider, original_model = self._parse_aggregator_model_name(model_name)

        if original_model and original_model != model_name:
            if original_model in DEFAULT_MODEL_CAPABILITIES:
                logger.info(f"🔄 聚合渠道模型映射: {model_name} -> {original_model}")
                return DEFAULT_MODEL_CAPABILITIES[original_model]["capability_level"], original_model

        return 2, None

    def get_model_capability(self, model_name: str) -> int:

        try:
            llm_configs = self._get_llm_configs_from_db()
            for config in llm_configs:
                if config.model_name == model_name:
                    return getattr(config, 'capability_level', 2)
        except Exception as e:
            logger.warning(f"从配置读取模型能力失败: {e}")

        capability, mapped_model = self._get_model_capability_with_mapping(model_name)
        if mapped_model:
            logger.info(f"✅ 使用映射模型 {mapped_model} 的能力等级: {capability}")

        return capability

    def get_model_config(self, model_name: str) -> Dict[str, Any]:

        try:
            from app.core.database import get_mongo_db_sync

            db = get_mongo_db_sync()
            collection = db.system_configs

            doc = collection.find_one({"is_active": True}, sort=[("version", -1)])

            if doc and "llm_configs" in doc:
                llm_configs = doc["llm_configs"]

                for config_dict in llm_configs:
                    if config_dict.get("model_name") == model_name:
                        features_str = config_dict.get('features', [])
                        features_enum = []
                        for feature_str in features_str:
                            try:
                                features_enum.append(ModelFeature(feature_str))
                            except ValueError:
                                logger.warning(f"⚠️ 未知的特性值: {feature_str}")

                        roles_str = config_dict.get('suitable_roles', ["both"])
                        roles_enum = []
                        for role_str in roles_str:
                            try:
                                roles_enum.append(ModelRole(role_str))
                            except ValueError:
                                logger.warning(f"⚠️ 未知的角色值: {role_str}")

                        if not roles_enum:
                            roles_enum = [ModelRole.BOTH]

                        return {
                            "model_name": config_dict.get("model_name"),
                            "capability_level": config_dict.get('capability_level', 2),
                            "suitable_roles": roles_enum,
                            "features": features_enum,
                            "performance_metrics": config_dict.get('performance_metrics', None)
                        }

        except Exception as e:
            logger.warning(f"从 MongoDB 读取模型信息失败: {e}", exc_info=True)

        if model_name in DEFAULT_MODEL_CAPABILITIES:
            return DEFAULT_MODEL_CAPABILITIES[model_name]

        provider, original_model = self._parse_aggregator_model_name(model_name)
        if original_model and original_model != model_name:
            if original_model in DEFAULT_MODEL_CAPABILITIES:
                logger.info(f"🔄 聚合渠道模型映射: {model_name} -> {original_model}")
                config = DEFAULT_MODEL_CAPABILITIES[original_model].copy()
                config["model_name"] = model_name
                config["_mapped_from"] = original_model
                return config

        logger.warning(f"未找到模型 {model_name} 的配置，使用默认配置")
        return {
            "model_name": model_name,
            "capability_level": 2,
            "suitable_roles": [ModelRole.BOTH],
            "features": [ModelFeature.TOOL_CALLING],
            "performance_metrics": {"speed": 3, "cost": 3, "quality": 3}
        }

    def validate_model_pair(
        self,
        analyst_model: str,
        debate_model: str,
    ) -> Dict[str, Any]:

        logger.info(f"🔍 开始验证模型对: analyst={analyst_model}, debate={debate_model}")

        analyst_config = self.get_model_config(analyst_model)
        debate_config = self.get_model_config(debate_model)

        result = {
            "valid": True,
            "warnings": [],
            "recommendations": []
        }

        analyst_roles = analyst_config.get("suitable_roles", [])
        if ModelRole.ANALYST not in analyst_roles and ModelRole.BOTH not in analyst_roles:
            result["warnings"].append(
                f"💡 模型 {analyst_model} 不是为一阶段分析优化的，可能影响数据收集效率"
            )

        analyst_features = analyst_config.get("features", [])
        if ModelFeature.TOOL_CALLING not in analyst_features:
            result["valid"] = False
            result["warnings"].append(
                f"❌ 分析师模型 {analyst_model} 不支持工具调用，无法完成数据收集任务"
            )

        debate_roles = debate_config.get("suitable_roles", [])
        if ModelRole.DEBATE not in debate_roles and ModelRole.BOTH not in debate_roles:
            result["warnings"].append(
                f"💡 模型 {debate_model} 不是为辩论推理优化的，可能影响分析质量"
            )

        debate_level = debate_config.get("capability_level", 2)
        if debate_level < 2:
            result["valid"] = False
            result["warnings"].append(
                f"❌ 辩论模型 {debate_model} (能力等级{debate_level}) 不满足最低要求(等级2)"
            )
            result["recommendations"].append(self._recommend_model("debate", 2))

        logger.info(f"🔍 验证结果: valid={result['valid']}, warnings={len(result['warnings'])}条")

        return result

    def recommend_models(self) -> Tuple[str, str]:

        try:
            llm_configs = self._get_llm_configs_from_db()
            enabled_models = [c for c in llm_configs if c.enabled]
        except Exception as e:
            logger.error(f"获取模型配置失败: {e}")
            return "", ""

        if not enabled_models:
            logger.warning("未添加任何启用的模型，无法推荐默认模型")
            return "", ""

        enabled_names = {m.model_name for m in enabled_models}

        settings_analyst = self._get_system_setting("analyst_model", "")
        settings_debate = self._get_system_setting("debate_model", "")

        analyst_model = settings_analyst if settings_analyst in enabled_names else ""
        debate_model = settings_debate if settings_debate in enabled_names else ""

        if not analyst_model:
            for m in enabled_models:
                roles = getattr(m, 'suitable_roles', [ModelRole.BOTH]) or [ModelRole.BOTH]
                if ModelRole.ANALYST in roles or ModelRole.BOTH in roles:
                    analyst_model = m.model_name
                    break

        if not debate_model:
            for m in enabled_models:
                roles = getattr(m, 'suitable_roles', [ModelRole.BOTH]) or [ModelRole.BOTH]
                if ModelRole.DEBATE in roles or ModelRole.BOTH in roles:
                    debate_model = m.model_name
                    break

        if not analyst_model:
            analyst_model = enabled_models[0].model_name
        if not debate_model:
            debate_model = enabled_models[0].model_name

        logger.info(
            f"🤖 推荐模型: analyst={analyst_model} (一阶段分析), debate={debate_model} (辩论推理)"
        )

        return analyst_model, debate_model

    def _get_default_models(self) -> Tuple[str, str]:
        analyst_model = self._get_system_setting("analyst_model", "")
        debate_model = self._get_system_setting("debate_model", "")
        if analyst_model or debate_model:
            logger.info(f"使用系统设置指定的模型: analyst={analyst_model}, debate={debate_model}")
        return analyst_model, debate_model

    def _recommend_model(self, model_type: str, min_level: int) -> str:
        try:
            llm_configs = self._get_llm_configs_from_db()
            for config in llm_configs:
                if config.enabled and getattr(config, 'capability_level', 2) >= min_level:
                    display_name = config.model_display_name or config.model_name
                    return f"建议使用: {display_name}"
        except Exception as e:
            logger.warning(f"推荐模型失败: {e}")

        return "建议升级模型配置"

_model_capability_service = None

def get_model_capability_service() -> ModelCapabilityService:
    global _model_capability_service
    if _model_capability_service is None:
        _model_capability_service = ModelCapabilityService()
    return _model_capability_service
