import logging
from typing import Dict, List

from app.data.core.interface import DataInterface

logger = logging.getLogger(__name__)

async def get_quality_overview(market: str, domains: List[str]) -> Dict[str, Dict]:

    di = DataInterface.get_instance()
    return await di.get_quality_overview(market, domains)

async def check_domain_quality(market: str, domain: str) -> Dict:
    di = DataInterface.get_instance()
    return await di.check_domain_quality(market, domain)
