import logging
from typing import List, Optional, Dict, Any
from datetime import datetime
from bson import ObjectId

from app.core.database import get_mongo_db
from app.utils.timezone import now_utc

logger = logging.getLogger(__name__)

class FavoritesService:

    _EXCHANGE_MAP = {
        "SSE": "上海证券交易所",
        "SZSE": "深圳证券交易所",
        "BSE": "北京证券交易所",
        "HKEX": "香港交易所",
        "NYSE": "纽约证券交易所",
        "NASDAQ": "纳斯达克",
        "AMEX": "美国证券交易所",
    }

    @staticmethod
    def _infer_board(code: str) -> str:
        if not code:
            return "-"
        c = str(code).zfill(6)
        if c.startswith("60"):
            return "主板"
        elif c.startswith("00"):
            return "主板"
        elif c.startswith("30"):
            return "创业板"
        elif c.startswith("68"):
            return "科创板"
        elif c.startswith(("4", "8")):
            return "北交所"
        return "主板"

    @classmethod
    def _exchange_display(cls, code: str) -> str:
        if not code or code == "-":
            return "-"
        return cls._EXCHANGE_MAP.get(code.upper(), code)

    def __init__(self):
        self.db = None

    async def _get_db(self):
        if self.db is None:
            self.db = get_mongo_db()
        return self.db

    def _is_valid_object_id(self, user_id: str) -> bool:
        return ObjectId.is_valid(user_id)

    def _format_favorite(self, favorite: Dict[str, Any]) -> Dict[str, Any]:
        added_at = favorite.get("added_at")
        if isinstance(added_at, datetime):
            added_at = added_at.isoformat()
        return {
            "stock_code": favorite.get("stock_code"),
            "stock_name": favorite.get("stock_name"),
            "market": favorite.get("market", "A股"),
            "added_at": added_at,
            "tags": favorite.get("tags", []),
            "notes": favorite.get("notes", ""),
            "alert_price_high": favorite.get("alert_price_high"),
            "alert_price_low": favorite.get("alert_price_low"),
            "current_price": None,
            "change_percent": None,
            "volume": None,
        }

    async def get_user_favorites(self, user_id: str) -> List[Dict[str, Any]]:
        db = await self._get_db()

        favorites: List[Dict[str, Any]] = []
        if self._is_valid_object_id(user_id):
            user = await db.users.find_one({"_id": ObjectId(user_id)})
            if user is None:
                user = await db.users.find_one({"_id": user_id})
            favorites = (user or {}).get("favorite_stocks", [])
        else:
            doc = await db.user_favorites.find_one({"user_id": user_id})
            favorites = (doc or {}).get("favorites", [])

        items = [self._format_favorite(fav) for fav in favorites]

        market = "CN"

        codes = [it.get("stock_code") for it in items if it.get("stock_code")]
        if codes:
            try:
                from app.data.core.interface import DataInterface

                di = DataInterface.get_instance()
                basic_docs = await di.read_batch(
                    market, "basic_info", codes,
                    projection={"symbol": 1, "exchange": 1, "market": 1},
                )
                basic_map = {
                    str(d.get("symbol")).zfill(6): d for d in (basic_docs or [])
                }

                for it in items:
                    code = it.get("stock_code")
                    basic = basic_map.get(code)
                    if basic:
                        raw_market = basic.get("market", "-")
                        if raw_market in ("CN", "HK", "US", ""):
                            it["board"] = self._infer_board(code)
                        else:
                            it["board"] = raw_market
                        it["exchange"] = self._exchange_display(
                            basic.get("exchange", "-")
                        )
                    else:
                        it["board"] = self._infer_board(code)
                        it["exchange"] = "-"
            except Exception:
                for it in items:
                    it["board"] = "-"
                    it["exchange"] = "-"

        if codes:
            try:
                from app.data.core.interface import DataInterface

                di = DataInterface.get_instance()

                mq_docs = await di.read_batch(
                    market, "market_quotes", codes,
                    projection={
                        "symbol": 1, "last_price": 1,
                        "last_volume": 1, "last_updated": 1,
                    },
                )
                mq_map = {str(d.get("symbol")).zfill(6): d for d in (mq_docs or [])}

                pct_map = {}
                try:
                    pct_map = await di.read_latest_batch(
                        "CN", "daily_quotes", codes,
                        projection={"close": 1, "pct_chg": 1, "trade_date": 1},
                    )
                except Exception as e:
                    logger.warning(f"批量获取 daily_quotes 最新行情失败: {e}")

                for it in items:
                    code = it.get("stock_code")
                    mq = mq_map.get(code)
                    dq = pct_map.get(code)
                    if mq and mq.get("last_price") is not None:
                        it["current_price"] = mq["last_price"]
                    elif dq and dq.get("close") is not None:
                        it["current_price"] = dq["close"]

                    if dq and dq.get("pct_chg") is not None:
                        it["change_percent"] = dq["pct_chg"]

                missing = [c for c in codes if c not in mq_map and c not in pct_map]
                if missing:
                    try:
                        from app.data.core.interface import DataInterface

                        di = DataInterface.get_instance()
                        quotes_online = {}
                        for code in missing:
                            try:
                                await di.refresh("CN", code, ["market_quotes"])
                                r = await di.read("CN", "market_quotes", symbol=code)
                                d = r.get("data")
                                if d:
                                    doc = d[0] if isinstance(d, list) and d else d
                                    quotes_online[code] = {
                                        "close": doc.get("last_price")
                                        or doc.get("close"),
                                        "pct_chg": doc.get("pct_chg"),
                                    }
                            except Exception as e:
                                logger.debug(f"获取行情数据失败: {e}")
                        for it in items:
                            code = it.get("stock_code")
                            if it.get("current_price") is None:
                                q2 = quotes_online.get(code, {})
                                it["current_price"] = q2.get("close")
                                it["change_percent"] = q2.get("pct_chg")
                    except Exception:
                        pass
            except Exception:
                pass

        return items

    async def add_favorite(
        self,
        user_id: str,
        stock_code: str,
        stock_name: str,
        market: str = "A股",
        tags: List[str] = None,
        notes: str = "",
        alert_price_high: Optional[float] = None,
        alert_price_low: Optional[float] = None,
    ) -> bool:

        try:
            logger.info(
                f"🔧 [add_favorite] 开始添加自选股: user_id={user_id}, stock_code={stock_code}"
            )

            db = await self._get_db()
            logger.info("🔧 [add_favorite] 数据库连接获取成功")

            favorite_stock = {
                "stock_code": stock_code,
                "stock_name": stock_name,
                "market": market,
                "added_at": now_utc(),
                "tags": tags or [],
                "notes": notes,
                "alert_price_high": alert_price_high,
                "alert_price_low": alert_price_low,
            }

            logger.info(f"🔧 [add_favorite] 自选股数据构建完成: {favorite_stock}")

            is_oid = self._is_valid_object_id(user_id)
            logger.info(
                f"🔧 [add_favorite] 用户ID类型检查: is_valid_object_id={is_oid}"
            )

            if is_oid:
                logger.info("🔧 [add_favorite] 使用 ObjectId 方式添加到 users 集合")

                result = await db.users.update_one(
                    {"_id": ObjectId(user_id)},
                    {"$push": {"favorite_stocks": favorite_stock}},
                )
                logger.info(
                    f"🔧 [add_favorite] ObjectId查询结果: matched_count={result.matched_count}, modified_count={result.modified_count}"
                )

                if result.matched_count == 0:
                    logger.info(
                        "🔧 [add_favorite] ObjectId查询失败，尝试使用字符串ID查询"
                    )
                    result = await db.users.update_one(
                        {"_id": user_id}, {"$push": {"favorite_stocks": favorite_stock}}
                    )
                    logger.info(
                        f"🔧 [add_favorite] 字符串ID查询结果: matched_count={result.matched_count}, modified_count={result.modified_count}"
                    )

                success = result.matched_count > 0
                logger.info(f"🔧 [add_favorite] 返回结果: {success}")
                return success
            else:
                logger.info(
                    "🔧 [add_favorite] 使用字符串ID方式添加到 user_favorites 集合"
                )
                result = await db.user_favorites.update_one(
                    {"user_id": user_id},
                    {
                        "$setOnInsert": {"user_id": user_id, "created_at": now_utc()},
                        "$push": {"favorites": favorite_stock},
                        "$set": {"updated_at": now_utc()},
                    },
                    upsert=True,
                )
                logger.info(
                    f"🔧 [add_favorite] 更新结果: matched_count={result.matched_count}, modified_count={result.modified_count}, upserted_id={result.upserted_id}"
                )
                logger.info("🔧 [add_favorite] 返回结果: True")
                return True
        except Exception as e:
            logger.error(
                f"❌ [add_favorite] 添加自选股异常: {type(e).__name__}: {str(e)}",
                exc_info=True,
            )
            raise

    async def remove_favorite(self, user_id: str, stock_code: str) -> bool:
        db = await self._get_db()

        if self._is_valid_object_id(user_id):
            result = await db.users.update_one(
                {"_id": ObjectId(user_id)},
                {"$pull": {"favorite_stocks": {"stock_code": stock_code}}},
            )
            if result.matched_count == 0:
                result = await db.users.update_one(
                    {"_id": user_id},
                    {"$pull": {"favorite_stocks": {"stock_code": stock_code}}},
                )
            return result.modified_count > 0
        else:
            result = await db.user_favorites.update_one(
                {"user_id": user_id},
                {
                    "$pull": {"favorites": {"stock_code": stock_code}},
                    "$set": {"updated_at": now_utc()},
                },
            )
            return result.modified_count > 0

    async def update_favorite(
        self,
        user_id: str,
        stock_code: str,
        tags: Optional[List[str]] = None,
        notes: Optional[str] = None,
        alert_price_high: Optional[float] = None,
        alert_price_low: Optional[float] = None,
    ) -> bool:
        db = await self._get_db()

        is_oid = self._is_valid_object_id(user_id)
        prefix = "favorite_stocks.$." if is_oid else "favorites.$."
        update_fields: Dict[str, Any] = {}
        if tags is not None:
            update_fields[prefix + "tags"] = tags
        if notes is not None:
            update_fields[prefix + "notes"] = notes
        if alert_price_high is not None:
            update_fields[prefix + "alert_price_high"] = alert_price_high
        if alert_price_low is not None:
            update_fields[prefix + "alert_price_low"] = alert_price_low

        if not update_fields:
            return True

        if is_oid:
            result = await db.users.update_one(
                {"_id": ObjectId(user_id), "favorite_stocks.stock_code": stock_code},
                {"$set": update_fields},
            )
            return result.modified_count > 0
        else:
            result = await db.user_favorites.update_one(
                {"user_id": user_id, "favorites.stock_code": stock_code},
                {"$set": {**update_fields, "updated_at": now_utc()}},
            )
            return result.modified_count > 0

    async def is_favorite(self, user_id: str, stock_code: str) -> bool:

        try:
            logger.info(
                f"🔧 [is_favorite] 检查自选股: user_id={user_id}, stock_code={stock_code}"
            )

            db = await self._get_db()

            is_oid = self._is_valid_object_id(user_id)
            logger.info(f"🔧 [is_favorite] 用户ID类型: is_valid_object_id={is_oid}")

            if is_oid:
                user = await db.users.find_one(
                    {"_id": ObjectId(user_id), "favorite_stocks.stock_code": stock_code}
                )

                if user is None:
                    logger.info(
                        "🔧 [is_favorite] ObjectId查询未找到，尝试使用字符串ID查询"
                    )
                    user = await db.users.find_one(
                        {"_id": user_id, "favorite_stocks.stock_code": stock_code}
                    )

                result = user is not None
                logger.info(f"🔧 [is_favorite] 查询结果: {result}")
                return result
            else:
                doc = await db.user_favorites.find_one(
                    {"user_id": user_id, "favorites.stock_code": stock_code}
                )
                result = doc is not None
                logger.info(f"🔧 [is_favorite] 字符串ID查询结果: {result}")
                return result
        except Exception as e:
            logger.error(
                f"❌ [is_favorite] 检查自选股异常: {type(e).__name__}: {str(e)}",
                exc_info=True,
            )
            raise

    async def get_user_tags(self, user_id: str) -> List[str]:
        db = await self._get_db()

        if self._is_valid_object_id(user_id):
            pipeline = [
                {"$match": {"_id": ObjectId(user_id)}},
                {"$unwind": "$favorite_stocks"},
                {"$unwind": "$favorite_stocks.tags"},
                {"$group": {"_id": "$favorite_stocks.tags"}},
                {"$sort": {"_id": 1}},
            ]
            result = await db.users.aggregate(pipeline).to_list(None)
        else:
            pipeline = [
                {"$match": {"user_id": user_id}},
                {"$unwind": "$favorites"},
                {"$unwind": "$favorites.tags"},
                {"$group": {"_id": "$favorites.tags"}},
                {"$sort": {"_id": 1}},
            ]
            result = await db.user_favorites.aggregate(pipeline).to_list(None)

        return [item["_id"] for item in result if item.get("_id")]

favorites_service = FavoritesService()
