import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, Any
from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.core.database import db_manager
from app.core.env import get_env
from app.utils.time_utils import now_utc
from app.utils.passwords import hash_password as secure_hash_password

logger = logging.getLogger(__name__)

DEFAULT_ADMIN = {
    "username": "admin",
    "email": "admin@zhenshabi.cn"
}

CONFIG_COLLECTIONS = [
    "system_configs",
    "users",
    "llm_providers",
    "market_categories",
    "user_tags",
    "datasource_groupings",
    "platform_configs",
    "user_configs",
    "model_catalog"
]

class SystemInitService:

    @staticmethod
    def hash_password(password: str) -> str:
        return secure_hash_password(password)

    @staticmethod
    def get_default_admin_config() -> Dict[str, str]:
        password = (
            get_env("INITIAL_ADMIN_PASSWORD")
            or get_env("DEFAULT_ADMIN_PASSWORD")
            or ""
        ).strip()

        if not password:
            password = "admin123"
            logger.warning(
                "⚠️ 未设置 INITIAL_ADMIN_PASSWORD，使用默认管理员密码 admin123，"
                "请在首次登录后立即修改密码"
            )

        return {
            "username": get_env("INITIAL_ADMIN_USERNAME", DEFAULT_ADMIN["username"]).strip() or DEFAULT_ADMIN["username"],
            "email": get_env("INITIAL_ADMIN_EMAIL", DEFAULT_ADMIN["email"]).strip() or DEFAULT_ADMIN["email"],
            "password": password,
        }

    @staticmethod
    def convert_to_bson(data: Any) -> Any:
        if isinstance(data, dict):
            result = {}
            for key, value in data.items():
                if key == "_id" or key.endswith("_id"):
                    if isinstance(value, str) and len(value) == 24:
                        try:
                            result[key] = ObjectId(value)
                            continue
                        except Exception as e:
                            logger.debug(f"ObjectId 转换失败: {key}={value}: {e}")
                            pass

                if key.endswith("_at") or key in ["created_at", "updated_at", "last_login", "added_at"]:
                    if isinstance(value, str):
                        try:
                            result[key] = datetime.fromisoformat(value.replace('Z', '+00:00'))
                            continue
                        except Exception as e:
                            logger.debug(f"日期解析失败: {key}={value}: {e}")
                            pass
                
                result[key] = SystemInitService.convert_to_bson(value)
            return result
        
        elif isinstance(data, list):
            return [SystemInitService.convert_to_bson(item) for item in data]
        
        else:
            return data

    @classmethod
    async def initialize_system(cls):
        try:
            logger.info("🚀 开始检查系统初始化状态...")
            
            db = db_manager.mongo_db
            if db is None:
                logger.error("❌ 数据库未连接，跳过初始化")
                return

            users_count = await db.users.count_documents({})
            
            if users_count > 0:
                logger.info(f"✅ 系统已初始化 (发现 {users_count} 个用户)，跳过数据导入")
            else:
                logger.info("🆕 检测到空数据库，准备执行初始化...")
                await cls._import_initial_data(db)
                
            await cls._ensure_default_admin(db)
            
            logger.info("✨ 系统初始化检查完成")
            
        except Exception as e:
            logger.error(f"❌ 系统初始化过程中发生错误: {e}", exc_info=True)

    @classmethod
    async def _import_initial_data(cls, db: AsyncIOMotorDatabase):
        
        project_root = Path(__file__).parent.parent.parent
        install_dirs = [
            Path("/app/install"),
            project_root / "install"
        ]
        
        export_file = None
        
        for install_dir in install_dirs:
            if install_dir.exists():
                config_files = list(install_dir.glob("database_export_config_*.json"))
                if config_files:
                    export_file = sorted(config_files)[-1]
                    logger.info(f"📂 找到初始配置文件: {export_file}")
                    break
        
        if not export_file:
            logger.info("ℹ️ 未找到外部数据导入文件 (install/database_export_config_*.json)，将仅执行基础初始化")
            return

        try:
            with open(export_file, 'r', encoding='utf-8') as f:
                data_wrapper = json.load(f)
            
            if "data" not in data_wrapper:
                logger.error("❌ 配置文件格式错误: 缺少 'data' 字段")
                return
                
            data = data_wrapper["data"]
            
            collections_to_import = [c for c in CONFIG_COLLECTIONS if c in data]
            
            logger.info(f"📋 准备导入 {len(collections_to_import)} 个集合")
            
            total_inserted = 0
            
            for col_name in collections_to_import:
                documents = data[col_name]
                if not documents:
                    continue
                    
                converted_docs = cls.convert_to_bson(documents)
                
                collection = db[col_name]
                
                if await collection.count_documents({}) == 0:
                    result = await collection.insert_many(converted_docs)
                    inserted_count = len(result.inserted_ids)
                    total_inserted += inserted_count
                    logger.info(f"   - {col_name}: 导入 {inserted_count} 条数据")
                else:
                    logger.info(f"   - {col_name}: 集合非空，跳过导入")
            
            logger.info(f"✅ 数据导入完成，共插入 {total_inserted} 条文档")
            
        except Exception as e:
            logger.error(f"❌ 导入初始数据失败: {e}")

    @classmethod
    async def _ensure_default_admin(cls, db: AsyncIOMotorDatabase):
        users_collection = db.users
        admin_config = cls.get_default_admin_config()

        existing_user = await users_collection.find_one({"username": admin_config["username"]})

        if existing_user:
            return

        logger.info(f"👤 创建默认管理员用户: {admin_config['username']}")
        
        user_doc = {
            "username": admin_config["username"],
            "email": admin_config["email"],
            "hashed_password": cls.hash_password(admin_config["password"]),
            "is_active": True,
            "is_verified": True,
            "is_admin": True,
            "must_change_password": admin_config["password"] == "admin123",
            "created_at": now_utc(),
            "updated_at": now_utc(),
            "last_login": None,
            "preferences": {
                "default_market": "A股",
                "default_debate_rounds": 2,
                "ui_theme": "light",
                "language": "zh-CN",
                "notifications_enabled": True,
                "email_notifications": False
            },
            "daily_quota": 10000,
            "concurrent_limit": 10,
            "total_analyses": 0,
            "successful_analyses": 0,
            "failed_analyses": 0,
            "favorite_stocks": []
        }
        
        await users_collection.insert_one(user_doc)
        logger.info("✅ 默认管理员创建成功")
