import asyncio
import logging

from datetime import datetime, time as dtime, timedelta
from typing import Dict, Optional, Tuple
from zoneinfo import ZoneInfo
from collections import deque

from pymongo import UpdateOne

from app.core.config import settings
from app.core.database import get_mongo_db
from app.data.storage.mongo.collections import get_collection_name
from app.utils.time_utils import now_config_tz, format_date_compact

logger = logging.getLogger(__name__)

class QuotesIngestionService:

    def __init__(self, collection_name: Optional[str] = None) -> None:

        self._market = "CN"
        self.collection_name = collection_name or get_collection_name("market_quotes", self._market)
        self.status_collection_name = "quotes_ingestion_status"
        self.tz = ZoneInfo(settings.TIMEZONE)

        self._tushare_permission_checked = False
        self._tushare_has_premium = False
        self._tushare_last_call_time = None
        self._tushare_hourly_limit = 2
        self._tushare_call_count = 0
        self._tushare_call_times = deque()

        self._rotation_sources = ["tushare", "akshare_eastmoney", "akshare_sina"]
        self._rotation_index = 0

    def _find_latest_trade_date(self) -> Optional[str]:

        try:
            from app.core.async_utils import run_async
            from app.data.storage.mongo.repositories.daily_quotes_repo import DailyQuotesRepo
            repo = DailyQuotesRepo()
            return run_async(repo.get_latest_date("__all__", "CN"))
        except Exception as e:
            logger.warning(f"获取最新交易日失败: {e}")
            return None

    def _get_realtime_quotes(self) -> Tuple[Optional[Dict], Optional[str]]:

        try:
            from app.core.async_utils import run_async
            from app.data.core.interface import DataInterface

            async def _fetch():
                di = DataInterface.get_instance()
                result = await di.read("CN", "market_quotes", symbol="__all__")
                return result.get("data")

            data = run_async(_fetch())
            if data is not None:
                return data, "data_interface"
            return None, None
        except Exception as e:
            logger.warning(f"获取实时行情失败: {e}")
            return None, None

    @staticmethod
    def _normalize_stock_code(code: str) -> str:

        if not code:
            return ""

        code_str = str(code).strip()

        if len(code_str) > 6:
            code_str = ''.join(filter(str.isdigit, code_str))

        if code_str.isdigit():
            code_clean = code_str.lstrip('0') or '0'
            return code_clean.zfill(6)

        code_digits = ''.join(filter(str.isdigit, code_str))
        if code_digits:
            return code_digits.zfill(6)

        return ""

    async def ensure_indexes(self) -> None:
        db = get_mongo_db()
        coll = db[self.collection_name]
        try:
            await coll.create_index("symbol", unique=True)
            await coll.create_index("updated_at")
        except Exception as e:
            logger.warning(f"创建行情表索引失败（忽略）: {e}")

    async def _record_sync_status(
        self,
        success: bool,
        source: Optional[str] = None,
        records_count: int = 0,
        error_msg: Optional[str] = None
    ) -> None:

        try:
            db = get_mongo_db()
            status_coll = db[self.status_collection_name]

            now = now_config_tz()

            status_doc = {
                "job": "quotes_ingestion",
                "last_sync_time": now,
                "last_sync_time_iso": now.isoformat(),
                "success": success,
                "data_source": source,
                "records_count": records_count,
                "interval_seconds": settings.QUOTES_INGEST_INTERVAL_SECONDS,
                "error_message": error_msg,
                "updated_at": now,
            }

            await status_coll.update_one(
                {"job": "quotes_ingestion"},
                {"$set": status_doc},
                upsert=True
            )

        except Exception as e:
            logger.warning(f"记录同步状态失败（忽略）: {e}")

    async def get_sync_status(self) -> Dict[str, any]:

        try:
            db = get_mongo_db()
            status_coll = db[self.status_collection_name]

            doc = await status_coll.find_one({"job": "quotes_ingestion"})

            if not doc:
                return {
                    "last_sync_time": None,
                    "last_sync_time_iso": None,
                    "interval_seconds": settings.QUOTES_INGEST_INTERVAL_SECONDS,
                    "interval_minutes": settings.QUOTES_INGEST_INTERVAL_SECONDS / 60,
                    "data_source": None,
                    "success": None,
                    "records_count": 0,
                    "error_message": "尚未执行过同步"
                }

            doc.pop("_id", None)
            doc.pop("job", None)

            doc["interval_minutes"] = doc.get("interval_seconds", 0) / 60

            if "last_sync_time" in doc and doc["last_sync_time"]:
                dt = doc["last_sync_time"]
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=ZoneInfo("UTC"))
                dt_local = dt.astimezone(self.tz)
                doc["last_sync_time"] = dt_local.strftime("%Y-%m-%d %H:%M:%S")

            return doc

        except Exception as e:
            logger.error(f"获取同步状态失败: {e}")
            return {
                "last_sync_time": None,
                "last_sync_time_iso": None,
                "interval_seconds": settings.QUOTES_INGEST_INTERVAL_SECONDS,
                "interval_minutes": settings.QUOTES_INGEST_INTERVAL_SECONDS / 60,
                "data_source": None,
                "success": None,
                "records_count": 0,
                "error_message": f"获取状态失败: {str(e)}"
            }

    def _check_tushare_permission(self) -> bool:

        if self._tushare_permission_checked:
            return self._tushare_has_premium or False

        try:
            from app.utils.ds_key_utils import get_datasource_api_key
            token = get_datasource_api_key("tushare")
            if not token or not token.strip():
                logger.info("Tushare 未配置 Token，跳过权限检测")
                self._tushare_has_premium = False
                self._tushare_permission_checked = True
                return False

            try:
                import tushare as ts
                ts.set_token(token)
                pro = ts.pro_api()
                df = pro.daily(ts_code='000001.SZ', limit=1)
                if df is not None and not getattr(df, 'empty', True):
                    logger.info("✅ 检测到 Tushare rt_k 接口权限（付费用户）")
                    self._tushare_has_premium = True
                else:
                    logger.info("⚠️ Tushare rt_k 接口返回空数据（可能是免费用户或接口限制）")
                    self._tushare_has_premium = False
            except Exception as e:
                error_msg = str(e).lower()
                if "权限" in error_msg or "permission" in error_msg or "没有访问" in error_msg:
                    logger.info("⚠️ Tushare rt_k 接口无权限（免费用户）")
                    self._tushare_has_premium = False
                else:
                    logger.warning(f"⚠️ Tushare rt_k 接口测试失败: {e}")
                    self._tushare_has_premium = False

            self._tushare_permission_checked = True
            return self._tushare_has_premium or False

        except Exception as e:
            logger.warning(f"Tushare 权限检测失败: {e}")
            self._tushare_has_premium = False
            self._tushare_permission_checked = True
            return False

    def _can_call_tushare(self) -> bool:

        if self._tushare_has_premium:
            return True

        now = now_config_tz()
        one_hour_ago = now - timedelta(hours=1)

        while self._tushare_call_times and self._tushare_call_times[0] < one_hour_ago:
            self._tushare_call_times.popleft()

        if len(self._tushare_call_times) >= self._tushare_hourly_limit:
            logger.warning(
                f"⚠️ Tushare rt_k 接口已达到每小时调用限制 ({self._tushare_hourly_limit}次)，"
                f"跳过本次调用，使用 AKShare 备用接口"
            )
            return False

        return True

    def _record_tushare_call(self) -> None:
        self._tushare_call_times.append(now_config_tz())

    def _get_next_source(self) -> Tuple[str, Optional[str]]:

        if not settings.QUOTES_ROTATION_ENABLED:
            return "tushare", None

        current_source = self._rotation_sources[self._rotation_index]

        self._rotation_index = (self._rotation_index + 1) % len(self._rotation_sources)

        if current_source == "tushare":
            return "tushare", None
        elif current_source == "akshare_eastmoney":
            return "akshare", "eastmoney"
        else:
            return "akshare", "sina"

    def _is_trading_time(self, now: Optional[datetime] = None) -> bool:

        now = now or now_config_tz()
        if now.weekday() > 4:
            return False
        t = now.time()
        morning = dtime(9, 30)
        noon = dtime(11, 30)
        afternoon_start = dtime(13, 0)
        buffer_end = dtime(15, 30)

        return (morning <= t <= noon) or (afternoon_start <= t <= buffer_end)

    async def _collection_empty(self) -> bool:
        db = get_mongo_db()
        coll = db[self.collection_name]
        try:
            count = await coll.estimated_document_count()
            return count == 0
        except Exception as e:
            logger.debug(f"检查集合是否为空失败: {e}")
            return True

    async def _collection_stale(self, latest_trade_date: Optional[str]) -> bool:
        if not latest_trade_date:
            return False
        db = get_mongo_db()
        coll = db[self.collection_name]
        try:
            cursor = coll.find({}, {"trade_date": 1}).sort("trade_date", -1).limit(1)
            docs = await cursor.to_list(length=1)
            if not docs:
                return True
            doc_td = str(docs[0].get("trade_date") or "")
            return doc_td < str(latest_trade_date)
        except Exception as e:
            logger.debug(f"检查集合数据时效失败: {e}")
            return True

    async def _bulk_upsert(self, quotes_map: Dict[str, Dict], trade_date: str, source: Optional[str] = None) -> None:
        db = get_mongo_db()
        coll = db[self.collection_name]
        ops = []
        updated_at = now_config_tz()
        for code, q in quotes_map.items():
            if not code:
                continue
            symbol6 = self._normalize_stock_code(code)
            if not symbol6:
                continue

            volume = q.get("volume")
            if symbol6 in ["300750", "000001", "600000"]:
                logger.debug(f"📊 [写入market_quotes] {symbol6} - volume={volume}, amount={q.get('amount')}, source={source}")

            set_doc = {
                "symbol": symbol6,
                "trade_date": trade_date,
                "data_source": source,
                "updated_at": updated_at,
            }
            for field, raw_val in [
                ("close", q.get("close")),
                ("pct_chg", q.get("pct_chg")),
                ("amount", q.get("amount")),
                ("volume", volume),
                ("open", q.get("open")),
                ("high", q.get("high")),
                ("low", q.get("low")),
                ("pre_close", q.get("pre_close")),
            ]:
                if raw_val is not None:
                    set_doc[field] = raw_val

            ops.append(
                UpdateOne(
                    {"symbol": symbol6},
                    {"$set": set_doc},
                    upsert=True,
                )
            )
        if not ops:
            logger.info("无可写入的数据，跳过")
            return
        result = await coll.bulk_write(ops, ordered=False)
        logger.info(
            f"✅ 行情入库完成 source={source}, matched={result.matched_count}, upserted={len(result.upserted_ids) if result.upserted_ids else 0}, modified={result.modified_count}"
        )

    async def _fix_missing_fields(self) -> None:
        db = get_mongo_db()
        coll = db[self.collection_name]

        cursor = coll.find({"pct_chg": None}, {"symbol": 1})
        missing_symbols = [doc["symbol"] for doc in await cursor.to_list(length=None)]

        if not missing_symbols:
            logger.info("✅ market_quotes 所有记录均包含 pct_chg，无需修复")
            return

        logger.info(f"📊 需要修复 {len(missing_symbols)} 条记录的缺失字段")

        daily_coll = db[get_collection_name("daily_quotes", self._market)]
        ops = []
        for symbol in missing_symbols:
            dq = await daily_coll.find_one(
                {"symbol": symbol},
                sort=[("trade_date", -1)],
            )
            if not dq:
                continue
            ops.append(UpdateOne(
                {"symbol": symbol},
                {"$set": {
                    "pct_chg": dq.get("pct_chg"),
                    "pre_close": dq.get("pre_close"),
                    "turnover_rate": dq.get("turnover_rate"),
                    "trade_date": dq.get("trade_date"),
                }},
            ))
        if ops:
            result = await coll.bulk_write(ops, ordered=False)
            logger.info(f"✅ 修复完成: modified={result.modified_count}")

    async def backfill_from_historical_data(self) -> None:
        try:
            is_empty = await self._collection_empty()

            if not is_empty:
                logger.info("✅ market_quotes 集合不为空，检查是否需要修复成交量...")
                await self._fix_missing_fields()
                return

            logger.info("📊 market_quotes 集合为空，开始从历史数据导入")

            db = get_mongo_db()

            try:
                latest_trade_date = self._find_latest_trade_date()
                if not latest_trade_date:
                    logger.warning("⚠️ 无法获取最新交易日，跳过历史数据导入")
                    return
            except Exception as e:
                logger.warning(f"⚠️ 获取最新交易日失败: {e}，跳过历史数据导入")
                return

            logger.info(f"📊 从历史数据集合导入 {latest_trade_date} 的收盘数据到 market_quotes")

            daily_quotes_collection = db[get_collection_name("daily_quotes", self._market)]
            cursor = daily_quotes_collection.find({
                "trade_date": latest_trade_date,
                "period": "daily"
            })

            docs = await cursor.to_list(length=None)

            if not docs:
                logger.debug(f"⚠️ 历史数据集合中未找到 {latest_trade_date} 的数据")
                logger.debug("⚠️ market_quotes 和历史数据集合都为空，请先同步历史数据或实时行情")
                return

            logger.info(f"✅ 从历史数据集合找到 {len(docs)} 条记录")

            quotes_map = {}
            for doc in docs:
                code = doc.get("symbol") or doc.get("code")
                if not code:
                    continue
                symbol6 = str(code).zfill(6)

                volume_value = doc.get("volume") or doc.get("vol")
                data_source = doc.get("data_source", "")

                if symbol6 in ["300750", "000001", "600000"]:
                    logger.debug(f"📊 [回填] {symbol6} - volume={doc.get('volume')}, vol={doc.get('vol')}, data_source={data_source}")

                quotes_map[symbol6] = {
                    "close": doc.get("close"),
                    "pct_chg": doc.get("pct_chg"),
                    "amount": doc.get("amount"),
                    "volume": volume_value,
                    "open": doc.get("open"),
                    "high": doc.get("high"),
                    "low": doc.get("low"),
                    "pre_close": doc.get("pre_close"),
                }

            if quotes_map:
                await self._bulk_upsert(quotes_map, latest_trade_date, "historical_data")
                logger.info(f"✅ 成功从历史数据导入 {len(quotes_map)} 条收盘数据到 market_quotes")
            else:
                logger.warning("⚠️ 历史数据转换后为空，无法导入")

        except Exception as e:
            logger.error(f"❌ 从历史数据导入失败: {e}")
            import traceback
            logger.error(f"堆栈跟踪:\n{traceback.format_exc()}")

    async def backfill_last_close_snapshot(self) -> None:
        try:
            quotes_map, source = self._get_realtime_quotes()
            if not quotes_map:
                logger.warning("backfill: 未获取到行情数据，跳过")
                return
            try:
                trade_date = self._find_latest_trade_date() or format_date_compact(now_config_tz())
            except Exception as e:
                logger.debug(f"获取最新交易日失败，使用当前日期: {e}")
                trade_date = format_date_compact(now_config_tz())
            await self._bulk_upsert(quotes_map, trade_date, source)
        except Exception as e:
            logger.error(f"❌ backfill 行情补数失败: {e}")

    async def backfill_last_close_snapshot_if_needed(self) -> None:
        try:
            is_empty = await self._collection_empty()

            if is_empty:
                logger.info("🔁 market_quotes 集合为空，尝试从历史数据导入")
                await self.backfill_from_historical_data()
                return

            latest_td = self._find_latest_trade_date()
            if await self._collection_stale(latest_td):
                logger.info("🔁 触发休市期/启动期 backfill 以填充最新收盘数据")
                await self.backfill_last_close_snapshot()
        except Exception as e:
            logger.warning(f"backfill 触发检查失败（忽略）: {e}")

    def _fetch_quotes_from_source(self, source_type: str, akshare_api: Optional[str] = None) -> Tuple[Optional[Dict], Optional[str]]:

        try:
            from app.core.async_utils import run_async
            from app.data.core.interface import DataInterface

            if source_type == "tushare":
                if not self._can_call_tushare():
                    return None, None

                logger.info("📊 使用 Tushare 接口获取实时行情")

                async def _fetch_tushare():
                    di = DataInterface.get_instance()
                    result = await di.read("CN", "market_quotes", symbol="__all__")
                    return result.get("data")

                data = run_async(_fetch_tushare())
                if data is not None:
                    self._record_tushare_call()
                    if isinstance(data, dict):
                        return data, "tushare"
                    elif isinstance(data, list) and data:
                        quotes_map = {}
                        for doc in data:
                            sym = str(doc.get("symbol", "")).zfill(6)
                            if sym:
                                quotes_map[sym] = doc
                        return quotes_map, "tushare"
                logger.warning("Tushare 返回空数据")
                return None, None

            elif source_type == "akshare":
                api_name = akshare_api or "eastmoney"
                logger.info(f"📊 使用 AKShare {api_name} 接口获取实时行情")

                async def _fetch_akshare():
                    di = DataInterface.get_instance()
                    result = await di.read("CN", "market_quotes", symbol="__all__")
                    return result.get("data")

                data = run_async(_fetch_akshare())
                if data is not None:
                    if isinstance(data, dict):
                        return data, f"akshare_{api_name}"
                    elif isinstance(data, list) and data:
                        quotes_map = {}
                        for doc in data:
                            sym = str(doc.get("symbol", "")).zfill(6)
                            if sym:
                                quotes_map[sym] = doc
                        return quotes_map, f"akshare_{api_name}"
                logger.warning(f"AKShare {api_name} 返回空数据")
                return None, None

            else:
                logger.error(f"未知数据源类型: {source_type}")
                return None, None

        except Exception as e:
            logger.error(f"从 {source_type} 获取行情失败: {e}")
            return None, None

    async def run_once(self) -> None:

        if not self._is_trading_time():
            if settings.QUOTES_BACKFILL_ON_OFFHOURS:
                await self.backfill_last_close_snapshot_if_needed()
            else:
                logger.info("⏭️ 非交易时段，跳过行情采集")
            return

        try:
            if settings.QUOTES_AUTO_DETECT_TUSHARE_PERMISSION and not self._tushare_permission_checked:
                logger.info("🔍 首次运行，检测 Tushare rt_k 接口权限...")
                has_premium = await asyncio.to_thread(self._check_tushare_permission)

                if has_premium:
                    logger.info(
                        "✅ 检测到 Tushare 付费权限！建议将 QUOTES_INGEST_INTERVAL_SECONDS 设置为 5-60 秒以充分利用权限"
                    )
                else:
                    logger.info(
                        f"ℹ️ Tushare 免费用户，每小时最多调用 {self._tushare_hourly_limit} 次 rt_k 接口。"
                        f"当前采集间隔: {settings.QUOTES_INGEST_INTERVAL_SECONDS} 秒"
                    )

            source_type, akshare_api = self._get_next_source()

            quotes_map, source_name = self._fetch_quotes_from_source(source_type, akshare_api)

            if not quotes_map:
                logger.warning(f"⚠️ {source_name or source_type} 未获取到行情数据，跳过本次入库")
                await self._record_sync_status(
                    success=False,
                    source=source_name or source_type,
                    records_count=0,
                    error_msg="未获取到行情数据"
                )
                return

            try:
                trade_date = self._find_latest_trade_date() or format_date_compact(now_config_tz())
            except Exception as e:
                logger.debug(f"获取最新交易日失败，使用当前日期: {e}")
                trade_date = format_date_compact(now_config_tz())

            await self._bulk_upsert(quotes_map, trade_date, source_name)

            await self._record_sync_status(
                success=True,
                source=source_name,
                records_count=len(quotes_map),
                error_msg=None
            )

        except Exception as e:
            logger.error(f"❌ 行情入库失败: {e}")
            await self._record_sync_status(
                success=False,
                source=None,
                records_count=0,
                error_msg=str(e)
            )

    async def get_latest_daily_quote(self, symbol: str) -> Optional[Dict]:

        try:
            from app.data.core.interface import DataInterface

            symbol6 = str(symbol).zfill(6)

            di = DataInterface.get_instance()
            return await di.read_latest(self._market, "daily_quotes", symbol6)

        except Exception as e:
            logger.error(f"获取最新日线数据失败 symbol={symbol}: {e}")
            return None

    async def get_market_quote(self, symbol: str) -> Optional[Dict]:

        try:
            from app.data.core.interface import DataInterface

            symbol6 = str(symbol).zfill(6)

            di = DataInterface.get_instance()
            result = await di.read(self._market, "market_quotes", symbol=symbol6)
            return result.get("data")

        except Exception as e:
            logger.error(f"获取行情数据失败 symbol={symbol}: {e}")
            return None

    async def upsert_market_quote(self, symbol: str, quote_data: Dict) -> bool:

        try:
            db = get_mongo_db()
            symbol6 = str(symbol).zfill(6)

            result = await db[self.collection_name].update_one(
                {"symbol": symbol6},
                {"$set": quote_data},
                upsert=True
            )
            return result.modified_count > 0 or result.upserted_id is not None

        except Exception as e:
            logger.error(f"更新行情数据失败 symbol={symbol}: {e}")
            return False

    async def sync_latest_to_market_quotes(self, symbol: str) -> None:

        symbol6 = str(symbol).zfill(6)

        latest_doc = await self.get_latest_daily_quote(symbol6)

        if not latest_doc:
            logger.warning(f"⚠️ {symbol6}: stock_daily_quotes 中没有数据")
            return

        historical_trade_date = latest_doc.get("trade_date")

        existing_quote = await self.get_market_quote(symbol6)

        if existing_quote:
            existing_trade_date = existing_quote.get("trade_date")

            if existing_trade_date and historical_trade_date:
                existing_date_str = str(existing_trade_date).replace("-", "")
                historical_date_str = str(historical_trade_date).replace("-", "")

                if existing_date_str >= historical_date_str:
                    logger.info(
                        f"⏭️ {symbol6}: market_quotes 中的数据日期 >= 历史数据日期 "
                        f"(market_quotes: {existing_trade_date}, historical: {historical_trade_date})，跳过覆盖"
                    )
                    return

        quote_data = {
            "symbol": symbol6,
            "close": latest_doc.get("close"),
            "open": latest_doc.get("open"),
            "high": latest_doc.get("high"),
            "low": latest_doc.get("low"),
            "volume": latest_doc.get("volume"),
            "amount": latest_doc.get("amount"),
            "pct_chg": latest_doc.get("pct_chg"),
            "pre_close": latest_doc.get("pre_close"),
            "trade_date": latest_doc.get("trade_date"),
            "updated_at": now_config_tz()
        }

        logger.info(
            f"📊 [同步到market_quotes] {symbol6} - "
            f"volume={quote_data['volume']}, amount={quote_data['amount']}, trade_date={quote_data['trade_date']}"
        )

        await self.upsert_market_quote(symbol6, quote_data)
