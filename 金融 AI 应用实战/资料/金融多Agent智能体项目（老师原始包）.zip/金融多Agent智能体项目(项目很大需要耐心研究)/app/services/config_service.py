from app.services.config import config_service, ConfigServiceFacade

__all__ = ['config_service', 'ConfigServiceFacade']
