import asyncio
import logging
import time
from typing import Any, Dict, List, Optional, Tuple

from app.models.screening import ScreeningCondition, BASIC_FIELDS_INFO
from app.services.database_screening_service import get_database_screening_service
from app.services.screening_service import ScreeningService, ScreeningParams

logger = logging.getLogger(__name__)

from app.services.enhanced_screening.utils import (
    analyze_conditions as _analyze_conditions_util,
    convert_conditions_to_traditional_format as _convert_to_traditional_util,
)

class EnhancedScreeningService:

    def __init__(self):
        self.db_service = get_database_screening_service()
        self.traditional_service = ScreeningService()

        self.db_supported_fields = set(BASIC_FIELDS_INFO.keys())

    async def screen_stocks(
        self,
        conditions: List[ScreeningCondition],
        market: str = "CN",
        date: Optional[str] = None,
        adj: str = "qfq",
        limit: int = 50,
        offset: int = 0,
        order_by: Optional[List[Dict[str, str]]] = None,
        use_database_optimization: bool = True
    ) -> Dict[str, Any]:

        start_time = time.time()

        try:
            analysis = self._analyze_conditions(conditions)

            if (use_database_optimization and
                analysis["can_use_database"] and
                not analysis["needs_technical_indicators"]):

                result = await self._screen_with_database(
                    conditions, limit, offset, order_by
                )
                optimization_used = "database"
                source = "mongodb"

            else:
                result = await self._screen_with_traditional_method(
                    conditions, market, date, adj, limit, offset, order_by
                )
                optimization_used = "traditional"
                source = "api"

            items = result[0] if isinstance(result, tuple) else result.get("items", [])
            total = result[1] if isinstance(result, tuple) else result.get("total", 0)

            if source == "mongodb" and items:
                try:
                    from app.data.core.interface import DataInterface

                    di = DataInterface.get_instance()
                    codes = [str(it.get("symbol")).zfill(6) for it in items if it.get("symbol")]
                    if codes:
                        quotes_list = await di.read_batch(
                            "CN", "market_quotes", codes,
                            projection={"symbol": 1, "close": 1, "pct_chg": 1, "amount": 1},
                        )
                        quotes_map = {}
                        for d in quotes_list:
                            k = str(d.get("symbol")).zfill(6)
                            quotes_map[k] = d
                        for it in items:
                            key = str(it.get("symbol")).zfill(6)
                            q = quotes_map.get(key)
                            if not q:
                                continue
                            if q.get("close") is not None:
                                it["close"] = q.get("close")
                            if q.get("pct_chg") is not None:
                                it["pct_chg"] = q.get("pct_chg")
                            if q.get("amount") is not None:
                                it["amount"] = q.get("amount")
                except Exception as enrich_err:
                    logger.warning(f"实时行情富集失败（已忽略）: {enrich_err}")

                missing_pct = [it for it in items if it.get("pct_chg") is None]
                if missing_pct:
                    try:
                        from app.data.core.interface import DataInterface

                        di = DataInterface.get_instance()
                        missing_codes = [str(it.get("symbol")).zfill(6) for it in missing_pct if it.get("symbol")]
                        if missing_codes:
                            dq_map = await di.read_latest_batch(
                                "CN", "daily_quotes", missing_codes,
                                projection={"pct_chg": 1, "close": 1, "amount": 1},
                            )
                            enriched = 0
                            for it in missing_pct:
                                key = str(it.get("symbol")).zfill(6)
                                dq = dq_map.get(key)
                                if not dq:
                                    continue
                                if it.get("pct_chg") is None and dq.get("pct_chg") is not None:
                                    it["pct_chg"] = dq["pct_chg"]
                                if it.get("close") is None and dq.get("close") is not None:
                                    it["close"] = dq["close"]
                                if it.get("amount") is None and dq.get("amount") is not None:
                                    it["amount"] = dq["amount"]
                                enriched += 1
                            logger.info(f"[screening] daily_quotes 回退补齐: {enriched}/{len(missing_pct)} 条")
                    except Exception as dq_err:
                        logger.warning(f"daily_quotes 回退补齐失败（已忽略）: {dq_err}")

            took_ms = int((time.time() - start_time) * 1000)

            return {
                "total": total,
                "items": items,
                "took_ms": took_ms,
                "optimization_used": optimization_used,
                "source": source,
                "analysis": analysis
            }

        except Exception as e:
            logger.error(f"❌ 股票筛选失败: {e}")
            took_ms = int((time.time() - start_time) * 1000)

            return {
                "total": 0,
                "items": [],
                "took_ms": took_ms,
                "optimization_used": "none",
                "source": "error",
                "error": str(e)
            }

    def _analyze_conditions(self, conditions: List[ScreeningCondition]) -> Dict[str, Any]:
        analysis = _analyze_conditions_util(conditions)
        logger.info(f"📊 筛选条件分析: {analysis}")
        return analysis

    async def _screen_with_database(
        self,
        conditions: List[ScreeningCondition],
        limit: int,
        offset: int,
        order_by: Optional[List[Dict[str, str]]]
    ) -> Tuple[List[Dict[str, Any]], int]:
        logger.info("🚀 使用数据库优化筛选")

        return await self.db_service.screen_stocks(
            conditions=conditions,
            limit=limit,
            offset=offset,
            order_by=order_by
        )

    async def _screen_with_traditional_method(
        self,
        conditions: List[ScreeningCondition],
        market: str,
        date: Optional[str],
        adj: str,
        limit: int,
        offset: int,
        order_by: Optional[List[Dict[str, str]]]
    ) -> Dict[str, Any]:
        logger.info("🔄 使用传统筛选方法")

        traditional_conditions = self._convert_conditions_to_traditional_format(conditions)

        params = ScreeningParams(
            market=market,
            date=date,
            adj=adj,
            limit=limit,
            offset=offset,
            order_by=order_by
        )

        result = await asyncio.to_thread(self.traditional_service.run, traditional_conditions, params)

        return result

    def _convert_conditions_to_traditional_format(
        self,
        conditions: List[ScreeningCondition]
    ) -> Dict[str, Any]:
        return _convert_to_traditional_util(conditions)

    async def get_industries(self) -> Dict[str, Any]:

        try:
            from app.data.core.registry.priority import PriorityConfig
            from app.data.storage.mongo.client import get_motor_db
            from app.data.storage.mongo.collections import get_collection_name

            db = get_motor_db()
            collection = db[get_collection_name("basic_info", "CN")]

            pc = PriorityConfig()
            enabled_sources = await pc.get_priority("CN", "basic_info")
            logger.info(f"[get_industries] 数据源优先级: {enabled_sources}")

            def _build_pipeline(source: str) -> list:
                return [
                    {"$match": {
                        "data_source": source,
                        "industry": {"$nin": [None, "", float("nan")]},
                    }},
                    {"$group": {"_id": "$industry", "count": {"$sum": 1}}},
                    {"$sort": {"count": -1}},
                    {"$project": {"industry": "$_id", "count": 1, "_id": 0}},
                ]

            def _safe_str(raw) -> str:
                if raw is None:
                    return ""
                if isinstance(raw, float):
                    if raw != raw or raw in (float("inf"), float("-inf")):
                        return ""
                return str(raw).strip()

            def _safe_int(raw) -> int:
                try:
                    if isinstance(raw, float):
                        if raw != raw or raw in (float("inf"), float("-inf")):
                            return 0
                    return int(raw)
                except Exception as e:
                    logger.debug(f"转换筛选值失败: {e}")
                    return 0

            used_source = None
            for src in enabled_sources:
                pipeline = _build_pipeline(src)
                industries = []
                async for doc in collection.aggregate(pipeline):
                    name = _safe_str(doc.get("industry"))
                    if not name:
                        continue
                    industries.append({
                        "value": name,
                        "label": name,
                        "count": _safe_int(doc.get("count", 0)),
                    })
                if industries:
                    used_source = src
                    logger.info(f"[get_industries] 从数据源 {src} 返回 {len(industries)} 个行业")
                    return {
                        "industries": industries,
                        "total": len(industries),
                        "source": used_source,
                    }
                logger.info(f"[get_industries] 数据源 {src} 无有效行业数据，尝试下一个")

            logger.warning("[get_industries] 所有数据源均无有效行业数据")
            return {"industries": [], "total": 0, "source": "none"}

        except Exception as e:
            logger.error(f"[get_industries] 获取行业列表失败: {e}", exc_info=True)
            raise

_enhanced_screening_service: Optional[EnhancedScreeningService] = None

def get_enhanced_screening_service() -> EnhancedScreeningService:
    global _enhanced_screening_service
    if _enhanced_screening_service is None:
        _enhanced_screening_service = EnhancedScreeningService()
    return _enhanced_screening_service
