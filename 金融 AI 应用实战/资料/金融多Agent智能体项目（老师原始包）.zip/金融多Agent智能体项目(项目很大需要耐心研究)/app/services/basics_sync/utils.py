from __future__ import annotations

import logging
import time
from datetime import datetime, timedelta
from typing import Dict

from app.utils.time_utils import now_config_tz, format_date_compact

logger = logging.getLogger(__name__)

def fetch_stock_basic_df():

    from app.data.sources.cn.tushare.api.connection import get_tushare_api

    try:
        from app.utils.ds_key_utils import get_datasource_api_key
        tushare_available = bool(get_datasource_api_key("tushare"))
    except Exception:
        from app.core.config import settings
        tushare_available = bool(
            settings.TUSHARE_ENABLED
            and (settings.TUSHARE_CN_TOKEN or settings.TUSHARE_TOKEN)
        )

    if not tushare_available:
        logger.error("❌ Tushare Token 未配置")
        logger.error("💡 请在 Web UI 配置管理中添加 Tushare Token，或在 .env 中设置 TUSHARE_CN_TOKEN")
        raise RuntimeError(
            "Tushare Token not configured. "
            "Please add Tushare Token in Web UI Config Management or set TUSHARE_CN_TOKEN in .env."
        )

    conn = get_tushare_api()

    max_wait_seconds = 5
    wait_interval = 0.1
    elapsed = 0.0

    logger.info("⏳ 等待 Tushare 连接...")
    while not getattr(conn, "connected", False) and elapsed < max_wait_seconds:
        time.sleep(wait_interval)
        elapsed += wait_interval

    if not getattr(conn, "connected", False) or conn.api is None:
        logger.error(f"❌ Tushare 连接失败（等待 {max_wait_seconds}s 后超时）")
        logger.error("💡 请检查：")
        logger.error("   1. .env 文件中配置了有效的 TUSHARE_CN_TOKEN（或 TUSHARE_TOKEN）")
        logger.error("   2. Tushare Token 未过期且有足够的积分")
        logger.error("   3. 网络连接正常")
        raise RuntimeError(
            f"Tushare not connected after waiting {max_wait_seconds}s. "
            "Check TUSHARE_CN_TOKEN in .env and ensure it's valid."
        )

    logger.info("✅ Tushare 已连接，开始获取股票列表...")

    try:
        df = conn.api.stock_basic(
            list_status='L',
            fields='ts_code,symbol,name,area,industry,market,exchange,list_date,is_hs'
        )

        if df is None:
            logger.error("❌ Tushare API 返回 None")
            logger.error("💡 可能原因：")
            logger.error("   1. Tushare Token 无效或过期")
            logger.error("   2. API 积分不足")
            logger.error("   3. 网络连接问题")
            raise RuntimeError("Tushare API returned None. Check token validity and API credits.")

        if hasattr(df, 'empty') and df.empty:
            logger.error("❌ Tushare API 返回空 DataFrame")
            logger.error("💡 可能原因：")
            logger.error("   1. list_status='L' 参数可能不正确")
            logger.error("   2. Tushare 数据源暂时不可用")
            logger.error("   3. API 调用限制（请检查积分和调用频率）")
            raise RuntimeError("Tushare API returned empty DataFrame. Check API parameters and data availability.")

        logger.info(f"✅ 成功获取 {len(df)} 条股票数据")
        return df

    except Exception as e:
        logger.error(f"❌ 调用 Tushare API 失败: {e}")
        raise RuntimeError(f"Failed to fetch stock basic DataFrame: {e}")

def find_latest_trade_date() -> str:
    from app.data.sources.cn.tushare.api.connection import get_tushare_api

    conn = get_tushare_api()
    api = conn.api
    if api is None:
        raise RuntimeError("Tushare API unavailable")

    today = now_config_tz()
    for delta in range(0, 6):
        d = format_date_compact(today - timedelta(days=delta))
        try:
            db = api.daily_basic(trade_date=d, fields="ts_code,total_mv")
            if db is not None and not db.empty:
                return d
        except Exception as e:
            logger.debug(f"Tushare获取每日指标失败 {d}: {e}")
            continue
    return format_date_compact(today - timedelta(days=1))

def fetch_daily_basic_mv_map(trade_date: str) -> Dict[str, Dict[str, float]]:
    from app.data.sources.cn.tushare.api.connection import get_tushare_api

    conn = get_tushare_api()
    api = conn.api
    if api is None:
        raise RuntimeError("Tushare API unavailable")

    fields = "ts_code,total_mv,circ_mv,pe,pb,ps,turnover_rate,volume_ratio,pe_ttm,pb_mrq,ps_ttm,total_share,float_share"
    db = api.daily_basic(trade_date=trade_date, fields=fields)

    data_map: Dict[str, Dict[str, float]] = {}
    if db is not None and not db.empty:
        for _, row in db.iterrows():
            ts_code = row.get("ts_code")
            if ts_code is not None:
                try:
                    metrics = {}
                    for field in [
                        "total_mv",
                        "circ_mv",
                        "pe",
                        "pb",
                        "ps",
                        "turnover_rate",
                        "volume_ratio",
                        "pe_ttm",
                        "pb_mrq",
                        "ps_ttm",
                        "total_share",
                        "float_share",
                    ]:
                        value = row.get(field)
                        if value is not None and str(value).lower() not in ["nan", "none", ""]:
                            metrics[field] = float(value)
                    if metrics:
                        data_map[str(ts_code)] = metrics
                except Exception as e:
                    logger.debug(f"解析总市值数据失败: {e}")
                    pass
    return data_map

def fetch_latest_roe_map() -> Dict[str, Dict[str, float]]:
    from app.data.sources.cn.tushare.api.connection import get_tushare_api

    conn = get_tushare_api()
    api = conn.api
    if api is None:
        raise RuntimeError("Tushare API unavailable")

    def quarter_ends(now: datetime):
        y = now.year
        q_dates = [
            f"{y}0331",
            f"{y}0630",
            f"{y}0930",
            f"{y}1231",
        ]
        py = y - 1
        q_dates_prev = [
            f"{py}1231",
            f"{py}0930",
            f"{py}0630",
            f"{py}0331",
        ]
        return q_dates_prev + q_dates

    candidates = quarter_ends(now_config_tz())
    data_map: Dict[str, Dict[str, float]] = {}

    for end_date in candidates:
        try:
            df = api.fina_indicator(end_date=end_date, fields="ts_code,end_date,roe")
            if df is not None and not df.empty:
                for _, row in df.iterrows():
                    ts_code = row.get("ts_code")
                    val = row.get("roe")
                    if ts_code is None or val is None:
                        continue
                    try:
                        v = float(val)
                    except Exception:
                        continue
                    data_map[str(ts_code)] = {"roe": v}
                if data_map:
                    break
        except Exception as e:
            logger.debug(f"获取ROE数据失败: {e}")
            continue

    return data_map
