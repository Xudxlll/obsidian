import logging
import zipfile
import uuid
from datetime import timedelta
from app.utils.timezone import now_utc, format_iso
from app.utils.time_utils import fromtimestamp_aware
from app.core.env import get_env
from pathlib import Path
from typing import List, Optional, Dict, Any
import re

logger = logging.getLogger(__name__)

DEFAULT_LOG_STATISTICS = {
    "total_files": 0,
    "total_size_mb": 0.0,
    "error_files": 0,
    "recent_errors": [],
    "log_types": {}
}

class LogExportService:

    def __init__(self, log_dir: str = "./logs"):

        self.log_dir = Path(log_dir)
        logger.debug("🔍 [LogExportService] 初始化日志导出服务")
        logger.debug(f"🔍 [LogExportService] 配置的日志目录: {log_dir}")
        logger.debug(f"🔍 [LogExportService] 解析后的日志目录: {self.log_dir}")
        logger.debug(f"🔍 [LogExportService] 绝对路径: {self.log_dir.absolute()}")
        logger.debug(f"🔍 [LogExportService] 目录是否存在: {self.log_dir.exists()}")

        if not self.log_dir.exists():
            logger.warning(f"⚠️ [LogExportService] 日志目录不存在: {self.log_dir}")
            try:
                self.log_dir.mkdir(parents=True, exist_ok=True)
                logger.info(f"✅ [LogExportService] 已创建日志目录: {self.log_dir}")
            except Exception as e:
                logger.error(f"❌ [LogExportService] 创建日志目录失败: {e}")
        else:
            logger.info("✅ [LogExportService] 日志目录存在")

    def list_log_files(self) -> List[Dict[str, Any]]:

        log_files = []

        try:
            logger.debug("🔍 [list_log_files] 开始列出日志文件")
            logger.debug(f"🔍 [list_log_files] 搜索目录: {self.log_dir}")
            logger.debug(f"🔍 [list_log_files] 绝对路径: {self.log_dir.absolute()}")
            logger.debug(f"🔍 [list_log_files] 目录是否存在: {self.log_dir.exists()}")
            logger.debug(f"🔍 [list_log_files] 是否为目录: {self.log_dir.is_dir()}")

            if not self.log_dir.exists():
                logger.error(f"❌ [list_log_files] 日志目录不存在: {self.log_dir}")
                return []

            if not self.log_dir.is_dir():
                logger.error(f"❌ [list_log_files] 路径不是目录: {self.log_dir}")
                return []

            try:
                all_items = list(self.log_dir.iterdir())
                logger.debug(f"🔍 [list_log_files] 目录中共有 {len(all_items)} 个项目")
                for item in all_items[:10]:
                    logger.debug(f"🔍 [list_log_files]   - {item.name} (is_file: {item.is_file()})")
            except Exception as e:
                logger.error(f"❌ [list_log_files] 列出目录内容失败: {e}")

            logger.debug("🔍 [list_log_files] 搜索模式: *.log*")
            for file_path in self.log_dir.glob("*.log*"):
                logger.debug(f"🔍 [list_log_files] 找到文件: {file_path.name}")
                if file_path.is_file():
                    stat = file_path.stat()
                    log_file_info = {
                        "name": file_path.name,
                        "path": str(file_path),
                        "size": stat.st_size,
                        "size_mb": round(stat.st_size / (1024 * 1024), 2),
                        "modified_at": format_iso(fromtimestamp_aware(stat.st_mtime)),
                        "type": self._get_log_type(file_path.name)
                    }
                    log_files.append(log_file_info)
                    logger.debug(f"✅ [list_log_files] 添加日志文件: {file_path.name} ({log_file_info['size_mb']} MB)")
                else:
                    logger.warning(f"⚠️ [list_log_files] 跳过非文件项: {file_path.name}")

            log_files.sort(key=lambda x: x["modified_at"], reverse=True)

            logger.info(f"📋 [list_log_files] 最终找到 {len(log_files)} 个日志文件")
            return log_files

        except Exception as e:
            logger.error(f"❌ [list_log_files] 列出日志文件失败: {e}", exc_info=True)
            return []

    def _get_log_type(self, filename: str) -> str:

        if "error" in filename.lower():
            return "error"
        elif "webapi" in filename.lower():
            return "webapi"
        elif "worker" in filename.lower():
            return "worker"
        elif "access" in filename.lower():
            return "access"
        else:
            return "other"

    def read_log_file(
        self,
        filename: str,
        lines: int = 1000,
        level: Optional[str] = None,
        keyword: Optional[str] = None,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None
    ) -> Dict[str, Any]:

        file_path = self.log_dir / filename

        if not file_path.resolve().is_relative_to(self.log_dir.resolve()):
            raise ValueError(f"非法文件路径: {filename}")

        if not file_path.exists():
            raise FileNotFoundError(f"日志文件不存在: {filename}")
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                all_lines = f.readlines()
            
            recent_lines = all_lines[-lines:] if len(all_lines) > lines else all_lines
            
            filtered_lines = []
            stats = {
                "total_lines": len(all_lines),
                "filtered_lines": 0,
                "error_count": 0,
                "warning_count": 0,
                "info_count": 0,
                "debug_count": 0
            }
            
            for line in recent_lines:
                if "ERROR" in line:
                    stats["error_count"] += 1
                elif "WARNING" in line:
                    stats["warning_count"] += 1
                elif "INFO" in line:
                    stats["info_count"] += 1
                elif "DEBUG" in line:
                    stats["debug_count"] += 1
                
                if level and level.upper() not in line:
                    continue
                
                if keyword and keyword.lower() not in line.lower():
                    continue
                
                if start_time or end_time:
                    time_match = re.search(r'\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}', line)
                    if time_match:
                        log_time = time_match.group()
                        if start_time and log_time < start_time:
                            continue
                        if end_time and log_time > end_time:
                            continue
                
                filtered_lines.append(line.rstrip())
            
            stats["filtered_lines"] = len(filtered_lines)
            
            return {
                "filename": filename,
                "lines": filtered_lines,
                "stats": stats
            }
            
        except Exception as e:
            logger.error(f"❌ 读取日志文件失败: {e}")
            raise

    def export_logs(
        self,
        filenames: Optional[List[str]] = None,
        level: Optional[str] = None,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        format: str = "zip"
    ) -> str:

        try:
            if filenames:
                files_to_export = [self.log_dir / f for f in filenames if (self.log_dir / f).exists()]
            else:
                files_to_export = list(self.log_dir.glob("*.log*"))
            
            if not files_to_export:
                raise ValueError("没有找到要导出的日志文件")
            
            export_dir = Path("./exports/logs")
            export_dir.mkdir(parents=True, exist_ok=True)
            
            timestamp = now_utc().strftime("%Y%m%d_%H%M%S")
            
            if format == "zip":
                export_path = export_dir / f"logs_export_{timestamp}.zip"
                
                with zipfile.ZipFile(export_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    for file_path in files_to_export:
                        if level or start_time or end_time:
                            filtered_data = self.read_log_file(
                                file_path.name,
                                lines=999999,
                                level=level,
                                start_time=start_time,
                                end_time=end_time
                            )
                            temp_file = export_dir / f"temp_{uuid.uuid4().hex}_{file_path.name}"
                            with open(temp_file, 'w', encoding='utf-8') as f:
                                f.write('\n'.join(filtered_data['lines']))
                            zipf.write(temp_file, file_path.name)
                            temp_file.unlink()
                        else:
                            zipf.write(file_path, file_path.name)
                
                logger.info(f"✅ 日志导出成功: {export_path}")
                return str(export_path)
            
            elif format == "txt":
                export_path = export_dir / f"logs_export_{timestamp}.txt"
                
                with open(export_path, 'w', encoding='utf-8') as outf:
                    for file_path in files_to_export:
                        outf.write(f"\n{'='*80}\n")
                        outf.write(f"文件: {file_path.name}\n")
                        outf.write(f"{'='*80}\n\n")
                        
                        if level or start_time or end_time:
                            filtered_data = self.read_log_file(
                                file_path.name,
                                lines=999999,
                                level=level,
                                start_time=start_time,
                                end_time=end_time
                            )
                            outf.write('\n'.join(filtered_data['lines']))
                        else:
                            with open(file_path, 'r', encoding='utf-8', errors='ignore') as inf:
                                outf.write(inf.read())
                        
                        outf.write('\n\n')
                
                logger.info(f"✅ 日志导出成功: {export_path}")
                return str(export_path)
            
            else:
                raise ValueError(f"不支持的导出格式: {format}")
                
        except Exception as e:
            logger.error(f"❌ 导出日志失败: {e}")
            raise

    def get_log_statistics(self, days: int = 7) -> Dict[str, Any]:

        try:
            cutoff_time = now_utc() - timedelta(days=days)

            stats = DEFAULT_LOG_STATISTICS.copy()

            if not self.log_dir.exists():
                logger.warning(f"⚠️ 日志目录不存在: {self.log_dir}")
                return stats

            for file_path in self.log_dir.glob("*.log*"):
                try:
                    if not file_path.is_file():
                        continue

                    stat = file_path.stat()
                    modified_time = fromtimestamp_aware(stat.st_mtime, to_config_tz=False)

                    if modified_time < cutoff_time:
                        continue

                    stats["total_files"] += 1
                    stats["total_size_mb"] += stat.st_size / (1024 * 1024)

                    log_type = self._get_log_type(file_path.name)
                    stats["log_types"][log_type] = stats["log_types"].get(log_type, 0) + 1

                    if log_type == "error":
                        stats["error_files"] += 1
                        try:
                            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                                lines = f.readlines()
                                error_lines = [line for line in lines[-100:] if "ERROR" in line]
                                stats["recent_errors"].extend(error_lines[-10:])
                        except Exception as file_error:
                            logger.warning(f"⚠️ 读取错误日志文件失败 {file_path.name}: {file_error}")

                except Exception as file_error:
                    logger.warning(f"⚠️ 处理日志文件失败 {file_path.name}: {file_error}")
                    continue
            
            stats["total_size_mb"] = round(stats["total_size_mb"], 2)

            if len(stats["recent_errors"]) > 50:
                stats["recent_errors"] = stats["recent_errors"][-50:]

            return stats
            
        except Exception as e:
            logger.error(f"❌ 获取日志统计失败: {e}", exc_info=True)
            return DEFAULT_LOG_STATISTICS.copy()

_log_export_service: Optional[LogExportService] = None

def get_log_export_service() -> LogExportService:
    global _log_export_service

    if _log_export_service is None:
        log_dir = _get_log_directory()
        _log_export_service = LogExportService(log_dir=log_dir)

    return _log_export_service

def _get_log_directory() -> str:
    from pathlib import Path

    try:
        logger.debug("🔍 [_get_log_directory] 开始获取日志目录")

        docker_env = get_env("DOCKER", "")
        dockerenv_exists = Path("/.dockerenv").exists()
        is_docker = docker_env.lower() in {"1", "true", "yes"} or dockerenv_exists

        logger.debug(f"🔍 [_get_log_directory] DOCKER环境变量: {docker_env}")
        logger.debug(f"🔍 [_get_log_directory] /.dockerenv存在: {dockerenv_exists}")
        logger.debug(f"🔍 [_get_log_directory] 判定为Docker环境: {is_docker}")

        try:
            import tomllib as toml_loader
            logger.debug("🔍 [_get_log_directory] 使用 tomllib 加载TOML")
        except ImportError:
            try:
                import tomli as toml_loader
                logger.debug("🔍 [_get_log_directory] 使用 tomli 加载TOML")
            except ImportError:
                toml_loader = None
                logger.warning("⚠️ [_get_log_directory] 无法导入TOML加载器")

        if toml_loader:
            profile = get_env("LOGGING_PROFILE", "")
            logger.debug(f"🔍 [_get_log_directory] LOGGING_PROFILE: {profile}")

            cfg_path = Path("config/logging_docker.toml") if profile.lower() == "docker" or is_docker else Path("config/logging.toml")
            logger.debug(f"🔍 [_get_log_directory] 选择配置文件: {cfg_path}")
            logger.debug(f"🔍 [_get_log_directory] 配置文件存在: {cfg_path.exists()}")

            if cfg_path.exists():
                try:
                    with cfg_path.open("rb") as f:
                        toml_data = toml_loader.load(f)

                    logger.debug("🔍 [_get_log_directory] 成功加载配置文件")

                    handlers_cfg = toml_data.get("logging", {}).get("handlers", {})
                    file_handler_cfg = handlers_cfg.get("file", {})
                    log_dir = file_handler_cfg.get("directory")

                    logger.debug(f"🔍 [_get_log_directory] 配置文件中的日志目录: {log_dir}")

                    if log_dir:
                        logger.info(f"✅ [_get_log_directory] 从日志配置文件读取日志目录: {log_dir}")
                        return log_dir
                except Exception as e:
                    logger.warning(f"⚠️ [_get_log_directory] 读取日志配置文件失败: {e}", exc_info=True)

        try:
            from app.core.config import settings
            log_dir = settings.log_dir
            logger.debug(f"🔍 [_get_log_directory] settings.log_dir: {log_dir}")
            if log_dir:
                logger.info(f"✅ [_get_log_directory] 从settings读取日志目录: {log_dir}")
                return log_dir
        except Exception as e:
            logger.warning(f"⚠️ [_get_log_directory] 从settings读取日志目录失败: {e}", exc_info=True)

        from app.utils.runtime_paths import get_logs_dir
        default_log_dir = str(get_logs_dir())
        if is_docker:
            logger.info("✅ [_get_log_directory] Docker环境，使用默认日志目录: /app/runtime/logs")
            return "/app/runtime/logs"

        logger.info(f"✅ [_get_log_directory] 使用默认日志目录: {default_log_dir}")
        return default_log_dir

    except Exception as e:
        logger.error(f"❌ [_get_log_directory] 获取日志目录失败: {e}", exc_info=True)
        try:
            from app.utils.runtime_paths import get_logs_dir
            return str(get_logs_dir())
        except Exception as e:
            logger.debug(f"获取日志目录失败: {e}")
            return "./runtime/logs"
