import asyncio
import logging
import re
from collections import OrderedDict
from threading import Lock
from typing import Any, Dict, List, Optional

from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.core.database import get_mongo_db, get_mongo_db_sync
from app.utils.timezone import now_utc, to_config_tz

logger = logging.getLogger(__name__)

_STOCK_NAME_CACHE_MAX_SIZE = 512
_stock_name_cache: "OrderedDict[str, str]" = OrderedDict()
_stock_name_cache_lock = Lock()

def _get_cached_stock_name(stock_code: str) -> Optional[str]:
    with _stock_name_cache_lock:
        cached_name = _stock_name_cache.get(stock_code)
        if cached_name is None:
            return None
        _stock_name_cache.move_to_end(stock_code)
        return cached_name

def _cache_stock_name(stock_code: str, stock_name: str) -> str:
    with _stock_name_cache_lock:
        _stock_name_cache[stock_code] = stock_name
        _stock_name_cache.move_to_end(stock_code)
        if len(_stock_name_cache) > _STOCK_NAME_CACHE_MAX_SIZE:
            _stock_name_cache.popitem(last=False)
    return stock_name

def _get_stock_name_sync(stock_code: str) -> str:
    cached_name = _get_cached_stock_name(stock_code)
    if cached_name is not None:
        return cached_name

    try:
        from app.data.core.registry.priority import PriorityConfig

        db = get_mongo_db_sync()
        if db is None:
            return _cache_stock_name(stock_code, stock_code)

        code6 = str(stock_code).zfill(6)

        enabled_sources = PriorityConfig().get_default_sources("CN", "basic_info")

        stock_info = None
        for data_source in enabled_sources:
            result = db.stock_basic_info.find_one(
                {"symbol": code6, "data_source": data_source}
            )
            if result is not None and not hasattr(result, '__await__'):
                stock_info = result
                logger.debug(f"使用数据源 {data_source} 获取股票名称 {code6}")
                break

        if not stock_info:
            result = db.stock_basic_info.find_one(
                {"symbol": code6}
            )
            if result is not None and not hasattr(result, '__await__'):
                stock_info = result

        if stock_info and stock_info.get("name"):
            return _cache_stock_name(stock_code, stock_info["name"])

        return _cache_stock_name(stock_code, stock_code)

    except Exception as e:
        logger.warning(f"获取股票名称失败 {stock_code}: {e}")
        return stock_code

async def _get_stock_name_async(stock_code: str) -> str:
    return await asyncio.to_thread(_get_stock_name_sync, stock_code)

def _build_report_query(report_id: str) -> Dict[str, Any]:
    ors: List[Dict[str, Any]] = [
        {"analysis_id": report_id},
        {"task_id": report_id},
    ]
    try:
        ors.append({"_id": ObjectId(report_id)})
    except Exception as e:
        logger.debug(f"ObjectId转换失败: {e}")
        pass
    return {"$or": ors}

_KNOWN_REPORT_KEYS = {
    "bull_researcher", "bear_researcher", "research_team_decision",
    "trader_investment_plan",
    "risky_analyst", "safe_analyst", "neutral_analyst", "risk_management_decision", "risk_manager_decision",
}

def _extract_reports_from_state(state: Dict[str, Any]) -> Dict[str, str]:
    reports: Dict[str, str] = {}
    if not isinstance(state, dict):
        return reports

    for key in state.keys():
        if key.endswith("_report") or key in _KNOWN_REPORT_KEYS:
            content = state[key]
            if content:
                if isinstance(content, str):
                    reports[key] = content
                elif hasattr(content, "content") and isinstance(content.content, str):
                    reports[key] = content.content
                else:
                    try:
                        reports[key] = str(content)
                    except Exception as e:
                        logger.debug(f"读取报告内容失败: {e}")
                        pass
    return reports

_RISK_LEVEL_MAP = {"High": "高", "Medium": "中等", "Low": "低"}

def _extract_structured_fields(doc: Dict[str, Any]) -> Dict[str, Any]:
    structured_summary = doc.get("structured_summary") or {}

    confidence_score = doc.get("confidence_score", 0.0)
    risk_level = doc.get("risk_level", "中等")
    recommendation = doc.get("recommendation", "")
    summary = doc.get("summary", "")

    if structured_summary:
        if structured_summary.get("model_confidence"):
            confidence_score = structured_summary.get("model_confidence", 0) / 100.0
        if structured_summary.get("risk_assessment", {}).get("level"):
            risk_level = _RISK_LEVEL_MAP.get(
                structured_summary.get("risk_assessment", {}).get("level", "Medium"),
                "中等"
            )
        if structured_summary.get("investment_recommendation"):
            recommendation = structured_summary.get("investment_recommendation", "")
        if structured_summary.get("analysis_summary") and not summary:
            summary = structured_summary.get("analysis_summary", "")

    return {
        "confidence_score": confidence_score,
        "risk_level": risk_level,
        "recommendation": recommendation,
        "summary": summary,
        "structured_summary": structured_summary,
    }

def _infer_market_type(stock_code: str) -> str:
    try:
        from app.utils.stock_utils import StockUtils
        market_info = StockUtils.get_market_info(stock_code)
        market_type_map = {
            "china_a": "A股",
            "hong_kong": "港股",
            "us": "美股",
            "unknown": "A股"
        }
        return market_type_map.get(market_info.get("market", "unknown"), "A股")
    except Exception as e:
        logger.debug(f"获取市场类型失败: {e}")
        return "A股"

class ReportsService:

    def __init__(self, db: AsyncIOMotorDatabase):
        self.db = db

    async def list_reports(
        self,
        filters: Optional[Dict[str, Any]] = None,
        page: int = 1,
        page_size: int = 20,
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:

        query = self._build_list_query(filters or {}, user_id)

        total = await self.db.analysis_reports.count_documents(query)

        skip = (page - 1) * page_size
        cursor = (
            self.db.analysis_reports
            .find(query)
            .sort("created_at", -1)
            .skip(skip)
            .limit(page_size)
        )

        reports = []
        async for doc in cursor:
            report = await self._format_report_list_item(doc)
            reports.append(report)

        return {
            "reports": reports,
            "total": total,
            "page": page,
            "page_size": page_size,
        }

    async def get_report(self, report_id: str) -> Optional[Dict[str, Any]]:

        query = _build_report_query(report_id)
        doc = await self.db.analysis_reports.find_one(query)

        if doc:
            return await self._format_report_detail_from_reports_collection(doc)

        return await self._restore_report_from_tasks(report_id)

    async def get_report_by_task_id(self, task_id: str) -> Optional[Dict[str, Any]]:

        doc = await self.db.analysis_reports.find_one({"task_id": task_id})
        if doc:
            return await self._format_report_detail_from_reports_collection(doc)

        return await self._restore_report_from_tasks(task_id)

    async def delete_report(
        self,
        report_id: str,
        user_id: Optional[str] = None,
    ) -> bool:

        query = _build_report_query(report_id)
        result = await self.db.analysis_reports.delete_one(query)
        return result.deleted_count > 0

    async def get_report_stats(self) -> Dict[str, Any]:

        pipeline = [
            {
                "$group": {
                    "_id": "$market_type",
                    "count": {"$sum": 1},
                }
            }
        ]

        by_market: Dict[str, int] = {}
        total = 0
        async for group_doc in self.db.analysis_reports.aggregate(pipeline):
            market = group_doc["_id"] or "未知"
            count = group_doc["count"]
            by_market[market] = count
            total += count

        no_market_count = await self.db.analysis_reports.count_documents(
            {"market_type": {"$exists": False}}
        )
        if no_market_count > 0 and "未知" not in by_market:
            by_market["未知"] = no_market_count

        now = now_utc()
        from datetime import timedelta
        seven_days_ago = now - timedelta(days=7)
        thirty_days_ago = now - timedelta(days=30)

        last_7_days = await self.db.analysis_reports.count_documents(
            {"created_at": {"$gte": seven_days_ago}}
        )
        last_30_days = await self.db.analysis_reports.count_documents(
            {"created_at": {"$gte": thirty_days_ago}}
        )

        return {
            "total": total,
            "by_market": by_market,
            "last_7_days": last_7_days,
            "last_30_days": last_30_days,
        }

    async def download_report(self, report_id: str) -> Optional[Dict[str, Any]]:

        query = _build_report_query(report_id)
        doc = await self.db.analysis_reports.find_one(query)

        if not doc:
            return None

        if "_id" in doc:
            doc["_id"] = str(doc["_id"])

        return doc

    def _build_list_query(
        self,
        filters: Dict[str, Any],
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        query: Dict[str, Any] = {}

        if user_id:
            query["user_id"] = user_id

        search_keyword = filters.get("search_keyword")
        if search_keyword:
            escaped = re.escape(search_keyword)
            query["$or"] = [
                {"stock_symbol": {"$regex": escaped, "$options": "i"}},
                {"analysis_id": {"$regex": escaped, "$options": "i"}},
                {"summary": {"$regex": escaped, "$options": "i"}},
            ]

        market_filter = filters.get("market_filter")
        if market_filter:
            query["market_type"] = market_filter

        stock_code = filters.get("stock_code")
        if stock_code:
            query["stock_symbol"] = stock_code

        start_date = filters.get("start_date")
        end_date = filters.get("end_date")
        if start_date or end_date:
            date_query: Dict[str, str] = {}
            if start_date:
                date_query["$gte"] = start_date
            if end_date:
                date_query["$lte"] = end_date
            query["analysis_date"] = date_query

        return query

    async def _format_report_list_item(self, doc: Dict[str, Any]) -> Dict[str, Any]:
        stock_code = doc.get("stock_symbol", "")

        stock_name = doc.get("stock_name")
        if not stock_name:
            stock_name = await _get_stock_name_async(stock_code)

        market_type = doc.get("market_type")
        if not market_type:
            market_type = _infer_market_type(stock_code)

        created_at = doc.get("created_at", now_utc())
        created_at_tz = to_config_tz(created_at)

        return {
            "id": str(doc["_id"]),
            "analysis_id": doc.get("analysis_id", ""),
            "title": f"{stock_name}({stock_code}) 分析报告",
            "stock_code": stock_code,
            "stock_name": stock_name,
            "market_type": market_type,
            "model_info": doc.get("model_info", "Unknown"),
            "type": "single",
            "format": "markdown",
            "status": doc.get("status", "completed"),
            "created_at": created_at_tz.isoformat() if created_at_tz else str(created_at),
            "analysis_date": doc.get("analysis_date", ""),
            "analysts": doc.get("analysts", []),
            "summary": doc.get("summary", ""),
            "file_size": len(str(doc.get("reports", {}))),
            "source": doc.get("source", "unknown"),
            "task_id": doc.get("task_id", ""),
        }

    async def _format_report_detail_from_reports_collection(
        self,
        doc: Dict[str, Any],
    ) -> Dict[str, Any]:
        stock_symbol = doc.get("stock_symbol", "")
        stock_name = doc.get("stock_name")
        if not stock_name:
            stock_name = await _get_stock_name_async(stock_symbol)

        created_at = doc.get("created_at", now_utc())
        updated_at = doc.get("updated_at", now_utc())
        created_at_tz = to_config_tz(created_at)
        updated_at_tz = to_config_tz(updated_at)

        reports = doc.get("reports", {})
        if not reports and doc.get("task_id"):
            reports = await self._recover_reports_from_task_state(doc["task_id"])

        extracted = _extract_structured_fields(doc)

        return {
            "id": str(doc["_id"]),
            "analysis_id": doc.get("analysis_id", ""),
            "stock_symbol": stock_symbol,
            "stock_name": stock_name,
            "model_info": doc.get("model_info", "Unknown"),
            "analysis_date": doc.get("analysis_date", ""),
            "status": doc.get("status", "completed"),
            "created_at": created_at_tz.isoformat() if created_at_tz else str(created_at),
            "updated_at": updated_at_tz.isoformat() if updated_at_tz else str(updated_at),
            "analysts": doc.get("analysts", []),
            "summary": extracted["summary"],
            "reports": reports,
            "source": doc.get("source", "unknown"),
            "task_id": doc.get("task_id", ""),
            "recommendation": extracted["recommendation"],
            "confidence_score": extracted["confidence_score"],
            "risk_level": extracted["risk_level"],
            "key_points": doc.get("key_points", []),
            "execution_time": doc.get("execution_time", 0),
            "tokens_used": doc.get("tokens_used", 0),
            "structured_summary": extracted["structured_summary"],
            "decision": doc.get("decision", {}),
        }

    async def _restore_report_from_tasks(
        self,
        report_id: str,
    ) -> Optional[Dict[str, Any]]:
        tasks_doc = await self.db.analysis_tasks.find_one(
            {"$or": [{"task_id": report_id}, {"result.analysis_id": report_id}]},
            {"result": 1, "task_id": 1, "stock_code": 1, "created_at": 1, "completed_at": 1}
        )

        if not tasks_doc or not tasks_doc.get("result"):
            return None

        r = tasks_doc["result"] or {}
        created_at = tasks_doc.get("created_at")
        updated_at = tasks_doc.get("completed_at") or created_at

        reports = r.get("reports", {})
        if not reports and "state" in r:
            state = r["state"]
            reports = _extract_reports_from_state(state)
            if reports:
                logger.info(f"从 state 中恢复了 {len(reports)} 个报告模块")

        created_at_tz = to_config_tz(created_at)
        updated_at_tz = to_config_tz(updated_at)

        def _to_iso(x: Any) -> str:
            if hasattr(x, "isoformat"):
                return x.isoformat()
            return x or ""

        stock_symbol = r.get("stock_symbol", r.get("stock_code", tasks_doc.get("stock_code", "")))
        stock_name = r.get("stock_name")
        if not stock_name:
            stock_name = await _get_stock_name_async(stock_symbol)

        extracted = _extract_structured_fields(r)

        return {
            "id": tasks_doc.get("task_id", report_id),
            "analysis_id": r.get("analysis_id", ""),
            "stock_symbol": stock_symbol,
            "stock_name": stock_name,
            "model_info": r.get("model_info", "Unknown"),
            "analysis_date": r.get("analysis_date", ""),
            "status": r.get("status", "completed"),
            "created_at": _to_iso(created_at_tz),
            "updated_at": _to_iso(updated_at_tz),
            "analysts": r.get("analysts", []),
            "summary": r.get("summary", "") or extracted.get("summary", ""),
            "reports": reports,
            "source": "analysis_tasks",
            "task_id": tasks_doc.get("task_id", report_id),
            "recommendation": extracted["recommendation"],
            "confidence_score": extracted["confidence_score"],
            "risk_level": extracted["risk_level"],
            "key_points": r.get("key_points", []),
            "execution_time": r.get("execution_time", 0),
            "tokens_used": r.get("tokens_used", 0),
            "structured_summary": extracted["structured_summary"],
            "decision": r.get("decision", {}),
        }

    async def _recover_reports_from_task_state(
        self,
        task_id: str,
    ) -> Dict[str, str]:
        try:
            task_doc = await self.db.analysis_tasks.find_one(
                {"task_id": task_id},
                {"result.state": 1}
            )
            if not task_doc or not task_doc.get("result"):
                return {}

            state = task_doc["result"].get("state")
            if not isinstance(state, dict):
                return {}

            reports = _extract_reports_from_state(state)
            if reports:
                logger.info(f"从任务 state 中恢复了 {len(reports)} 个报告模块")
            return reports

        except Exception as e:
            logger.warning(f"尝试恢复报告失败: {e}")
            return {}

_service: Optional[ReportsService] = None

def get_reports_service() -> ReportsService:
    global _service
    if _service is None:
        db = get_mongo_db()
        _service = ReportsService(db)
    return _service
