import asyncio
import json
import logging
from typing import Dict, Set, Any
from fastapi import WebSocket

from app.core.config import settings

logger = logging.getLogger(__name__)

class ConnectionLimitExceeded(Exception):
    pass

class WebSocketManager:

    def __init__(self):
        self.active_connections: Dict[str, Set[WebSocket]] = {}
        self._lock = asyncio.Lock()
        self._max_per_task = getattr(
            settings, "WEBSOCKET_MAX_CONNECTIONS_PER_TASK", 5
        )
        self._max_total = getattr(
            settings, "WEBSOCKET_MAX_TOTAL_CONNECTIONS", 1000
        )

    async def connect(self, websocket: WebSocket, task_id: str):

        async with self._lock:
            total = sum(len(c) for c in self.active_connections.values())
            if total >= self._max_total:
                logger.warning(
                    f"⚠️ WebSocket 全局连接数已达上限 {self._max_total}，"
                    f"拒绝新连接 task_id={task_id}"
                )
                raise ConnectionLimitExceeded(
                    f"全局连接数已达上限 {self._max_total}"
                )
            task_conns = self.active_connections.get(task_id, set())
            if len(task_conns) >= self._max_per_task:
                logger.warning(
                    f"⚠️ WebSocket 任务 {task_id} 连接数已达上限 "
                    f"{self._max_per_task}，拒绝新连接"
                )
                raise ConnectionLimitExceeded(
                    f"任务 {task_id} 连接数已达上限 {self._max_per_task}"
                )
            if task_id not in self.active_connections:
                self.active_connections[task_id] = set()
            self.active_connections[task_id].add(websocket)

        offered = websocket.headers.get("sec-websocket-protocol", "")
        subprotocol = "bearer" if "bearer" in offered.split(",") else None
        try:
            await websocket.accept(subprotocol=subprotocol)
        except Exception as e:
            async with self._lock:
                if task_id in self.active_connections:
                    self.active_connections[task_id].discard(websocket)
                    if not self.active_connections[task_id]:
                        del self.active_connections[task_id]
            logger.warning(f"⚠️ WebSocket accept 失败: {e}")
            raise

        logger.info(f"🔌 WebSocket 连接建立: {task_id}")
    
    async def disconnect(self, websocket: WebSocket, task_id: str):
        async with self._lock:
            if task_id in self.active_connections:
                self.active_connections[task_id].discard(websocket)
                if not self.active_connections[task_id]:
                    del self.active_connections[task_id]
        
        logger.info(f"🔌 WebSocket 连接断开: {task_id}")
    
    async def send_progress_update(self, task_id: str, message: Dict[str, Any]):
        if task_id not in self.active_connections:
            return
        
        connections = self.active_connections[task_id].copy()
        
        for connection in connections:
            try:
                await connection.send_text(json.dumps(message))
            except Exception as e:
                logger.warning(f"⚠️ 发送 WebSocket 消息失败: {e}")
                async with self._lock:
                    if task_id in self.active_connections:
                        self.active_connections[task_id].discard(connection)
    
    async def broadcast_to_user(self, user_id: str, message: Dict[str, Any]):

        if not self.active_connections:
            return

        message_json = json.dumps(message, ensure_ascii=False)

        async with self._lock:
            all_connections = []
            for connections in self.active_connections.values():
                all_connections.extend(connections)

        for connection in all_connections:
            try:
                await connection.send_text(message_json)
            except Exception as e:
                logger.warning(f"⚠️ broadcast_to_user 发送失败: {e}")
    
    async def get_connection_count(self, task_id: str) -> int:
        async with self._lock:
            return len(self.active_connections.get(task_id, set()))
    
    async def get_total_connections(self) -> int:
        async with self._lock:
            total = 0
            for connections in self.active_connections.values():
                total += len(connections)
            return total

_websocket_manager = None

def get_websocket_manager() -> WebSocketManager:
    global _websocket_manager
    if _websocket_manager is None:
        _websocket_manager = WebSocketManager()
    return _websocket_manager
