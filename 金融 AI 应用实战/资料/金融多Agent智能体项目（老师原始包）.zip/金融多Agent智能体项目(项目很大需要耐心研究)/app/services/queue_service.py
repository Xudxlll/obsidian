import json
import time
import uuid
import logging
from typing import List, Optional, Dict, Any

from redis.asyncio import Redis

from app.core.database import get_redis_client
from app.core.config import settings

from app.services.queue import (
    READY_LIST,
    TASK_PREFIX,
    BATCH_PREFIX,
    SET_PROCESSING,
    SET_COMPLETED,
    SET_FAILED,
    SET_DEAD_LETTER,
    BATCH_TASKS_PREFIX,
    USER_PROCESSING_PREFIX,
    VISIBILITY_TIMEOUT_PREFIX,
    check_user_concurrent_limit,
    check_global_concurrent_limit,
    mark_task_processing,
    unmark_task_processing,
    set_visibility_timeout,
    clear_visibility_timeout,
)

logger = logging.getLogger(__name__)

class QueueService:

    def __init__(self, redis: Redis):
        self.r = redis
        self.user_concurrent_limit = settings.DEFAULT_USER_CONCURRENT_LIMIT
        self.global_concurrent_limit = settings.GLOBAL_CONCURRENT_LIMIT
        self.visibility_timeout = settings.QUEUE_VISIBILITY_TIMEOUT

    async def enqueue_task(
        self,
        user_id: str,
        symbol: str,
        params: Dict[str, Any],
        batch_id: Optional[str] = None
    ) -> str:

        if not await self._check_user_concurrent_limit(user_id):
            raise ValueError(f"用户 {user_id} 达到并发限制 ({self.user_concurrent_limit})")

        if not await self._check_global_concurrent_limit():
            raise ValueError(f"系统达到全局并发限制 ({self.global_concurrent_limit})")

        task_id = str(uuid.uuid4())
        key = TASK_PREFIX + task_id
        now = int(time.time())

        mapping = {
            "id": task_id,
            "user": user_id,
            "symbol": symbol,
            "status": "queued",
            "created_at": str(now),
            "params": json.dumps(params or {}),
            "enqueued_at": str(now)
        }

        if batch_id:
            mapping["batch_id"] = batch_id

        await self.r.hset(key, mapping=mapping)

        await self.r.lpush(READY_LIST, task_id)

        if batch_id:
            await self.r.sadd(BATCH_TASKS_PREFIX + batch_id, task_id)

        logger.info(f"任务已入队: {task_id}")
        return task_id

    async def dequeue_task(self, worker_id: str) -> Optional[Dict[str, Any]]:
        try:
            task_id = await self.r.rpop(READY_LIST)
            if not task_id:
                return None

            task_data = await self.get_task(task_id)
            if not task_data:
                logger.warning(f"任务数据不存在: {task_id}")
                return None

            user_id = task_data.get("user")

            lua_script = """
            local user_key = KEYS[1]
            local task_id = ARGV[1]
            local user_id = ARGV[2]
            local worker_id = ARGV[3]
            local limit = tonumber(ARGV[4])

            local current = redis.call('SCARD', user_key)
            if current >= limit then
                return 0
            end

            redis.call('SADD', user_key, task_id)
            return 1
            """
            limit = settings.DEFAULT_USER_CONCURRENT_LIMIT
            acquired = await self.r.eval(
                lua_script, 1,
                USER_PROCESSING_PREFIX + str(user_id),
                task_id, str(user_id), worker_id, str(limit)
            )

            if not acquired:
                await self.r.rpush(READY_LIST, task_id)
                logger.warning(f"用户 {user_id} 并发限制，任务重新入队（尾部）: {task_id}")
                return None

            await self._set_visibility_timeout(task_id, worker_id)

            await self.r.hset(TASK_PREFIX + task_id, mapping={
                "status": "processing",
                "worker_id": worker_id,
                "started_at": str(int(time.time()))
            })

            logger.info(f"任务已出队: {task_id} -> Worker: {worker_id}")
            return task_data

        except Exception as e:
            logger.error(f"出队失败: {e}")
            return None

    async def ack_task(self, task_id: str, success: bool = True) -> bool:
        try:
            task_data = await self.get_task(task_id)
            if not task_data:
                return False

            user_id = task_data.get("user")
            task_data.get("worker_id")

            await self._unmark_task_processing(task_id, user_id)

            await self._clear_visibility_timeout(task_id)

            status = "completed" if success else "failed"
            await self.r.hset(TASK_PREFIX + task_id, mapping={
                "status": status,
                "completed_at": str(int(time.time()))
            })

            if success:
                await self.r.sadd(SET_COMPLETED, task_id)
            else:
                await self.r.sadd(SET_FAILED, task_id)

            logger.info(f"任务已确认: {task_id} (成功: {success})")
            return True

        except Exception as e:
            logger.error(f"确认任务失败: {e}")
            return False

    async def create_batch(self, user_id: str, symbols: List[str], params: Dict[str, Any]) -> tuple[str, int]:
        batch_id = str(uuid.uuid4())
        now = int(time.time())
        batch_key = BATCH_PREFIX + batch_id
        await self.r.hset(batch_key, mapping={
            "id": batch_id,
            "user": user_id,
            "status": "queued",
            "submitted": str(len(symbols)),
            "created_at": str(now),
        })
        for s in symbols:
            await self.enqueue_task(user_id=user_id, symbol=s, params=params, batch_id=batch_id)
        return batch_id, len(symbols)

    async def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        key = TASK_PREFIX + task_id
        data = await self.r.hgetall(key)
        if not data:
            return None
        if "params" in data:
            try:
                data["parameters"] = json.loads(data.pop("params"))
            except Exception as e:
                logger.debug(f"解析队列任务参数失败: {e}")
                data["parameters"] = {}
        if "created_at" in data and data["created_at"].isdigit():
            data["created_at"] = int(data["created_at"])
        if "submitted" in data and str(data["submitted"]).isdigit():
            data["submitted"] = int(data["submitted"])
        return data

    async def get_batch(self, batch_id: str) -> Optional[Dict[str, Any]]:
        key = BATCH_PREFIX + batch_id
        data = await self.r.hgetall(key)
        if not data:
            return None
        submitted = data.get("submitted")
        if submitted is not None and str(submitted).isdigit():
            data["submitted"] = int(submitted)
        if "created_at" in data and data["created_at"].isdigit():
            data["created_at"] = int(data["created_at"])
        data["tasks"] = list(await self.r.smembers(BATCH_TASKS_PREFIX + batch_id))
        return data

    async def stats(self) -> Dict[str, int]:
        queued = await self.r.llen(READY_LIST)
        processing = await self.r.scard(SET_PROCESSING)
        completed = await self.r.scard(SET_COMPLETED)
        failed = await self.r.scard(SET_FAILED)
        return {
            "queued": int(queued or 0),
            "processing": int(processing or 0),
            "completed": int(completed or 0),
            "failed": int(failed or 0),
        }

    async def _check_user_concurrent_limit(self, user_id: str) -> bool:
        return await check_user_concurrent_limit(self.r, user_id, self.user_concurrent_limit)

    async def _check_global_concurrent_limit(self) -> bool:
        return await check_global_concurrent_limit(self.r, self.global_concurrent_limit)

    async def _mark_task_processing(self, task_id: str, user_id: str, worker_id: str):
        await mark_task_processing(self.r, task_id, user_id)

    async def _unmark_task_processing(self, task_id: str, user_id: str):
        await unmark_task_processing(self.r, task_id, user_id)

    async def _set_visibility_timeout(self, task_id: str, worker_id: str):
        await set_visibility_timeout(self.r, task_id, worker_id, self.visibility_timeout)

    async def _clear_visibility_timeout(self, task_id: str):
        await clear_visibility_timeout(self.r, task_id)

    async def cleanup_expired_tasks(self):
        try:
            current_time = int(time.time())
            expired_tasks = []

            async for key in self.r.scan_iter(match=VISIBILITY_TIMEOUT_PREFIX + "*", count=100):
                timeout_data = await self.r.hgetall(key)
                if timeout_data:
                    timeout_at = int(timeout_data.get("timeout_at", 0))
                    if current_time > timeout_at:
                        task_id = timeout_data.get("task_id")
                        if task_id:
                            expired_tasks.append(task_id)

            for task_id in expired_tasks:
                await self._handle_expired_task(task_id)

            if expired_tasks:
                logger.warning(f"处理了 {len(expired_tasks)} 个过期任务")

        except Exception as e:
            logger.error(f"清理过期任务失败: {e}")

    async def _handle_expired_task(self, task_id: str):

        try:
            task_data = await self.get_task(task_id)
            if not task_data:
                return

            user_id = task_data.get("user")

            await self._unmark_task_processing(task_id, user_id)

            await self._clear_visibility_timeout(task_id)

            max_retries = getattr(settings, "QUEUE_MAX_RETRIES", 3)
            current_retries = int(task_data.get("retry_count", 0))

            if current_retries >= max_retries:
                await self.r.sadd(SET_DEAD_LETTER, task_id)
                await self.r.hset(TASK_PREFIX + task_id, mapping={
                    "status": "dead_letter",
                    "dead_letter_at": str(int(time.time())),
                    "retry_count": current_retries,
                })
                logger.error(
                    f"任务 {task_id} 已达重试上限 {max_retries}，移入死信队列"
                )
                return

            await self.r.rpush(READY_LIST, task_id)

            await self.r.hset(TASK_PREFIX + task_id, mapping={
                "status": "queued",
                "worker_id": "",
                "requeued_at": str(int(time.time())),
                "retry_count": current_retries + 1,
            })

            logger.warning(
                f"过期任务重新入队: {task_id} (将进行第 {current_retries + 1} 次重试，上限 {max_retries})"
            )

        except Exception as e:
            logger.error(f"处理过期任务失败: {task_id} - {e}")

    async def cancel_task(self, task_id: str) -> bool:
        try:
            task_data = await self.get_task(task_id)
            if not task_data:
                return False

            status = task_data.get("status")
            user_id = task_data.get("user")

            if status == "processing":
                await self._unmark_task_processing(task_id, user_id)
                await self._clear_visibility_timeout(task_id)
            elif status == "queued":
                await self.r.lrem(READY_LIST, 0, task_id)

            await self.r.hset(TASK_PREFIX + task_id, mapping={
                "status": "cancelled",
                "cancelled_at": str(int(time.time()))
            })

            logger.info(f"任务已取消: {task_id}")
            return True

        except Exception as e:
            logger.error(f"取消任务失败: {e}")
            return False

def get_queue_service() -> QueueService:
    return QueueService(get_redis_client())
