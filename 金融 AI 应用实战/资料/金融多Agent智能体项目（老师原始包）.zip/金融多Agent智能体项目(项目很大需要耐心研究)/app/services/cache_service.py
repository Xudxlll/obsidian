from typing import Dict, List, Optional, Tuple

from app.data.storage.cache.memory_cache import TTLCache
from app.data.storage.redis.client import get_redis

FORBIDDEN_KEY_PREFIXES: Tuple[str, ...] = (
    "token_blacklist:",
    "system_secrets:",
    "session:",
    "ratelimit:",
    "auth:",
    "lock:",
)

BUSINESS_CACHE_PATTERN = "foreign_stock:*"

class CacheService:

    _instance: Optional["CacheService"] = None
    _memory_cache: Optional[TTLCache] = None

    @classmethod
    def get_instance(cls) -> "CacheService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def register_memory_cache(cls, cache: TTLCache) -> None:
        cls._memory_cache = cache

    @classmethod
    def reset_instance(cls) -> None:
        cls._instance = None
        cls._memory_cache = None

    @staticmethod
    def is_forbidden_key(key: str) -> bool:
        if not key:
            return False
        return any(key.startswith(prefix) for prefix in FORBIDDEN_KEY_PREFIXES)

    @staticmethod
    def _get_redis():
        try:
            return get_redis()
        except Exception:
            return None

    def get_memory_cache(self) -> Optional[TTLCache]:
        return self._memory_cache

    async def get_stats(self) -> Dict:
        redis = self._get_redis()
        redis_info: Dict = {}
        total_keys = 0
        if redis:
            try:
                total_keys = await redis.dbsize()
                info = await redis.info("memory")
                redis_info = {
                    "used_memory_human": info.get("used_memory_human", "N/A"),
                    "used_memory_peak_human": info.get(
                        "used_memory_peak_human", "N/A"
                    ),
                }
            except Exception:
                pass

        memory_size = self._memory_cache.size() if self._memory_cache else 0
        return {
            "redis": {"totalKeys": total_keys, **redis_info},
            "memoryCache": {"size": memory_size},
            "totalSize": 0,
            "maxSize": 1024 * 1024 * 1024,
            "stockDataCount": 0,
            "newsDataCount": 0,
            "analysisDataCount": 0,
        }

    async def cleanup_old_cache(self) -> int:
        redis = self._get_redis()
        deleted = 0
        if not redis:
            return 0
        try:
            cursor = 0
            while True:
                cursor, keys = await redis.scan(
                    cursor, match=BUSINESS_CACHE_PATTERN, count=100
                )
                if keys:
                    for key in keys:
                        ttl = await redis.ttl(key)
                        if ttl == -1:
                            await redis.delete(key)
                            deleted += 1
                if cursor == 0:
                    break
        except Exception:
            pass
        return deleted

    async def clear_all(self) -> int:
        redis = self._get_redis()
        deleted = 0
        if redis:
            try:
                cursor = 0
                while True:
                    cursor, keys = await redis.scan(
                        cursor, match=BUSINESS_CACHE_PATTERN, count=100
                    )
                    if keys:
                        await redis.delete(*keys)
                        deleted += len(keys)
                    if cursor == 0:
                        break
            except Exception:
                pass
        if self._memory_cache:
            self._memory_cache.clear()
        return deleted

    async def list_details(self, page: int, page_size: int) -> Dict:
        redis = self._get_redis()
        items: List[Dict] = []
        total = 0
        if not redis:
            return {"items": items, "total": total, "page": page, "page_size": page_size}

        try:
            all_keys = []
            cursor = 0
            while True:
                cursor, keys = await redis.scan(
                    cursor, match=BUSINESS_CACHE_PATTERN, count=100
                )
                all_keys.extend(keys)
                if cursor == 0:
                    break

            total = len(all_keys)
            start = (page - 1) * page_size
            end = start + page_size
            for key in all_keys[start:end]:
                key_str = key if isinstance(key, str) else key.decode()
                ttl = await redis.ttl(key)
                key_type = await redis.type(key)
                items.append({"key": key_str, "ttl": ttl, "type": key_type})
        except Exception:
            pass

        return {
            "items": items,
            "total": total,
            "page": page,
            "page_size": page_size,
        }

    async def delete_item(self, key: str) -> Tuple[bool, bool, bool]:

        if self.is_forbidden_key(key):
            raise PermissionError("forbidden system cache key")

        redis_deleted = False
        redis = self._get_redis()
        if redis:
            try:
                deleted = await redis.delete(key)
                redis_deleted = deleted > 0
            except Exception:
                pass

        memory_deleted = False
        if self._memory_cache:
            memory_deleted = self._memory_cache.invalidate(key)

        existed = redis_deleted or memory_deleted
        return existed, redis_deleted, memory_deleted
