from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional
from datetime import datetime, timedelta
from app.utils.timezone import now_utc

import pandas as pd

from app.utils.indicators import IndicatorSpec, compute_many
from app.data.core.interface import DataInterface
from app.data.core.reader import Reader

from app.services.screening.eval_utils import (
    collect_fields_from_conditions as _collect_fields_from_conditions_util,
    evaluate_conditions as _evaluate_conditions_util,
    evaluate_fund_conditions as _evaluate_fund_conditions_util,
    safe_float as _safe_float_util,
)

ALLOWED_FIELDS = {
    "open", "high", "low", "close", "vol", "amount",
    "pct_chg",
    "ma5", "ma10", "ma20", "ma60",
    "ema12", "ema26",
    "dif", "dea", "macd_hist",
    "rsi14",
    "boll_mid", "boll_upper", "boll_lower",
    "atr14",
    "kdj_k", "kdj_d", "kdj_j",
    "pe", "pb", "roe", "market_cap",
}

BASE_FIELDS = {"open", "high", "low", "close", "vol", "amount", "pct_chg"}
TECH_FIELDS = {
    "ma5", "ma10", "ma20", "ma60",
    "ema12", "ema26",
    "dif", "dea", "macd_hist",
    "rsi14",
    "boll_mid", "boll_upper", "boll_lower",
    "atr14",
    "kdj_k", "kdj_d", "kdj_j",
}
FUND_FIELDS = {"pe", "pb", "roe", "market_cap"}

ALLOWED_OPS = {">", "<", ">=", "<=", "==", "!=", "between", "cross_up", "cross_down"}

@dataclass
class ScreeningParams:
    market: str = "CN"
    date: Optional[str] = None
    adj: str = "qfq"
    limit: int = 50
    offset: int = 0
    order_by: Optional[List[Dict[str, str]]] = None

import logging
logger = logging.getLogger("agents")

class ScreeningService:
    def __init__(self):
        self.provider = None

    def run(self, conditions: Dict[str, Any], params: ScreeningParams) -> Dict[str, Any]:
        symbols = self._get_universe()

        if params.date:
            end_date = datetime.strptime(params.date, "%Y-%m-%d")
        else:
            end_date = now_utc()
        start_date = end_date - timedelta(days=220)
        end_s = end_date.strftime("%Y-%m-%d")
        start_s = start_date.strftime("%Y-%m-%d")

        results: List[Dict[str, Any]] = []

        needed_fields = self._collect_fields_from_conditions(conditions)
        order_fields = {o.get("field") for o in (params.order_by or []) if o.get("field")}
        all_needed = set(needed_fields) | set(order_fields)
        need_tech = any(f in TECH_FIELDS for f in all_needed)
        need_base = any(f in BASE_FIELDS for f in all_needed) or need_tech
        need_fund = any(f in FUND_FIELDS for f in all_needed)

        reader = Reader() if need_base else None

        for code in symbols:
            try:
                dfc = None
                last = None

                if need_base:
                    from app.core.async_utils import run_async
                    raw_records = run_async(
                        reader.get_data("CN", code, "daily_quotes", start_date=start_s, end_date=end_s)
                    )
                    raw_data = raw_records[0] if raw_records else None
                    if not raw_data:
                        continue
                    df = pd.DataFrame(raw_data) if isinstance(raw_data, list) else pd.DataFrame([raw_data])
                    if df.empty:
                        continue
                    dfu = df.rename(columns={
                        "Open": "open", "High": "high", "Low": "low", "Close": "close",
                        "Volume": "vol", "Amount": "amount"
                    }).copy()
                    if "close" in dfu.columns:
                        dfu["pct_chg"] = dfu["close"].pct_change() * 100.0

                    if need_tech:
                        specs = [
                            IndicatorSpec("ma", {"n": 5}),
                            IndicatorSpec("ma", {"n": 10}),
                            IndicatorSpec("ma", {"n": 20}),
                            IndicatorSpec("ema", {"n": 12}),
                            IndicatorSpec("ema", {"n": 26}),
                            IndicatorSpec("macd"),
                            IndicatorSpec("rsi", {"n": 14}),
                            IndicatorSpec("boll", {"n": 20, "k": 2}),
                            IndicatorSpec("atr", {"n": 14}),
                            IndicatorSpec("kdj", {"n": 9, "m1": 3, "m2": 3}),
                        ]
                        dfc = compute_many(dfu, specs)
                    else:
                        dfc = dfu

                    last = dfc.iloc[-1]

                passes = True
                if need_base:
                    passes = self._evaluate_conditions(dfc, conditions)
                elif need_fund and not need_base and not need_tech:
                    from app.core.async_utils import run_async
                    try:
                        _di = DataInterface.get_instance()
                        fund_data = run_async(_di.read("CN", "financial_data", symbol=code))
                        snap = fund_data.get("data")
                    except Exception as e:
                        logger.debug(f"获取财务数据失败: {e}")
                        snap = None
                    if not snap:
                        passes = False
                    else:
                        passes = self._evaluate_fund_conditions(snap, conditions)

                if passes:
                    item = {"symbol": code}
                    if last is not None:
                        item.update({
                            "close": self._safe_float(last.get("close")),
                            "pct_chg": self._safe_float(last.get("pct_chg")),
                            "amount": self._safe_float(last.get("amount")),
                            "ma20": self._safe_float(last.get("ma20")) if need_tech else None,
                            "rsi14": self._safe_float(last.get("rsi14")) if need_tech else None,
                            "kdj_k": self._safe_float(last.get("kdj_k")) if need_tech else None,
                            "kdj_d": self._safe_float(last.get("kdj_d")) if need_tech else None,
                            "kdj_j": self._safe_float(last.get("kdj_j")) if need_tech else None,
                            "dif": self._safe_float(last.get("dif")) if need_tech else None,
                            "dea": self._safe_float(last.get("dea")) if need_tech else None,
                            "macd_hist": self._safe_float(last.get("macd_hist")) if need_tech else None,
                        })
                    results.append(item)
            except Exception as exc:
                logger.debug("筛选股票 %s 时出错: %s", code, exc)
                continue

        total = len(results)
        if params.order_by:
            for order in reversed(params.order_by):
                f = order.get("field")
                d = order.get("direction", "desc").lower()
                if f in ALLOWED_FIELDS:
                    results.sort(
                        key=lambda x, _f=f: (x.get(_f) is None, x.get(_f) or 0),
                        reverse=(d == "desc"),
                    )

        start = params.offset or 0
        end = start + (params.limit or 50)
        page_items = results[start:end]

        return {
            "total": total,
            "items": page_items,
        }
    def _evaluate_fund_conditions(self, snap: Dict[str, Any], node: Dict[str, Any]) -> bool:
        return _evaluate_fund_conditions_util(snap, node, FUND_FIELDS)

    def _collect_fields_from_conditions(self, node: Dict[str, Any]) -> List[str]:
        return _collect_fields_from_conditions_util(node, ALLOWED_FIELDS)

    def _evaluate_conditions(self, df: pd.DataFrame, node: Dict[str, Any]) -> bool:
        return _evaluate_conditions_util(df, node, ALLOWED_FIELDS, ALLOWED_OPS)

    def _safe_float(self, v: Any) -> Optional[float]:
        return _safe_float_util(v)

    def _get_universe(self) -> List[str]:
        try:
            from app.core.async_utils import run_async
            from app.data.core.interface import DataInterface

            result = run_async(
                DataInterface.get_instance().screen(
                    "CN",
                    "basic_info",
                    filters={
                        "$or": [
                            {"market_info.market": "CN"},
                            {"category": "stock_cn"},
                            {"market": "CN"},
                            {"market": {"$in": ["主板", "创业板", "科创板", "北交所"]}}
                        ]
                    },
                    projection={"symbol": 1},
                    limit=0,
                )
            )

            codes = [
                doc.get("symbol")
                for doc in result.get("items", [])
                if doc.get("symbol")
            ]

            if codes:
                logger.info(f"📊 从数据层获取到 {len(codes)} 只A股股票")
                return codes
            else:
                logger.warning("⚠️ 数据库中未找到股票数据，请先执行数据同步")
                return []

        except Exception as e:
            logger.error(f"❌ 从数据层获取股票列表失败: {e}")
            return []
