import os
from typing import Dict, List, Optional

import yaml

import logging

logger = logging.getLogger("services.report_titles")

_REPORT_KEY_SLUG_ALIAS = {
    "trader_investment_plan": "trader",
    "investment_plan": "trader",
    "final_trade_decision": "trader",
    "research_team_decision": "research-manager",
    "risk_management_decision": "risk-manager",
}

_AGENT_CONFIG_FILES = (
    "phase1_agents_config.yaml",
    "phase2_agents_config.yaml",
    "phase3_agents_config.yaml",
)

def _slug_to_internal(slug: str) -> str:
    return slug.replace("-analyst", "").replace("-", "_")

def _config_dir() -> Optional[str]:
    probe = os.path.dirname(os.path.abspath(__file__))
    for _ in range(8):
        candidate = os.path.join(probe, "config", "agents")
        if os.path.exists(candidate):
            return candidate
        nxt = os.path.dirname(probe)
        if nxt == probe:
            return None
        probe = nxt
    return None

def _load_slug_names() -> Dict[str, str]:
    names: Dict[str, str] = {}
    agents_dir = _config_dir()
    if not agents_dir:
        return names
    for config_file in _AGENT_CONFIG_FILES:
        path = os.path.join(agents_dir, config_file)
        if not os.path.exists(path):
            continue
        try:
            with open(path, "r", encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}
            for agent in (config.get("agents") or []) + (config.get("customModes") or []):
                slug, name = agent.get("slug"), agent.get("name")
                if slug and name:
                    names[slug] = name
        except Exception as e:
            logger.warning(f"⚠️ [report_titles] 读取 {config_file} 失败: {e}")
    return names

async def build_report_titles(task_id: str, report_keys: List[str]) -> Dict[str, str]:
    if not report_keys:
        return {}

    titles: Dict[str, str] = {}

    try:
        from app.services.analysis_events import load_events

        for ev in await load_events(task_id, event_type="agent_start", limit=500):
            key = ev.get("agent_key") or ""
            name = (ev.get("payload") or {}).get("name")
            if key and isinstance(name, str) and name:
                titles[key] = name
    except Exception as e:
        logger.debug(f"[report_titles] 读取任务事件失败: {e}")

    slug_names = _load_slug_names()
    internal_names = {_slug_to_internal(s): n for s, n in slug_names.items()}
    for raw_key in report_keys:
        key = raw_key.replace("_report", "")
        if key in titles:
            continue
        name = internal_names.get(key)
        if name is None:
            slug = _REPORT_KEY_SLUG_ALIAS.get(key)
            name = slug_names.get(slug) if slug else None
        if name:
            titles[key] = name

    return {k: v for k, v in titles.items()}
