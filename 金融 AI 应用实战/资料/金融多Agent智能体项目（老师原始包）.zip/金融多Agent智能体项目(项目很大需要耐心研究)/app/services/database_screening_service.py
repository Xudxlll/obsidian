import logging
from typing import Any, Dict, List, Optional, Tuple

from app.data.query.screening_query import ScreeningQueryService

logger = logging.getLogger(__name__)

class DatabaseScreeningService:

    def __init__(self):
        self._query = ScreeningQueryService()

    async def can_handle_conditions(self, conditions: List[Dict[str, Any]]) -> bool:
        return await self._query.can_handle_conditions(conditions)

    async def screen_stocks(
        self,
        conditions: List[Dict[str, Any]],
        limit: int = 50,
        offset: int = 0,
        order_by: Optional[List[Dict[str, str]]] = None,
        source: Optional[str] = None,
    ) -> Tuple[List[Dict[str, Any]], int]:
        return await self._query.screen_stocks(
            conditions=conditions,
            limit=limit,
            offset=offset,
            order_by=order_by,
            source=source,
        )

    async def get_field_statistics(self, field: str) -> Dict[str, Any]:
        return await self._query.get_field_statistics(field)

    async def get_available_values(self, field: str, limit: int = 100) -> List[str]:
        return await self._query.get_available_values(field, limit)

_database_screening_service: Optional[DatabaseScreeningService] = None

def get_database_screening_service() -> DatabaseScreeningService:
    global _database_screening_service
    if _database_screening_service is None:
        _database_screening_service = DatabaseScreeningService()
    return _database_screening_service
