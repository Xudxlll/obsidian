import logging
import re
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from bson import ObjectId

from app.core.database import get_mongo_db
from app.models.operation_log import (
    OperationLogCreate,
    OperationLogResponse,
    OperationLogQuery,
    OperationLogStats,
    convert_objectid_to_str
)
from app.utils.timezone import now_tz, now_config_tz
from app.utils.secret_masking import mask_username

logger = logging.getLogger(__name__)

class OperationLogService:
    
    def __init__(self):
        self.collection_name = "operation_logs"
    
    async def create_log(
        self,
        user_id: str,
        username: str,
        log_data: OperationLogCreate,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None
    ) -> str:
        try:
            db = get_mongo_db()

            current_time = now_tz().replace(tzinfo=None)
            log_doc = {
                "user_id": user_id,
                "username": username,
                "action_type": log_data.action_type,
                "action": log_data.action,
                "details": log_data.details or {},
                "success": log_data.success,
                "error_message": log_data.error_message,
                "duration_ms": log_data.duration_ms,
                "ip_address": ip_address or log_data.ip_address,
                "user_agent": user_agent or log_data.user_agent,
                "session_id": log_data.session_id,
                "timestamp": current_time,
                "created_at": current_time
            }
            
            result = await db[self.collection_name].insert_one(log_doc)

            logger.info(f"📝 操作日志已记录: {mask_username(username)} - {log_data.action}")
            return str(result.inserted_id)
            
        except Exception as e:
            logger.error(f"创建操作日志失败: {e}")
            raise RuntimeError(f"创建操作日志失败: {str(e)}") from e
    
    async def get_logs(self, query: OperationLogQuery) -> Tuple[List[OperationLogResponse], int]:
        try:
            db = get_mongo_db()
            
            filter_query = {}
            
            if query.start_date or query.end_date:
                time_filter = {}
                if query.start_date:
                    start_str = query.start_date.replace('Z', '')
                    time_filter["$gte"] = datetime.fromisoformat(start_str)
                if query.end_date:
                    end_str = query.end_date.replace('Z', '')
                    time_filter["$lte"] = datetime.fromisoformat(end_str)
                filter_query["timestamp"] = time_filter
            
            if query.action_type:
                filter_query["action_type"] = query.action_type
            
            if query.success is not None:
                filter_query["success"] = query.success
            
            if query.user_id:
                filter_query["user_id"] = query.user_id
            
            if query.keyword:
                escaped_keyword = re.escape(query.keyword)
                filter_query["$or"] = [
                    {"action": {"$regex": escaped_keyword, "$options": "i"}},
                    {"username": {"$regex": escaped_keyword, "$options": "i"}},
                    {"details.stock_symbol": {"$regex": escaped_keyword, "$options": "i"}}
                ]
            
            total = await db[self.collection_name].count_documents(filter_query)
            
            skip = (query.page - 1) * query.page_size
            cursor = db[self.collection_name].find(filter_query).sort("timestamp", -1).skip(skip).limit(query.page_size)
            
            logs = []
            async for doc in cursor:
                doc = convert_objectid_to_str(doc)
                logs.append(OperationLogResponse(**doc))

            logger.info(f"📋 获取操作日志: 总数={total}, 返回={len(logs)}")
            return logs, total
            
        except Exception as e:
            logger.error(f"获取操作日志失败: {e}")
            raise RuntimeError(f"获取操作日志失败: {str(e)}") from e

    async def get_all_for_export(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        action_type: Optional[str] = None,
        limit: int = 10000,
    ) -> List[OperationLogResponse]:

        try:
            db = get_mongo_db()
            filter_query: Dict[str, Any] = {}
            if start_date or end_date:
                time_filter: Dict[str, Any] = {}
                if start_date:
                    time_filter["$gte"] = datetime.fromisoformat(start_date.replace("Z", ""))
                if end_date:
                    time_filter["$lte"] = datetime.fromisoformat(end_date.replace("Z", ""))
                filter_query["timestamp"] = time_filter
            if action_type:
                filter_query["action_type"] = action_type

            cursor = (
                db[self.collection_name]
                .find(filter_query)
                .sort("timestamp", -1)
                .limit(limit)
            )
            logs: List[OperationLogResponse] = []
            async for doc in cursor:
                doc = convert_objectid_to_str(doc)
                logs.append(OperationLogResponse(**doc))
            logger.info(f"📋 导出操作日志: 返回 {len(logs)} 条 (limit={limit})")
            return logs
        except Exception as e:
            logger.error(f"导出操作日志失败: {e}")
            raise RuntimeError(f"导出操作日志失败: {str(e)}") from e

    async def get_stats(self, days: int = 30) -> OperationLogStats:
        try:
            db = get_mongo_db()
            
            start_date = now_tz() - timedelta(days=days)
            time_filter = {"timestamp": {"$gte": start_date}}
            
            total_logs = await db[self.collection_name].count_documents(time_filter)
            success_logs = await db[self.collection_name].count_documents({**time_filter, "success": True})
            failed_logs = total_logs - success_logs
            success_rate = (success_logs / total_logs * 100) if total_logs > 0 else 0
            
            action_type_pipeline = [
                {"$match": time_filter},
                {"$group": {"_id": "$action_type", "count": {"$sum": 1}}},
                {"$sort": {"count": -1}}
            ]
            action_type_cursor = db[self.collection_name].aggregate(action_type_pipeline)
            action_type_distribution = {}
            async for doc in action_type_cursor:
                action_type_distribution[doc["_id"]] = doc["count"]
            
            hourly_pipeline = [
                {"$match": time_filter},
                {
                    "$group": {
                        "_id": {"$hour": "$timestamp"},
                        "count": {"$sum": 1}
                    }
                },
                {"$sort": {"_id": 1}}
            ]
            hourly_cursor = db[self.collection_name].aggregate(hourly_pipeline)
            hourly_distribution = []
            hourly_data = {i: 0 for i in range(24)}
            
            async for doc in hourly_cursor:
                hourly_data[doc["_id"]] = doc["count"]
            
            for hour, count in hourly_data.items():
                hourly_distribution.append({
                    "hour": f"{hour:02d}:00",
                    "count": count
                })
            
            stats = OperationLogStats(
                total_logs=total_logs,
                success_logs=success_logs,
                failed_logs=failed_logs,
                success_rate=round(success_rate, 2),
                action_type_distribution=action_type_distribution,
                hourly_distribution=hourly_distribution
            )
            
            logger.info(f"📊 操作日志统计: 总数={total_logs}, 成功率={success_rate:.1f}%")
            return stats
            
        except Exception as e:
            logger.error(f"获取操作日志统计失败: {e}")
            raise RuntimeError(f"获取操作日志统计失败: {str(e)}") from e
    
    async def clear_logs(self, days: Optional[int] = None, action_type: Optional[str] = None) -> Dict[str, Any]:
        try:
            db = get_mongo_db()
            
            delete_filter = {}
            
            if days is not None:
                cutoff_date = now_config_tz() - timedelta(days=days)
                delete_filter["timestamp"] = {"$lt": cutoff_date}
            
            if action_type:
                delete_filter["action_type"] = action_type
            
            result = await db[self.collection_name].delete_many(delete_filter)
            
            logger.info(f"🗑️ 清空操作日志: 删除了 {result.deleted_count} 条记录")
            
            return {
                "deleted_count": result.deleted_count,
                "filter": delete_filter
            }
            
        except Exception as e:
            logger.error(f"清空操作日志失败: {e}")
            raise RuntimeError(f"清空操作日志失败: {str(e)}") from e
    
    async def get_log_by_id(self, log_id: str) -> Optional[OperationLogResponse]:
        try:
            db = get_mongo_db()

            doc = await db[self.collection_name].find_one({"_id": ObjectId(log_id)})
            if not doc:
                return None

            doc = convert_objectid_to_str(doc)
            return OperationLogResponse(**doc)

        except Exception as e:
            logger.error(f"获取操作日志详情失败: {e}")
            return None

_operation_log_service: Optional[OperationLogService] = None

def get_operation_log_service() -> OperationLogService:
    global _operation_log_service
    if _operation_log_service is None:
        _operation_log_service = OperationLogService()
    return _operation_log_service

async def log_operation(
    user_id: str,
    username: str,
    action_type: str,
    action: str,
    details: Optional[Dict[str, Any]] = None,
    success: bool = True,
    error_message: Optional[str] = None,
    duration_ms: Optional[int] = None,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
    session_id: Optional[str] = None
) -> str:
    try:
        service = get_operation_log_service()
        log_data = OperationLogCreate(
            action_type=action_type,
            action=action,
            details=details,
            success=success,
            error_message=error_message,
            duration_ms=duration_ms,
            ip_address=ip_address,
            user_agent=user_agent,
            session_id=session_id
        )
        return await service.create_log(user_id, username, log_data, ip_address, user_agent)
    except Exception as e:
        logger.debug(f"快速创建操作日志失败: {e}")
        return ""
