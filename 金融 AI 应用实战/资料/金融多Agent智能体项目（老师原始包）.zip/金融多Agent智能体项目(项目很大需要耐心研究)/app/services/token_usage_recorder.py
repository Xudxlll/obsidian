import asyncio
import json
import logging
from pathlib import Path
from typing import Optional

from app.core.env import get_env
from app.utils.timezone import now_utc

logger = logging.getLogger("app.services.token_usage_recorder")

COLLECTION_NAME = "token_usage"

class PricingCalculator:

    def __init__(self, pricing_file: str = "config/pricing.json"):
        self._pricing_file = Path(pricing_file)
        self._pricing_cache: list = []
        self._loaded = False

    def _load(self) -> list:
        if self._loaded:
            return self._pricing_cache
        try:
            if self._pricing_file.exists():
                with open(self._pricing_file, "r", encoding="utf-8") as f:
                    self._pricing_cache = json.load(f)
            self._loaded = True
        except Exception as e:
            logger.warning(f"加载定价配置失败: {e}")
        return self._pricing_cache

    def reload(self) -> None:
        self._loaded = False
        self._load()

    def calculate_cost(
        self,
        provider: str,
        model_name: str,
        input_tokens: int,
        output_tokens: int,
        cache_read_tokens: int = 0,
        cache_creation_tokens: int = 0,
    ) -> tuple:
        for pricing in self._load():
            if not isinstance(pricing, dict):
                continue
            if pricing.get("provider") != provider or pricing.get("model_name") != model_name:
                continue
            inp = pricing.get("input_price_per_1k", 0)
            out = pricing.get("output_price_per_1k", 0)
            cache_read_price = pricing.get("cache_read_price_per_1k", inp)
            cache_write_price = pricing.get("cache_write_price_per_1k", inp)
            billable_plain_input = max(0, input_tokens - cache_read_tokens - cache_creation_tokens)
            total = (
                (billable_plain_input / 1000) * inp
                + (cache_read_tokens / 1000) * cache_read_price
                + (cache_creation_tokens / 1000) * cache_write_price
                + (output_tokens / 1000) * out
            )
            return round(total, 6), pricing.get("currency", "CNY")
        return 0.0, "CNY"

class TokenUsageRecorder:

    def __init__(self):
        self._server_loop: Optional[asyncio.AbstractEventLoop] = None
        self._pricing = PricingCalculator()

    def set_server_loop(self, loop: Optional[asyncio.AbstractEventLoop]) -> None:
        self._server_loop = loop
        if loop is not None and loop.is_running():
            loop.create_task(self._ensure_indexes())

    async def _ensure_indexes(self) -> None:
        try:
            from app.core.database import get_mongo_db

            db = get_mongo_db()
            col = db[COLLECTION_NAME]
            await col.create_index([("timestamp", 1)])
            await col.create_index([("task_id", 1)])
        except Exception as e:
            logger.warning(f"⚠️ [Token记录] 创建索引失败: {e}")

    def _enabled(self) -> bool:
        return str(get_env("TOKEN_USAGE_RECORDING_ENABLED", "true")).lower() not in (
            "false",
            "0",
            "no",
        )

    def record(
        self,
        *,
        provider: str,
        model_name: str,
        usage,
        task_id: str = "",
        user_id: str = "",
        agent_key: str = "",
        phase: str = "",
        analysis_type: str = "stock_analysis",
    ) -> None:

        if not self._enabled():
            return
        try:
            input_tokens = int(getattr(usage, "input_tokens", 0) or 0)
            output_tokens = int(getattr(usage, "output_tokens", 0) or 0)
            cache_read = int(getattr(usage, "cache_read_input_tokens", 0) or 0)
            cache_creation = int(getattr(usage, "cache_creation_input_tokens", 0) or 0)

            cost, currency = self._pricing.calculate_cost(
                provider,
                model_name,
                input_tokens,
                output_tokens,
                cache_read_tokens=cache_read,
                cache_creation_tokens=cache_creation,
            )

            doc = {
                "timestamp": now_utc().isoformat(),
                "provider": provider,
                "model_name": model_name,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "cache_creation_input_tokens": cache_creation,
                "cache_read_input_tokens": cache_read,
                "cost": cost,
                "currency": currency,
                "session_id": task_id or "",
                "analysis_type": analysis_type,
                "task_id": task_id,
                "user_id": user_id,
                "agent_key": agent_key,
                "phase": phase,
            }
            self._schedule_insert(doc)
        except Exception as e:
            logger.warning(f"⚠️ [Token记录] 构建记录失败（已丢弃）: {e}")

    def _schedule_insert(self, doc: dict) -> None:
        loop = self._server_loop
        try:
            if loop is not None and loop.is_running():
                fut = asyncio.run_coroutine_threadsafe(self._insert(doc), loop)
                fut.add_done_callback(
                    lambda f: (
                        logger.warning(f"⚠️ [Token记录] 写入失败: {f.exception()}")
                        if f.exception()
                        else None
                    )
                )
            else:
                asyncio.get_running_loop().create_task(self._insert(doc))
        except RuntimeError:
            self._insert_sync_fallback(doc)
        except Exception as e:
            logger.warning(f"⚠️ [Token记录] 调度写入失败（已丢弃）: {e}")

    def _insert_sync_fallback(self, doc: dict) -> None:
        try:
            from app.core.database import get_mongo_db_sync

            db = get_mongo_db_sync()
            if db is None:
                return
            result = db[COLLECTION_NAME].insert_one(doc)
            if hasattr(result, "__await__"):
                logger.warning("⚠️ [Token记录] get_mongo_db_sync() 返回了 Motor 异步数据库，跳过同步写入")
        except Exception as e:
            logger.warning(f"⚠️ [Token记录] 同步兜底写入失败（已丢弃）: {e}")

    async def _insert(self, doc: dict) -> None:
        try:
            from app.core.database import get_mongo_db

            db = get_mongo_db()
            await db[COLLECTION_NAME].insert_one(doc)
            logger.info(
                f"💾 [Token记录] {doc['provider']}/{doc['model_name']} "
                f"in={doc['input_tokens']} out={doc['output_tokens']} "
                f"cache_read={doc['cache_read_input_tokens']} cost={doc['cost']}"
            )
        except Exception as e:
            logger.warning(f"⚠️ [Token记录] MongoDB 写入失败（已丢弃）: {e}")

token_usage_recorder = TokenUsageRecorder()
