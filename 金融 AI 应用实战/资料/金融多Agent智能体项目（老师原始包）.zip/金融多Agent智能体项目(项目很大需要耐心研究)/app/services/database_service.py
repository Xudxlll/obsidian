import logging
from typing import Dict, Any, List

from app.core.database import get_mongo_db
from app.core.config import settings
from app.utils.runtime_paths import get_backups_dir, get_exports_dir

from app.services.database import status_checks as _db_status
from app.services.database import cleanup as _db_cleanup
from app.services.database import backups as _db_backups
from app.services.database.serialization import serialize_document as _serialize_doc

logger = logging.getLogger(__name__)

class DatabaseService:

    def __init__(self):
        self.backup_dir = str(get_backups_dir(settings.RUNTIME_BASE_DIR))
        self.export_dir = str(get_exports_dir(settings.RUNTIME_BASE_DIR))

    async def get_database_status(self) -> Dict[str, Any]:
        return await _db_status.get_database_status()

    async def _get_mongodb_status(self) -> Dict[str, Any]:
        return await _db_status.get_mongodb_status()

    async def _get_redis_status(self) -> Dict[str, Any]:
        return await _db_status.get_redis_status()

    async def get_database_stats(self) -> Dict[str, Any]:
        try:
            db = get_mongo_db()

            collection_names = await db.list_collection_names()

            collections_info = []
            total_documents = 0
            total_size = 0

            import asyncio

            async def get_collection_stats(collection_name: str):
                try:
                    try:
                        collections = await db.list_collections(filter={"name": collection_name})
                        coll_info = next((c for c in collections), None)

                        if coll_info and coll_info.get('type') == 'view':
                            return {
                                "name": collection_name,
                                "type": "view",
                                "documents": 0,
                                "size": 0,
                                "storage_size": 0,
                                "indexes": 0,
                                "index_size": 0,
                                "note": "视图不支持统计"
                            }
                    except Exception as e:
                        logger.debug(f"判断集合类型失败: {e}")
                        pass

                    stats = await db.command("collStats", collection_name)
                    doc_count = stats.get('count', 0)

                    return {
                        "name": collection_name,
                        "type": "collection",
                        "documents": doc_count,
                        "size": stats.get('size', 0),
                        "storage_size": stats.get('storageSize', 0),
                        "indexes": stats.get('nindexes', 0),
                        "index_size": stats.get('totalIndexSize', 0)
                    }
                except Exception as e:
                    error_msg = str(e)
                    if "is a view, not a collection" in error_msg or "CommandNotSupportedOnView" in error_msg:
                        logger.info(f"跳过视图 {collection_name} 的统计")
                        return {
                            "name": collection_name,
                            "type": "view",
                            "documents": 0,
                            "size": 0,
                            "storage_size": 0,
                            "indexes": 0,
                            "index_size": 0,
                            "note": "视图不支持统计"
                        }
                    else:
                        logger.error(f"获取集合 {collection_name} 统计失败: {e}")
                        return {
                            "name": collection_name,
                            "type": "unknown",
                            "documents": 0,
                            "size": 0,
                            "storage_size": 0,
                            "indexes": 0,
                            "index_size": 0
                        }

            collections_info = await asyncio.gather(
                *[get_collection_stats(name) for name in collection_names]
            )

            for collection_info in collections_info:
                if collection_info.get('type') != 'view':
                    total_documents += collection_info['documents']
                    total_size += collection_info['storage_size']

            return {
                "total_collections": len(collection_names),
                "total_documents": total_documents,
                "total_size": total_size,
                "collections": collections_info
            }
        except Exception as e:
            raise RuntimeError(f"获取数据库统计失败: {str(e)}") from e

    async def test_connections(self) -> Dict[str, Any]:
        return await _db_status.test_connections()

    async def _test_mongodb_connection(self) -> Dict[str, Any]:
        return await _db_status.test_mongodb_connection()

    async def _test_redis_connection(self) -> Dict[str, Any]:
        return await _db_status.test_redis_connection()

    async def create_backup(self, name: str, collections: List[str] = None, user_id: str = None) -> Dict[str, Any]:

        if _db_backups._check_mongodump_available():
            logger.info("✅ 使用 mongodump 原生备份（推荐）")
            return await _db_backups.create_backup_native(
                name=name,
                backup_dir=self.backup_dir,
                collections=collections,
                user_id=user_id
            )
        else:
            logger.warning("⚠️ mongodump 不可用，使用 Python 备份（较慢）")
            logger.warning("💡 建议安装 MongoDB Database Tools 以获得更快的备份速度")
            return await _db_backups.create_backup(
                name=name,
                backup_dir=self.backup_dir,
                collections=collections,
                user_id=user_id
            )

    async def list_backups(self) -> List[Dict[str, Any]]:
        return await _db_backups.list_backups()

    async def delete_backup(self, backup_id: str) -> None:
        await _db_backups.delete_backup(backup_id)

    async def cleanup_old_data(self, days: int) -> Dict[str, Any]:
        return await _db_cleanup.cleanup_old_data(days)

    async def cleanup_analysis_results(self, days: int) -> Dict[str, Any]:
        return await _db_cleanup.cleanup_analysis_results(days)

    async def cleanup_operation_logs(self, days: int) -> Dict[str, Any]:
        return await _db_cleanup.cleanup_operation_logs(days)

    async def import_data(self, content: bytes, collection: str, format: str = "json",
                         overwrite: bool = False, filename: str = None) -> Dict[str, Any]:
        return await _db_backups.import_data(content, collection, format=format, overwrite=overwrite, filename=filename)

    async def export_data(self, collections: List[str] = None, format: str = "json", sanitize: bool = False) -> str:
        return await _db_backups.export_data(collections, export_dir=self.export_dir, format=format, sanitize=sanitize)

    def _serialize_document(self, doc: dict) -> dict:
        return _serialize_doc(doc)
