from typing import Optional, List
from bson import ObjectId

from app.models.user import User, UserCreate, UserUpdate, UserResponse
from app.utils.time_utils import now_utc
from app.utils.passwords import (
    hash_password as secure_hash_password,
    verify_password as secure_verify_password,
    needs_password_rehash,
)

from motor.motor_asyncio import AsyncIOMotorDatabase
from pymongo.errors import (
    ConnectionFailure,
    ServerSelectionTimeoutError,
    NetworkTimeout,
    AutoReconnect,
)

import logging

logger = logging.getLogger(__name__)

def _is_system_error(exc: Exception) -> bool:
    system_errors = (
        ConnectionFailure,
        ServerSelectionTimeoutError,
        NetworkTimeout,
        AutoReconnect,
        OSError,
        ConnectionError,
        TimeoutError,
    )
    return isinstance(exc, system_errors)

class UserService:

    def __init__(self):
        self.db: Optional[AsyncIOMotorDatabase] = None

    def set_database(self, db: AsyncIOMotorDatabase):
        self.db = db

    @staticmethod
    def hash_password(password: str) -> str:
        return secure_hash_password(password)

    @staticmethod
    def verify_password(plain_password: str, hashed_password: str) -> bool:
        return secure_verify_password(plain_password, hashed_password)

    async def create_user(self, user_data: UserCreate) -> Optional[User]:
        try:
            if self.db is None:
                logger.error("数据库未初始化")
                return None

            users_collection = self.db.users

            existing_user = await users_collection.find_one({"username": user_data.username})
            if existing_user:
                logger.warning(f"用户名已存在: {user_data.username}")
                return None

            existing_email = await users_collection.find_one({"email": user_data.email})
            if existing_email:
                logger.warning(f"邮箱已存在: {user_data.email}")
                return None

            user_doc = {
                "username": user_data.username,
                "email": user_data.email,
                "hashed_password": self.hash_password(user_data.password),
                "is_active": True,
                "is_verified": False,
                "is_admin": False,
                "created_at": now_utc(),
                "updated_at": now_utc(),
                "last_login": None,
                "preferences": {
                    "default_market": "A股",
                    "default_debate_rounds": 2,
                    "default_analysts": [],
                    "auto_refresh": True,
                    "refresh_interval": 30,
                    "ui_theme": "light",
                    "sidebar_width": 240,
                    "language": "zh-CN",
                    "notifications_enabled": True,
                    "email_notifications": False,
                    "desktop_notifications": True,
                    "analysis_complete_notification": True,
                    "system_maintenance_notification": True
                },
                "daily_quota": 1000,
                "concurrent_limit": 3,
                "total_analyses": 0,
                "successful_analyses": 0,
                "failed_analyses": 0,
                "favorite_stocks": []
            }

            result = await users_collection.insert_one(user_doc)
            user_doc["_id"] = result.inserted_id

            logger.info(f"✅ 用户创建成功: {user_data.username}")
            return User(**user_doc)

        except Exception as e:
            if _is_system_error(e):
                logger.error(f"系统级错误 - 创建用户失败: {e}")
                raise
            logger.error(f"❌ 创建用户失败: {e}")
            return None

    async def authenticate_user(self, username: str, password: str) -> Optional[User]:
        try:
            if self.db is None:
                logger.error("数据库未初始化")
                return None

            users_collection = self.db.users

            user_doc = await users_collection.find_one({"username": username})

            if not user_doc:
                logger.warning(f"用户不存在: {username}")
                return None

            stored_password_hash = user_doc["hashed_password"]

            if not self.verify_password(password, stored_password_hash):
                logger.warning(f"密码错误: {username}")
                return None

            if not user_doc.get("is_active", True):
                logger.warning(f"用户已禁用: {username}")
                return None

            update_fields = {"last_login": now_utc()}
            if needs_password_rehash(stored_password_hash):
                update_fields["hashed_password"] = self.hash_password(password)
                update_fields["updated_at"] = now_utc()
                user_doc["hashed_password"] = update_fields["hashed_password"]

            await users_collection.update_one(
                {"_id": user_doc["_id"]},
                {"$set": update_fields}
            )

            logger.info(f"用户认证成功: {username}")
            return User(**user_doc)

        except Exception as e:
            if _is_system_error(e):
                logger.error(f"系统级错误 - 用户认证失败: {e}")
                raise
            logger.error(f"❌ 用户认证失败: {e}")
            return None

    async def get_user_by_username(self, username: str) -> Optional[User]:
        try:
            if self.db is None:
                logger.error("数据库未初始化")
                return None

            user_doc = await self.db.users.find_one({"username": username})
            if user_doc:
                return User(**user_doc)
            return None
        except Exception as e:
            if _is_system_error(e):
                logger.error(f"系统级错误 - 获取用户失败: {e}")
                raise
            logger.error(f"❌ 获取用户失败: {e}")
            return None

    async def get_user_by_id(self, user_id: str) -> Optional[User]:
        try:
            if self.db is None:
                logger.error("数据库未初始化")
                return None

            if not ObjectId.is_valid(user_id):
                return None

            user_doc = await self.db.users.find_one({"_id": ObjectId(user_id)})
            if user_doc:
                return User(**user_doc)
            return None
        except Exception as e:
            if _is_system_error(e):
                logger.error(f"系统级错误 - 获取用户失败: {e}")
                raise
            logger.error(f"❌ 获取用户失败: {e}")
            return None

    async def update_user(self, username: str, user_data: UserUpdate) -> Optional[User]:
        try:
            if self.db is None:
                logger.error("数据库未初始化")
                return None

            users_collection = self.db.users
            update_data = {"updated_at": now_utc()}

            if user_data.email:
                existing_email = await users_collection.find_one({
                    "email": user_data.email,
                    "username": {"$ne": username}
                })
                if existing_email:
                    logger.warning(f"邮箱已被使用: {user_data.email}")
                    return None
                update_data["email"] = user_data.email

            if user_data.preferences:
                update_data["preferences"] = user_data.preferences.model_dump()

            if user_data.daily_quota is not None:
                update_data["daily_quota"] = user_data.daily_quota

            if user_data.concurrent_limit is not None:
                update_data["concurrent_limit"] = user_data.concurrent_limit

            result = await users_collection.update_one(
                {"username": username},
                {"$set": update_data}
            )

            if result.modified_count > 0:
                logger.info(f"✅ 用户信息更新成功: {username}")
                return await self.get_user_by_username(username)
            else:
                logger.warning(f"用户不存在或无需更新: {username}")
                return None

        except Exception as e:
            if _is_system_error(e):
                logger.error(f"系统级错误 - 更新用户信息失败: {e}")
                raise
            logger.error(f"❌ 更新用户信息失败: {e}")
            return None

    async def change_password(self, username: str, old_password: str, new_password: str) -> bool:
        try:
            user = await self.authenticate_user(username, old_password)
            if not user:
                logger.warning(f"旧密码验证失败: {username}")
                return False

            if self.db is None:
                logger.error("数据库未初始化")
                return False

            new_hashed_password = self.hash_password(new_password)
            result = await self.db.users.update_one(
                {"username": username},
                {
                    "$set": {
                        "hashed_password": new_hashed_password,
                        "updated_at": now_utc()
                    }
                }
            )

            if result.modified_count > 0:
                logger.info(f"✅ 密码修改成功: {username}")
                return True
            else:
                logger.error(f"❌ 密码修改失败: {username}")
                return False

        except Exception as e:
            if _is_system_error(e):
                logger.error(f"系统级错误 - 修改密码失败: {e}")
                raise
            logger.error(f"❌ 修改密码失败: {e}")
            return False

    async def reset_password(self, username: str, new_password: str) -> bool:
        try:
            if self.db is None:
                logger.error("数据库未初始化")
                return False

            new_hashed_password = self.hash_password(new_password)
            result = await self.db.users.update_one(
                {"username": username},
                {
                    "$set": {
                        "hashed_password": new_hashed_password,
                        "updated_at": now_utc()
                    }
                }
            )

            if result.modified_count > 0:
                logger.info(f"✅ 密码重置成功: {username}")
                return True
            else:
                logger.error(f"❌ 密码重置失败: {username}")
                return False

        except Exception as e:
            if _is_system_error(e):
                logger.error(f"系统级错误 - 重置密码失败: {e}")
                raise
            logger.error(f"❌ 重置密码失败: {e}")
            return False

    async def create_admin_user(
        self,
        username: str = "admin",
        password: Optional[str] = None,
        email: str = "admin@zhenshabi.cn",
    ) -> Optional[User]:
        try:
            if self.db is None:
                logger.error("数据库未初始化")
                return None

            if not password:
                logger.error("创建管理员用户失败: 未提供管理员密码")
                return None

            users_collection = self.db.users

            existing_admin = await users_collection.find_one({"username": username})
            if existing_admin:
                logger.info(f"管理员用户已存在: {username}")
                return User(**existing_admin)

            admin_doc = {
                "username": username,
                "email": email,
                "hashed_password": self.hash_password(password),
                "is_active": True,
                "is_verified": True,
                "is_admin": True,
                "created_at": now_utc(),
                "updated_at": now_utc(),
                "last_login": None,
                "preferences": {
                    "default_market": "A股",
                    "default_debate_rounds": 2,
                    "ui_theme": "light",
                    "language": "zh-CN",
                    "notifications_enabled": True,
                    "email_notifications": False
                },
                "daily_quota": 10000,
                "concurrent_limit": 10,
                "total_analyses": 0,
                "successful_analyses": 0,
                "failed_analyses": 0,
                "favorite_stocks": []
            }

            result = await users_collection.insert_one(admin_doc)
            admin_doc["_id"] = result.inserted_id

            logger.info(f"✅ 管理员用户创建成功: {username}")

            return User(**admin_doc)

        except Exception as e:
            if _is_system_error(e):
                logger.error(f"系统级错误 - 创建管理员用户失败: {e}")
                raise
            logger.error(f"❌ 创建管理员用户失败: {e}")
            return None

    async def list_users(self, skip: int = 0, limit: int = 100) -> List[UserResponse]:
        try:
            if self.db is None:
                logger.error("数据库未初始化")
                return []

            cursor = self.db.users.find().skip(skip).limit(limit)
            users = []

            async for user_doc in cursor:
                user = User(**user_doc)
                users.append(UserResponse(
                    id=str(user.id),
                    username=user.username,
                    email=user.email,
                    is_active=user.is_active,
                    is_verified=user.is_verified,
                    created_at=user.created_at,
                    last_login=user.last_login,
                    preferences=user.preferences,
                    daily_quota=user.daily_quota,
                    concurrent_limit=user.concurrent_limit,
                    total_analyses=user.total_analyses,
                    successful_analyses=user.successful_analyses,
                    failed_analyses=user.failed_analyses
                ))

            return users

        except Exception as e:
            if _is_system_error(e):
                logger.error(f"系统级错误 - 获取用户列表失败: {e}")
                raise
            logger.error(f"❌ 获取用户列表失败: {e}")
            return []

    async def deactivate_user(self, username: str) -> bool:
        try:
            if self.db is None:
                logger.error("数据库未初始化")
                return False

            result = await self.db.users.update_one(
                {"username": username},
                {
                    "$set": {
                        "is_active": False,
                        "updated_at": now_utc()
                    }
                }
            )

            if result.modified_count > 0:
                logger.info(f"✅ 用户已禁用: {username}")
                return True
            else:
                logger.warning(f"用户不存在: {username}")
                return False

        except Exception as e:
            if _is_system_error(e):
                logger.error(f"系统级错误 - 禁用用户失败: {e}")
                raise
            logger.error(f"❌ 禁用用户失败: {e}")
            return False

    async def activate_user(self, username: str) -> bool:
        try:
            if self.db is None:
                logger.error("数据库未初始化")
                return False

            result = await self.db.users.update_one(
                {"username": username},
                {
                    "$set": {
                        "is_active": True,
                        "updated_at": now_utc()
                    }
                }
            )

            if result.modified_count > 0:
                logger.info(f"✅ 用户已激活: {username}")
                return True
            else:
                logger.warning(f"用户不存在: {username}")
                return False

        except Exception as e:
            if _is_system_error(e):
                logger.error(f"系统级错误 - 激活用户失败: {e}")
                raise
            logger.error(f"❌ 激活用户失败: {e}")
            return False

    async def set_admin_status(self, username: str, is_admin: bool) -> bool:
        try:
            if self.db is None:
                logger.error("数据库未初始化")
                return False

            result = await self.db.users.update_one(
                {"username": username},
                {
                    "$set": {
                        "is_admin": is_admin,
                        "updated_at": now_utc(),
                    }
                },
            )

            if result.matched_count == 0:
                logger.warning(f"用户不存在: {username}")
                return False

            logger.info(f"用户管理员状态已更新: {username}, is_admin={is_admin}")
            return True
        except Exception as e:
            if _is_system_error(e):
                logger.error(f"系统级错误 - 更新用户管理员状态失败: {e}")
                raise
            logger.error(f"❌ 更新用户管理员状态失败: {e}")
            return False

user_service = UserService()
