from datetime import datetime, timedelta, timezone
from typing import Optional
import hashlib
import jwt
import logging
import uuid
from pydantic import BaseModel
from app.core.config import settings

logger = logging.getLogger(__name__)

class TokenData(BaseModel):
    sub: str
    exp: int
    type: str = "access"

class AuthService:
    @staticmethod
    def create_access_token(sub: str, expires_minutes: int | None = None, expires_delta: int | None = None, token_type: str = "access") -> str:
        if expires_delta:
            now = datetime.now(timezone.utc)
            expire = now + timedelta(seconds=expires_delta)
        else:
            now = datetime.now(timezone.utc)
            expire = now + timedelta(minutes=expires_minutes or settings.ACCESS_TOKEN_EXPIRE_MINUTES)
        payload = {
            "sub": sub,
            "exp": expire,
            "iat": now,
            "jti": uuid.uuid4().hex,
            "type": token_type,
        }
        token = jwt.encode(payload, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)
        return token

    @staticmethod
    def verify_token(token: str) -> Optional[TokenData]:
        try:
            payload = jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM])

            token_data = TokenData(sub=payload.get("sub"), exp=int(payload.get("exp", 0)), type=payload.get("type", "access"))

            return token_data

        except jwt.ExpiredSignatureError:
            logger.warning("⏰ Token已过期")
            return None
        except jwt.InvalidTokenError as e:
            logger.warning(f"❌ Token无效: {str(e)}")
            return None
        except Exception as e:
            logger.error(f"❌ Token验证异常: {str(e)}")
            return None

    @staticmethod
    def extract_jti(token: str) -> Optional[str]:

        if not token:
            return None
        try:
            payload = jwt.decode(
                token,
                settings.JWT_SECRET,
                algorithms=[settings.JWT_ALGORITHM],
                options={"verify_exp": False},
            )
            return payload.get("jti")
        except Exception:
            return None

    @staticmethod
    def _token_hash(token: str) -> str:
        return hashlib.sha256(token.encode("utf-8")).hexdigest()

    @staticmethod
    async def add_token_to_blacklist(
        token: str, ttl_seconds: int
    ) -> bool:

        if not token:
            return False
        try:
            from app.data.storage.redis.client import get_redis
            redis = get_redis()
            if not redis:
                return False
            await redis.set(
                f"token_blacklist:{AuthService._token_hash(token)}",
                "1",
                ex=ttl_seconds,
            )
            return True
        except Exception as exc:
            logger.debug(f"token 黑名单写入失败: {exc}")
            return False

    @staticmethod
    async def is_token_blacklisted(
        token: str, *, fail_closed: bool = False
    ) -> bool:

        if not token:
            return False
        try:
            from app.data.storage.redis.client import get_redis
            redis = get_redis()
            if not redis:
                if fail_closed:
                    logger.warning(
                        "Redis 不可用且 fail_closed=True，拒绝 token"
                    )
                    return True
                return False
            return bool(
                await redis.get(
                    f"token_blacklist:{AuthService._token_hash(token)}"
                )
            )
        except Exception as exc:
            logger.debug(f"token 黑名单检查失败: {exc}")
            if fail_closed:
                logger.warning(
                    f"token 黑名单检查异常 fail_closed=True，拒绝 token: {exc}"
                )
                return True
            return False
