from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, Dict, Optional

from app.core.env import has_env_var, get_raw_env
from app.services.config_service import config_service
from app.utils.time_utils import now_utc

def _flatten_config(settings: Dict[str, Any]) -> Dict[str, Any]:

    if not isinstance(settings, dict):
        return settings

    flat: Dict[str, Any] = {}
    for key, value in settings.items():
        if key == "config":
            inner = _flatten_config(value) if isinstance(value, dict) else value
            if isinstance(inner, dict):
                for ik, iv in inner.items():
                    flat.setdefault(ik, iv)
        else:
            flat[key] = value
    return flat

class ConfigProvider:

    def __init__(self, ttl_seconds: int = 60) -> None:
        self._ttl = timedelta(seconds=ttl_seconds)
        self._cache_settings: Optional[Dict[str, Any]] = None
        self._cache_time: Optional[datetime] = None
        self._cache_version: int = 0

    def invalidate(self) -> None:
        self._cache_settings = None
        self._cache_time = None
        self._cache_version += 1

    @property
    def current_version(self) -> int:
        return self._cache_version

    def _is_cache_valid(self) -> bool:
        return (
            self._cache_settings is not None
            and self._cache_time is not None
            and now_utc() - self._cache_time < self._ttl
        )

    async def get_effective_system_settings(self) -> Dict[str, Any]:
        if self._is_cache_valid():
            return {
                "config": dict(self._cache_settings or {}),
                "version": self._cache_version,
                "cached_at": self._cache_time.isoformat() if self._cache_time else None
            }

        cfg = await config_service.get_system_config()
        base: Dict[str, Any] = {}
        if cfg and getattr(cfg, "system_settings", None):
            try:
                base = dict(cfg.system_settings)
            except Exception:
                base = {}

        base = _flatten_config(base)

        merged: Dict[str, Any] = dict(base)
        for k, v in list(base.items()):
            candidates = [
                k,
                k.upper(),
                str(k).replace(".", "_").replace(" ", "_").upper(),
            ]
            found = None
            for ek in candidates:
                if has_env_var(ek):
                    found = get_raw_env(ek)
                    break
            if found is not None:
                merged[k] = found

        self._cache_settings = dict(merged)
        self._cache_time = now_utc()

        return {
            "config": dict(merged),
            "version": self._cache_version,
            "cached_at": self._cache_time.isoformat()
        }
    async def get_system_settings_meta(self) -> Dict[str, Dict[str, Any]]:
        cfg = await config_service.get_system_config()
        db_settings: Dict[str, Any] = {}
        if cfg and getattr(cfg, "system_settings", None):
            try:
                db_settings = dict(cfg.system_settings)
            except Exception:
                db_settings = {}

        db_settings = _flatten_config(db_settings)

        def _env_override_for_key(key: str) -> Optional[Any]:
            candidates = [
                key,
                key.upper(),
                str(key).replace(".", "_").replace(" ", "_").upper(),
            ]
            for ek in candidates:
                if has_env_var(ek):
                    return get_raw_env(ek)
            return None

        sens_patterns = ("key", "secret", "password", "token", "client_secret")
        meta: Dict[str, Dict[str, Any]] = {}
        for k, v in db_settings.items():
            env_v = _env_override_for_key(k)
            source = "environment" if env_v is not None else ("database" if v is not None else "default")
            sensitive = isinstance(k, str) and any(p in k.lower() for p in sens_patterns)
            editable = not sensitive and source != "environment"
            effective_val = env_v if env_v is not None else v
            has_value = effective_val not in (None, "")
            meta[k] = {
                "sensitive": bool(sensitive),
                "editable": bool(editable),
                "source": source,
                "has_value": bool(has_value),
            }
        return meta

provider = ConfigProvider(ttl_seconds=60)
