import json
import os
import secrets
import tempfile
import logging
from pathlib import Path
from typing import Optional

from app.core.database import get_mongo_db
from app.core.env import get_env

logger = logging.getLogger("app.secret_service")

_COLLECTION = "system_secrets"

_RUNTIME_BASE_DIR = get_env("RUNTIME_BASE_DIR", "runtime")
_FALLBACK_FILE = Path(_RUNTIME_BASE_DIR) / ".secrets.json"

_MANAGED_SECRETS = {
    "jwt_secret": 48,
    "csrf_secret": 48,
}

_ENV_MAP = {"jwt_secret": "JWT_SECRET", "csrf_secret": "CSRF_SECRET"}

def _load_fallback_file() -> dict[str, str]:
    try:
        if _FALLBACK_FILE.exists():
            data = json.loads(_FALLBACK_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return {k: v for k, v in data.items() if isinstance(v, str) and v}
    except Exception as exc:
        logger.warning(f"读取密钥兜底文件失败: {exc}")
    return {}

def _save_fallback_file(values: dict[str, str]) -> None:

    tmp_path = None
    try:
        _FALLBACK_FILE.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(
            dir=_FALLBACK_FILE.parent,
            mode="w",
            encoding="utf-8",
            suffix=".tmp",
            delete=False,
        ) as tmp:
            tmp.write(json.dumps(values, ensure_ascii=False, indent=2))
            tmp.flush()
            os.fsync(tmp.fileno())
            tmp_path = Path(tmp.name)
        os.replace(tmp_path, _FALLBACK_FILE)
        tmp_path = None
        try:
            os.chmod(_FALLBACK_FILE, 0o600)
        except Exception:
            pass
        logger.debug(f"密钥兜底文件已写入: {_FALLBACK_FILE}")
    except Exception as exc:
        if tmp_path is not None and tmp_path.exists():
            try:
                os.unlink(tmp_path)
            except Exception:
                pass
        logger.warning(f"写入密钥兜底文件失败: {exc}（仍可使用 DB 与环境变量）")

class SecretService:

    @staticmethod
    async def ensure_secrets() -> dict[str, str]:

        db = get_mongo_db()
        collection = db[_COLLECTION]
        result: dict[str, str] = {}
        newly_generated: dict[str, str] = {}

        for name, length in _MANAGED_SECRETS.items():
            value: Optional[str] = None
            try:
                doc = await collection.find_one({"name": name})
                if doc and doc.get("value"):
                    value = doc["value"]
                    logger.debug(f"从 DB 加载密钥: {name}")
            except Exception as exc:
                logger.warning(f"从 DB 读取密钥 {name} 失败: {exc}")

            if not value:
                fallback = _load_fallback_file()
                value = fallback.get(name)

            if not value:
                value = secrets.token_urlsafe(length)
                try:
                    result_op = await collection.update_one(
                        {"name": name},
                        {"$setOnInsert": {"name": name, "value": value}},
                        upsert=True,
                    )
                    if result_op.upserted_id is None:
                        existing = await collection.find_one({"name": name})
                        if existing and existing.get("value"):
                            value = existing["value"]
                            logger.info(f"密钥 {name} 已由其他 worker 创建，使用 DB 权威值")
                        else:
                            logger.warning(
                                f"密钥 {name} upsert 未创建新文档且 DB 读取为空，使用本地生成值"
                            )
                    else:
                        logger.info(f"自动生成并持久化密钥: {name}")
                except Exception as exc:
                    try:
                        existing = await collection.find_one({"name": name})
                    except Exception:
                        existing = None
                    if existing and existing.get("value"):
                        value = existing["value"]
                        logger.info(
                            f"密钥 {name} 并发插入冲突已解决，使用 DB 权威值: {type(exc).__name__}"
                        )
                    else:
                        logger.warning(
                            f"密钥 {name} 写入 DB 失败且无法读取: {exc}（将仅落兜底文件 + os.environ）"
                        )
                newly_generated[name] = value

            result[name] = value

        for name, env_key in _ENV_MAP.items():
            if name in result:
                os.environ[env_key] = result[name]

        if newly_generated or not _load_fallback_file():
            _save_fallback_file(result)

        logger.info(f"安全密钥管理完成，共 {len(result)} 个密钥已就绪")
        return result

    @staticmethod
    def persist_to_env() -> None:

        fallback = _load_fallback_file()
        for name, env_key in _ENV_MAP.items():
            if env_key in os.environ and os.environ[env_key]:
                continue
            value = fallback.get(name)
            if value:
                os.environ[env_key] = value
                logger.debug(f"从兜底文件同步密钥到 os.environ: {env_key}")

    @staticmethod
    async def get_secret(name: str) -> Optional[str]:
        db = get_mongo_db()
        doc = await db[_COLLECTION].find_one({"name": name})
        return doc.get("value") if doc else None

    @staticmethod
    async def rotate_secret(name: str) -> str:
        if name not in _MANAGED_SECRETS:
            raise ValueError(f"未知密钥: {name}")

        length = _MANAGED_SECRETS[name]
        new_value = secrets.token_urlsafe(length)

        db = get_mongo_db()
        await db[_COLLECTION].update_one(
            {"name": name},
            {"$set": {"value": new_value}},
            upsert=True,
        )

        env_key = _ENV_MAP.get(name)
        if env_key:
            os.environ[env_key] = new_value

        current = _load_fallback_file()
        current[name] = new_value
        _save_fallback_file(current)

        logger.warning(f"密钥已轮换: {name}")
        return new_value
