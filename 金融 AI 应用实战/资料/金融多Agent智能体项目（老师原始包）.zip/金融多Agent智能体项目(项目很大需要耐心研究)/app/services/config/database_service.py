import time
import os
import logging
from typing import List, Optional, Dict, Any
from urllib.parse import quote_plus

from app.core.database import get_mongo_db
from app.core.env import get_env
from app.models.config import DatabaseConfig

logger = logging.getLogger(__name__)

class DatabaseService:

    def __init__(self, db_manager=None):
        self.db = None
        self.db_manager = db_manager

    async def _get_db(self):
        if self.db is None:
            if self.db_manager and self.db_manager.mongo_db is not None:
                self.db = self.db_manager.mongo_db
            else:
                self.db = get_mongo_db()
        return self.db

    async def _get_system_config(self):
        try:
            from app.models.config import SystemConfig

            db = await self._get_db()
            config_collection = db.system_configs
            config_data = await config_collection.find_one(
                {"is_active": True},
                sort=[("version", -1)]
            )
            if config_data:
                config_data.setdefault('config_name', config_data.get('config_name', 'bridged'))
                config_data.setdefault('config_type', config_data.get('config_type', 'system'))
                return SystemConfig(**config_data)
            return None
        except Exception as e:
            logger.error(f"❌ 获取系统配置失败: {e}")
            return None

    async def _save_system_config(self, config) -> bool:
        try:
            from app.utils.timezone import now_tz

            db = await self._get_db()
            config_collection = db.system_configs

            config.updated_at = now_tz()
            config.version += 1

            await config_collection.update_many(
                {"is_active": True},
                {"$set": {"is_active": False}}
            )

            config_dict = config.model_dump(by_alias=True)
            if '_id' in config_dict:
                del config_dict['_id']

            await config_collection.insert_one(config_dict)
            return True
        except Exception as e:
            logger.error(f"❌ 保存系统配置失败: {e}")
            return False

    async def update_database_config(self, db_config: DatabaseConfig) -> bool:
        try:
            logger.info(f"🔄 更新数据库配置: {db_config.name}")

            config = await self._get_system_config()
            if not config:
                logger.error("❌ 系统配置为空")
                return False

            found = False
            for i, existing_db in enumerate(config.database_configs):
                if existing_db.name == db_config.name:
                    config.database_configs[i] = db_config
                    found = True
                    break

            if not found:
                logger.error(f"❌ 数据库配置 '{db_config.name}' 不存在")
                return False

            result = await self._save_system_config(config)
            if result:
                logger.info(f"✅ 数据库配置 '{db_config.name}' 更新成功")
            else:
                logger.error(f"❌ 数据库配置 '{db_config.name}' 更新失败")

            return result

        except Exception as e:
            logger.error("更新数据库配置失败: %s", e, exc_info=True)
            return False

    async def get_database_config(self, db_name: str) -> Optional[DatabaseConfig]:
        try:
            config = await self._get_system_config()
            if not config:
                return None

            for db in config.database_configs:
                if db.name == db_name:
                    return db

            return None

        except Exception as e:
            logger.error(f"❌ 获取数据库配置失败: {e}")
            return None

    async def get_database_configs(self) -> List[DatabaseConfig]:
        try:
            config = await self._get_system_config()
            if not config:
                return []

            return config.database_configs

        except Exception as e:
            logger.error(f"❌ 获取数据库配置列表失败: {e}")
            return []

    async def test_database_config(self, db_config: DatabaseConfig) -> Dict[str, Any]:
        start_time = time.time()
        try:
            db_type = db_config.type.value if hasattr(db_config.type, 'value') else str(db_config.type)

            logger.info(f"🧪 测试数据库配置: {db_config.name} ({db_type})")
            logger.info(f"📍 连接地址: {db_config.host}:{db_config.port}")

            if db_type == "mongodb":
                try:
                    from motor.motor_asyncio import AsyncIOMotorClient

                    host = db_config.host
                    port = db_config.port
                    username = db_config.username
                    password = db_config.password
                    database = db_config.database
                    auth_source = None
                    used_env_config = False

                    is_docker = os.path.exists('/.dockerenv') or get_env('DOCKER_CONTAINER') == 'true'

                    if not username or not password:
                        env_host = get_env('MONGODB_HOST')
                        env_port = get_env('MONGODB_PORT')
                        env_username = get_env('MONGODB_USERNAME')
                        env_password = get_env('MONGODB_PASSWORD')
                        env_auth_source = get_env('MONGODB_AUTH_SOURCE', 'admin')

                        if env_username and env_password:
                            username = env_username
                            password = env_password
                            auth_source = env_auth_source
                            used_env_config = True

                            if env_host:
                                host = env_host
                                if is_docker and host == 'localhost':
                                    host = 'mongodb'
                                    logger.info("🐳 检测到 Docker 环境，将 host 从 localhost 改为 mongodb")

                            if env_port:
                                port = int(env_port)

                            logger.info(f"🔑 使用环境变量中的 MongoDB 配置 (host={host}, port={port}, authSource={auth_source})")

                    if not database:
                        env_database = get_env('MONGODB_DATABASE')
                        if env_database:
                            database = env_database
                            logger.info(f"📦 使用环境变量中的数据库名: {database}")

                    if not auth_source and db_config.connection_params:
                        auth_source = db_config.connection_params.get('authSource')

                    if username and password:
                        safe_user = quote_plus(username)
                        safe_pass = quote_plus(password)
                        connection_string = f"mongodb://{safe_user}:{safe_pass}@{host}:{port}"
                    else:
                        safe_pass = None
                        connection_string = f"mongodb://{host}:{port}"

                    if database:
                        connection_string += f"/{database}"

                    params_list = []

                    if auth_source:
                        params_list.append(f"authSource={auth_source}")

                    if db_config.connection_params:
                        for k, v in db_config.connection_params.items():
                            if k != 'authSource':
                                params_list.append(f"{k}={v}")

                    if params_list:
                        connection_string += f"?{'&'.join(params_list)}"

                    if safe_pass:
                        safe_log_uri = connection_string.replace(safe_pass, "***", 1)
                    else:
                        safe_log_uri = connection_string
                    logger.info(f"🔗 连接字符串: {safe_log_uri}")

                    client = AsyncIOMotorClient(
                        connection_string,
                        serverSelectionTimeoutMS=5000
                    )

                    if database:
                        db = client[database]
                        collections = await db.list_collection_names()
                        test_result = f"数据库 '{database}' 可访问，包含 {len(collections)} 个集合"
                    else:
                        await client.admin.command('ping')
                        test_result = "连接成功"

                    response_time = time.time() - start_time

                    client.close()

                    return {
                        "success": True,
                        "message": "成功连接到 MongoDB 数据库",
                        "response_time": response_time,
                        "details": {
                            "type": db_type,
                            "host": host,
                            "port": port,
                            "database": database,
                            "auth_source": auth_source,
                            "test_result": test_result,
                            "used_env_config": used_env_config
                        }
                    }
                except ImportError:
                    return {
                        "success": False,
                        "message": "Motor 库未安装，请运行: pip install motor",
                        "response_time": time.time() - start_time,
                        "details": None
                    }
                except Exception as e:
                    error_msg = str(e)
                    logger.error(f"❌ MongoDB 连接测试失败: {error_msg}")

                    if "Authentication failed" in error_msg or "auth failed" in error_msg.lower():
                        message = "认证失败，请检查用户名和密码"
                    elif "requires authentication" in error_msg.lower():
                        message = "需要认证，请配置用户名和密码"
                    elif "not authorized" in error_msg.lower():
                        message = "权限不足，请检查用户权限配置"
                    elif "Connection refused" in error_msg:
                        message = "连接被拒绝，请检查主机地址和端口"
                    elif "timed out" in error_msg.lower():
                        message = "连接超时，请检查网络和防火墙设置"
                    elif "No servers found" in error_msg:
                        message = "找不到服务器，请检查主机地址和端口"
                    else:
                        message = f"连接失败: {error_msg}"

                    return {
                        "success": False,
                        "message": message,
                        "response_time": time.time() - start_time,
                        "details": None
                    }

            elif db_type == "redis":
                try:
                    import redis.asyncio as aioredis

                    host = db_config.host
                    port = db_config.port
                    password = db_config.password
                    database = db_config.database
                    used_env_config = False

                    is_docker = os.path.exists('/.dockerenv') or get_env('DOCKER_CONTAINER') == 'true'

                    if not password:
                        env_host = get_env('REDIS_HOST')
                        env_port = get_env('REDIS_PORT')
                        env_password = get_env('REDIS_PASSWORD')

                        if env_password:
                            password = env_password
                            used_env_config = True

                            if env_host:
                                host = env_host
                                if is_docker and host == 'localhost':
                                    host = 'redis'
                                    logger.info("🐳 检测到 Docker 环境，将 Redis host 从 localhost 改为 redis")

                            if env_port:
                                port = int(env_port)

                            logger.info(f"🔑 使用环境变量中的 Redis 配置 (host={host}, port={port})")

                    if database is None:
                        env_db = get_env('REDIS_DB')
                        if env_db:
                            database = int(env_db)
                            logger.info(f"📦 使用环境变量中的 Redis 数据库编号: {database}")

                    redis_params = {
                        "host": host,
                        "port": port,
                        "decode_responses": True,
                        "socket_connect_timeout": 5
                    }

                    if password:
                        redis_params["password"] = password

                    if database is not None:
                        redis_params["db"] = int(database)

                    redis_client = await aioredis.from_url(
                        f"redis://{host}:{port}",
                        **redis_params
                    )

                    await redis_client.ping()

                    info = await redis_client.info("server")

                    response_time = time.time() - start_time

                    await redis_client.close()

                    return {
                        "success": True,
                        "message": "成功连接到 Redis 数据库",
                        "response_time": response_time,
                        "details": {
                            "type": db_type,
                            "host": host,
                            "port": port,
                            "database": database,
                            "redis_version": info.get("redis_version", "unknown"),
                            "used_env_config": used_env_config
                        }
                    }
                except ImportError:
                    return {
                        "success": False,
                        "message": "Redis 库未安装，请运行: pip install redis",
                        "response_time": time.time() - start_time,
                        "details": None
                    }
                except Exception as e:
                    error_msg = str(e)
                    if "WRONGPASS" in error_msg or "Authentication" in error_msg:
                        message = "认证失败，请检查密码"
                    elif "Connection refused" in error_msg:
                        message = "连接被拒绝，请检查主机地址和端口"
                    elif "timed out" in error_msg.lower():
                        message = "连接超时，请检查网络和防火墙设置"
                    else:
                        message = f"连接失败: {error_msg}"

                    return {
                        "success": False,
                        "message": message,
                        "response_time": time.time() - start_time,
                        "details": None
                    }

            elif db_type == "mysql":
                try:
                    import aiomysql

                    conn = await aiomysql.connect(
                        host=db_config.host,
                        port=db_config.port,
                        user=db_config.username,
                        password=db_config.password,
                        db=db_config.database,
                        connect_timeout=5
                    )

                    async with conn.cursor() as cursor:
                        await cursor.execute("SELECT VERSION()")
                        version = await cursor.fetchone()

                    response_time = time.time() - start_time

                    conn.close()

                    return {
                        "success": True,
                        "message": "成功连接到 MySQL 数据库",
                        "response_time": response_time,
                        "details": {
                            "type": db_type,
                            "host": db_config.host,
                            "port": db_config.port,
                            "database": db_config.database,
                            "version": version[0] if version else "unknown"
                        }
                    }
                except ImportError:
                    return {
                        "success": False,
                        "message": "aiomysql 库未安装，请运行: pip install aiomysql",
                        "response_time": time.time() - start_time,
                        "details": None
                    }
                except Exception as e:
                    error_msg = str(e)
                    if "Access denied" in error_msg:
                        message = "访问被拒绝，请检查用户名和密码"
                    elif "Unknown database" in error_msg:
                        message = f"数据库 '{db_config.database}' 不存在"
                    elif "Can't connect" in error_msg:
                        message = "无法连接，请检查主机地址和端口"
                    else:
                        message = f"连接失败: {error_msg}"

                    return {
                        "success": False,
                        "message": message,
                        "response_time": time.time() - start_time,
                        "details": None
                    }

            elif db_type == "postgresql":
                try:
                    import asyncpg

                    conn = await asyncpg.connect(
                        host=db_config.host,
                        port=db_config.port,
                        user=db_config.username,
                        password=db_config.password,
                        database=db_config.database,
                        timeout=5
                    )

                    version = await conn.fetchval("SELECT version()")

                    response_time = time.time() - start_time

                    await conn.close()

                    return {
                        "success": True,
                        "message": "成功连接到 PostgreSQL 数据库",
                        "response_time": response_time,
                        "details": {
                            "type": db_type,
                            "host": db_config.host,
                            "port": db_config.port,
                            "database": db_config.database,
                            "version": version.split()[1] if version else "unknown"
                        }
                    }
                except ImportError:
                    return {
                        "success": False,
                        "message": "asyncpg 库未安装，请运行: pip install asyncpg",
                        "response_time": time.time() - start_time,
                        "details": None
                    }
                except Exception as e:
                    error_msg = str(e)
                    if "password authentication failed" in error_msg:
                        message = "密码认证失败，请检查用户名和密码"
                    elif "does not exist" in error_msg:
                        message = f"数据库 '{db_config.database}' 不存在"
                    elif "Connection refused" in error_msg:
                        message = "连接被拒绝，请检查主机地址和端口"
                    else:
                        message = f"连接失败: {error_msg}"

                    return {
                        "success": False,
                        "message": message,
                        "response_time": time.time() - start_time,
                        "details": None
                    }

            elif db_type == "sqlite":
                try:
                    import aiosqlite

                    db_path = db_config.database or db_config.host

                    async with aiosqlite.connect(db_path, timeout=5) as conn:
                        async with conn.execute("SELECT sqlite_version()") as cursor:
                            version = await cursor.fetchone()

                    response_time = time.time() - start_time

                    return {
                        "success": True,
                        "message": "成功连接到 SQLite 数据库",
                        "response_time": response_time,
                        "details": {
                            "type": db_type,
                            "database": db_path,
                            "version": version[0] if version else "unknown"
                        }
                    }
                except ImportError:
                    return {
                        "success": False,
                        "message": "aiosqlite 库未安装，请运行: pip install aiosqlite",
                        "response_time": time.time() - start_time,
                        "details": None
                    }
                except Exception as e:
                    return {
                        "success": False,
                        "message": f"连接失败: {str(e)}",
                        "response_time": time.time() - start_time,
                        "details": None
                    }

            else:
                return {
                    "success": False,
                    "message": f"不支持的数据库类型: {db_type}",
                    "response_time": time.time() - start_time,
                    "details": None
                }

        except Exception as e:
            response_time = time.time() - start_time
            logger.error(f"❌ 测试数据库配置失败: {e}")
            return {
                "success": False,
                "message": f"连接失败: {str(e)}",
                "response_time": response_time,
                "details": None
            }
