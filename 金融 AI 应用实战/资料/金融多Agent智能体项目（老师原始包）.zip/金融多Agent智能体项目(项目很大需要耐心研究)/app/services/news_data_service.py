from typing import Optional, List, Dict, Any, Union
from datetime import datetime, timedelta
from dataclasses import dataclass
import logging
from pymongo import ReplaceOne
from pymongo.errors import BulkWriteError

from app.core.database import get_mongo_db
from app.utils.timezone import now_utc

logger = logging.getLogger(__name__)

def convert_objectid_to_str(data: Union[Dict, List[Dict]]) -> Union[Dict, List[Dict]]:

    if isinstance(data, list):
        for item in data:
            if isinstance(item, dict) and '_id' in item:
                item['_id'] = str(item['_id'])
        return data
    elif isinstance(data, dict):
        if '_id' in data:
            data['_id'] = str(data['_id'])
        return data
    return data

@dataclass
class NewsQueryParams:
    symbol: Optional[str] = None
    symbols: Optional[List[str]] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    category: Optional[str] = None
    sentiment: Optional[str] = None
    importance: Optional[str] = None
    data_source: Optional[str] = None
    keywords: Optional[List[str]] = None
    limit: int = 50
    skip: int = 0
    sort_by: str = "publish_time"
    sort_order: int = -1

@dataclass
class NewsStats:
    total_count: int = 0
    positive_count: int = 0
    negative_count: int = 0
    neutral_count: int = 0
    high_importance_count: int = 0
    medium_importance_count: int = 0
    low_importance_count: int = 0
    categories: Dict[str, int] = None
    sources: Dict[str, int] = None
    
    def __post_init__(self):
        if self.categories is None:
            self.categories = {}
        if self.sources is None:
            self.sources = {}

class NewsDataService:
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self._db = None
        self._collection = None
        self._indexes_ensured = False

    async def _ensure_indexes(self):
        if self._indexes_ensured:
            return

        try:
            collection = self._get_collection()
            self.logger.info("📊 检查并创建新闻数据索引...")

            await collection.create_index([
                ("url", 1),
                ("title", 1),
                ("publish_time", 1)
            ], unique=True, name="url_title_time_unique", background=True)

            await collection.create_index([("symbol", 1)], name="symbol_index", background=True)

            await collection.create_index([("symbols", 1)], name="symbols_index", background=True)

            await collection.create_index([("publish_time", -1)], name="publish_time_desc", background=True)

            await collection.create_index([
                ("symbol", 1),
                ("publish_time", -1)
            ], name="symbol_time_index", background=True)

            await collection.create_index([("data_source", 1)], name="data_source_index", background=True)

            await collection.create_index([("category", 1)], name="category_index", background=True)

            await collection.create_index([("sentiment", 1)], name="sentiment_index", background=True)

            await collection.create_index([("importance", 1)], name="importance_index", background=True)

            await collection.create_index([("updated_at", -1)], name="updated_at_index", background=True)

            self._indexes_ensured = True
            self.logger.info("✅ 新闻数据索引检查完成")
        except Exception as e:
            self.logger.warning(f"⚠️ 创建索引时出现警告（可能已存在）: {e}")

    def _get_collection(self):
        if self._collection is None:
            self._db = get_mongo_db()
            self._collection = self._db.stock_news
        return self._collection
    
    async def save_news_data(
        self,
        news_data: Union[Dict[str, Any], List[Dict[str, Any]]],
        data_source: str,
        market: str = "CN"
    ) -> int:

        try:
            await self._ensure_indexes()

            collection = self._get_collection()
            now = now_utc()
            
            if isinstance(news_data, dict):
                news_list = [news_data]
            else:
                news_list = news_data
            
            if not news_list:
                return 0
            
            operations = []

            for i, news in enumerate(news_list):
                standardized_news = self._standardize_news_data(
                    news, data_source, market, now
                )

                if i < 3:
                    self.logger.info(f"   📝 标准化后的新闻 {i+1}:")
                    self.logger.info(f"      symbol: {standardized_news.get('symbol')}")
                    self.logger.info(f"      title: {standardized_news.get('title', '')[:50]}...")
                    self.logger.info(f"      publish_time: {standardized_news.get('publish_time')} (type: {type(standardized_news.get('publish_time'))})")
                    self.logger.info(f"      url: {standardized_news.get('url', '')[:80]}...")

                filter_query = {
                    "url": standardized_news["url"],
                    "title": standardized_news["title"],
                    "publish_time": standardized_news["publish_time"]
                }

                operations.append(
                    ReplaceOne(
                        filter_query,
                        standardized_news,
                        upsert=True
                    )
                )
            
            if operations:
                result = await collection.bulk_write(operations)
                saved_count = result.upserted_count + result.modified_count
                
                self.logger.info(f"💾 新闻数据保存完成: {saved_count}条记录 (数据源: {data_source})")
                return saved_count
            
            return 0
            
        except BulkWriteError as e:
            write_errors = e.details.get('writeErrors', [])
            error_count = len(write_errors)
            self.logger.warning(f"⚠️ 部分新闻数据保存失败: {error_count}条错误")

            for i, error in enumerate(write_errors[:3], 1):
                error_msg = error.get('errmsg', 'Unknown error')
                error_code = error.get('code', 'N/A')
                self.logger.warning(f"   错误 {i}: [Code {error_code}] {error_msg}")

            success_count = len(operations) - error_count
            if success_count > 0:
                self.logger.info(f"💾 成功保存 {success_count} 条新闻数据")

            return success_count
            
        except Exception as e:
            self.logger.error(f"❌ 保存新闻数据失败: {e}")
            return 0

    def save_news_data_sync(
        self,
        news_data: Union[Dict[str, Any], List[Dict[str, Any]]],
        data_source: str,
        market: str = "CN"
    ) -> int:

        try:
            from app.core.database import get_mongo_db_sync

            db = get_mongo_db_sync()
            collection = db.stock_news
            now = now_utc()

            if isinstance(news_data, dict):
                news_list = [news_data]
            else:
                news_list = news_data

            if not news_list:
                return 0

            operations = []

            self.logger.info(f"📝 开始标准化 {len(news_list)} 条新闻数据...")

            for i, news in enumerate(news_list, 1):
                standardized_news = self._standardize_news_data(news, data_source, market, now)

                if i <= 3:
                    self.logger.info(f"   📝 标准化后的新闻 {i}:")
                    self.logger.info(f"      symbol: {standardized_news.get('symbol')}")
                    self.logger.info(f"      title: {standardized_news.get('title', '')[:50]}...")
                    publish_time = standardized_news.get('publish_time')
                    self.logger.info(f"      publish_time: {publish_time} (type: {type(publish_time)})")
                    self.logger.info(f"      url: {standardized_news.get('url', '')[:60]}...")

                filter_query = {
                    "url": standardized_news.get("url"),
                    "title": standardized_news.get("title"),
                    "publish_time": standardized_news.get("publish_time")
                }

                operations.append(
                    ReplaceOne(
                        filter_query,
                        standardized_news,
                        upsert=True
                    )
                )

            if operations:
                result = collection.bulk_write(operations)
                saved_count = result.upserted_count + result.modified_count

                self.logger.info(f"💾 新闻数据保存完成: {saved_count}条记录 (数据源: {data_source})")
                return saved_count

            return 0

        except BulkWriteError as e:
            write_errors = e.details.get('writeErrors', [])
            error_count = len(write_errors)
            self.logger.warning(f"⚠️ 部分新闻数据保存失败: {error_count}条错误")

            for i, error in enumerate(write_errors[:3], 1):
                error_msg = error.get('errmsg', 'Unknown error')
                error_code = error.get('code', 'N/A')
                self.logger.warning(f"   错误 {i}: [Code {error_code}] {error_msg}")

            success_count = len(operations) - error_count
            if success_count > 0:
                self.logger.info(f"💾 成功保存 {success_count} 条新闻数据")

            return success_count

        except Exception as e:
            self.logger.error(f"❌ 保存新闻数据失败: {e}", exc_info=True)
            return 0

    def _standardize_news_data(
        self,
        news_data: Dict[str, Any],
        data_source: str,
        market: str,
        now: datetime
    ) -> Dict[str, Any]:
        
        symbol = news_data.get("symbol")
        symbols = news_data.get("symbols", [])
        
        if symbol and symbol not in symbols:
            symbols = [symbol] + symbols
        
        standardized = {
            "symbol": symbol,
            "full_symbol": self._get_full_symbol(symbol, market) if symbol else None,
            "market": market,
            "symbols": symbols,
            
            "title": news_data.get("title", ""),
            "content": news_data.get("content", ""),
            "summary": news_data.get("summary", ""),
            "url": news_data.get("url", ""),
            "source": news_data.get("source", ""),
            "author": news_data.get("author", ""),
            
            "publish_time": self._parse_datetime(news_data.get("publish_time")),
            
            "category": news_data.get("category", "general"),
            "sentiment": news_data.get("sentiment", "neutral"),
            "sentiment_score": self._safe_float(news_data.get("sentiment_score")),
            "keywords": news_data.get("keywords", []),
            "importance": news_data.get("importance", "medium"),

            "data_source": data_source,
            "created_at": now,
            "updated_at": now,
            "version": 1
        }
        
        return standardized
    
    def _get_full_symbol(self, symbol: str, market: str) -> str:
        if not symbol:
            return None
        from app.data.schema.base.markets import get_full_symbol
        return get_full_symbol(symbol, market or "CN")
    
    def _parse_datetime(self, dt_value) -> Optional[datetime]:
        if dt_value is None:
            return None
        
        if isinstance(dt_value, datetime):
            return dt_value
        
        if isinstance(dt_value, str):
            try:
                formats = [
                    "%Y-%m-%d %H:%M:%S",
                    "%Y-%m-%dT%H:%M:%S",
                    "%Y-%m-%dT%H:%M:%SZ",
                    "%Y-%m-%d",
                ]
                
                for fmt in formats:
                    try:
                        return datetime.strptime(dt_value, fmt)
                    except ValueError:
                        continue
                
                self.logger.warning(f"⚠️ 无法解析日期时间: {dt_value}")
                return now_utc()
                
            except Exception as e:
                logger.debug(f"解析新闻日期失败: {e}")
                return now_utc()

        return now_utc()
    
    def _safe_float(self, value) -> Optional[float]:
        if value is None:
            return None
        
        try:
            return float(value)
        except (ValueError, TypeError):
            return None
    
    async def query_news(self, params: NewsQueryParams) -> List[Dict[str, Any]]:

        try:
            self.logger.info("🔍 [query_news] 开始查询新闻数据")
            self.logger.info(f"   参数: symbol={params.symbol}, start_time={params.start_time}, end_time={params.end_time}, limit={params.limit}")

            query = {}

            if params.symbol:
                query["symbol"] = params.symbol
                self.logger.info(f"   添加查询条件: symbol={params.symbol}")

            if params.symbols:
                query["symbols"] = {"$in": params.symbols}
                self.logger.info(f"   添加查询条件: symbols in {params.symbols}")

            if params.start_time or params.end_time:
                time_query = {}
                if params.start_time:
                    time_query["$gte"] = params.start_time
                if params.end_time:
                    time_query["$lte"] = params.end_time
                query["publish_time"] = time_query
                self.logger.info(f"   添加查询条件: publish_time between {params.start_time} and {params.end_time}")

            if params.category:
                query["category"] = params.category
                self.logger.info(f"   添加查询条件: category={params.category}")

            if params.sentiment:
                query["sentiment"] = params.sentiment
                self.logger.info(f"   添加查询条件: sentiment={params.sentiment}")

            if params.importance:
                query["importance"] = params.importance
                self.logger.info(f"   添加查询条件: importance={params.importance}")

            if params.data_source:
                query["data_source"] = params.data_source
                self.logger.info(f"   添加查询条件: data_source={params.data_source}")

            if params.keywords:
                query["$text"] = {"$search": " ".join(params.keywords)}
                self.logger.info(f"   添加查询条件: text search={params.keywords}")

            self.logger.info(f"   最终查询条件: {query}")

            from app.data.core.interface import DataInterface

            result = await DataInterface.get_instance().screen(
                "CN",
                "news",
                filters=query,
                sort=[(params.sort_by, params.sort_order)],
                skip=params.skip,
                limit=params.limit,
            )
            total_count = result.get("total", 0)
            self.logger.info(f"   数据库中符合条件的总记录数: {total_count}")

            results = result.get("items", [])
            self.logger.info(f"   查询返回: {len(results)} 条记录")

            results = convert_objectid_to_str(results)

            if results:
                self.logger.info("   前3条预览:")
                for i, r in enumerate(results[:3], 1):
                    self.logger.info(f"      {i}. symbol={r.get('symbol')}, title={r.get('title', 'N/A')[:50]}..., publish_time={r.get('publish_time')}")
            else:
                self.logger.debug("   ⚠️ 查询结果为空")

            self.logger.info(f"✅ [query_news] 查询完成，返回 {len(results)} 条记录")
            return results

        except Exception as e:
            self.logger.error(f"❌ 查询新闻数据失败: {e}", exc_info=True)
            return []
    
    async def get_latest_news(
        self,
        symbol: str = None,
        limit: int = 10,
        hours_back: int = 24
    ) -> List[Dict[str, Any]]:

        start_time = now_utc() - timedelta(hours=hours_back)
        
        params = NewsQueryParams(
            symbol=symbol,
            start_time=start_time,
            limit=limit,
            sort_by="publish_time",
            sort_order=-1
        )

        return await self.query_news(params)

_service_instance = None

async def get_news_data_service() -> NewsDataService:
    global _service_instance
    if _service_instance is None:
        _service_instance = NewsDataService()
        logger.info("✅ 新闻数据服务初始化成功")
    return _service_instance
