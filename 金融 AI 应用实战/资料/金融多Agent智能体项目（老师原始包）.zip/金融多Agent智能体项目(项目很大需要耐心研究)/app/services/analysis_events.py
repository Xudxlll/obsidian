import asyncio
import time
from typing import Any, Dict, List, Optional

import logging

logger = logging.getLogger("app.services.analysis_events")

EVENTS_COLLECTION = "analysis_events"

_active_sinks: Dict[str, Any] = {}

def get_active_sink(task_id: str):
    return _active_sinks.get(task_id)

def is_agent_running(task_id: str, agent_key: str) -> bool:
    sink = _active_sinks.get(task_id)
    return bool(sink) and sink.is_running(agent_key)

def running_agents(task_id: str) -> List[str]:
    sink = _active_sinks.get(task_id)
    return sink.running_agents if sink else []

def create_event_sink(task_id: str, server_loop=None, on_progress=None):

    from app.llm.events import EventSink
    from app.services.websocket_manager import get_websocket_manager

    ws_manager = get_websocket_manager()

    def _schedule(coro):
        if server_loop is not None and server_loop.is_running():
            fut = asyncio.run_coroutine_threadsafe(coro, server_loop)
            fut.add_done_callback(
                lambda f: (
                    logger.warning(f"⚠️ [analysis_events] 回调失败: {f.exception()}")
                    if f.exception()
                    else None
                )
            )
        else:
            async def _run():
                try:
                    await co
                except Exception as e:
                    logger.warning(f"⚠️ [analysis_events] 回调失败: {e}")

            co = coro
            try:
                asyncio.get_running_loop().create_task(_run())
            except RuntimeError:
                asyncio.run(co)

    def _on_event(ev) -> None:
        _schedule(ws_manager.send_progress_update(task_id, {"type": "agent_event", **ev.to_dict()}))

    def _on_persist(batch) -> None:
        _schedule(persist_events([e.to_dict() for e in batch]))

    sink = EventSink(
        task_id=task_id,
        on_event=_on_event,
        on_persist=_on_persist,
        on_progress=on_progress,
        persist_batch=20,
        persist_interval=2.0,
    )
    _active_sinks[task_id] = sink
    return sink

def release_event_sink(task_id: str, server_loop=None, timeout: float = 15.0) -> None:
    import asyncio as _asyncio

    sink = _active_sinks.pop(task_id, None)
    if sink is not None:
        try:
            if server_loop is not None and server_loop.is_running():
                fut = _asyncio.run_coroutine_threadsafe(sink.flush(), server_loop)
                fut.result(timeout=timeout)
            else:
                _asyncio.run(sink.flush())
        except Exception as e:
            logger.warning(f"⚠️ [analysis_events] flush 失败 task={task_id}: {e}")
    try:
        from app.llm.message_queue import message_queues

        message_queues.clear_task(task_id)
    except Exception:
        pass

async def persist_events(events: List[Dict[str, Any]]) -> None:
    if not events:
        return
    try:
        from app.core.database import get_mongo_db

        db = get_mongo_db()
        await db[EVENTS_COLLECTION].insert_many([dict(e) for e in events])
    except Exception as e:
        logger.warning(f"⚠️ [analysis_events] 落库失败（丢弃 {len(events)} 条）: {e}")

async def load_events(
    task_id: str,
    *,
    agent_key: Optional[str] = None,
    event_type: Optional[str] = None,
    after_seq: int = 0,
    limit: int = 500,
    before_seq: Optional[int] = None,
    order: str = "asc",
) -> List[Dict[str, Any]]:
    from app.core.database import get_mongo_db

    db = get_mongo_db()
    if order.lower() == "desc":
        seq_cond = {"$lt": before_seq} if before_seq is not None else {"$gte": 0}
        sort_dir = -1
    else:
        seq_cond = {"$gt": after_seq}
        sort_dir = 1
    query: Dict[str, Any] = {"task_id": task_id, "seq": seq_cond}
    if agent_key:
        query["agent_key"] = agent_key
    if event_type:
        query["event_type"] = event_type

    cursor = db[EVENTS_COLLECTION].find(query).sort("seq", sort_dir).limit(max(1, min(limit, 5000)))
    out: List[Dict[str, Any]] = []
    async for doc in cursor:
        doc.pop("_id", None)
        out.append(doc)
    return out

def enqueue_user_message(task_id: str, agent_key: str, text: str) -> bool:
    if not is_agent_running(task_id, agent_key):
        return False
    from app.llm.message_queue import message_queues

    message_queues.enqueue(task_id, agent_key, text)
    return True

def utc_now() -> float:
    return time.time()
