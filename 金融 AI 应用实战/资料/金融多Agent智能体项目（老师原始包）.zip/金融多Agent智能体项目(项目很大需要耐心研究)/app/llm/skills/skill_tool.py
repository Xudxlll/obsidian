from typing import List, Optional

import logging

from ..core.types import ToolDef
from .loader import SkillStore

logger = logging.getLogger("app.llm.skills")

SKILL_TOOL_NAME = "skill"

def make_skill_tool(store: Optional[SkillStore] = None, skill_dirs: Optional[List[str]] = None) -> ToolDef:

    _store = store or SkillStore(skill_dirs)

    async def skill(skill: str, args: str = "") -> str:
        result = _store.expand_skill(skill, args)
        logger.info(f"📚 [skill] 展开 {skill} ({len(result)} 字符)")
        return result

    return ToolDef(
        name=SKILL_TOOL_NAME,
        description=(
            "加载并展开一个 skill 的完整指令。先从清单中选择合适的 skill 名，"
            "调用本工具获取其完整指令后按指令执行。args 为传给 skill 的参数文本。"
        ),
        params_schema={
            "type": "object",
            "properties": {
                "skill": {"type": "string", "description": "skill 名称（来自清单）"},
                "args": {"type": "string", "description": "传给 skill 的参数（可选）"},
            },
            "required": ["skill"],
        },
        handler=skill,
        is_concurrency_safe=True,
    )
