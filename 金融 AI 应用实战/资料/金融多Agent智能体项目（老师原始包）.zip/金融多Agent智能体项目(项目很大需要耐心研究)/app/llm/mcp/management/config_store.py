import json
import logging
import os
import platform
import shutil
from contextlib import nullcontext
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from app.core.env import get_env

try:
    from filelock import FileLock
except Exception:
    FileLock = None

try:
    from pydantic import BaseModel, Field, field_validator, model_validator
    PYDANTIC_V2 = True
except ImportError:
    from pydantic import BaseModel, Field, validator as field_validator, root_validator as model_validator
    PYDANTIC_V2 = False

logger = logging.getLogger(__name__)

class MCPServerType(str, Enum):
    STDIO = "stdio"
    HTTP = "http"
    STREAMABLE_HTTP = "streamable-http"
    SSE = "sse"

BASE_CONFIG_DIR = Path(__file__).resolve().parents[3] / "config"

_env_config_path = get_env("MCP_CONFIG_PATH")
DEFAULT_CONFIG_FILE = Path(_env_config_path) if _env_config_path else BASE_CONFIG_DIR / "mcp.json"

def _safe_is_relative_to(path: Path, base: Path) -> bool:
    try:
        path.resolve().relative_to(base.resolve())
        return True
    except Exception as e:
        logger.debug(f"路径相对检查失败: {path} vs {base}: {e}")
        return False

def _allowed_commands() -> set:
    env_value = get_env("MCP_ALLOWED_COMMANDS", "")
    return {c.strip() for c in env_value.split(",") if c.strip()}

def _allowed_roots() -> List[Path]:
    env_value = get_env("MCP_ALLOWED_ROOTS", "")
    roots: List[Path] = []
    for part in env_value.split(os.pathsep):
        if part.strip():
            roots.append(Path(part).expanduser().resolve())
    roots.append(BASE_CONFIG_DIR.resolve())
    return roots

_IS_WINDOWS = platform.system() == "Windows"

_COMMAND_FALLBACKS: Dict[str, List[str]] = {
    "uvx": ["uv", "uvx"],
    "npx": ["npx", "npx.cmd", "npm"],
}

_RESOLVED_COMMAND_CACHE: Dict[str, Optional[str]] = {}

def resolve_command(command: str) -> Tuple[str, Optional[str]]:

    if not command:
        return command, "命令为空"

    if Path(command).is_absolute():
        if os.path.isfile(command):
            return command, None
        return command, f"绝对路径命令不存在: {command}"

    cmd_name = Path(command).name

    if cmd_name in _RESOLVED_COMMAND_CACHE:
        cached = _RESOLVED_COMMAND_CACHE[cmd_name]
        if cached is not None:
            return cached, None
        return command, f"命令 '{cmd_name}' 未找到（已缓存）"

    resolved = shutil.which(command)
    if resolved:
        _RESOLVED_COMMAND_CACHE[cmd_name] = resolved
        logger.debug("[MCP] 命令解析: %s -> %s", command, resolved)
        return resolved, None

    fallbacks = _COMMAND_FALLBACKS.get(cmd_name, [])
    for fb in fallbacks:
        if fb == command:
            continue
        fb_resolved = shutil.which(fb)
        if fb_resolved:
            _RESOLVED_COMMAND_CACHE[cmd_name] = fb_resolved
            logger.info("[MCP] 命令回退: %s -> %s (%s)", command, fb, fb_resolved)
            return fb_resolved, None

    if cmd_name == "uvx":
        _RESOLVED_COMMAND_CACHE[cmd_name] = None
        msg = (
            f"命令 '{command}' 未找到。"
            "请安装 uv: pip install uv 或 https://docs.astral.sh/uv/getting-started/installation/"
        )
        return command, msg

    if cmd_name == "npx":
        _RESOLVED_COMMAND_CACHE[cmd_name] = None
        msg = (
            f"命令 '{command}' 未找到。"
            "请安装 Node.js: https://nodejs.org/"
        )
        return command, msg

    _RESOLVED_COMMAND_CACHE[cmd_name] = None
    return command, f"命令 '{command}' 未找到，请确认已安装并添加到 PATH"

def check_command_available(command: str) -> Tuple[bool, Optional[str]]:

    if not command:
        return False, "命令为空"

    resolved = shutil.which(command)
    if resolved:
        return True, None

    cmd_name = Path(command).name
    fallbacks = _COMMAND_FALLBACKS.get(cmd_name, [])
    for fb in fallbacks:
        if shutil.which(fb):
            return True, None

    return False, f"命令 '{command}' 未找到，请确认已安装并添加到 PATH"

def clear_command_cache() -> None:
    _RESOLVED_COMMAND_CACHE.clear()

class HealthCheckConfig(BaseModel):
    enabled: bool = Field(default=True, description="是否启用健康检查")
    interval: int = Field(default=60, ge=10, le=3600, description="检查间隔（秒）")
    timeout: int = Field(default=10, ge=1, le=60, description="超时时间（秒）")

class MCPServerConfig(BaseModel):

    type: MCPServerType = Field(default=MCPServerType.STDIO, description="服务器类型")
    command: Optional[str] = Field(default=None, min_length=1, max_length=256, description="可执行程序路径或名称")
    args: List[str] = Field(default_factory=list, max_length=32)
    env: Dict[str, str] = Field(default_factory=dict)
    deps: List[str] = Field(default_factory=list, max_length=64, description="stdio 服务器运行所需的 Python 依赖（如 'pandas>=2.0'），由运行时安装到容器环境")
    url: Optional[str] = Field(default=None, max_length=2048, description="HTTP 服务器 URL")
    headers: Dict[str, str] = Field(default_factory=dict, description="HTTP 请求头")
    description: Optional[str] = Field(default=None, max_length=500)
    enabled: bool = Field(default=True, alias="_enabled", description="内部启用标记")
    healthCheck: Optional[HealthCheckConfig] = Field(default=None, description="健康检查配置")

    model_config = {"extra": "ignore", "populate_by_name": True, "use_enum_values": True}

    @field_validator("command", mode="before")
    @classmethod
    def _validate_command(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return None
        value = value.strip()
        if any(ch in value for ch in ("\n", "\r", "\t")):
            raise ValueError("command 含有非法控制字符")

        allowed_commands = _allowed_commands()
        command_path = Path(value).expanduser()

        if allowed_commands:
            if command_path.name not in allowed_commands and value not in allowed_commands:
                raise ValueError("command 不在允许列表中，请配置 MCP_ALLOWED_COMMANDS")
        else:
            if command_path.is_absolute():
                raise ValueError("未配置 MCP_ALLOWED_COMMANDS 时禁止使用绝对路径 command")

        if command_path.is_absolute():
            roots = _allowed_roots()
            if not any(_safe_is_relative_to(command_path, root) for root in roots):
                raise ValueError("command 不在允许的根目录下")

        return value

    @field_validator("url", mode="before")
    @classmethod
    def _validate_url(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return None
        value = value.strip()
        if not value.startswith(("http://", "https://")):
            raise ValueError("url 必须以 http:// 或 https:// 开头")
        if len(value) > 2048:
            raise ValueError("url 过长")
        return value

    @field_validator("headers", mode="before")
    @classmethod
    def _validate_headers(cls, value: Dict[str, Any]) -> Dict[str, str]:
        if not value:
            return {}
        sanitized: Dict[str, str] = {}
        for k, v in value.items():
            if not isinstance(k, str):
                raise ValueError("headers key 必须为字符串")
            if len(k) > 128:
                raise ValueError("headers key 过长")
            sanitized[k] = "" if v is None else str(v)
        return sanitized

    @field_validator("args", mode="before")
    @classmethod
    def _validate_args(cls, value: List[str]) -> List[str]:
        if not value:
            return []
        _DANGEROUS_PREFIXES = ("-c", "--eval", "--")
        result = []
        for item in value:
            if not isinstance(item, str):
                raise ValueError("args 必须为字符串列表")
            if len(item) > 512:
                raise ValueError("单个参数过长")
            if any(item == p or item.startswith(p + " ") for p in _DANGEROUS_PREFIXES):
                raise ValueError(f"args 含有危险旗标: {item}")
            result.append(item)
        return result

    @field_validator("deps", mode="before")
    @classmethod
    def _validate_deps(cls, value: List[str]) -> List[str]:
        from app.core.package_install import validate_package_spec

        if not value:
            return []
        result = []
        for item in value:
            if not isinstance(item, str):
                raise ValueError("deps 必须为字符串列表")
            package, _, version = item.strip().partition("==")
            if version == "":
                for op in (">=", "<=", "!=", "~=", "==", ">", "<"):
                    if op in package:
                        package, _, version = package.partition(op)
                        break
            validate_package_spec(package.strip(), version.strip())
            result.append(item.strip())
        return result

    @field_validator("env", mode="before")
    @classmethod
    def _validate_env(cls, value: Dict[str, Any]) -> Dict[str, str]:
        if not value:
            return {}
        sanitized: Dict[str, str] = {}
        for k, v in value.items():
            if not isinstance(k, str):
                raise ValueError("env key 必须为字符串")
            if len(k) > 128:
                raise ValueError("env key 过长")
            sanitized[k] = "" if v is None else str(v)
        return sanitized

    @model_validator(mode="before")
    @classmethod
    def _ensure_enabled(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        if isinstance(values, dict):
            if "_enabled" not in values and "enabled" not in values:
                values["_enabled"] = True
        return values

    @model_validator(mode="after")
    def _validate_server_type(self) -> "MCPServerConfig":
        server_type = self.type
        if isinstance(server_type, str):
            server_type = MCPServerType(server_type)
        
        if server_type == MCPServerType.STDIO:
            if not self.command:
                raise ValueError("stdio 类型服务器需要 'command' 字段")
        elif server_type in (MCPServerType.HTTP, MCPServerType.STREAMABLE_HTTP, MCPServerType.SSE):
            if not self.url:
                raise ValueError("http/streamable-http/sse 类型服务器需要 'url' 字段")
        return self

    def sanitized(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "type": self.type if isinstance(self.type, str) else self.type.value,
            "description": self.description,
            "_enabled": bool(self.enabled),
        }
        
        if self.type == MCPServerType.STDIO or self.type == "stdio":
            result["command"] = self.command
            result["args"] = list(self.args)
            result["env"] = dict(self.env)
            if self.deps:
                result["deps"] = list(self.deps)
        elif (
            self.type in (MCPServerType.HTTP, MCPServerType.STREAMABLE_HTTP, MCPServerType.SSE)
            or self.type in ("http", "streamable-http", "sse")
        ):
            result["url"] = self.url
            result["headers"] = dict(self.headers)
        
        if self.healthCheck:
            result["healthCheck"] = {
                "enabled": self.healthCheck.enabled,
                "interval": self.healthCheck.interval,
                "timeout": self.healthCheck.timeout,
            }
        
        return result
    
    def is_stdio(self) -> bool:
        return self.type == MCPServerType.STDIO or self.type == "stdio"
    
    def is_http(self) -> bool:
        return self.type in (MCPServerType.HTTP, MCPServerType.STREAMABLE_HTTP, MCPServerType.SSE) or self.type in ("http", "streamable-http", "sse")
    
    def is_streamable_http(self) -> bool:
        return self.type == MCPServerType.STREAMABLE_HTTP or self.type == "streamable-http"

class MCPConfig(BaseModel):
    mcpServers: Dict[str, MCPServerConfig] = Field(default_factory=dict)

    model_config = {"extra": "ignore"}

def get_config_path(config_file: Optional[Path] = None) -> Path:
    path = Path(config_file) if config_file else DEFAULT_CONFIG_FILE
    return path

def validate_servers_map(
    servers: Dict[str, Any],
    *,
    strict: bool = False,
) -> Dict[str, Dict[str, Any]]:
    validated: Dict[str, Dict[str, Any]] = {}
    for name, raw in servers.items():
        try:
            model = MCPServerConfig(**raw)
            validated[name] = model.sanitized()
        except Exception as exc:
            logger.warning("[MCP] 无效配置已跳过 (%s): %s", name, exc)
            if strict:
                raise
    return validated

def load_mcp_config(config_file: Optional[Path] = None, *, strict: bool = False) -> Dict[str, Any]:
    path = get_config_path(config_file)
    if not path.exists():
        return {"mcpServers": {}}

    try:
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as exc:
        logger.error("[MCP] 读取配置失败: %s", exc)
        return {"mcpServers": {}}

    servers = data.get("mcpServers", {}) or {}
    validated = validate_servers_map(servers, strict=strict)
    return {"mcpServers": validated}

def merge_servers(
    current: Dict[str, Dict[str, Any]],
    incoming: Dict[str, Dict[str, Any]],
    *,
    strict: bool = True,
) -> Dict[str, Dict[str, Any]]:
    validated = validate_servers_map(incoming, strict=strict)
    merged = dict(current)
    for name, cfg in validated.items():
        cfg["_enabled"] = bool(current.get(name, {}).get("_enabled", cfg.get("_enabled", True)))
        merged[name] = cfg
    return merged

def _atomic_write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    with tmp_path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    os.replace(tmp_path, path)

def write_mcp_config(config: Dict[str, Any], config_file: Optional[Path] = None) -> None:
    path = get_config_path(config_file)
    payload = {"mcpServers": config.get("mcpServers", {})}
    lock_ctx = (
        FileLock(str(path) + ".lock")
        if FileLock is not None
        else nullcontext()
    )
    with lock_ctx:
        _atomic_write_json(path, payload)
