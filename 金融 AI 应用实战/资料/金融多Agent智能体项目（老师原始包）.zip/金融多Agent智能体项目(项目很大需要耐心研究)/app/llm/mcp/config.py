import json
import re
from dataclasses import dataclass, field
from typing import Dict, Optional

import logging

logger = logging.getLogger("app.llm.mcp")

_ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")

def expand_env(value: str) -> str:
    import os

    def _sub(m: "re.Match[str]") -> str:
        var = m.group(1)
        val = os.environ.get(var)
        if val is None:
            logger.warning(f"⚠️ [mcp] 环境变量 {var} 未定义，占位符保留原样")
            return m.group(0)
        return val

    return _ENV_PATTERN.sub(_sub, value)

@dataclass
class MCPServerConfig:
    name: str
    type: str = "stdio"
    command: Optional[str] = None
    args: list = field(default_factory=list)
    env: Dict[str, str] = field(default_factory=dict)
    url: Optional[str] = None
    headers: Dict[str, str] = field(default_factory=dict)

    @property
    def cache_key(self) -> str:
        return f"{self.name}:{json.dumps(self.__dict__, sort_keys=True, ensure_ascii=False)}"
