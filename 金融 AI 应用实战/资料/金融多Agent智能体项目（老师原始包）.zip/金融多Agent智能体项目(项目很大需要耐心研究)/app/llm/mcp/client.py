import asyncio
from contextlib import AsyncExitStack
from typing import Dict, Optional, Tuple

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

import logging

from .config import MCPServerConfig
from .management.config_store import resolve_command

logger = logging.getLogger("app.llm.mcp")

CONNECT_TIMEOUT = 30.0
LOCAL_CONNECT_CONCURRENCY = 3

class MCPManager:

    def __init__(self):
        self._stack: Optional[AsyncExitStack] = None
        self._sessions: Dict[str, Tuple[MCPServerConfig, ClientSession]] = {}
        self._connecting: Dict[str, asyncio.Lock] = {}
        self._local_semaphore = asyncio.Semaphore(LOCAL_CONNECT_CONCURRENCY)
        self._closed = False

    async def _ensure_stack(self) -> AsyncExitStack:
        if self._stack is None:
            self._stack = AsyncExitStack()
        return self._stack

    async def connect(self, cfg: MCPServerConfig) -> ClientSession:
        if self._closed:
            raise RuntimeError("MCPManager 已关闭")
        cached = self._sessions.get(cfg.name)
        if cached and cached[0].cache_key == cfg.cache_key:
            return cached[1]

        lock = self._connecting.setdefault(cfg.name, asyncio.Lock())
        async with lock:
            cached = self._sessions.get(cfg.name)
            if cached and cached[0].cache_key == cfg.cache_key:
                return cached[1]
            session = await self._connect_one(cfg)
            self._sessions[cfg.name] = (cfg, session)
            return session

    async def _connect_one(self, cfg: MCPServerConfig) -> ClientSession:
        stack = await self._ensure_stack()
        async with self._local_semaphore:
            try:
                async with asyncio.timeout(CONNECT_TIMEOUT):
                    if cfg.type in ("http", "streamable-http"):
                        session = await self._connect_http(stack, cfg)
                    elif cfg.type == "sse":
                        session = await self._connect_sse(stack, cfg)
                    else:
                        session = await self._connect_stdio(stack, cfg)
            except asyncio.TimeoutError:
                raise TimeoutError(f"MCP server '{cfg.name}' 连接超时({CONNECT_TIMEOUT}s)")
        logger.info(f"🔗 [mcp] 已连接 {cfg.name} ({cfg.type})")
        return session

    async def _connect_stdio(self, stack: AsyncExitStack, cfg: MCPServerConfig) -> ClientSession:
        resolved, cmd_err = resolve_command(cfg.command or "")
        if cmd_err:
            raise RuntimeError(f"MCP server '{cfg.name}' 命令不可用: {cmd_err}")
        params = StdioServerParameters(command=resolved, args=cfg.args, env=cfg.env or None)
        read_stream, write_stream = await stack.enter_async_context(stdio_client(params))
        session = await stack.enter_async_context(ClientSession(read_stream, write_stream))
        await session.initialize()
        return session

    async def _connect_http(self, stack: AsyncExitStack, cfg: MCPServerConfig) -> ClientSession:
        from mcp.client.streamable_http import streamablehttp_client

        transport = await stack.enter_async_context(streamablehttp_client(cfg.url, headers=cfg.headers or None))
        read_stream, write_stream, _ = transport
        session = await stack.enter_async_context(ClientSession(read_stream, write_stream))
        await session.initialize()
        return session

    async def _connect_sse(self, stack: AsyncExitStack, cfg: MCPServerConfig) -> ClientSession:
        from mcp.client.sse import sse_client

        try:
            read_stream, write_stream = await stack.enter_async_context(
                sse_client(cfg.url, headers=cfg.headers or None)
            )
        except Exception as e:
            raise RuntimeError(
                f"MCP server '{cfg.name}' SSE 连接失败: {e}（旧版 SSE 传输，建议升级为 streamable-http）"
            ) from e
        session = await stack.enter_async_context(ClientSession(read_stream, write_stream))
        await session.initialize()
        return session

    async def get_session(self, cfg: MCPServerConfig) -> ClientSession:
        session = await self.connect(cfg)
        try:
            await asyncio.wait_for(session.send_ping(), timeout=10.0)
        except Exception as e:
            logger.warning(f"⚠️ [mcp] server '{cfg.name}' 会话失效({e})，尝试重连")
            self._sessions.pop(cfg.name, None)
            session = await self.connect(cfg)
        return session

    async def close_all(self) -> None:
        self._closed = True
        self._sessions.clear()
        if self._stack is not None:
            await self._stack.aclose()
            self._stack = None
        logger.info("[mcp] 全部连接已关闭")
