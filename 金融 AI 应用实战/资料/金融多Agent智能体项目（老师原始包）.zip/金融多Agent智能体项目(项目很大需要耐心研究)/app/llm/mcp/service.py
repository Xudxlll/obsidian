import threading
from typing import Any, Dict, List, Optional

import logging

from .client import MCPManager
from .config import MCPServerConfig as NewServerConfig
from .tools import mcp_tool_name

logger = logging = logging.getLogger("app.llm.mcp.service")

_manager: Optional[MCPManager] = None
_lock = threading.Lock()
_server_status: Dict[str, str] = {}

def get_shared_manager() -> MCPManager:
    global _manager
    if _manager is None:
        with _lock:
            if _manager is None:
                _manager = MCPManager()
    return _manager

def _load_old_config() -> Dict[str, Any]:
    from .management.config_store import load_mcp_config

    return load_mcp_config()

def enabled_server_configs() -> Dict[str, NewServerConfig]:
    result: Dict[str, NewServerConfig] = {}
    for name, old in _load_old_config().get("mcpServers", {}).items():
        raw = old.model_dump() if hasattr(old, "model_dump") else dict(old)
        if not getattr(old, "enabled", raw.get("_enabled", raw.get("enabled", True))):
            _server_status.setdefault(name, "stopped")
            continue
        stype = raw.get("type") or ("http" if raw.get("url") else "stdio")
        cfg = NewServerConfig(
            name=name,
            type=stype,
            command=raw.get("command"),
            args=list(raw.get("args") or []),
            env={k: str(v) for k, v in (raw.get("env") or {}).items()},
            url=raw.get("url"),
            headers={k: str(v) for k, v in (raw.get("headers") or {}).items()},
        )
        if cfg.type == "stdio" and not cfg.command:
            continue
        if cfg.type in ("http", "streamable-http", "sse") and not cfg.url:
            continue
        result[name] = cfg
    return result

async def startup() -> int:
    manager = get_shared_manager()
    connected = 0
    for name, cfg in enabled_server_configs().items():
        try:
            await manager.connect(cfg)
            _server_status[name] = "connected"
            connected += 1
        except Exception as e:
            _server_status[name] = "disconnected"
            logger.warning(f"⚠️ [mcp.service] server '{name}' 连接失败: {e}")
    logger.info(f"🔧 [mcp.service] 启动预热完成: {connected} 个 server 连接")
    return connected

async def shutdown() -> None:
    global _manager
    if _manager is not None:
        try:
            await _manager.close_all()
        except Exception as e:
            logger.warning(f"⚠️ [mcp.service] 关闭失败: {e}")
        _manager = None
        _server_status.clear()

async def list_tools() -> List[Dict[str, Any]]:
    manager = get_shared_manager()
    result: List[Dict[str, Any]] = []
    for name, cfg in enabled_server_configs().items():
        try:
            session = await manager.get_session(cfg)
            resp = await session.list_tools()
            _server_status[name] = "connected"
            for t in resp.tools:
                result.append(
                    {
                        "name": mcp_tool_name(name, t.name),
                        "originalName": t.name,
                        "description": t.description or "",
                        "serverName": name,
                        "available": True,
                        "status": "connected",
                        "inputSchema": getattr(t, "input_schema", None) or getattr(t, "inputSchema", None),
                    }
                )
        except Exception as e:
            _server_status[name] = "disconnected"
            logger.warning(f"⚠️ [mcp.service] server '{name}' 工具列举失败: {e}")
    return result

def get_server_status(name: str) -> str:
    return _server_status.get(name, "unknown")

async def ping_server(name: str) -> str:
    manager = get_shared_manager()
    cfg = enabled_server_configs().get(name)
    if cfg is None:
        return "stopped"
    try:
        await manager.get_session(cfg)
        _server_status[name] = "connected"
    except Exception:
        _server_status[name] = "disconnected"
    return _server_status[name]

def all_server_status() -> Dict[str, Dict[str, Any]]:
    return {name: {"status": s} for name, s in _server_status.items()}

from .task_manager import (
    TaskLevelMCPManager,
    get_task_mcp_manager,
    remove_task_mcp_manager,
    cleanup_all_managers,
    CircuitBreaker,
    RetryMechanism,
    CircuitState,
    CircuitBreakerConfig,
    RetryConfig,
)
