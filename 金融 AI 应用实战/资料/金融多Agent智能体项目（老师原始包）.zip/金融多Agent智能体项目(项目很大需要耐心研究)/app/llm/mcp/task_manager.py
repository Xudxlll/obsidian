import asyncio
import logging
import threading
import time
from dataclasses import dataclass
from typing import Dict, Set, Optional, Any, Callable
from enum import Enum

logger = logging.getLogger(__name__)

class CircuitState(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"

@dataclass
class CircuitBreakerConfig:
    failure_threshold: int = 3
    success_threshold: int = 2
    timeout: float = 60.0
    window_size: int = 10

@dataclass
class RetryConfig:
    max_attempts: int = 3
    base_delay: float = 1.0
    max_delay: float = 10.0
    exponential_base: float = 2.0

@dataclass
class ToolState:
    failure_count: int = 0
    last_failure_time: float = 0.0
    last_success_time: float = 0.0
    circuit_state: CircuitState = CircuitState.CLOSED
    total_calls: int = 0
    total_failures: int = 0

class CircuitBreaker:

    def __init__(self, config: CircuitBreakerConfig):
        self.config = config
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.last_state_change = time.time()
        self._lock: Optional[asyncio.Lock] = None

    async def _can_attempt(self) -> bool:
        now = time.time()

        if self.state == CircuitState.CLOSED:
            return True

        if self.state == CircuitState.OPEN:
            if now - self.last_state_change >= self.config.timeout:
                logger.info("断路器超时，进入半开状态")
                self.state = CircuitState.HALF_OPEN
                self.last_state_change = now
                self.success_count = 0
                return True
            return False

        if self.state == CircuitState.HALF_OPEN:
            return True

        return False

    def _ensure_lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    async def acquire(self) -> bool:
        async with self._ensure_lock():
            return await self._can_attempt()

    async def record_success(self):
        async with self._ensure_lock():
            now = time.time()

            if self.state == CircuitState.HALF_OPEN:
                self.success_count += 1
                if self.success_count >= self.config.success_threshold:
                    logger.info("断路器恢复，进入关闭状态")
                    self.state = CircuitState.CLOSED
                    self.failure_count = 0
            elif self.state == CircuitState.CLOSED:
                self.failure_count = 0

            self.last_state_change = now

    async def record_failure(self):
        async with self._ensure_lock():
            now = time.time()

            self.failure_count += 1

            if self.state == CircuitState.HALF_OPEN:
                logger.warning("半开状态失败，重新打开断路器")
                self.state = CircuitState.OPEN
                self.last_state_change = now
                self.success_count = 0
            elif self.failure_count >= self.config.failure_threshold:
                logger.warning(f"连续失败 {self.failure_count} 次，打开断路器")
                self.state = CircuitState.OPEN
                self.last_state_change = now

    def get_state(self) -> CircuitState:
        return self.state

class RetryMechanism:

    RETRYABLE_EXCEPTIONS = (
        ConnectionError,
        TimeoutError,
        asyncio.TimeoutError,
        OSError,
    )

    def __init__(self, config: RetryConfig):
        self.config = config

    def is_retryable(self, exception: Exception) -> bool:
        for exc_type in self.RETRYABLE_EXCEPTIONS:
            if isinstance(exception, exc_type):
                return True

        error_msg = str(exception).lower()
        retryable_keywords = [
            "timeout", "timed out",
            "connection", "connect",
            "network", "network unreachable",
            "temporary", "temporarily",
            "rate limit", "too many requests",
            "503", "502", "504",
        ]

        for keyword in retryable_keywords:
            if keyword in error_msg:
                return True

        return False

    def calculate_delay(self, attempt: int) -> float:
        delay = self.config.base_delay * (self.config.exponential_base ** (attempt - 1))
        return min(delay, self.config.max_delay)

    async def execute_with_retry(
        self,
        func: Callable,
        *args,
        **kwargs
    ) -> Any:
        last_exception = None

        for attempt in range(1, self.config.max_attempts + 1):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                last_exception = e

                if attempt >= self.config.max_attempts:
                    logger.warning(f"重试 {attempt}/{self.config.max_attempts} 次后仍失败: {e}")
                    break

                if not self.is_retryable(e):
                    logger.warning(f"不可重试的错误: {type(e).__name__}: {e}")
                    raise

                delay = self.calculate_delay(attempt)
                logger.info(f"可重试错误 ({attempt}/{self.config.max_attempts}): {e}, {delay:.1f}秒后重试")
                await asyncio.sleep(delay)

        raise last_exception

class TaskLevelMCPManager:

    def __init__(self, task_id: str):
        self.task_id = task_id
        self._tool_states: Dict[str, ToolState] = {}
        self._circuit_breakers: Dict[str, CircuitBreaker] = {}
        self._server_semaphores: Dict[str, asyncio.Semaphore] = {}
        self._failed_tools: Set[str] = set()
        self._retry_mechanism = RetryMechanism(RetryConfig())
        self._circuit_config = CircuitBreakerConfig()
        self._lock = threading.Lock()

        self._inflight_tasks: Set[asyncio.Task] = set()

        self._default_server_concurrency = 5

        logger.info(f"创建任务级 MCP 管理器: {task_id}")

    def _get_tool_key(self, tool_name: str, server_name: Optional[str] = None) -> str:
        if server_name:
            return f"{server_name}:{tool_name}"
        return tool_name

    def _get_server_name(self, tool_key: str) -> Optional[str]:
        if ":" in tool_key:
            return tool_key.split(":", 1)[0]
        return None

    def _get_tool_state(self, tool_key: str) -> ToolState:
        if tool_key not in self._tool_states:
            self._tool_states[tool_key] = ToolState()
        return self._tool_states[tool_key]

    def _get_circuit_breaker(self, tool_key: str) -> CircuitBreaker:
        if tool_key not in self._circuit_breakers:
            self._circuit_breakers[tool_key] = CircuitBreaker(self._circuit_config)
        return self._circuit_breakers[tool_key]

    def _try_get_tool_state(self, tool_key: str) -> ToolState | None:
        return self._tool_states.get(tool_key)

    def _try_get_circuit_breaker(self, tool_key: str) -> CircuitBreaker | None:
        return self._circuit_breakers.get(tool_key)

    def _get_server_semaphore(self, server_name: str) -> asyncio.Semaphore:
        if server_name not in self._server_semaphores:
            self._server_semaphores[server_name] = asyncio.Semaphore(self._default_server_concurrency)
        return self._server_semaphores[server_name]

    async def is_tool_available(self, tool_name: str, server_name: Optional[str] = None) -> bool:
        tool_key = self._get_tool_key(tool_name, server_name)

        if tool_key in self._failed_tools:
            return False

        circuit_breaker = self._try_get_circuit_breaker(tool_key)
        if circuit_breaker is None:
            return True
        return circuit_breaker.state != CircuitState.OPEN

    async def execute_tool(
        self,
        tool_name: str,
        func: Callable,
        *args,
        server_name: Optional[str] = None,
        **kwargs
    ) -> Any:

        tool_key = self._get_tool_key(tool_name, server_name)

        try:
            running_loop = asyncio.get_running_loop()
        except RuntimeError:
            running_loop = None

        if running_loop is None:
            return await self._execute_tool_inner(
                tool_name, func, *args,
                server_name=server_name, tool_key=tool_key, **kwargs
            )

        coro = self._execute_tool_inner(
            tool_name, func, *args,
            server_name=server_name, tool_key=tool_key, **kwargs
        )
        task = running_loop.create_task(coro, name=f"mcp_exec:{self.task_id}:{tool_name}")
        self._inflight_tasks.add(task)

        def _discard(t: asyncio.Task) -> None:
            self._inflight_tasks.discard(t)

        task.add_done_callback(_discard)
        try:
            return await task
        except asyncio.CancelledError:
            self._inflight_tasks.discard(task)
            raise

    async def _execute_tool_inner(
        self,
        tool_name: str,
        func: Callable,
        *args,
        server_name: Optional[str],
        tool_key: str,
        **kwargs
    ) -> Any:
        if not await self.is_tool_available(tool_name, server_name):
            logger.warning(f"工具 {tool_name} 在当前任务中已禁用")
            return {
                "status": "disabled",
                "message": f"工具 {tool_name} 在当前任务中已禁用（连续失败或断路器打开）",
                "tool_name": tool_name
            }

        circuit_breaker = self._get_circuit_breaker(tool_key)
        tool_state = self._get_tool_state(tool_key)

        if not await circuit_breaker.acquire():
            logger.warning(f"工具 {tool_name} 断路器拒绝调用")
            return {
                "status": "disabled",
                "message": f"工具 {tool_name} 断路器拒绝调用",
                "tool_name": tool_name
            }

        semaphore = None
        if server_name:
            semaphore = self._get_server_semaphore(server_name)

        acquired = False
        try:
            if semaphore:
                await semaphore.acquire()
                acquired = True

            tool_state.total_calls += 1

            result = await self._retry_mechanism.execute_with_retry(func, *args, **kwargs)

            await circuit_breaker.record_success()
            tool_state.last_success_time = time.time()
            tool_state.failure_count = 0

            if circuit_breaker.state == CircuitState.CLOSED and tool_key in self._failed_tools:
                with self._lock:
                    self._failed_tools.discard(tool_key)
                logger.info(f"工具 {tool_name} 断路器已恢复，重新启用工具")

            return result

        except Exception as e:
            await circuit_breaker.record_failure()
            tool_state.failure_count += 1
            tool_state.last_failure_time = time.time()
            tool_state.total_failures += 1

            if tool_state.failure_count >= self._circuit_config.failure_threshold:
                with self._lock:
                    self._failed_tools.add(tool_key)
                logger.error(f"工具 {tool_name} 连续失败 {tool_state.failure_count} 次，已在当前任务中禁用")

            return {
                "status": "error",
                "message": f"工具调用失败: {str(e)}",
                "tool_name": tool_name,
                "error_type": type(e).__name__
            }

        finally:
            if semaphore and acquired:
                semaphore.release()

    def get_tool_statistics(self, tool_name: str, server_name: Optional[str] = None) -> Dict[str, Any]:
        tool_key = self._get_tool_key(tool_name, server_name)
        tool_state = self._try_get_tool_state(tool_key)
        circuit_breaker = self._try_get_circuit_breaker(tool_key)

        if tool_state is None:
            return {
                "tool_name": tool_name,
                "server_name": server_name,
                "total_calls": 0,
                "total_failures": 0,
                "failure_count": 0,
                "circuit_state": CircuitState.CLOSED.value,
                "is_disabled": tool_key in self._failed_tools,
                "last_success_time": None,
                "last_failure_time": None,
            }

        return {
            "tool_name": tool_name,
            "server_name": server_name,
            "total_calls": tool_state.total_calls,
            "total_failures": tool_state.total_failures,
            "failure_count": tool_state.failure_count,
            "circuit_state": circuit_breaker.get_state().value if circuit_breaker else CircuitState.CLOSED.value,
            "is_disabled": tool_key in self._failed_tools,
            "last_success_time": tool_state.last_success_time,
            "last_failure_time": tool_state.last_failure_time,
        }

    def get_all_statistics(self) -> Dict[str, Dict[str, Any]]:
        return {
            tool_key: self.get_tool_statistics(
                tool_key.split(":", 1)[1] if ":" in tool_key else tool_key,
                self._get_server_name(tool_key)
            )
            for tool_key in self._tool_states.keys()
        }

    def to_dict(self) -> Dict[str, Any]:

        return {
            "task_id": self.task_id,
            "default_server_concurrency": self._default_server_concurrency,
            "circuit_breaker_config": {
                "failure_threshold": self._circuit_config.failure_threshold,
                "success_threshold": self._circuit_config.success_threshold,
                "timeout": self._circuit_config.timeout,
                "window_size": self._circuit_config.window_size
            },
            "retry_config": {
                "max_attempts": self._retry_mechanism.config.max_attempts,
                "base_delay": self._retry_mechanism.config.base_delay,
                "max_delay": self._retry_mechanism.config.max_delay,
                "exponential_base": self._retry_mechanism.config.exponential_base
            },
            "tool_states": {
                key: {
                    "failure_count": state.failure_count,
                    "last_failure_time": state.last_failure_time,
                    "last_success_time": state.last_success_time,
                    "total_calls": state.total_calls,
                    "total_failures": state.total_failures
                }
                for key, state in self._tool_states.items()
            },
            "failed_tools": list(self._failed_tools)
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TaskLevelMCPManager':

        task_id = data.get("task_id", "unknown")
        manager = cls(task_id)

        if "circuit_breaker_config" in data:
            config = data["circuit_breaker_config"]
            manager._circuit_config = CircuitBreakerConfig(
                failure_threshold=config.get("failure_threshold", 3),
                success_threshold=config.get("success_threshold", 2),
                timeout=config.get("timeout", 60.0),
                window_size=config.get("window_size", 10)
            )

        if "retry_config" in data:
            config = data["retry_config"]
            manager._retry_mechanism = RetryMechanism(RetryConfig(
                max_attempts=config.get("max_attempts", 3),
                base_delay=config.get("base_delay", 1.0),
                max_delay=config.get("max_delay", 10.0),
                exponential_base=config.get("exponential_base", 2.0)
            ))

        if "default_server_concurrency" in data:
            manager._default_server_concurrency = data["default_server_concurrency"]

        if "tool_states" in data:
            for key, state_data in data["tool_states"].items():
                manager._tool_states[key] = ToolState(
                    failure_count=state_data.get("failure_count", 0),
                    last_failure_time=state_data.get("last_failure_time", 0.0),
                    last_success_time=state_data.get("last_success_time", 0.0),
                    total_calls=state_data.get("total_calls", 0),
                    total_failures=state_data.get("total_failures", 0)
                )

        if "failed_tools" in data:
            manager._failed_tools = set(data["failed_tools"])

        return manager

    async def close(self) -> None:

        try:
            if self._inflight_tasks:
                inflight_snapshot = list(self._inflight_tasks)
                logger.debug(
                    f"TaskLevelMCPManager[{self.task_id}] close 等待 "
                    f"{len(inflight_snapshot)} 个 in-flight 任务收尾"
                )
                await asyncio.wait_for(
                    asyncio.gather(*inflight_snapshot, return_exceptions=True),
                    timeout=5.0,
                )
            self._tool_states.clear()
            self._circuit_breakers.clear()
            self._server_semaphores.clear()
            with self._lock:
                self._failed_tools.clear()
            logger.debug(f"TaskLevelMCPManager[{self.task_id}] 已关闭")
        except Exception as exc:
            logger.warning(
                f"TaskLevelMCPManager[{self.task_id}] close 异常: {exc}"
            )

from app.core.lru_cache import BoundedLRUCache

_pending_evict_tasks: set = set()

def _on_manager_evict(task_id: Any, manager: Any) -> None:

    try:
        loop = asyncio.get_running_loop()
        task = loop.create_task(manager.close())
        _pending_evict_tasks.add(task)
        task.add_done_callback(_pending_evict_tasks.discard)
    except RuntimeError:
        logger.debug(
            f"LRU evict task_id={task_id} 时无 running loop，跳过 close"
        )

_task_managers: BoundedLRUCache = BoundedLRUCache(
    maxsize=100, ttl=3600, name="task_mcp_managers", on_evict=_on_manager_evict,
)
_managers_lock: Optional[asyncio.Lock] = None
_managers_thread_lock = threading.Lock()

def _get_managers_async_lock() -> asyncio.Lock:

    global _managers_lock
    if _managers_lock is None:
        with _managers_thread_lock:
            if _managers_lock is None:
                _managers_lock = asyncio.Lock()
    return _managers_lock

def get_task_mcp_manager(task_id: str) -> TaskLevelMCPManager:
    with _managers_thread_lock:
        manager = _task_managers.get(task_id)
        if manager is None:
            manager = TaskLevelMCPManager(task_id)
            _task_managers.set(task_id, manager)
        return manager

async def remove_task_mcp_manager(task_id: str) -> None:
    async with _get_managers_async_lock():
        manager = _task_managers.get(task_id)
        if manager is not None:
            try:
                await manager.close()
            except Exception as exc:
                logger.warning(
                    f"remove_task_mcp_manager close 失败 task_id={task_id}: {exc}"
                )
            _task_managers.invalidate(task_id)
            logger.info(f"移除任务级 MCP 管理器: {task_id}")

async def cleanup_all_managers() -> None:
    async with _get_managers_async_lock():
        count = _task_managers.clear()
        logger.info(f"清理所有任务级 MCP 管理器: {count} 个")
