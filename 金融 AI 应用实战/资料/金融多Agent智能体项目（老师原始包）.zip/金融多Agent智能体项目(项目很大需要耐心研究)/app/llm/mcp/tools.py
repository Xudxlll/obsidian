import json
import re
from typing import Dict, List, Optional

from mcp import ClientSession

import logging

from ..core.types import ToolDef
from .client import MCPManager
from .config import MCPServerConfig

logger = logging.getLogger("app.llm.mcp")

TOOL_NAME_PREFIX = "mcp__"
MAX_DESCRIPTION_CHARS = 2048
MAX_TOOL_RESULT_CHARS = 100_000

_INVALID_CHARS = re.compile(r"[^a-zA-Z0-9_-]")

def mcp_tool_name(server: str, tool: str) -> str:
    return f"{TOOL_NAME_PREFIX}{_INVALID_CHARS.sub('_', server)}__{_INVALID_CHARS.sub('_', tool)}"

def _format_content(result, *, task_id: str = "") -> str:
    from ..tools.result_budget import apply_result_budget

    parts: List[str] = []
    for block in result.content or []:
        text = getattr(block, "text", None)
        if text:
            parts.append(text)
    structured = getattr(result, "structured_content", None) or getattr(result, "structuredContent", None)
    if not parts and structured:
        parts.append(json.dumps(structured, ensure_ascii=False))
    if not parts:
        return "(空结果)"
    return apply_result_budget("mcp_result", "\n".join(parts), task_id=task_id, max_chars=MAX_TOOL_RESULT_CHARS)

def make_mcp_tool_def(cfg: MCPServerConfig, manager: MCPManager, tool) -> ToolDef:
    display_name = mcp_tool_name(cfg.name, tool.name)
    desc = (tool.description or f"MCP tool '{tool.name}' from server '{cfg.name}'")[:MAX_DESCRIPTION_CHARS]

    async def _call(*call_args, **call_kwargs) -> str:
        payload = call_args[0] if call_args and isinstance(call_args[0], dict) else call_kwargs
        session: ClientSession = await manager.get_session(cfg)
        result = await session.call_tool(tool.name, arguments=payload or {})
        is_error = getattr(result, "is_error", None)
        if is_error is None:
            is_error = getattr(result, "isError", False)
        if is_error:
            return f"MCP 工具执行错误: {_format_content(result)}"
        return _format_content(result)

    annotations = getattr(tool, "annotations", None)
    read_only = bool(
        annotations
        and (
            getattr(annotations, "read_only_hint", None)
            if getattr(annotations, "read_only_hint", None) is not None
            else getattr(annotations, "readOnlyHint", False)
        )
    )

    return ToolDef(
        name=display_name,
        description=desc,
        params_schema=(
            getattr(tool, "input_schema", None)
            or getattr(tool, "inputSchema", None)
            or {"type": "object", "properties": {}}
        ),
        handler=_call,
        is_concurrency_safe=read_only,
    )

async def discover_mcp_tools(
    manager: Optional[MCPManager] = None,
    servers: Optional[Dict[str, MCPServerConfig]] = None,
    config_path: Optional[str] = None,
) -> List[ToolDef]:
    mgr = manager or MCPManager()
    if servers is None:
        from .service import enabled_server_configs

        servers = enabled_server_configs()
    cfgs = servers
    defs: List[ToolDef] = []
    for name, cfg in cfgs.items():
        try:
            session = await mgr.connect(cfg)
            listed = await session.list_tools()
        except Exception as e:
            logger.warning(f"⚠️ [mcp] server '{name}' 连接/发现失败: {e}")
            continue
        for tool in listed.tools:
            try:
                defs.append(make_mcp_tool_def(cfg, mgr, tool))
            except Exception as e:
                logger.warning(f"⚠️ [mcp] server '{name}' 工具 '{tool.name}' 包装失败: {e}")
        logger.info(f"[mcp] server '{name}' 发现 {len(listed.tools)} 个工具")
    return defs
