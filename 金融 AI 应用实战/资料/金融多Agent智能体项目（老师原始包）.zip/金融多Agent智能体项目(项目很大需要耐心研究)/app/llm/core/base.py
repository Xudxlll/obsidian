from abc import ABC, abstractmethod
from typing import AsyncIterator, List, Optional

from .types import ChatResponse, Message, ToolDef

class StreamEvent:

    __slots__ = ("type", "text", "response")

    def __init__(self, type_: str, text: str = "", response: Optional[ChatResponse] = None):
        self.type = type_
        self.text = text
        self.response = response

class BaseLLMClient(ABC):

    protocol: str = ""
    provider: str = ""

    @abstractmethod
    async def chat(
        self,
        messages: List[Message],
        *,
        system: Optional[str] = None,
        tools: Optional[List[ToolDef]] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        thinking_budget: Optional[int] = None,
        thinking_effort: Optional[str] = None,
        **kwargs,
    ) -> ChatResponse:
        pass

    @abstractmethod
    def chat_stream(
        self,
        messages: List[Message],
        *,
        system: Optional[str] = None,
        tools: Optional[List[ToolDef]] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        thinking_budget: Optional[int] = None,
        thinking_effort: Optional[str] = None,
        **kwargs,
    ) -> AsyncIterator[StreamEvent]:
        pass

    @abstractmethod
    async def count_tokens(self, messages: List[Message]) -> int:
        pass
