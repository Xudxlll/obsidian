class LLMError(Exception):

    def __init__(self, message: str, *, protocol: str = "", status_code: int | None = None):
        super().__init__(message)
        self.protocol = protocol
        self.status_code = status_code

class AuthError(LLMError):
    pass

class RateLimitError(LLMError):
    pass

class ContextWindowExceededError(LLMError):
    pass

class TimeoutError_(LLMError):
    pass

class ProtocolError(LLMError):
    pass
