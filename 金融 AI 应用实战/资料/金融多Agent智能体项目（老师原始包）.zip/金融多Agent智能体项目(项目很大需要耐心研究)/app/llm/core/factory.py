from typing import Optional

from ..config import LLMConfig, load_config
from .base import BaseLLMClient
from .errors import AuthError

VALID_PROTOCOLS = ("anthropic", "openai")

def create_client(
    protocol: str = "anthropic",
    *,
    model: Optional[str] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    config: Optional[LLMConfig] = None,
    max_tokens: Optional[int] = None,
    timeout: Optional[float] = None,
    temperature: Optional[float] = None,
    thinking_budget: Optional[int] = None,
    thinking_effort: Optional[str] = None,
    provider: Optional[str] = None,
) -> BaseLLMClient:

    if protocol not in VALID_PROTOCOLS:
        raise ValueError(f"未知协议: {protocol}，可选: {VALID_PROTOCOLS}")

    cfg = config or load_config()
    key = api_key or cfg.api_key
    if not key:
        raise AuthError("缺少 API key：请设置 ARK_API_KEY 或传入 api_key 参数", protocol=protocol)

    model = model or cfg.default_model

    if protocol == "anthropic":
        from ..protocols.anthropic_client import AnthropicLLMClient

        return AnthropicLLMClient(
            api_key=key,
            base_url=base_url or cfg.anthropic_base_url,
            model=model,
            timeout=timeout if timeout is not None else cfg.timeout,
            max_tokens=max_tokens if max_tokens is not None else cfg.max_tokens,
            temperature=temperature,
            thinking_budget=thinking_budget,
            thinking_effort=thinking_effort,
            provider=provider,
        )

    from ..protocols.openai_client import OpenAILLMClient

    return OpenAILLMClient(
        api_key=key,
        base_url=base_url or cfg.openai_base_url,
        model=model,
        timeout=timeout if timeout is not None else cfg.timeout,
        max_tokens=max_tokens if max_tokens is not None else cfg.max_tokens,
        temperature=temperature,
        thinking_budget=thinking_budget,
        thinking_effort=thinking_effort,
        provider=provider,
    )
