import asyncio
from dataclasses import dataclass
from typing import Awaitable, Callable, List, Sequence, TypeVar

import logging

from ..core.types import ToolUseBlock

logger = logging.getLogger("app.llm.orchestration")

MAX_TOOL_CONCURRENCY = 10

T = TypeVar("T")

@dataclass
class ToolBatch:

    items: List[ToolUseBlock]
    concurrent: bool

def _is_concurrency_safe(tu: ToolUseBlock, lookup: Callable[[str], bool]) -> bool:
    try:
        return bool(lookup(tu.name))
    except Exception:
        return False

def partition_tool_calls(
    tool_uses: Sequence[ToolUseBlock],
    lookup: Callable[[str], bool],
) -> List[ToolBatch]:
    batches: List[ToolBatch] = []
    for tu in tool_uses:
        safe = _is_concurrency_safe(tu, lookup)
        if safe and batches and batches[-1].concurrent and len(batches[-1].items) < MAX_TOOL_CONCURRENCY:
            batches[-1].items.append(tu)
        else:
            batches.append(ToolBatch(items=[tu], concurrent=safe))
    return batches

async def run_batches(
    batches: List[ToolBatch],
    executor: Callable[[ToolUseBlock], Awaitable[str]],
) -> List[str]:
    results: List[str] = []
    for batch in batches:
        if batch.concurrent and len(batch.items) > 1:
            batch_results = await asyncio.gather(*(executor(tu) for tu in batch.items))
            logger.info(f"⚡ [orchestration] 并发执行 {len(batch.items)} 个只读工具")
            results.extend(batch_results)
        else:
            for tu in batch.items:
                results.append(await executor(tu))
    return results
