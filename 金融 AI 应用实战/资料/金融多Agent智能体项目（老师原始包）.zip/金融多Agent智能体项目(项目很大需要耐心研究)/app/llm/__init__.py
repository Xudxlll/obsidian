from .config import LLMConfig, load_config
from .core.base import BaseLLMClient, StreamEvent
from .core.errors import (
    AuthError,
    ContextWindowExceededError,
    LLMError,
    ProtocolError,
    RateLimitError,
    TimeoutError_,
)
from .core.factory import create_client
from .core.types import (
    ChatResponse,
    Message,
    Role,
    StopReason,
    TextBlock,
    ToolDef,
    ToolResultBlock,
    ToolUseBlock,
    Usage,
)

__all__ = [
    "create_client",
    "load_config",
    "LLMConfig",
    "BaseLLMClient",
    "StreamEvent",
    "ChatResponse",
    "Message",
    "Role",
    "StopReason",
    "TextBlock",
    "ToolDef",
    "ToolResultBlock",
    "ToolUseBlock",
    "Usage",
    "LLMError",
    "AuthError",
    "RateLimitError",
    "ContextWindowExceededError",
    "ProtocolError",
    "TimeoutError_",
    "run_conversation",
    "tool_registry",
]

def __getattr__(name: str):
    if name == "run_conversation":
        from .runner import run_conversation

        return run_conversation
    if name == "tool_registry":
        from .tools.registry import tool_registry

        return tool_registry
    raise AttributeError(f"module 'app.llm' has no attribute '{name}'")
