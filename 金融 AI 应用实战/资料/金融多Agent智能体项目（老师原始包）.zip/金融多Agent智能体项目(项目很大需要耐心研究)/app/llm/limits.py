import os
from dataclasses import dataclass
from typing import Dict, Optional

from app.constants.llm_defaults import (
    DEFAULT_CONTEXT_WINDOW,
    DEFAULT_MAX_TOKENS,
    ESCALATED_MAX_TOKENS,
    MAX_TOKENS_MAX,
)
import logging

logger = logging.getLogger("app.llm")

_catalog_index: Dict[str, Dict[str, Optional[int]]] = {}

def set_catalog_index(index: Dict[str, Dict[str, Optional[int]]]) -> None:
    global _catalog_index
    _catalog_index = dict(index or {})

def get_catalog_index() -> Dict[str, Dict[str, Optional[int]]]:
    return _catalog_index

def _env_default_max_tokens() -> Optional[int]:
    raw = os.getenv("LLM_DEFAULT_MAX_TOKENS", "").strip()
    if not raw:
        return None
    try:
        val = int(raw)
    except ValueError:
        logger.warning(f"⚠️ [limits] 环境变量 LLM_DEFAULT_MAX_TOKENS 非法: {raw!r}，忽略")
        return None
    if val < 1:
        return None
    return min(val, MAX_TOKENS_MAX)

@dataclass(frozen=True)
class OutputLimits:

    max_tokens: int
    upper_limit: int
    context_window: Optional[int]

def resolve_output_limits(
    model: str,
    provider: Optional[str] = None,
    *,
    db_max_tokens: Optional[int] = None,
    db_context_window: Optional[int] = None,
) -> OutputLimits:

    catalog = _lookup_catalog(model, provider)

    max_tokens = _first_positive(db_max_tokens, catalog.get("max_tokens"))
    if max_tokens is None:
        max_tokens = _env_default_max_tokens() or DEFAULT_MAX_TOKENS

    catalog_max = catalog.get("max_tokens")
    upper_base = max(ESCALATED_MAX_TOKENS, catalog_max) if catalog_max else ESCALATED_MAX_TOKENS
    upper_limit = min(upper_base, MAX_TOKENS_MAX)
    if max_tokens > upper_limit:
        upper_limit = min(max_tokens, MAX_TOKENS_MAX)

    context_window = _first_positive(db_context_window, catalog.get("context_length"))

    return OutputLimits(
        max_tokens=max_tokens,
        upper_limit=upper_limit,
        context_window=context_window,
    )

def fallback_context_window(limits: OutputLimits) -> int:
    return limits.context_window or DEFAULT_CONTEXT_WINDOW

def _lookup_catalog(
    model: str, provider: Optional[str]
) -> Dict[str, Optional[int]]:
    if not model or not _catalog_index:
        return {}
    if provider:
        hit = _catalog_index.get(f"{provider.strip().lower()}|{model}")
        if hit:
            return hit
    for key, value in _catalog_index.items():
        if key.split("|", 1)[-1] == model:
            return value
    return {}

def _first_positive(*values: Optional[int]) -> Optional[int]:
    for v in values:
        if isinstance(v, int) and v > 0:
            return v
    return None
