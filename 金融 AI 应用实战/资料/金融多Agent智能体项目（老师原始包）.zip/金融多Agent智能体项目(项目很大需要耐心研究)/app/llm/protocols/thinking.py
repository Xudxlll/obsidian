import logging
import re
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

_OPENAI_EFFORT = {
    "minimal": "minimal", "low": "low", "medium": "medium", "high": "high", "max": "xhigh",
}
_TRINARY_EFFORT = {
    "minimal": "low", "low": "low", "medium": "high", "high": "high", "max": "max",
}
_CTK_EFFORT = {
    "minimal": "low", "low": "low", "medium": "medium", "high": "high", "max": "high",
}
_CTK_EFFORT_QWEN38 = {
    "minimal": "low", "low": "low", "medium": "medium", "high": "xhigh", "max": "xhigh",
}
_OLLAMA_EFFORT = {
    "minimal": "low", "low": "low", "medium": "medium", "high": "high", "max": "high",
}
_ANTHROPIC_BUDGET = {
    "minimal": 1024, "low": 4096, "medium": 16384, "high": 32768, "max": 65536,
}

_QWEN38_PATTERN = re.compile(r"qwen\s*3\.8", re.IGNORECASE)

@dataclass(frozen=True)
class _Dialect:

    name: str
    providers: Tuple[str, ...]
    model_pattern: Optional["re.Pattern[str]"]
    builder: Any

def _build_openai(effort: str, model: str, budget: Optional[int]) -> Dict[str, Any]:
    if effort == "off":
        if re.match(r"^gpt-5", model, re.IGNORECASE):
            return {"reasoning_effort": "none"}
        logger.info(f"[thinking] o 系模型 {model} 不支持关闭思考，本次不注入参数")
        return {}
    return {"reasoning_effort": _OPENAI_EFFORT[effort]}

def _build_trinary(effort: str, model: str, budget: Optional[int]) -> Dict[str, Any]:
    if effort == "off":
        logger.info(f"[thinking] 模型 {model} 为仅思考模型，无法关闭，本次不注入参数")
        return {}
    return {"reasoning_effort": _TRINARY_EFFORT[effort]}

def _ctk_effort_value(effort: str, model: str) -> str:
    table = _CTK_EFFORT_QWEN38 if _QWEN38_PATTERN.search(model) else _CTK_EFFORT
    return table[effort]

def _build_vllm(effort: str, model: str, budget: Optional[int]) -> Dict[str, Any]:

    ctk: Dict[str, Any] = {}
    if effort == "off":
        ctk["enable_thinking"] = False
    else:
        ctk["reasoning_effort"] = _ctk_effort_value(effort, model)
    extra_body: Dict[str, Any] = {"chat_template_kwargs": ctk}
    if budget and budget > 0:
        extra_body["thinking_token_budget"] = budget
    return {"extra_body": extra_body}

def _build_llamacpp(effort: str, model: str, budget: Optional[int]) -> Dict[str, Any]:

    if budget:
        logger.info(f"[thinking] llama.cpp 预算须由服务端 --reasoning-budget 配置，请求级不注入 (budget={budget})")
    ctk: Dict[str, Any] = {}
    if effort == "off":
        ctk["enable_thinking"] = False
    else:
        ctk["reasoning_effort"] = _ctk_effort_value(effort, model)
    return {"extra_body": {"chat_template_kwargs": ctk}}

def _build_ollama(effort: str, model: str, budget: Optional[int]) -> Dict[str, Any]:

    if budget:
        logger.info(f"[thinking] Ollama /v1 不支持请求级思考预算，不注入 (budget={budget})")
    if effort == "off":
        logger.info("[thinking] Ollama /v1 不支持关闭思考（需用原生 API think 字段），本次不注入参数")
        return {}
    return {"reasoning_effort": _OLLAMA_EFFORT[effort]}

_DIALECTS: Tuple[_Dialect, ...] = (
    _Dialect(
        name="openai",
        providers=("openai",),
        model_pattern=re.compile(r"^(o[134](-mini|-preview)?\b|gpt-5)", re.IGNORECASE),
        builder=_build_openai,
    ),
    _Dialect(
        name="deepseek",
        providers=("deepseek",),
        model_pattern=re.compile(r"deepseek-(v4|v3\.[12]|r1|reasoner)", re.IGNORECASE),
        builder=_build_trinary,
    ),
    _Dialect(
        name="vllm",
        providers=("vllm",),
        model_pattern=None,
        builder=_build_vllm,
    ),
    _Dialect(
        name="llamacpp",
        providers=("llamacpp", "llama.cpp", "llama-cpp", "llama-server"),
        model_pattern=None,
        builder=_build_llamacpp,
    ),
    _Dialect(
        name="ollama",
        providers=("ollama",),
        model_pattern=None,
        builder=_build_ollama,
    ),
)

def _lookup_model(model: str) -> str:
    return (model or "").split("/")[-1].strip()

def detect_dialect(provider: Optional[str], model: str) -> Optional[_Dialect]:

    lookup = _lookup_model(model)
    prov = (provider or "").strip().lower()
    for dialect in _DIALECTS:
        if prov and prov in dialect.providers:
            if dialect.model_pattern is None or dialect.model_pattern.search(lookup):
                return dialect
            return None
    for dialect in _DIALECTS:
        if dialect.model_pattern is not None and dialect.model_pattern.search(lookup):
            return dialect
    return None

def resolve_anthropic_thinking_budget(
    effort: Optional[str], explicit_budget: Optional[int]
) -> Optional[int]:

    if explicit_budget and explicit_budget > 0:
        return explicit_budget
    return _ANTHROPIC_BUDGET.get(effort or "")

def build_openai_thinking_params(
    provider: Optional[str],
    model: str,
    effort: Optional[str],
    budget: Optional[int] = None,
) -> Dict[str, Any]:

    if not effort and not (budget and budget > 0):
        return {}
    dialect = detect_dialect(provider, model)
    if dialect is None:
        logger.info(
            f"[thinking] 模型 {model}（provider={provider or '未知'}）未匹配思考方言，"
            f"档位 {effort or '未设'}/预算 {budget or '未设'} 不注入参数"
        )
        return {}
    if not effort:
        if dialect.name == "vllm":
            return {"extra_body": {"thinking_token_budget": budget}}
        logger.info(f"[thinking] {dialect.name} 方言无请求级预算参数，仅预算配置不注入")
        return {}
    return dialect.builder(effort, _lookup_model(model), budget)

def merge_openai_thinking_params(
    params: Dict[str, Any],
    kwargs: Dict[str, Any],
    *,
    provider: Optional[str],
    model: str,
    effort: Optional[str],
    budget: Optional[int] = None,
) -> None:

    thinking = build_openai_thinking_params(provider, model, effort, budget)
    if not thinking:
        return
    extra_body = thinking.pop("extra_body", None)
    if extra_body:
        merged = {**(kwargs.get("extra_body") or {}), **extra_body}
        kwargs["extra_body"] = merged
    params.update(thinking)
