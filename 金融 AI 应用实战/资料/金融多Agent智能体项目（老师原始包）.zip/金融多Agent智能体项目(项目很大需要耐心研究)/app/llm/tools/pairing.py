from typing import List

from ..core.types import Message, Role, ToolResultBlock, ToolUseBlock

def ensure_pairing(messages: List[Message]) -> List[Message]:
    called_ids = set()
    answered_ids = set()
    for msg in messages:
        for b in msg.blocks():
            if isinstance(b, ToolUseBlock):
                called_ids.add(b.id)
            elif isinstance(b, ToolResultBlock):
                answered_ids.add(b.tool_use_id)

    orphans = called_ids - answered_ids
    stale = answered_ids - called_ids

    if not orphans and not stale:
        return messages

    fixed: List[Message] = []
    for msg in messages:
        if stale and msg.role == Role.USER:
            kept = [b for b in msg.blocks() if not (isinstance(b, ToolResultBlock) and b.tool_use_id in stale)]
            if kept:
                fixed.append(Message(role=msg.role, content=kept))
        else:
            fixed.append(msg)

    if orphans:
        synthetic = [
            ToolResultBlock(tool_use_id=oid, content="[工具调用被中断，无执行结果]", is_error=True)
            for oid in sorted(orphans)
        ]
        fixed.append(Message(role=Role.USER, content=synthetic))

    return fixed
