import re
import threading
from typing import Optional

import logging
from app.utils.runtime_paths import ensure_subdir

logger = logging.getLogger("app.llm.tools.result_budget")

DEFAULT_MAX_RESULT_CHARS = 30_000
PREVIEW_CHARS = 2_000
_UNSAFE = re.compile(r"[^a-zA-Z0-9_.-]")

_seq_lock = threading.Lock()
_seq_counter = 0

def _next_seq() -> int:
    global _seq_counter
    with _seq_lock:
        _seq_counter += 1
        return _seq_counter

def _safe_name(name: str) -> str:
    cleaned = _UNSAFE.sub("_", name)[:64]
    return cleaned or "tool"

def apply_result_budget(
    name: str,
    result: str,
    *,
    task_id: str = "",
    max_chars: Optional[int] = None,
) -> str:

    limit = max_chars if max_chars is not None else DEFAULT_MAX_RESULT_CHARS
    if len(result) <= limit:
        return result

    seq = _next_seq()
    scope = _safe_name(task_id or "adhoc")
    try:
        artifacts_dir = ensure_subdir(f"artifacts/tool-results/{scope}")
        path = artifacts_dir / f"{_safe_name(name)}-{seq}.txt"
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(result, encoding="utf-8")
        tmp.replace(path)
    except OSError as e:
        logger.warning(f"⚠️ [result_budget] {name} 落盘失败，退化为截断: {e}")
        return result[:PREVIEW_CHARS] + f"\n...[结果共 {len(result)} 字符，已截断（落盘失败）]"

    logger.info(f"📦 [result_budget] {name} 结果 {len(result)} 字符超限 {limit}，已落盘: {path}")
    return (
        f"{result[:PREVIEW_CHARS]}\n"
        f"...[结果共 {len(result)} 字符，已截断。完整结果已保存：{path}]"
    )
