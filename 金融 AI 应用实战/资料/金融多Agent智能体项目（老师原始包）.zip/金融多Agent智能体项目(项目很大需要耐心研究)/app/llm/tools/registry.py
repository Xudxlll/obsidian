import inspect
from typing import Any, Callable, Dict, List, Optional

import logging

from ..core.types import ToolDef

logger = logging.getLogger("app.llm.tools")

class ToolRegistry:

    def __init__(self) -> None:
        self._tools: Dict[str, ToolDef] = {}

    def register(
        self,
        fn: Optional[Callable] = None,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        params_schema: Optional[Dict[str, Any]] = None,
    ):

        def wrap(f: Callable) -> Callable:
            tool_name = name or f.__name__
            tool_def = ToolDef(
                name=tool_name,
                description=description or inspect.getdoc(f) or tool_name,
                params_schema=params_schema or self._infer_schema(f),
                handler=f,
            )
            self._tools[tool_name] = tool_def
            logger.debug(f"注册工具: {tool_name}")
            return f

        return wrap(fn) if fn is not None else wrap

    @staticmethod
    def _infer_schema(fn: Callable) -> Dict[str, Any]:
        sig = inspect.signature(fn)
        props: Dict[str, Any] = {}
        required: List[str] = []
        for pname, param in sig.parameters.items():
            if pname in ("self", "cls"):
                continue
            ann = param.annotation
            t = {"int": "integer", "float": "number", "bool": "boolean", "str": "string"}.get(
                getattr(ann, "__name__", ""), "string"
            )
            props[pname] = {"type": t}
            if param.default is inspect.Parameter.empty:
                required.append(pname)
        schema: Dict[str, Any] = {"type": "object", "properties": props}
        if required:
            schema["required"] = required
        return schema

    def get(self, name: str) -> Optional[ToolDef]:
        return self._tools.get(name)

    def defs(self) -> List[ToolDef]:
        return list(self._tools.values())

    def extend(self, defs: List[ToolDef]) -> None:

        for t in defs:
            self._tools[t.name] = t

    async def execute(self, name: str, tool_input: Dict[str, Any], *, task_id: str = "") -> str:

        from .result_budget import apply_result_budget

        tool = self._tools.get(name)
        if tool is None:
            return f"错误：未知工具 '{name}'"
        try:
            result = tool.handler(**tool_input)
            if inspect.isawaitable(result):
                result = await result
            return apply_result_budget(name, str(result), task_id=task_id)
        except Exception as e:
            logger.warning(f"工具 {name} 执行失败: {e}")
            return f"工具执行失败: {e}"

tool_registry = ToolRegistry()

@tool_registry.register(
    description="获取当前的 UTC 时间，格式为 ISO 8601。当用户询问当前时间、日期时使用。",
    params_schema={"type": "object", "properties": {}},
)
def get_current_time() -> str:
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).isoformat()
