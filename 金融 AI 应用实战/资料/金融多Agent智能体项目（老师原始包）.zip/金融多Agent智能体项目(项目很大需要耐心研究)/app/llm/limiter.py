import asyncio
import logging
import threading
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from typing import Dict, Optional

logger = logging.getLogger(__name__)

_WAIT_POOL = ThreadPoolExecutor(max_workers=32, thread_name_prefix="llm-limiter")

class ModelLimiter:

    def __init__(self, limit: int):
        self._limit = max(1, int(limit))
        self._inflight = 0
        self._lock = threading.Lock()
        self._waiters: deque = deque()
        self._pending_limit: Optional[int] = None

    @property
    def limit(self) -> int:
        with self._lock:
            return self._pending_limit if self._pending_limit is not None else self._limit

    def update_limit(self, new_limit: int) -> None:
        new_limit = max(1, int(new_limit))
        with self._lock:
            if new_limit >= self._limit and self._pending_limit is None:
                self._limit = new_limit
                self._wake_waiters_locked()
            elif new_limit < self._limit:
                self._pending_limit = new_limit

    def _wake_waiters_locked(self) -> int:
        woken = 0
        while self._waiters and self._inflight < self._limit:
            ev = self._waiters.popleft()
            self._inflight += 1
            ev.set()
            woken += 1
        if self._pending_limit is not None and not self._waiters and self._inflight <= self._pending_limit:
            self._limit = self._pending_limit
            self._pending_limit = None
        return woken

    def acquire_sync(self, timeout: Optional[float] = None) -> bool:
        with self._lock:
            if self._inflight < self._limit and not self._waiters:
                self._inflight += 1
                return True
            ev = threading.Event()
            self._waiters.append(ev)
        acquired = ev.wait(timeout)
        if acquired:
            return True
        if ev.is_set():
            return True
        with self._lock:
            try:
                self._waiters.remove(ev)
            except ValueError:
                pass
            else:
                return False
        return True

    def release(self) -> None:
        with self._lock:
            if self._waiters:
                ev = self._waiters.popleft()
                ev.set()
                return
            self._inflight = max(0, self._inflight - 1)
            self._wake_waiters_locked()

_LIMITERS: Dict[str, ModelLimiter] = {}
_GUARD = threading.Lock()

def get_limiter(key: str, limit: int) -> ModelLimiter:
    lim = max(1, int(limit))
    with _GUARD:
        m = _LIMITERS.get(key)
        if m is None:
            m = ModelLimiter(lim)
            _LIMITERS[key] = m
        elif lim != m.limit:
            m.update_limit(lim)
        return m

def get_inflight(key: str) -> Optional[int]:
    with _GUARD:
        m = _LIMITERS.get(key)
    return None if m is None else m._inflight

@asynccontextmanager
async def alimit(key: Optional[str], limit: Optional[int]):
    if not key or not limit or int(limit) <= 0:
        yield
        return
    limiter = get_limiter(key, int(limit))
    acquired_slot = False
    try:
        if limiter.acquire_sync(timeout=0):
            acquired_slot = True
        else:
            loop = asyncio.get_running_loop()
            acquired_slot = await loop.run_in_executor(_WAIT_POOL, limiter.acquire_sync, 600.0)
            if not acquired_slot:
                logger.warning(
                    f"⚠️ [limiter] key={key} acquire 超时（10min），兜底放行；"
                    f"疑似槽位泄漏，请检查 max_concurrency 配置"
                )
        yield
    finally:
        if acquired_slot:
            limiter.release()
