from dataclasses import dataclass, field
from typing import Dict, List, Optional

import logging

from .core.types import Message, Role

logger = logging.getLogger("app.llm.queue")

USER_MESSAGE_TEMPLATE = (
    "The user sent a new message while you were working:\n"
    "{text}\n\n"
    "IMPORTANT: After completing your current task, you MUST address the user's "
    "message above. Do not ignore it."
)

def wrap_user_message(text: str) -> str:
    return f"<system-reminder>\n{USER_MESSAGE_TEMPLATE.format(text=text)}\n</system-reminder>"

@dataclass
class QueuedMessage:
    text: str
    agent_key: str = ""
    priority: str = "next"
    pending: bool = field(default=True)

class MessageQueueManager:

    def __init__(self) -> None:
        self._queues: Dict[str, Dict[str, List[QueuedMessage]]] = {}

    def enqueue(self, task_id: str, agent_key: str, text: str, priority: str = "next") -> None:
        self._queues.setdefault(task_id, {}).setdefault(agent_key, []).append(
            QueuedMessage(text=text, agent_key=agent_key, priority=priority)
        )
        logger.info(f"📩 [queue] 用户消息入队 task={task_id} agent={agent_key}")

    def drain(self, task_id: str, agent_key: str) -> List[QueuedMessage]:
        msgs = self._queues.get(task_id, {}).pop(agent_key, [])
        return msgs

    def clear_task(self, task_id: str) -> None:
        self._queues.pop(task_id, None)

message_queues = MessageQueueManager()

def to_injected_messages(msgs: List[QueuedMessage]) -> List[Message]:
    return [Message(role=Role.USER, content=wrap_user_message(m.text)) for m in msgs]

class AgentMessageInbox:

    def __init__(self, task_id: str, agent_key: str, manager: Optional[MessageQueueManager] = None):
        self.task_id = task_id
        self.agent_key = agent_key
        self._manager = manager or message_queues

    def drain(self) -> List[Message]:
        msgs = self._manager.drain(self.task_id, self.agent_key)
        if msgs:
            logger.info(f"📩 [queue] 注入 {len(msgs)} 条用户消息到 {self.agent_key}")
        return to_injected_messages(msgs)

    async def drain_async(self) -> List[Message]:
        return self.drain()

__all__ = [
    "MessageQueueManager",
    "AgentMessageInbox",
    "message_queues",
    "to_injected_messages",
    "wrap_user_message",
    "QueuedMessage",
]
