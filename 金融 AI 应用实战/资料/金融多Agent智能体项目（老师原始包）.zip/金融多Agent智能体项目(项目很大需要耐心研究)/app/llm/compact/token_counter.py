from dataclasses import dataclass
from typing import List

from ..core.types import Message, ToolResultBlock, ToolUseBlock

def estimate_messages_tokens(messages: List[Message]) -> int:
    chars = 0
    for m in messages:
        for b in m.blocks():
            if isinstance(b, ToolUseBlock):
                import json

                chars += len(b.name) + len(json.dumps(b.input, ensure_ascii=False))
            elif isinstance(b, ToolResultBlock):
                chars += len(b.content)
            else:
                chars += len(getattr(b, "text", "") or "")
    return chars // 4

@dataclass
class TokenCounter:

    authoritative_input_tokens: int = 0
    authoritative_upto: int = 0

    def update_from_usage(self, input_tokens: int, messages_count: int) -> None:
        if input_tokens and messages_count >= self.authoritative_upto:
            self.authoritative_input_tokens = input_tokens
            self.authoritative_upto = messages_count

    def count(self, messages: List[Message]) -> int:
        if len(messages) <= self.authoritative_upto:
            return self.authoritative_input_tokens
        prefix = self.authoritative_input_tokens
        tail = messages[self.authoritative_upto :]
        return prefix + estimate_messages_tokens(tail)
