from dataclasses import dataclass
from typing import List, Optional, Tuple

from app.constants.llm_defaults import DEFAULT_CONTEXT_WINDOW, DEFAULT_MAX_TOKENS
import logging

from ..core.base import BaseLLMClient
from ..core.types import Message, Role, TextBlock, ToolResultBlock, ToolUseBlock
from .prompts import COMPACT_INSTRUCTIONS, COMPACT_SYSTEM_PROMPT, CONTINUATION_HEADER
from .token_counter import TokenCounter, estimate_messages_tokens

logger = logging.getLogger("app.llm.compact")

_OLD_RESULT_PLACEHOLDER = "[Old tool result content cleared]"

MAX_OUTPUT_TOKENS_FOR_SUMMARY = 20_000
PREDICTED_TURN_GROWTH = 15_000
MAX_CONSECUTIVE_FAILURES = 3

def _tiered_buffer(context_window: int) -> int:
    if context_window >= 800_000:
        return 50_000
    if context_window >= 400_000:
        return 30_000
    return 13_000

@dataclass
class CompactConfig:
    context_window: int = DEFAULT_CONTEXT_WINDOW
    max_output_tokens: int = DEFAULT_MAX_TOKENS
    buffer: Optional[int] = None
    keep_recent_turns: int = 4
    min_tool_results_to_clear: int = 2

    @property
    def effective_buffer(self) -> int:
        return self.buffer if self.buffer is not None else _tiered_buffer(self.context_window)

    @property
    def effective_window(self) -> int:
        return self.context_window - min(self.max_output_tokens, MAX_OUTPUT_TOKENS_FOR_SUMMARY)

    @property
    def threshold(self) -> int:
        return self.effective_window - self.effective_buffer

class AutoCompactor:

    def __init__(
        self,
        client: BaseLLMClient,
        counter: TokenCounter,
        config: Optional[CompactConfig] = None,
    ):
        self.client = client
        self.counter = counter
        self.config = config or CompactConfig()
        self.consecutive_failures = 0
        self.reactive_attempted = False

    def should_compact(self, messages: List[Message]) -> bool:
        if self.consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
            return False
        return self.counter.count(messages) >= self.config.threshold

    def should_compact_predictive(self, messages: List[Message]) -> bool:
        if self.consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
            return False
        output_reserve = min(self.config.max_output_tokens, MAX_OUTPUT_TOKENS_FOR_SUMMARY)
        projected = self.counter.count(messages) + output_reserve + PREDICTED_TURN_GROWTH
        return projected > self.config.effective_window

    def is_blocking(self, messages: List[Message]) -> bool:
        return self.counter.count(messages) >= self.config.effective_window - 3_000

    async def compact(self, messages: List[Message], system: Optional[str] = None) -> Tuple[List[Message], bool]:

        token_before = self.counter.count(messages)
        new_messages = self._microcompact(messages)
        if new_messages is not messages:
            token_after = estimate_messages_tokens(new_messages)
            logger.info(
                f"🧹 [compact] microcompact: {token_before} -> {token_after} tokens (阈值 {self.config.threshold})"
            )
            if token_after < self.config.threshold:
                self.counter = TokenCounter()
                return new_messages, False

        if self.consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
            logger.warning("⚠️ [compact] 熔断中：跳过自动 LLM 压缩")
            return messages, False

        try:
            summary = await self._summarize(messages, system)
        except Exception as e:
            self.consecutive_failures += 1
            logger.warning(f"⚠️ [compact] LLM 压缩失败({self.consecutive_failures}/{MAX_CONSECUTIVE_FAILURES}): {e}")
            return messages, False
        self.consecutive_failures = 0

        compacted: List[Message] = []
        if system:
            compacted.append(Message(role=Role.SYSTEM, content=system))
        compacted.append(
            Message(
                role=Role.USER,
                content=CONTINUATION_HEADER + summary,
            )
        )
        logger.info(f"📦 [compact] LLM compact 完成: {token_before} tokens -> 摘要 {len(summary)} 字符")
        self.counter = TokenCounter()
        return compacted, True

    async def reactive_compact(self, messages: List[Message], system: Optional[str] = None) -> List[Message]:
        if self.reactive_attempted:
            logger.warning("⚠️ [compact] reactive 已尝试过，不再重试")
            return messages
        self.reactive_attempted = True
        logger.warning("🔄 [compact] reactive compact：API 报告超窗，执行兜底压缩")
        new_messages, _ = await self.compact(messages, system)
        return new_messages

    def _microcompact(self, messages: List[Message]) -> List[Message]:
        turn_boundary = len(messages)
        turns_seen = 0
        for i in range(len(messages) - 1, -1, -1):
            if messages[i].role == Role.USER:
                turns_seen += 1
                if turns_seen > self.config.keep_recent_turns:
                    turn_boundary = i
                    break

        old_slice = messages[:turn_boundary]
        clearable = sum(1 for m in old_slice for b in m.blocks() if isinstance(b, ToolResultBlock))
        if clearable < self.config.min_tool_results_to_clear:
            return messages

        changed = False
        new_messages: List[Message] = []
        for i, m in enumerate(messages):
            if i < turn_boundary:
                blocks = []
                for b in m.blocks():
                    if isinstance(b, ToolResultBlock) and len(b.content) > len(_OLD_RESULT_PLACEHOLDER):
                        changed = True
                        blocks.append(
                            ToolResultBlock(
                                tool_use_id=b.tool_use_id,
                                content=_OLD_RESULT_PLACEHOLDER,
                                is_error=b.is_error,
                            )
                        )
                    else:
                        blocks.append(b)
                new_messages.append(Message(role=m.role, content=blocks))
            else:
                new_messages.append(m)
        return new_messages if changed else messages

    async def _summarize(self, messages: List[Message], system: Optional[str]) -> str:
        request_messages = list(messages)
        request_messages.append(Message(role=Role.USER, content=TextBlock(text=COMPACT_INSTRUCTIONS)))
        resp = await self.client.chat(
            request_messages,
            system=system or COMPACT_SYSTEM_PROMPT,
            tools=None,
            max_tokens=self.config.max_output_tokens,
        )
        summary = resp.text()
        if not summary:
            logger.warning("⚠️ [compact] 压缩摘要为空，退化为 microcompact 后的历史")
            summary = "（摘要生成失败，以下为末尾对话保留）\n" + self._tail_text(messages, 2000)
        return summary

    @staticmethod
    def _tail_text(messages: List[Message], max_chars: int) -> str:
        parts: List[str] = []
        total = 0
        for m in reversed(messages):
            for b in reversed(m.blocks()):
                if isinstance(b, (TextBlock, ToolUseBlock)):
                    text = getattr(b, "text", "") or str(getattr(b, "input", ""))
                    parts.append(text[:300])
                    total += min(len(text), 300)
                    if total >= max_chars:
                        return "\n".join(reversed(parts))
        return "\n".join(reversed(parts))
